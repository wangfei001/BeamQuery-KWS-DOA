# Copyright (c) 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
"""dynamic_query 模型的通用评测工具。

被 train.py（每轮评测）与 eval_dynamic_query.py（独立评测）共用，
保证两者指标口径完全一致。

核心函数：
  collect_predictions : 在 spatial list 上跑前向，收集 s_logits/真值（方向=argmax(s_q)）
  write_metrics       : 计算默认工作点指标 + 阈值扫描，写出 txt/csv
"""
import csv
import logging
import os

import torch
from torch.utils.data import DataLoader

from wekws.dataset.spatial_kws_dataset import SpatialKwsDataset, spatial_collate_fn
from wekws.utils.spatial_metrics import wake_detection_metrics

# 默认阈值扫描点（对 sigmoid 后的唤醒概率）
DEFAULT_SWEEP = [i / 10.0 for i in range(1, 10)]
NL = chr(10)


def collect_predictions(model, data_list, varcol_list, device,
                        batch_size=8, num_workers=0):
    """在给定 spatial list 上收集全部样本的预测与真值。

    Returns:
        s_logits   [N, Q]
        None       （方向由 argmax(s_logits) 给出，不再需要单独 DOA 输出）
        kws_label  [N]
        wake_angle [N]  (负样本为 -100)
    注意：函数会临时切到 eval 模式，结束后恢复原来的 train/eval 状态。
    """
    dataset = SpatialKwsDataset(data_list=data_list,
                                varcol_tmp_list=varcol_list,
                                max_gt=3)
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False,
                        num_workers=num_workers, collate_fn=spatial_collate_fn)
    s_list, kws_list, wake_list = [], [], []
    was_training = model.training
    model.eval()
    with torch.no_grad():
        for feat_list, gt_s, gt_doa, gt_valid_mask, kws_label, wake_angle_gt in loader:
            kws_label = kws_label.to(device)
            wake_angle_gt = wake_angle_gt.to(device)
            pred_s_list = []
            for f in feat_list:
                f = f.to(device).unsqueeze(0)  # [1, M, F, T]
                out = model(f)
                pred_s_list.append(out["s_q"])
            s_list.append(torch.cat(pred_s_list, dim=0).cpu())
            kws_list.append(kws_label.cpu())
            wake_list.append(wake_angle_gt.cpu())
    if was_training:
        model.train()
    return (torch.cat(s_list, dim=0), None,
            torch.cat(kws_list, dim=0), torch.cat(wake_list, dim=0))


def write_metrics(prefix, title, s_logits, doa_logits, kws_label, wake_angle,
                  prob_thr=0.5, thresholds=None, quiet=False):
    """输出默认工作点指标 + 阈值扫描表。

    Args:
        prefix: 输出文件前缀，生成 {prefix}.txt 与 {prefix}_sweep.csv
        doa_logits: 可传 None；本模型 direction = argmax(s_logits)
        title:  写入 txt 第一行的说明
    Returns:
        (default_metrics, sweep_rows) 两个 dict/list，便于调用方写 tensorboard
    """
    thresholds = thresholds if thresholds is not None else DEFAULT_SWEEP
    m = wake_detection_metrics(s_logits, doa_logits, kws_label, wake_angle,
                               prob_thr=prob_thr, compute_auc=True)
    rows = [wake_detection_metrics(s_logits, doa_logits, kws_label, wake_angle,
                                   prob_thr=t) for t in thresholds]

    os.makedirs(os.path.dirname(os.path.abspath(prefix)), exist_ok=True)
    lines = [
        "# " + title,
        "# samples: pos={n_pos}, neg={n_neg}".format(**m),
        "",
        "[prob_thr=%.2f]" % prob_thr,
        "  wake_auc(检测AUC)         = {wake_auc:.4f}".format(**m),
        "  wake_recall(唤醒率)       = {wake_recall:.4f}  (tp={tp}, fn={fn})".format(**m),
        "  fpr(虚警率)               = {fpr:.4f}  (fp={fp}, tn={tn})".format(**m),
        "  loc_acc_det(检出定位准确) = {loc_acc_det:.4f}  (检出正样本={n_det_pos})".format(**m),
        "  loc_acc_all(全正样本定位) = {loc_acc_all:.4f}".format(**m),
        "  mean_deg_err(平均角度误差)= {mean_deg_err:.2f} deg".format(**m),
        "",
    ]
    for r in rows:
        lines.append("thr={prob_thr:.1f}  wake_recall={wake_recall:.4f}  "
                     "fpr={fpr:.4f}  loc_acc_det={loc_acc_det:.4f}".format(**r))
    with open(prefix + ".txt", "w", encoding="utf-8") as f:
        f.write(NL.join(lines) + NL)
    with open(prefix + "_sweep.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for r in rows:
            writer.writerow(r)

    if not quiet:
        logging.info("eval %s: wake_recall=%.4f fpr=%.4f loc_acc_det=%.4f "
                     "loc_acc_all=%.4f mean_deg_err=%.2f",
                     os.path.basename(prefix), m["wake_recall"], m["fpr"],
                     m["loc_acc_det"], m["loc_acc_all"], m["mean_deg_err"])
    return m, rows
