# Copyright (c) 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
"""房间冲激响应(RIR)仿真：镜像法(image-source method)。

为什么要换掉旧实现
------------------
stage5 早期版本的"RIR"是**自由场直达声冲激**：每个通道只有 2 个非零抽头
(分数延时插值)，等价于一条纯时延线，不含任何墙面反射。在这种数据上
GCC-PHAT / 延迟求和几乎可以精确恢复角度、通道间 coherence 恒为 1，
无法支撑"模型学到了鲁棒空间表示"这类结论。

本模块用 pyroomacoustics 的镜像法生成**真正的房间 RIR**：含墙面反射、
可控混响时间(T60)、距离衰减，可选散射/空气吸收/预设材料(频带吸声)。

与模型端的约定必须严格一致
--------------------------
阵列沿房间某一坐标轴摆放，第 m 个麦克风位置为

    p_m = center + (m - (M-1)/2) * spacing * e_axis

模型端 wekws/model/spatial_dynamic_query.py 的空间假设是

    tau_m = (p_m - center) · e_axis * cos(theta) / c

即"第 m 个麦克风的到达时延 = 其轴向坐标 * cos(theta) / c"。
声源方向单位向量 u = (P - center)/|P - center| 必须满足

    u · e_axis = -cos(theta)

因为声源到 p_m 的距离 ≈ D - (p_m-center)·e_axis * (u·e_axis)，时延正比于
-(u·e_axis)。(theta=0 → 声源在 -e_axis 端射方向；theta=90 → 正侧向；
theta=180 → +e_axis 端射方向。)

`direction_for_theta()` 严格按该式构造方向；`tools/check_room_rir.py`
会数值校验"测量 TDOA == 解析式"，`tools/gen_multi_channel_wav.py` 使用
同一实现生成数据。

pyroomacoustics 的两个实现细节(已在本模块中处理)
------------------------------------------------
1. 分数延时滤波器：pra 用 81 抽头滤波器插值亚样本时延(常数
   frac_delay_length=81)，给**所有**通道加恒定 40 样本群延时。该延时是共模的，
   不影响通道间相对时延(DOA)，但直达声峰位比几何距离晚 40 个样本。
2. Sabine 公式偏差：Sabine 假设扩散声场，直接按公式反解吸声系数时，
   实测 T60 会比目标长 20%~40%(吸声越小偏差越大)。本模块默认用二分法
   对"实测 T60"标定吸声系数，保证报告的 T60 是真值。
"""
from __future__ import annotations

import math
import os
import sys
from dataclasses import dataclass
from typing import Dict, Optional, Sequence, Tuple

import numpy as np

SPEED_OF_SOUND = 340.0  # 与模型端 speed_sound 默认值保持一致

# pyroomacoustics 分数延时滤波器(GROUP DELAY)相关常数
PRA_FRAC_DELAY_LENGTH = 81
PRA_GROUP_DELAY_SAMPLES = (PRA_FRAC_DELAY_LENGTH - 1) // 2

try:  # pyroomacoustics 后端
    import pyroomacoustics as pra
except ImportError:  # pragma: no cover
    pra = None

try:  # Habets RIR-Generator 后端(原作者脚本使用的 rir_generator)
    import rir_generator
    HAS_RIR_GENERATOR = True
except ImportError:  # pragma: no cover
    rir_generator = None
    HAS_RIR_GENERATOR = False


def has_pyroomacoustics() -> bool:
    return pra is not None


def has_rir_generator() -> bool:
    return HAS_RIR_GENERATOR


def load_roomsimove(path: Optional[str] = None):
    """导入 roomsimove_single(必要时把其所在目录加入 sys.path)。"""
    if path:
        p = os.path.expanduser(str(path))
        if os.path.isdir(p) and p not in sys.path:
            sys.path.insert(0, p)
    try:
        import roomsimove_single  # noqa: F401
        return roomsimove_single
    except Exception:
        return None


def has_roomsimove(path: Optional[str] = None) -> bool:
    return load_roomsimove(path) is not None


def require_roomsimove(path: Optional[str] = None):
    rs = load_roomsimove(path)
    if rs is None:
        raise ImportError(
            "backend=roomsimove 需要 roomsimove_single.py(及其依赖 olafilt.py/"
            "utils.py)，请设置 data_gen.room_rir.roomsimove_path 指向其所在目录，"
            "或把该目录加入 PYTHONPATH。")
    return rs


def require_rir_generator():
    if not HAS_RIR_GENERATOR:
        raise ImportError(
            "backend=rir_generator 需要 rir-generator，请先安装:\n"
            "    pip install rir-generator")


def require_pyroomacoustics():
    if pra is None:
        raise ImportError(
            "rir_mode=room 需要 pyroomacoustics，请先安装:\n"
            "    pip install pyroomacoustics\n"
            "若只想复现旧的自由场直达声数据，可用 rir_mode=direct。"
        )


# ======================================================================
# 配置
# ======================================================================
@dataclass
class RoomRirConfig:
    """房间/阵列/声源几何配置(对应 conf/*.yaml 的 data_gen 字段)。

    坐标单位统一为米，`room_dim` 为鞋盒房间 [长, 宽, 高]。
    """
    # 后端: pyroomacoustics | rir_generator(Habets) | roomsimove(Roomsimove 3.3)
    backend: str = "pyroomacoustics"
    room_dim: Tuple[float, float, float] = (5.0, 4.0, 2.8)
    # 阵列中心；None → 取房间几何中心(保证 0~180° 各方向都在房间内)
    array_center: Optional[Tuple[float, float, float]] = None
    # 阵列轴向(麦间距沿该轴)：x | y | z
    array_axis: str = "x"
    # 目标混响时间(秒)；wall_material=None 时反解并标定墙面吸声系数
    t60: float = 0.4
    # 预设材料名(pyroomacoustics 吸声表，如 plasterboard/glass_3mm/carpet_thin)；
    # 指定后吸声频带相关，此时 t60 只用于确定 max_order，不做标定
    wall_material: Optional[str] = None
    # 散射系数(0=纯镜面反射)
    scattering: float = 0.0
    # 镜像法最高阶数；None → 由混响时间自动估计
    max_order: Optional[int] = None
    # 是否计入空气吸收
    air_absorption: bool = False
    # 声源到阵列中心的距离范围(米)
    source_distance_range: Tuple[float, float] = (0.8, 1.5)
    # 多条件 T60 范围(秒)：数据生成端会按 t60_grid 离散后逐条随机取；
    # None → 只用 t60。原作者脚本为 rt60 = 0.1 + 0.19*rand
    t60_range: Optional[Tuple[float, float]] = None
    t60_grid: int = 8
    # 声源垂直偏移(米)：标量 h → U(-h, +h)；[lo, hi] → U(lo, hi)
    height_jitter: float = 0.15
    # 声源半平面：both | + | -  (取垂直轴向的第一个垂直坐标，axis=x 时为 y)
    half_plane: str = "both"
    # 声速，需与模型端 speed_sound 一致
    speed_sound: float = SPEED_OF_SOUND
    # RIR 固定长度(样本数)；None → 保留 pyroomacoustics 输出长度
    rir_len: Optional[int] = None
    # RIR 缓存量化粒度：距离/高度按该粒度取整，提高缓存命中率
    cache_quant_distance: float = 0.05
    cache_quant_height: float = 0.05
    cache_size: int = 4096
    # 是否二分标定吸声系数(使实测 T60 命中 t60)，仅 wall_material=None 时生效
    calibrate: bool = True
    # 标定用的声源距离(米)
    calib_distance: float = 1.2

    # ---- rir_generator(Habets) 后端专用 ----
    # RIR 长度(样本)；None → T60*fs。原作者脚本用 4096
    nsample: Optional[int] = 4096
    # 镜像法阶数：-1 = 自动最大阶(最慢)；建议 20~40 兼顾速度
    order: int = -1
    # 过采样倍数：>1 时先在 oversample*fs 上生成再抽取，
    # 用来恢复 Habets 生成器缺失的亚样本时延(其延时按整数样本取整)
    oversample: int = 1
    # 是否对 RIR 做高通(与 rir_generator 默认一致)
    hp_filter: bool = True
    # ---- roomsimove 后端专用 ----
    # roomsimove_single.py 所在目录(含 olafilt.py/utils.py)；None → 依赖 sys.path
    roomsimove_path: Optional[str] = None
    # 麦克风指向(roomsimove 支持 omnidirectional/cardioid)，可给单个值或每麦一个
    mic_directivity: str = "omnidirectional"

    # 完全消声(仅直达声)，供几何一致性校验使用
    anechoic: bool = False

    # 直接指定 6 个墙面反射系数(覆盖 reverberation_time)；
    # beta=[0]*6 即完全消声(仅直达声)，可用于几何一致性校验
    beta: Optional[Tuple[float, float, float, float, float, float]] = None

    @classmethod
    def from_dict(cls, d: Optional[Dict]) -> "RoomRirConfig":
        d = dict(d or {})
        if d.get("room_dim") is not None:
            d["room_dim"] = tuple(float(x) for x in d["room_dim"])
        if d.get("array_center") is not None:
            d["array_center"] = tuple(float(x) for x in d["array_center"])
        if d.get("source_distance_range") is not None:
            d["source_distance_range"] = tuple(
                float(x) for x in d["source_distance_range"])
        if isinstance(d.get("height_jitter"), (list, tuple)):
            d["height_jitter"] = tuple(float(x) for x in d["height_jitter"])
        if d.get("t60_range") is not None:
            d["t60_range"] = tuple(float(x) for x in d["t60_range"])
        if d.get("beta") is not None:
            d["beta"] = tuple(float(x) for x in d["beta"])
        if d.get("backend") is not None:
            d["backend"] = str(d["backend"]).lower()
            if d["backend"] not in ("pyroomacoustics", "rir_generator",
                                   "roomsimove"):
                raise ValueError(
                    "backend 只能是 pyroomacoustics/rir_generator/roomsimove，"
                    f"当前={d['backend']}")
        unknown = set(d) - set(cls.__dataclass_fields__)
        if unknown:
            raise ValueError(f"未知的 RIR 配置项: {sorted(unknown)}")
        return cls(**d)

    def describe(self) -> str:
        return (f"room={tuple(self.room_dim)}m t60={self.t60}s "
                f"material={self.wall_material or 'sabine+calibrated'} "
                f"scattering={self.scattering} max_order={self.max_order} "
                f"height_jitter={self.height_jitter}m")


# ======================================================================
# Sabine 经验公式
# ======================================================================
def _room_volume_area(room_dim: Sequence[float]) -> Tuple[float, float]:
    l, w, h = (float(x) for x in room_dim)
    return l * w * h, 2.0 * (l * w + l * h + w * h)


def sabine_absorption(t60: float, room_dim: Sequence[float]) -> float:
    """Sabine 公式反解平均吸声系数：T60 = 0.161 V / (A S)。"""
    v, s = _room_volume_area(room_dim)
    a = 0.161 * v / (max(float(t60), 1e-3) * s)
    return float(np.clip(a, 1e-3, 0.99))


def sabine_max_order(t60: float, room_dim: Sequence[float],
                     c: float = SPEED_OF_SOUND) -> int:
    """按平均自由程估计覆盖混响尾所需镜像阶数(向上取整，+1 阶余量)。"""
    v, s = _room_volume_area(room_dim)
    mean_free_path = 4.0 * v / s
    return int(math.ceil(float(t60) * c / mean_free_path)) + 1


# ======================================================================
# 仿真器
# ======================================================================
_AXIS_INDEX = {"x": 0, "y": 1, "z": 2}


class RoomGeometry:
    """房间/阵列几何 + 与模型端一致的时延约定(不含具体 RIR 后端)。"""

    def __init__(self, cfg: RoomRirConfig, num_mic: int, mic_spacing: float,
                 sr: int):
        if cfg.array_axis not in _AXIS_INDEX:
            raise ValueError(f"array_axis 必须是 x/y/z，当前={cfg.array_axis}")
        if str(cfg.half_plane) not in ("both", "+", "-"):
            raise ValueError(f"half_plane 只能是 both/+/-，当前={cfg.half_plane}")
        self.cfg = cfg
        self.num_mic = int(num_mic)
        self.mic_spacing = float(mic_spacing)
        self.sr = int(sr)
        self.speed_sound = float(cfg.speed_sound)
        self.group_delay_samples = 0.0

        self.room_dim = np.asarray(cfg.room_dim, dtype=np.float64)
        if self.room_dim.shape != (3,) or np.any(self.room_dim <= 0):
            raise ValueError(f"room_dim 非法: {cfg.room_dim}")
        self.axis = _AXIS_INDEX[cfg.array_axis]
        self.center = (np.asarray(cfg.array_center, dtype=np.float64)
                       if cfg.array_center is not None
                       else self.room_dim / 2.0)
        if np.any(self.center <= 0) or np.any(self.center >= self.room_dim):
            raise ValueError(f"array_center 必须位于房间内部: {self.center.tolist()}")

        offsets = ((np.arange(self.num_mic) - (self.num_mic - 1) / 2.0)
                   * self.mic_spacing)
        mics = np.repeat(self.center[:, None], self.num_mic, axis=1)
        mics[self.axis, :] += offsets
        self.mic_positions = mics
        self.axial_offsets = offsets
        self._check_geometry()

    # ---------------- 几何 ----------------
    def _check_geometry(self) -> None:
        margin = 0.05
        # 注意按坐标轴广播：(3,M) 与 (3,1) 比较，M!=3 时不能直接与 (3,) 广播
        lo = np.full((3, 1), margin)
        hi = self.room_dim[:, None] - margin
        if np.any(self.mic_positions < lo) or np.any(self.mic_positions > hi):
            raise ValueError(
                f"阵列超出房间范围: center={self.center.tolist()}, "
                f"room={self.room_dim.tolist()}")

    def direction_for_theta(self, theta_deg: float, z_factor: float = 0.0,
                            y_sign: float = 1.0) -> np.ndarray:
        """构造满足 u·e_axis = -cos(theta) 的单位方向向量。

        z_factor ∈ [-1,1]：垂直于轴向的平面内、第二个垂直坐标(通常为高度)
        上的分量比例，实际垂直位移 = distance * sin(theta) * z_factor。
        y_sign：另一个垂直坐标的正负号(0~180° 的两个镜像半平面)。
        """
        th = math.radians(float(theta_deg))
        u = np.zeros(3, dtype=np.float64)
        u[self.axis] = -math.cos(th)
        s = math.sin(th)
        perp = [i for i in range(3) if i != self.axis]
        sz = float(np.clip(z_factor, -1.0, 1.0))
        sy = math.sqrt(max(0.0, 1.0 - sz * sz))
        u[perp[0]] = s * sy * (1.0 if y_sign >= 0 else -1.0)
        u[perp[1]] = s * sz
        return u / np.linalg.norm(u)

    def source_position(self, theta_deg: float, distance: float,
                        z_factor: float = 0.0,
                        y_sign: float = 1.0) -> np.ndarray:
        return self.center + float(distance) * self.direction_for_theta(
            theta_deg, z_factor, y_sign)

    def effective_theta(self, position: Sequence[float]) -> float:
        """由声源位置反算真实 theta(度)，用于校验/标注一致性。"""
        v = np.asarray(position, dtype=np.float64) - self.center
        v = v / np.linalg.norm(v)
        return float(np.degrees(np.arccos(np.clip(-v[self.axis], -1.0, 1.0))))

    def predicted_tdoa(self, theta_deg: float) -> np.ndarray:
        """解析到达时延(秒)，**相对阵列中心**：tau_m = x_m cos(theta)/c。"""
        return (self.axial_offsets
                * math.cos(math.radians(float(theta_deg))) / self.speed_sound)

    def analytic_direct_samples(self, theta_deg: float, distance: float,
                                ref: int = None) -> np.ndarray:
        """解析直达声峰位(样本)，含 pra 的共模群延时，便于与实测峰位比对。"""
        ref = 0 if ref is None else ref
        src = self.source_position(theta_deg, distance)
        dist = np.linalg.norm(self.mic_positions - src[:, None], axis=0)
        return dist / self.speed_sound * self.sr + PRA_GROUP_DELAY_SAMPLES

    def inside_room(self, position: Sequence[float], margin: float = 0.05) -> bool:
        p = np.asarray(position, dtype=np.float64)
        return bool(np.all(p >= margin) and np.all(p <= self.room_dim - margin))

    def cache_key(self, theta_deg: float, distance: float, z_factor: float,
                  y_sign: float) -> Tuple:
        """量化后的几何键；同时作为"量化后的生成参数"用于缓存。"""
        cfg = self.cfg
        qd = max(float(cfg.cache_quant_distance), 1e-6)
        qh = max(float(cfg.cache_quant_height), 1e-6)
        d = round(float(distance) / qd) * qd
        th = float(theta_deg)
        s = math.sin(math.radians(th))
        z_off = s * d * float(z_factor)
        z_off = round(z_off / qh) * qh
        z_factor_q = 0.0 if abs(s * d) < 1e-9 else float(
            np.clip(z_off / (s * d), -1.0, 1.0))
        return (round(th, 3), round(d, 6), round(z_factor_q, 4),
                1.0 if y_sign >= 0 else -1.0)


class RoomRirSimulator(RoomGeometry):
    """pyroomacoustics 镜像法后端(含 Sabine 吸声标定)。"""

    def __init__(self, cfg: RoomRirConfig, num_mic: int, mic_spacing: float,
                 sr: int):
        require_pyroomacoustics()
        super().__init__(cfg, num_mic, mic_spacing, sr)
        self.group_delay_samples = float(PRA_GROUP_DELAY_SAMPLES)

        if cfg.anechoic:
            self.material = pra.Material("anechoic", scattering=cfg.scattering)
            self.absorption = None
        elif cfg.wall_material:
            self.material = pra.Material(cfg.wall_material,
                                         scattering=cfg.scattering)
            self.absorption = None
        else:
            self.absorption = sabine_absorption(cfg.t60, self.room_dim)
            self.material = pra.Material(self.absorption,
                                         scattering=cfg.scattering)
        self.max_order = (int(cfg.max_order) if cfg.max_order
                          else sabine_max_order(cfg.t60, self.room_dim,
                                                c=self.speed_sound))

        self.sabine_absorption0 = self.absorption
        self.calibrated_t60 = float("nan")
        self.calibration_log = []
        if cfg.calibrate and not cfg.wall_material and not cfg.anechoic:
            self._calibrate_absorption()

    def _measure_reference_t60(self) -> float:
        rir = self.rir(90.0, float(self.cfg.calib_distance))
        return measure_t60(rir, self.sr)

    def _calibrate_absorption(self) -> None:
        """二分搜索吸声系数，使 RIR 实测 T60 命中目标值(容差 2%)。"""
        target = float(self.cfg.t60)
        lo, hi = 0.01, 0.99
        best_a, best_err = float(self.absorption), None
        for _ in range(12):
            mid = 0.5 * (lo + hi)
            self.absorption = mid
            self.material = pra.Material(mid, scattering=self.cfg.scattering)
            t60 = self._measure_reference_t60()
            if not np.isfinite(t60):
                break
            err = t60 - target
            self.calibration_log.append((round(mid, 4), round(float(t60), 4)))
            if best_err is None or abs(err) < abs(best_err):
                best_a, best_err = mid, err
            if abs(err) <= 0.02 * target:
                break
            if err > 0:      # 混响偏长 → 提高吸声
                lo = mid
            else:
                hi = mid
        self.absorption = float(best_a)
        self.material = pra.Material(self.absorption,
                                     scattering=self.cfg.scattering)
        self.calibrated_t60 = self._measure_reference_t60()

    def rir(self, theta_deg: float, distance: float, z_factor: float = 0.0,
            y_sign: float = 1.0) -> np.ndarray:
        """生成 [M, L] 多通道房间 RIR(float32)。"""
        pos = self.source_position(theta_deg, distance, z_factor, y_sign)
        if not self.inside_room(pos):
            raise ValueError(
                f"声源超出房间: theta={theta_deg}, distance={distance}, "
                f"pos={np.round(pos, 3).tolist()}, room={self.room_dim.tolist()}")
        room = pra.ShoeBox(self.room_dim.tolist(), fs=self.sr,
                           materials=self.material,
                           max_order=self.max_order,
                           air_absorption=self.cfg.air_absorption)
        room.add_microphone_array(
            pra.MicrophoneArray(self.mic_positions.copy(), room.fs))
        room.add_source(pos.tolist())
        room.compute_rir()
        rirs = [np.asarray(room.rir[m][0], dtype=np.float32)
                for m in range(self.num_mic)]
        length = max(len(r) for r in rirs)
        out = np.zeros((self.num_mic, length), dtype=np.float32)
        for m, r in enumerate(rirs):
            out[m, :len(r)] = r
        if self.cfg.rir_len:
            n = int(self.cfg.rir_len)
            out = (out[:, :n] if n <= length
                   else np.pad(out, ((0, 0), (0, n - length))))
        return out


class RirGeneratorSimulator(RoomGeometry):
    """rir_generator(Habets RIR-Generator)后端。

    与原作者脚本一致：rir.generate(c, fs, r, s, L, reverberation_time, nsample)。
    注意两点（已实测，论文里可直接写）：
      1. 该生成器的每个到达都是**带限 sinc 形状**(几十个抽头)，因此**时延本身
         就是亚样本精度**：消声对照下相对时延误差 ≤0.12 样本，且与 oversample
         无关(过采样不会进一步改善)。oversample 仅作为可选的高倍率开关保留。
      2. 该生成器无额外群延时(group_delay_samples=0)。
    """

    def __init__(self, cfg: RoomRirConfig, num_mic: int, mic_spacing: float,
                 sr: int):
        require_rir_generator()
        super().__init__(cfg, num_mic, mic_spacing, sr)
        self.group_delay_samples = 0.0
        self.oversample = max(1, int(cfg.oversample))
        self.fs_gen = self.sr * self.oversample
        self.absorption = None
        self.calibrated_t60 = float("nan")
        self.max_order = int(cfg.order)

    def rir(self, theta_deg: float, distance: float, z_factor: float = 0.0,
            y_sign: float = 1.0) -> np.ndarray:
        pos = self.source_position(theta_deg, distance, z_factor, y_sign)
        if not self.inside_room(pos):
            raise ValueError(
                f"声源超出房间: theta={theta_deg}, distance={distance}, "
                f"pos={np.round(pos, 3).tolist()}, room={self.room_dim.tolist()}")
        # nsample 按目标采样率给出；过采样时按倍数放大，抽取后长度仍为 nsample
        n = (int(self.cfg.nsample) if self.cfg.nsample
             else int(round(float(self.cfg.t60) * self.sr)))
        n = max(1, n) * self.oversample
        kwargs = dict(
            c=self.speed_sound,
            fs=float(self.fs_gen),
            r=self.mic_positions.T,
            s=pos.tolist(),
            L=self.room_dim.tolist(),
            nsample=int(n),
            order=int(self.cfg.order),
            hp_filter=bool(self.cfg.hp_filter),
        )
        if self.cfg.beta is not None:
            kwargs["beta"] = list(self.cfg.beta)
        elif self.cfg.anechoic:
            kwargs["beta"] = [0.0] * 6
        else:
            kwargs["reverberation_time"] = float(self.cfg.t60)
        h = rir_generator.generate(**kwargs)
        h = np.asarray(h, dtype=np.float64)
        if h.ndim == 1:                 # 单麦 → (n,)
            h = h[:, None]
        h = h.T                         # rir_generator 返回 (nsample, n_recv)
        if self.oversample > 1:
            from scipy.signal import resample_poly
            h = resample_poly(h, up=1, down=self.oversample, axis=-1)
        if self.cfg.rir_len:
            m = int(self.cfg.rir_len)
            h = (h[:, :m] if m <= h.shape[1]
                 else np.pad(h, ((0, 0), (0, m - h.shape[1]))))
        return h.astype(np.float32)


class RoomsimoveSimulator(RoomGeometry):
    """Roomsimove 3.3(roomsimove_single.RoomSim)后端。

    与 rir_generator 的差别：
      1. 内置 32 阶分数延时 FIR 插值 → **直达声时延是亚样本精度**，更适合
         8cm 小孔径阵列(不需要 oversample 技巧)；
      2. 吸声由 Norris-Eyring 公式 rt60_to_absorption 给出，且支持麦克风指向
         (omnidirectional/cardioid)；
      3. 内部声速硬编码为 343 m/s(Fs_c = fs/343)，与模型端默认 340 有 0.9%
         差异(≈0.02 样本)，可忽略；如需严格一致可把 speed_sound 设为 343。
    """

    def __init__(self, cfg: RoomRirConfig, num_mic: int, mic_spacing: float,
                 sr: int):
        rs = require_roomsimove(cfg.roomsimove_path)
        super().__init__(cfg, num_mic, mic_spacing, sr)
        self.roomsimove = rs
        self.group_delay_samples = 0.0
        self.speed_sound_impl = 343.0
        if cfg.anechoic:
            absorption, self.absorption = 0.999, None
        else:
            absorption = float(rs.rt60_to_absorption(
                self.room_dim.tolist(), float(cfg.t60)))
            self.absorption = absorption
        self.calibrated_t60 = float("nan")
        self.max_order = None

        room = rs.Room(self.room_dim.tolist(), abs_coeff=float(absorption))
        dirs = cfg.mic_directivity
        mics = []
        for i in range(self.num_mic):
            one = (dirs[i] if isinstance(dirs, (list, tuple)) else dirs)
            mics.append(rs.Microphone(self.mic_positions[:, i].tolist(), i + 1,
                                      orientation=[0.0, 0.0, 0.0],
                                      direction=self._resolve_directivity(one)))
        self.sim = rs.RoomSim(self.sr, room, mics, RT60=float(cfg.t60))

    def _resolve_directivity(self, name) -> str:
        """roomsimove 内部用 np.loadtxt(name + '.txt') 读指向文件，这里解析成绝对路径
        (否则依赖当前工作目录)。"""
        stem = str(name)
        if os.path.isabs(stem):
            return stem
        for base in filter(None, (self.cfg.roomsimove_path, os.getcwd())):
            cand = os.path.join(os.path.expanduser(str(base)), stem + ".txt")
            if os.path.isfile(cand):
                return os.path.join(os.path.expanduser(str(base)), stem)
        return stem

    def rir(self, theta_deg: float, distance: float, z_factor: float = 0.0,
            y_sign: float = 1.0) -> np.ndarray:
        pos = self.source_position(theta_deg, distance, z_factor, y_sign)
        if not self.inside_room(pos):
            raise ValueError(
                f"声源超出房间: theta={theta_deg}, distance={distance}, "
                f"pos={np.round(pos, 3).tolist()}, room={self.room_dim.tolist()}")
        h = np.asarray(self.sim.create_rir(pos.tolist()), dtype=np.float32)
        if h.ndim == 1:               # 单麦 → (L,)
            h = h[:, None]
        h = h.T                       # Roomsimove 返回 (L, n_mic)
        if self.cfg.rir_len:
            m = int(self.cfg.rir_len)
            h = (h[:, :m] if m <= h.shape[1]
                 else np.pad(h, ((0, 0), (0, m - h.shape[1]))))
        return h.astype(np.float32)


def build_simulator(cfg: RoomRirConfig, num_mic: int, mic_spacing: float,
                    sr: int) -> RoomGeometry:
    """按 cfg.backend 构造仿真器。"""
    backend = str(cfg.backend)
    if backend == "rir_generator":
        return RirGeneratorSimulator(cfg, num_mic, mic_spacing, sr)
    if backend == "roomsimove":
        return RoomsimoveSimulator(cfg, num_mic, mic_spacing, sr)
    return RoomRirSimulator(cfg, num_mic, mic_spacing, sr)


def missing_backend_dependency(cfg: RoomRirConfig) -> Optional[str]:
    """返回缺失依赖的安装提示；依赖齐全时返回 None。"""
    if str(cfg.backend) == "rir_generator":
        return None if HAS_RIR_GENERATOR else "pip install rir-generator"
    if str(cfg.backend) == "roomsimove":
        return (None if has_roomsimove(cfg.roomsimove_path)
                else "设置 room_rir.roomsimove_path 指向 roomsimove_single.py 目录")
    return None if pra is not None else "pip install pyroomacoustics"


def vertical_z_factor_bounds(theta_deg: float, distance: float,
                             height_jitter=0.0) -> Tuple[float, float]:
    """把"声源垂直偏移(米)"换算成方向向量 z 分量比例 z_factor 的区间。

    z_factor ∈ [-1,1]，实际垂直偏移 = distance * sin(theta) * z_factor。
    标量 height_jitter=h → 偏移 ±h；[lo,hi] → 偏移区间。
    theta 接近端射(sin≈0)时垂直偏移必须为 0，返回 (0,0)。
    """
    if isinstance(height_jitter, (list, tuple)):
        h_lo, h_hi = float(height_jitter[0]), float(height_jitter[1])
    else:
        h_lo, h_hi = -abs(float(height_jitter)), abs(float(height_jitter))
    span = math.sin(math.radians(float(theta_deg))) * float(distance)
    if span < 1e-9:
        return 0.0, 0.0
    lo = max(-1.0, min(1.0, h_lo / span))
    hi = max(-1.0, min(1.0, h_hi / span))
    return lo, hi


def validate_placement(sim: "RoomGeometry", distance_range,
                       height_jitter=0.0, margin: float = 0.05,
                       step_deg: int = 5) -> list:
    """检查"实际采样规则"在 0~180° 各方向是否都落在房间内。

    与数据生成端采样规则一致：垂直偏移受 height_jitter 限制
    (标量 h → ±h；[lo,hi] → 区间)，半平面受 half_plane 限制。
    返回非法参数列表(空列表 = 合法)。只做几何判断，不生成 RIR。
    """
    lo, hi = float(distance_range[0]), float(distance_range[1])
    signs = {"both": (1.0, -1.0), "+": (1.0,), "-": (-1.0,)}.get(
        str(getattr(sim.cfg, "half_plane", "both")), (1.0, -1.0))
    bad = []
    for theta in range(0, 181, step_deg):
        for d in (lo, hi):
            z_lo, z_hi = vertical_z_factor_bounds(theta, d, height_jitter)
            for z_factor in (z_lo, 0.0, z_hi):
                for y_sign in signs:
                    pos = sim.source_position(theta, d, z_factor, y_sign)
                    if not sim.inside_room(pos, margin):
                        bad.append({
                            "theta": theta, "distance": d,
                            "z_factor": round(z_factor, 4), "y_sign": y_sign,
                            "pos": np.round(pos, 3).tolist(),
                        })
    return bad


# ======================================================================
# 分析工具(供 tools/check_room_rir.py 使用)
# ======================================================================
def measure_t60(rir: np.ndarray, sr: int,
                decay_db: Tuple[float, float] = (-5.0, -35.0)) -> float:
    """Schroeder 反向积分法测 T60(外推到 -60 dB)。

    rir: [L] 或 [M, L]；多通道时逐通道测量后取中位数。
    """
    rir = np.atleast_2d(np.asarray(rir, dtype=np.float64))
    t60s = []
    for ch in rir:
        e = ch ** 2
        total = float(np.sum(e))
        if total <= 0:
            continue
        edc = np.cumsum(e[::-1])[::-1]
        edc_db = 10.0 * np.log10(np.maximum(edc / total, 1e-300))
        t = np.arange(len(edc_db)) / float(sr)
        i_hi = np.where(edc_db <= decay_db[0])[0]
        i_lo = np.where(edc_db <= decay_db[1])[0]
        if len(i_hi) == 0 or len(i_lo) == 0 or i_lo[0] <= i_hi[0]:
            continue
        i0, i1 = int(i_hi[0]), int(i_lo[0])
        slope = np.polyfit(t[i0:i1 + 1], edc_db[i0:i1 + 1], 1)[0]
        if slope < 0:
            t60s.append(-60.0 / slope)
    return float(np.median(t60s)) if t60s else float("nan")


def direct_index(rir: np.ndarray, sr: int, search_ms: float = 25.0,
                 center_sample: Optional[float] = None,
                 half_win_ms: float = 1.5) -> int:
    """直达声峰位(样本)。

    - 默认在前 search_ms 内取绝对峰值；
    - 给定 center_sample 时只在 ±half_win_ms 窗口内取峰值(默认 ±1.5ms)：
      房间早期反射(地板/天花板)可能比直达声更强，窗口过宽会误取反射峰。
    注意 pyroomacoustics 会额外加 PRA_GROUP_DELAY_SAMPLES 个样本共模延时。
    """
    r = np.asarray(rir, dtype=np.float64).reshape(-1)
    if center_sample is not None:
        half = max(1, int(half_win_ms * 1e-3 * sr))
        lo = max(0, int(center_sample) - half)
        hi = min(len(r), int(center_sample) + half + 1)
    else:
        lo, hi = 0, min(len(r), max(1, int(search_ms * 1e-3 * sr)))
    return int(lo + int(np.argmax(np.abs(r[lo:hi]))))


def measured_tdoa(rir: np.ndarray, sr: int, ref: int = 0,
                  search_ms: float = 25.0,
                  center_sample: Optional[float] = None) -> np.ndarray:
    """用直达声峰位估计 TDOA(秒)，返回相对 ref 通道的时延。

    ref 建议取阵列中心通道(3 麦时 ref=1)，以便与 predicted_tdoa 直接比较。
    """
    rir = np.atleast_2d(rir)
    idx = np.array([direct_index(ch, sr, search_ms, center_sample)
                    for ch in rir], dtype=np.float64)
    return (idx - idx[ref]) / float(sr)


def xcorr_delay_samples(sig_a: np.ndarray, sig_b: np.ndarray) -> float:
    """互相关 + 抛物线插值，返回 sig_a 相对 sig_b 的亚样本时延(样本)。

    直接比较两条 RIR：等价于测"两通道到达时延差"，精度远高于整数峰位
    (本例中典型误差 <0.15 样本)，用于校验仿真与模型端解析式是否一致。
    """
    a = np.asarray(sig_a, dtype=np.float64).reshape(-1)
    b = np.asarray(sig_b, dtype=np.float64).reshape(-1)
    n = 1 << int(math.ceil(math.log2(len(a) + len(b))))
    cc = np.fft.irfft(np.fft.rfft(a, n) * np.conj(np.fft.rfft(b, n)), n)
    k = int(np.argmax(np.abs(cc)))
    x0, x1, x2 = cc[(k - 1) % n], cc[k], cc[(k + 1) % n]
    den = x0 - 2 * x1 + x2
    delta = 0.5 * (x0 - x2) / den if abs(den) > 1e-12 else 0.0
    lag = k + delta
    return float(lag - n if lag > n / 2 else lag)


def drr_db(rir: np.ndarray, sr: int, direct_win_ms: float = 5.0,
           search_ms: float = 25.0,
           center_sample: Optional[float] = None) -> np.ndarray:
    """直达混响比(DRR, dB)：直达窗能量 / 其余能量。

    窗口默认 ±2.5ms —— pra 的分数延时滤波器会把直达声展宽到约
    ±(40/fs)s，窗口太窄会把部分直达能量算进混响。
    """
    rir = np.atleast_2d(np.asarray(rir, dtype=np.float64))
    win = max(1, int(direct_win_ms * 1e-3 * sr))
    out = []
    for ch in rir:
        idx = direct_index(ch, sr, search_ms, center_sample)
        lo = max(0, idx - win // 2)
        hi = min(len(ch), idx + win // 2 + 1)
        e_dir = float(np.sum(ch[lo:hi] ** 2))
        e_rev = float(np.sum(ch ** 2) - e_dir)
        out.append(10.0 * math.log10(max(e_dir, 1e-300) / max(e_rev, 1e-300)))
    return np.asarray(out)


def convolved_coherence(rir: np.ndarray, sr: int, duration: float = 4.0,
                        nperseg: int = 1024, seed: int = 0,
                        bands: Sequence[Tuple[float, float]] = ((300.0, 1000.0),
                                                               (1000.0, 3000.0),
                                                               (3000.0, 8000.0))):
    """把 RIR 作用于白噪声后计算通道间幅值平方相干(MSC)。

    直达声 RIR(纯时延)的 MSC≈1；房间 RIR 因混响去相关会明显 <1。
    返回 ({频带: 通道对平均 MSC}, 总体平均)。
    """
    from scipy import signal  # 仅分析脚本需要

    rir = np.atleast_2d(np.asarray(rir, dtype=np.float64))
    n = int(duration * sr)
    rng = np.random.default_rng(seed)
    x = rng.standard_normal(n)
    nfft = 1 << int(math.ceil(math.log2(n + rir.shape[1])))
    X = np.fft.rfft(x, nfft)
    ys = [np.fft.irfft(np.fft.rfft(ch, nfft) * X, nfft)[:n] for ch in rir]
    ys = np.asarray(ys)

    pairs = [(i, j) for i in range(len(rir)) for j in range(i + 1, len(rir))]
    cxy_cache = {p: signal.coherence(ys[p[0]], ys[p[1]], fs=sr,
                                     nperseg=nperseg) for p in pairs}
    per_band = {}
    for lo, hi in bands:
        vals = []
        for p in pairs:
            f, cxy = cxy_cache[p]
            m = (f >= lo) & (f < hi)
            if np.any(m):
                vals.append(float(np.mean(cxy[m])))
        per_band[(float(lo), float(hi))] = float(np.mean(vals)) if vals else float("nan")
    overall = float(np.nanmean(list(per_band.values()))) if per_band else float("nan")
    return per_band, overall


def gcc_phat_tdoa(rir: np.ndarray, sr: int, pair: Tuple[int, int] = (0, 1),
                  duration: float = 4.0, seed: int = 0,
                  fmin: float = 0.0, fmax: Optional[float] = None) -> float:
    """把 RIR 作用于白噪声后用 GCC-PHAT 估计麦对时延(秒，含抛物线插值)。

    与模型端 wekws/model/spatial_dynamic_query.py:_pair_angle_feature 使用
    同一约定(交叉谱相位 = phi_i - phi_j，lag = tau_i - tau_j)。
    """
    rir = np.atleast_2d(np.asarray(rir, dtype=np.float64))
    i, j = pair
    n = int(duration * sr)
    rng = np.random.default_rng(seed)
    x = rng.standard_normal(n)
    nfft = 1 << int(math.ceil(math.log2(n + rir.shape[1])))
    X = np.fft.rfft(x, nfft)
    Yi = np.fft.rfft(rir[i], nfft) * X
    Yj = np.fft.rfft(rir[j], nfft) * X
    cross = Yi * np.conj(Yj)
    cross = cross / (np.abs(cross) + 1e-12)          # PHAT 白化
    if fmin > 0 or fmax is not None:
        freqs = np.fft.rfftfreq(nfft, d=1.0 / sr)
        mask = np.ones_like(freqs, dtype=bool)
        if fmin > 0:
            mask &= freqs >= fmin
        if fmax is not None:
            mask &= freqs <= fmax
        cross = cross * mask
    cc = np.fft.irfft(cross, nfft)
    k = int(np.argmax(np.abs(cc)))
    a, b, c = cc[k - 1], cc[k], cc[(k + 1) % nfft]
    den = a - 2 * b + c
    delta = 0.5 * (a - c) / den if abs(den) > 1e-12 else 0.0
    lag = k + delta
    if lag > nfft / 2:
        lag -= nfft
    return float(lag / sr)


def tdoa_to_theta(tau: float, mic_spacing: float, pair: Tuple[int, int] = (0, 1),
                  c: float = SPEED_OF_SOUND) -> float:
    """麦对时延 → theta(度)，与模型端 _pair_angle_feature 反解公式一致。"""
    i, j = pair
    d = (i - j) * mic_spacing
    cos_th = float(np.clip(c * tau / d, -1.0, 1.0))
    return float(np.degrees(np.arccos(cos_th)))
