# Copyright (c) 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
"""
唤醒检测 / 唤醒词DOA定位 评测指标（纯函数）。

被 train.py（训练中每轮在 cv 上监控）和 eval_dynamic_query.py（独立评测）复用，
保证两边指标口径完全一致。

评测约定（与模型输出一致）：
- 模型对每段音频输出 Q=3 个槽，每个槽有 kws logit s_q 和 3 类粗方位 doa logit；
- “检测到唤醒词”：任意一个槽 sigmoid(s_q) > prob_thr（样本级二值判定）；
- “唤醒词方位”：取 sigmoid(s_q) 最大的那个槽，对该槽的 doa_logit 取 argmax；
- kws_label=1 为正样本（含唤醒词），kws_label=0 为负样本；
- wake_angle_gt 为正样本的唤醒词粗方位类(0/1/2)，负样本为 -100（不参与定位统计）。

输出指标：
- wake_recall   : 唤醒率 = 正样本检出率 TP/(TP+FN)
- fpr           : 虚警率 = 负样本误检率 FP/(FP+TN)
- loc_acc_det   : 检出正样本中定位正确率（预测类 == 唤醒词真值类）
- loc_acc_all   : 全部正样本（含漏检，用最强槽兜底给方位）的定位正确率
- mean_deg_err  : 检出正样本的平均绝对角度误差（按类别中心30°/90°/150°计算）
"""
import torch


DOA_CLASS_CENTERS = (30.0, 90.0, 150.0)


def _binary_auc(scores: torch.Tensor, labels: torch.Tensor) -> float:
    """二分类 AUC；用于判断唤醒分数是否真正可分，而不只看 0.5 阈值。"""
    scores = scores.detach().double().reshape(-1)
    labels = labels.detach().reshape(-1)
    pos = scores[labels == 1]
    neg = scores[labels == 0]
    n_pos, n_neg = int(pos.numel()), int(neg.numel())
    if n_pos == 0 or n_neg == 0:
        return float("nan")

    all_scores = torch.cat([pos, neg], dim=0)
    order = torch.argsort(all_scores)
    ranks = torch.empty_like(all_scores)
    ranks[order] = torch.arange(1, all_scores.numel() + 1,
                                dtype=ranks.dtype, device=ranks.device)
    # 对相同分数取平均 rank，避免 ties 把 AUC 算偏。
    sorted_scores = all_scores[order]
    _, counts = torch.unique_consecutive(sorted_scores, return_counts=True)
    start = 0
    for count in counts.tolist():
        if count > 1:
            avg_rank = (start + 1 + start + count) / 2.0
            ranks[order[start:start + count]] = avg_rank
        start += count
    auc = (ranks[:n_pos].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)
    return float(auc.item())


def wake_detection_metrics(s_logits, doa_logits, kws_label, wake_angle_gt,
                           prob_thr=0.5, compute_auc=False, det_logits=None):
    """
    Args:
        s_logits:     [N, Q]     每个 query 的唤醒 logit；query c 代表 DOA 类 c
        doa_logits:   [N,Q,3] 或 None
                      本模型方向 = argmax(s_logits)（选中的 query 下标）,
                      传 None 时直接使用该口径；传入时保留旧行为
        kws_label:    [N]        0/1
        wake_angle_gt:[N]        唤醒词粗方位类 0/1/2；负样本 -100
        prob_thr:     检测概率阈值，默认 0.5
    Returns:
        指标 dict（全部为 python 标量，便于直接打印/存 tensorboard）
    """
    s = torch.sigmoid(s_logits.detach().float())        # [N, Q]
    if det_logits is not None:
        # 独立二分类唤醒头：检测分来自该头，方位仍由 query argmax 决定
        sd = torch.sigmoid(det_logits.detach().float())
        det = (sd > prob_thr).any(dim=-1)
        det_score = sd.max(dim=-1).values
    else:
        det = (s > prob_thr).any(dim=-1)                # 样本级：任意槽超阈值即判“有唤醒词”
        det_score = s.max(dim=-1).values
    chosen = s.argmax(dim=-1)                           # 每个样本“最强 query”
    if doa_logits is None:
        # 本模型：query c 直接代表 DOA 类 c，方向 = 选中的 query 下标
        chosen_doa = chosen
    else:
        assert doa_logits.size(-1) == len(DOA_CLASS_CENTERS), (
            f"DOA类别数不匹配: logits={doa_logits.size(-1)}, 期望={len(DOA_CLASS_CENTERS)}"
        )
        pred_doa = doa_logits.detach().argmax(dim=-1)   # [N, Q] 每槽预测粗方位类
        chosen_doa = pred_doa.gather(1, chosen.unsqueeze(-1)).squeeze(-1)

    # 正样本 = 含唤醒词；valid_wake 额外要求唤醒角度真值有效(>=0)，
    # 避免个别脏数据(label=1 但 wake_angle=-100)把角度误差放大成天文数字。
    pos = (kws_label == 1)
    valid_wake = wake_angle_gt >= 0
    neg = ~pos
    n_pos = int(pos.sum().item())
    n_neg = int(neg.sum().item())

    tp = int((det & pos).sum().item())
    fn = n_pos - tp
    fp = int((det & neg).sum().item())
    tn = n_neg - fp

    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0   # 唤醒率
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0      # 虚警率

    det_pos = det & pos & valid_wake
    n_det_pos = int(det_pos.sum().item())
    if n_det_pos > 0:
        loc_hit_det = int(((chosen_doa == wake_angle_gt) & det_pos).sum().item())
        loc_acc_det = loc_hit_det / n_det_pos
        centers = torch.tensor(
            DOA_CLASS_CENTERS, device=chosen_doa.device, dtype=torch.float32
        )
        pred_deg = centers[chosen_doa]
        gt_deg = centers[wake_angle_gt.clamp(0, len(DOA_CLASS_CENTERS) - 1)]
        err_deg = (pred_deg - gt_deg).abs()[det_pos]
        mean_deg_err = float(err_deg.mean().item())
    else:
        loc_acc_det = float("nan")
        mean_deg_err = float("nan")

    n_pos_loc = int((pos & valid_wake).sum().item())
    if n_pos_loc > 0:
        loc_hit_all = int(((chosen_doa == wake_angle_gt) & pos & valid_wake).sum().item())
        loc_acc_all = loc_hit_all / n_pos_loc
    else:
        loc_acc_all = float("nan")

    return {
        "prob_thr": prob_thr,
        "wake_auc": _binary_auc(det_score, pos)
                    if compute_auc else float("nan"),
        "n_pos": n_pos,
        "n_neg": n_neg,
        "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        "wake_recall": recall,
        "fpr": fpr,
        "n_det_pos": n_det_pos,
        "loc_acc_det": loc_acc_det,
        "loc_acc_all": loc_acc_all,
        "mean_deg_err": mean_deg_err,
    }
