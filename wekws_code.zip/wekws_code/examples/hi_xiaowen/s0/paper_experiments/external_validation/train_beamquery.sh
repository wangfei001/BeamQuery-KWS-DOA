#!/bin/bash
set -e
cd /242602/wekws/examples/hi_xiaowen_duolu/s0_deepseek_3
export PYTHONPATH=$PWD USE_BATCHED_FORWARD=1 KWS_MAX_SEC=3.0 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
PY=/242602/conda/envs/wekws/bin/python
B=paper_experiments/table_ext_speech_commands; D=$B/data; C=paper_experiments/main_model/configs; L=$B/logs
COMMON="--train_data $D/train_spatial.list --train_varcol $D/train_varcol.tmp.list --cv_data $D/eval_spatial.list --cv_varcol $D/eval_varcol.tmp.list --test_data $D/test_spatial.list --test_varcol $D/test_varcol.tmp.list"
echo "[bq] stage1 $(date)"
$PY -u wekws/bin/train.py --config $C/stage1.yaml $COMMON --model_dir $B/exp/beamquery/stage1 --eval_interval 1 --gpus 0 --num_workers 8 > $L/beamquery_stage1.log 2>&1
echo "[bq] stage2 $(date)"
$PY -u wekws/bin/train.py --config $C/stage2.yaml $COMMON --checkpoint $B/exp/beamquery/stage1/best_cv.pt --model_dir $B/exp/beamquery/stage2 --eval_interval 1 --gpus 0 --num_workers 8 > $L/beamquery_stage2.log 2>&1
cp -f $B/exp/beamquery/stage2/best_cv.pt $B/exp/beamquery/best_cv.pt
cp -f $C/stage2.yaml $B/exp/beamquery/config.yaml
echo "[bq] DONE $(date)"
