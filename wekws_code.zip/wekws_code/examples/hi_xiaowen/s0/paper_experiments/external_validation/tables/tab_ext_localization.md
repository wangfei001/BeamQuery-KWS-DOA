# Table 7  Localisation / joint (external, all positives; split by source count)

| Method | DOA Acc. | MAE (deg) | Joint | $n_{src}$=1 | $n_{src}$=2 |
|---|---:|---:|---:|---:|---:|
| Cascade GCC-PHAT | 0.6390 | 24.26 | 0.3394 | 0.8889 | 0.4014 |
| Cascade SRP-PHAT | 0.4007 | 54.58 | 0.2058 | 0.4519 | 0.3521 |
| Fixed-beam-3 | 0.3105 | 53.72 | 0.1047 | 0.2074 | 0.4085 |
| BeamQuery-1stage | 0.7906 | 13.21 | 0.4332 | 0.8444 | 0.7394 |
| BeamQuery (ours) | **0.7978** | **13.00** | **0.4621** | 0.8889 | 0.7113 |
