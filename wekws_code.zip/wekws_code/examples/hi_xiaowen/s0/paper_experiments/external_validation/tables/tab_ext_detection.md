# Table 6  Detection (external: Google Speech Commands 'marvin' + RIR 2-mic)

| Method | Params (K) | AUC | FPR@0.5 | FRR@1/h |
|---|---:|---:|---:|---:|
| Mono | 645 | 0.9619 | 0.0193 | 0.5668 |
| Concat-MC | 722 | 0.9637 | 0.0234 | 0.4946 |
| KWT | 468 | 0.9238 | 0.0307 | 0.8448 |
| BC-ResNet | 9 | 0.9384 | 0.0306 | 0.7329 |
| TCSN | 454 | **0.9724** | 0.0145 | **0.4224** |
| Spatial-prior | 701 | 0.9625 | 0.0187 | 0.5162 |
| Fixed-beam | 645 | 0.9594 | 0.0168 | 0.5704 |
| Fixed-beam-3 | 645 | 0.9600 | 0.0186 | 0.5921 |
| BeamQuery-1stage | 971 | 0.9655 | **0.0127** | 0.5090 |
| BeamQuery (ours) | 971 | 0.9670 | 0.0144 | 0.4729 |
