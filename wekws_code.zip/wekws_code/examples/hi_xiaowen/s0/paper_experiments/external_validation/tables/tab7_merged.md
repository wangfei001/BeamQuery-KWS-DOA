
# Table 7  Localisation / joint: in-corpus vs external (all positives)

| Method | DOA (in) | DOA (ext) | MAE (in) | MAE (ext) | Joint (in) | Joint (ext) |
|---|---:|---:|---:|---:|---:|---:|
| Cascade GCC-PHAT | 0.5723 | 0.6390 | 33.24 | 24.26 | 0.4740 | 0.3394 |
| Cascade SRP-PHAT | 0.3900 | 0.4007 | 55.58 | 54.58 | 0.2773 | 0.2058 |
| Fixed-beam-3 | 0.4767 | 0.3105 | 35.92 | 53.72 | 0.3043 | 0.1047 |
| BeamQuery (ours) | 0.9310 | 0.7978 | 4.48 | 13.00 | 0.6297 | 0.4621 |
