#!/bin/bash
set -e
cd /242602/wekws/examples/hi_xiaowen_duolu/s0_deepseek_3
B=paper_experiments/table_ext_speech_commands
PY=/242602/conda/envs/wekws/bin/python
echo "[autopilot] waiting for ALL_DONE"
while ! grep -q ALL_DONE /gen.log 2>/dev/null; do sleep 60; done
echo "[autopilot] generation done Wed Oct 14 04:41:56 UTC 2026"
 /build_test_lists.py
echo "[autopilot] training start Wed Oct 14 04:41:56 UTC 2026"
bash /train_all.sh
echo "[autopilot] TRAINING DONE Wed Oct 14 04:41:56 UTC 2026"
