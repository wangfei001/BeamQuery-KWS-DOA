#!/bin/bash
# External validation (Speech Commands "marvin" + RIR 2-mic): Table 6 + Table 7.
# FAST MODE: 6 learned baselines + BeamQuery stage-1 run concurrently on the GPU;
# BeamQuery stage-2 follows stage-1. Recipe matches the paper (10 epochs, no AMP, val-AUC select).
set -e
cd /242602/wekws/examples/hi_xiaowen_duolu/s0_deepseek_3
export PYTHONPATH=$PWD USE_BATCHED_FORWARD=1 KWS_MAX_SEC=3.0
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
PY=/242602/conda/envs/wekws/bin/python
B=paper_experiments/table_ext_speech_commands
D=$B/data
C=paper_experiments/main_model/configs
L=$B/logs
mkdir -p $L
COMMON="--train_data $D/train_spatial.list --train_varcol $D/train_varcol.tmp.list --cv_data $D/eval_spatial.list --cv_varcol $D/eval_varcol.tmp.list --test_data $D/test_spatial.list --test_varcol $D/test_varcol.tmp.list"

base_bg () {
  name=$1; model=$2; bs=$3
  if [ -f "$B/exp/$name/best_cv.pt" ]; then echo "[skip] $name"; return 0; fi
  echo "[launch] $name ($model bs=$bs) $(date)"
  ( $PY -u paper_experiments/shared/code/train_duibi.py --model $model \
      --model_dir "$B/exp/$name" $COMMON \
      --epochs 10 --batch_size $bs --eval_interval 1 --select_metric auc \
      --num_mic 2 --num_workers 4 --gpus 0 ) > $L/$name.log 2>&1 &
}

echo "=== parallel baselines + beamquery stage1 $(date) ==="
base_bg mono          mono          128
base_bg concat_mc     concat-mc     128
base_bg kwt           kwt           128
base_bg bc_resnet     bc-resnet     128
base_bg tcsn          tcsn          128
base_bg spatial_prior spatial-prior  32

if [ ! -f "$B/exp/beamquery/stage1/best_cv.pt" ]; then
  echo "[launch] beamquery stage1 $(date)"
  ( $PY -u wekws/bin/train.py --config $C/stage1.yaml $COMMON \
      --model_dir "$B/exp/beamquery/stage1" --eval_interval 1 --gpus 0 --num_workers 4 ) > $L/beamquery_stage1.log 2>&1 &
fi
wait
echo "=== stage-1 wave done $(date) ==="

if [ ! -f "$B/exp/beamquery/stage2/best_cv.pt" ]; then
  echo "[launch] beamquery stage2 $(date)"
  $PY -u wekws/bin/train.py --config $C/stage2.yaml $COMMON \
      --checkpoint "$B/exp/beamquery/stage1/best_cv.pt" \
      --model_dir "$B/exp/beamquery/stage2" --eval_interval 1 --gpus 0 --num_workers 8 \
      > $L/beamquery_stage2.log 2>&1
fi
cp -f "$B/exp/beamquery/stage2/best_cv.pt" "$B/exp/beamquery/best_cv.pt" 2>/dev/null || true
cp -f "$C/stage2.yaml" "$B/exp/beamquery/config.yaml" 2>/dev/null || true
echo "TRAIN_ALL_DONE $(date)"
