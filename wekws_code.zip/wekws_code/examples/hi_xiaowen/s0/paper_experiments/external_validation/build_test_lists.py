import os
B = os.path.dirname(os.path.abspath(__file__))
src = os.path.join(B, "data", "test", "varcol.tmp.list")
out = os.path.join(B, "data", "test_varcol.tmp.list")
outsp = os.path.join(B, "data", "test_spatial.list")
n = 0
with open(src) as f, open(out, "w") as fo, open(outsp, "w") as fs:
    for line in f:
        p = line.split()
        if len(p) < 3:
            continue
        fo.write(line)
        fs.write(" ".join([p[0], "2"] + p[1:]) + chr(10))
        n += 1
print("test lists:", n)
