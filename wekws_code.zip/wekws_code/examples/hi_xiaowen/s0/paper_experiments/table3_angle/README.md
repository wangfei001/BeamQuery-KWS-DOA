# table3_angle — 主模型波束网格步长 Δ

`configs/step_{6,8,12,15,20,30}_s{1,2}.yaml`：主模型在每个 Δ 下的两阶段配置。
`results/step_<Δ>/`：checkpoint + `val_allpos.json` / `val_fair.json`。
在 10k 验证集上选定 **Δ=8°**（`results/summary.json`），即发布的主模型配置。
