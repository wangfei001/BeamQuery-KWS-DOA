# table_builder — 主模型数值校验

| 脚本 | 作用 |
|---|---|
| `sync_paper_tables.py` | 把生成的 `tab_*.tex` 同步到论文表格目录 |
| `verify_paper_numbers.py` | 校验表格完整性、消融顺序与数值单元格 |
| `audit_numbers.py` | 用实验 JSON 核对文档中的数值 |

生成的表格位于 `paper_experiments/24h_plan/docs/tables/`。
