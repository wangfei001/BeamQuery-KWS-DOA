# Paper sync checklist

The authoritative result sources are:

* `paper_experiments/main_experiment/test_metrics.json`
* `paper_experiments/main_experiment/threshold_sweep.json`
* `paper_experiments/24h_plan/results/angles/step_*/val_allpos.json`
* `paper_experiments/24h_plan/results/lambda/lw*/val_allpos.json`
* `paper_experiments/24h_plan/results/ablation/*/val_allpos.json`
* `paper_experiments/24h_plan/results/baselines_retrain/*/results.json`
* `paper_experiments/24h_plan/results/baselines_retrain/*/test_allpos.json`
* `paper_experiments/external_validation/results/*_metrics.json`

The generated tables are stored in `24h_plan/docs/tables/` and copied into
`papaer/tables/`. The final manuscript is `papaer/main_speech.tex`.
