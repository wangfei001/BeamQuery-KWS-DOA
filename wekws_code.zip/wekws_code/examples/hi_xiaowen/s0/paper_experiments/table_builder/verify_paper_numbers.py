# -*- coding: utf-8 -*-
"""Verify generated tables and their paper copies before final submission.

This is intentionally strict about the table contracts that have caused silent
paper errors before:

* every required table exists and has the expected row count;
* the ablation table contains A0/A1/A2/A3/A4 and never A9;
* numeric cells in ``tables_data.json`` occur in the corresponding LaTeX
  table, so a stale copied table cannot silently survive a rerun;

It does not need a GPU and does not write any experiment results.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

REQUIRED = {
    'tab_angle': 6,
    'tab_lambda': 4,
    'tab_ablation': 5,
    'tab_main': 9,
    'tab_strat': 4,
    'tab_threshold': 6,
}
OPTIONAL = {'tab_complexity': 9}
ABLATION_ORDER = ['A0', 'A1', 'A2', 'A3', 'A4']
# paper tables that are intentionally merged with the external validation
MERGED_IN_PAPER = {'tab_main', 'tab_strat'}
DECIMAL = re.compile(r'(?<![A-Za-z0-9_])-?\d+\.\d+(?![A-Za-z0-9_])')



# Table 8 is generated from the same prediction files as Table 7 but must use
# the detected-positive fields, not the all-positives fields.
def check_strat_detected(paper_dir: Path, errors):
    table_path = paper_dir / 'tables' / 'tab_strat_detected.tex'
    if not table_path.exists():
        errors.append(f'tab_strat_detected: missing {table_path}')
        return
    body = table_path.read_text(encoding='utf-8')
    root = Path(__file__).resolve().parents[2]
    sources = {
        ('Cascade GCC-PHAT', 'in-corpus'):
            root / 'paper_experiments/24h_plan/results/baselines_retrain/cascade_gccphat/test_allpos.json',
        ('Cascade GCC-PHAT', 'external'):
            root / 'paper_experiments/external_validation/results/cascade_gcc_metrics.json',
        ('Cascade SRP-PHAT', 'in-corpus'):
            root / 'paper_experiments/24h_plan/results/baselines_retrain/cascade_srpphat/test_allpos.json',
        ('Cascade SRP-PHAT', 'external'):
            root / 'paper_experiments/external_validation/results/cascade_srp_metrics.json',
        ('Fixed-beam-3', 'in-corpus'):
            root / 'paper_experiments/24h_plan/results/baselines/fixed_beam3_frozen_mono/test_allpos.json',
        ('Fixed-beam-3', 'external'):
            root / 'paper_experiments/external_validation/results/fixed_beam3_metrics.json',
        ('BeamQuery (ours)', 'in-corpus'):
            root / 'paper_experiments/main_model/experiment/test_metrics.json',
        ('BeamQuery (ours)', 'external'):
            root / 'paper_experiments/external_validation/results/beamquery_test_metrics.json',
    }
    for (method, corpus), path in sources.items():
        if not path.exists():
            errors.append(f'tab_strat_detected: missing source {path}')
            continue
        try:
            d = json.loads(path.read_text(encoding='utf-8'))
            dp = d['detected_positive']
            sd = d['stratified_detected']
            expected = [
                f"{float(dp['doa_acc']):.4f}",
                f"{float(dp['mae']):.2f}",
                f"{float(sd['n_src=1']['acc']):.4f} / {float(sd['n_src=1']['oracle']):.4f}",
                f"{float(sd['n_src=2']['acc']):.4f} / {float(sd['n_src=2']['oracle']):.4f}",
                f"{float(dp['oracle_acc']) - float(dp['doa_acc']):.4f}",
            ]
        except Exception as e:
            errors.append(f'tab_strat_detected: cannot read {path}: {e!r}')
            continue
        missing = [v for v in expected if v not in body]
        if missing:
            errors.append(f'tab_strat_detected: {method}/{corpus} expected cells absent: {missing}')
    # Guard against the specific regression that triggered the audit.
    for stale in ('0.9310', '0.5723', '0.3900', '0.4767'):
        if stale in body:
            errors.append(f'tab_strat_detected: contains all-positives value {stale} in detected-positive table')


def load_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def first_id(label: str) -> str:
    m = re.match(r'\s*(A\d+)', str(label))
    return m.group(1) if m else ''


def normalized(text: str) -> str:
    return re.sub(r'\s+', ' ', text).strip()


def check_table(key: str, expected_rows, data, tables_dir: Path, errors, warnings):
    tab = data.get(key)
    if not isinstance(tab, dict) or not isinstance(tab.get('rows'), list) or not tab['rows']:
        errors.append(f'{key}: missing or empty rows in tables_data.json')
        return
    rows = tab['rows']
    if expected_rows is not None and len(rows) != expected_rows:
        errors.append(f'{key}: expected {expected_rows} rows, got {len(rows)}')
    tex = tables_dir / f'{key}.tex'
    if not tex.exists():
        errors.append(f'{key}: missing {tex}')
        return
    body = tex.read_text(encoding='utf-8')
    if len(body.strip()) < 40:
        errors.append(f'{key}: generated .tex is unexpectedly short')
    if re.search(r'\\TBD\b|(?:^|\W)nan(?:\W|$)', body, re.I):
        errors.append(f'{key}: generated .tex contains TBD/nan')
    missing = []
    for row in rows:
        for cell in row:
            for num in DECIMAL.findall(str(cell)):
                if num not in body:
                    missing.append(num)
    if missing:
        errors.append(f'{key}: numeric cells absent from .tex: {sorted(set(missing))}')
    if key == 'tab_ablation':
        ids = [first_id(r[0]) for r in rows if r]
        if ids != ABLATION_ORDER:
            errors.append(f'tab_ablation: expected IDs {ABLATION_ORDER}, got {ids}')
        if any(first_id(r[0]) == 'A9' for r in rows if r):
            errors.append('tab_ablation: A9 must not be listed (covered by Table 3)')
    if key == 'tab_strat':
        labels = ' '.join(str(r[0]) for r in rows if r)
        if 'Fixed-beam-3' not in labels:
            errors.append('tab_strat: missing Fixed-beam-3 localisation row')
    if key == 'tab_main':
        labels = ' '.join(str(r[0]) for r in rows if r)
        if 'TCSN' not in labels:
            errors.append('tab_main: missing TCSN baseline row')
        if 'Fixed-beam-3' not in labels:
            errors.append('tab_main: missing Fixed-beam-3 baseline row')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--tables_dir', required=True,
                    help='directory generated by make_tables.py')
    ap.add_argument('--paper_dir', default=None,
                    help='optional paper root containing tables/')
    ap.add_argument('--json_out', default=None)
    a = ap.parse_args()

    tables_dir = Path(a.tables_dir)
    errors, warnings = [], []
    data_path = tables_dir / 'tables_data.json'
    if not data_path.exists():
        errors.append(f'missing {data_path}')
        data = {}
    else:
        try:
            data = load_json(data_path)
        except Exception as e:
            errors.append(f'cannot parse {data_path}: {e!r}')
            data = {}

    for key, expected in {**REQUIRED, **OPTIONAL}.items():
        if key in REQUIRED or key in data:
            check_table(key, expected, data, tables_dir, errors, warnings)

    if a.paper_dir:
        paper_tables = Path(a.paper_dir) / 'tables'
        check_strat_detected(Path(a.paper_dir), errors)
        for key in REQUIRED:
            src = tables_dir / f'{key}.tex'
            dst = paper_tables / f'{key}.tex'
            if not dst.exists():
                errors.append(f'paper copy missing: {dst}')
            elif (key not in MERGED_IN_PAPER and src.exists()
                  and normalized(src.read_text(encoding='utf-8')) != normalized(dst.read_text(encoding='utf-8'))):
                # tab_main / tab_strat are intentionally merged with the external
                # validation results in the paper, so they no longer match the
                # internally-generated tables byte-for-byte; the numeric-cell
                # cross-check above still applies.
                errors.append(f'paper copy differs from generated table: {dst}')


    out = {
        'ok': not errors,
        'errors': errors,
        'warnings': warnings,
        'required_tables': sorted(REQUIRED),
        'ablation_order': ABLATION_ORDER,
    }
    text = json.dumps(out, ensure_ascii=False, indent=2)
    print(text)
    if a.json_out:
        Path(a.json_out).write_text(text + '\n', encoding='utf-8')
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
