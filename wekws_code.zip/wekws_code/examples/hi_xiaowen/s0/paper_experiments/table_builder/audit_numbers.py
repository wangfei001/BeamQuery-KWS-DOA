import json, re, os, glob
from pathlib import Path
R = str(Path(__file__).resolve().parents[2])
os.chdir(R)
auth=set()
def add(x):
    try: auth.add(round(float(x),4))
    except: pass
td=json.load(open('paper_experiments/24h_plan/docs/tables/tables_data.json'))
for k,t in td.items():
    for row in t.get('rows',[]):
        for c in row:
            for m in re.findall(r'-?\d+\.\d+', str(c)): add(m)
paths = ['paper_experiments/main_model/experiment/*.json',
         'paper_experiments/24h_plan/results/baselines/**/*.json',
         'paper_experiments/external_validation/results/*.json',
         'paper_experiments/external_validation/exp/*/results.json',
         'paper_experiments/external_validation/exp/*/results_test.json',
         'paper_experiments/external_validation/exp/beamquery/stage2/*.json']
for pat in paths:
    for p in glob.glob(pat):
        try: s=open(p).read()
        except: continue
        for m in re.findall(r'-?\d+\.\d+', s): add(m)
print('authoritative distinct values:', len(auth))
files=['papaer/main_speech.tex','papaer/sections/experiments.tex','papaer/sections/discussion.tex',
       'papaer/sections/conclusion.tex','papaer/sections/introduction.tex','papaer/sections/method.tex',
       'papaer/sections/problem.tex']
bad={}
for f in files:
    if not os.path.exists(f): continue
    txt=re.sub(r'%.*','',open(f,encoding='utf-8').read())
    for m in re.findall(r'(?<![\dA-Za-z_])(\d+\.\d{3,4})(?![\dA-Za-z_])', txt):
        v=float(m)
        ok=any(abs(v-a) < 0.5*10**-3 for a in auth)
        if not ok: bad.setdefault(f,set()).add(m)
for f,v in bad.items(): print(' ',f,'->',sorted(v))
print('total suspicious:', sum(len(v) for v in bad.values()))
