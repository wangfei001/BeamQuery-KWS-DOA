# -*- coding: utf-8 -*-
"""Splice the generated result tables into the paper sources (idempotent).

Usage
-----
python sync_paper_tables.py \
    --tables_dir /path/to/docs/tables \
    --paper_dir  /path/to/papaer \

Steps
-----
1. copy every ``*.tex`` in ``--tables_dir`` into ``<paper_dir>/tables/``
2. make sure ``sections/experiments.tex`` pulls in the two *new* tables
   (``tab_angle`` before ``tab_lambda``, ``tab_threshold`` after ``tab_strat``)
"""
import argparse
import shutil
import sys
from pathlib import Path

ANGLE_ANCHOR = "\\input{tables/tab_lambda}"
THRESH_ANCHOR = "\\input{tables/tab_strat}"
COMPLEXITY_ANCHOR = "\\paragraph{Streaming inference.}"


def ensure_input(text, line, anchor, before=True):
    """Return text with `line` inserted next to the first `anchor`."""
    if line in text:
        return text, False
    idx = text.find(anchor)
    if idx < 0:
        raise SystemExit(f"anchor not found: {anchor!r}")
    if before:
        new = text[:idx] + line + "\n" + text[idx:]
    else:
        end = idx + len(anchor)
        new = text[:end] + "\n" + line + text[end:]
    return new, True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--tables_dir', required=True)
    ap.add_argument('--paper_dir', required=True)
    a = ap.parse_args()

    src = Path(a.tables_dir)
    paper = Path(a.paper_dir)
    dst = paper / 'tables'
    dst.mkdir(parents=True, exist_ok=True)

    copied = []
    for f in sorted(src.glob('*.tex')):
        shutil.copy2(f, dst / f.name)
        copied.append(f.name)
    print(f'copied {len(copied)} tables -> {dst}: {", ".join(copied)}')

    exp = paper / 'sections/experiments.tex'
    text = exp.read_text(encoding='utf-8')
    changed = []
    text, c1 = ensure_input(text, "\\input{tables/tab_angle}", ANGLE_ANCHOR, before=True)
    text, c2 = ensure_input(text, "\\input{tables/tab_threshold}", THRESH_ANCHOR, before=False)
    text, c3 = ensure_input(text, "\\input{tables/tab_complexity}", COMPLEXITY_ANCHOR, before=True)
    if c1 or c2 or c3:
        exp.write_text(text, encoding='utf-8')
        if c1:
            changed.append('+input tab_angle')
        if c2:
            changed.append('+input tab_threshold')
        if c3:
            changed.append('+input tab_complexity')
        print('patched sections/experiments.tex:', ', '.join(changed))
    else:
        print('sections/experiments.tex already wired (no change)')


if __name__ == '__main__':
    main()
