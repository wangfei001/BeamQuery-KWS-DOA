# table5_ablation — 主模型组件消融

行：**A0（完整）**、A1（dynamic query）、A2（单麦）、A3（去 presence 头）、A4（attention 池化）。
`configs/`：各变体配置；`results/`：各变体 checkpoint 与 `val_allpos.json`。
A0 即发布的主模型。
