# -*- coding: utf-8 -*-
"""为双唤醒词泛化实验构建 per-keyword 源池。

对每个关键词标签 <TAG>：
  pool_<tag>_pos.{scp,text} : 只含该关键词的语句（作为正样本池）
  pool_<tag>_neg.{scp,text} : 不含任何关键词标签的语句（作为干扰/负样本池）
两个池合并成一个 scp/text 交给生成器（生成器按 RIR_POS_TAG 划分正负）。
"""
import os, re, sys

TAG_RE = re.compile(r"<[A-Z_]+>")


def load(text_path):
    txt = {}
    with open(text_path, encoding="utf-8") as f:
        for ln in f:
            parts = ln.strip().split(maxsplit=1)
            if len(parts) == 2:
                txt[parts[0]] = parts[1]
    return txt


def load_scp(scp_path):
    d = {}
    with open(scp_path, encoding="utf-8") as f:
        for ln in f:
            parts = ln.strip().split(maxsplit=1)
            if len(parts) == 2:
                d[parts[0]] = parts[1]
    return d


def main():
    src_scp, src_text, out_dir = sys.argv[1], sys.argv[2], sys.argv[3]
    rng_seed = int(sys.argv[4]) if len(sys.argv) > 4 else 0
    scp, txt = load_scp(src_scp), load(src_text)
    tags = sorted({t for s in txt.values() for t in TAG_RE.findall(s)})
    print("发现标签:", tags)
    os.makedirs(out_dir, exist_ok=True)
    # <FILLER> 是填充词（非关键词），应作为"干扰/负样本池"，不能当关键词
    wake_tags = [t for t in tags if t != "<FILLER>"]
    # 纯干扰池：FILLER 语句（不含任何唤醒词）
    plain = [u for u in txt
             if u in scp and "<FILLER>" in txt[u]
             and not any(t in txt[u] for t in wake_tags)]
    if not plain:      # 兜底：若没有 FILLER，则用不含唤醒词的语句
        plain = [u for u in txt if u in scp
                 and not any(t in txt[u] for t in wake_tags)]
    print(f"  干扰池(FILLER) {len(plain)} 条")
    for tag in wake_tags:
        name = tag.strip("<>").lower()
        pos = [u for u in txt if u in scp and tag in txt[u]]
        keep = pos + plain
        with open(f"{out_dir}/pool_{name}.scp", "w", encoding="utf-8") as f:
            f.writelines(f"{u} {scp[u]}\n" for u in keep)
        with open(f"{out_dir}/pool_{name}.text", "w", encoding="utf-8") as f:
            f.writelines(f"{u} {txt[u]}\n" for u in keep)
        print(f"  {tag}: 正样本池 {len(pos)} 条, 干扰池 {len(plain)} 条 -> pool_{name}.scp")


if __name__ == "__main__":
    main()
