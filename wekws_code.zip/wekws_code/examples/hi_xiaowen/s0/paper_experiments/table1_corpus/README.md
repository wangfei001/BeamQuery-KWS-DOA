# table1_corpus — 主模型使用的语料

- `configs/gen_v5.yaml`：多通道语料生成配置。
- `data_lists/`：主模型训练 / 验证 / 测试用的 spatial 与 varcol 数据清单。
- `scripts/make_keyword_pools.py`：关键词与干扰词池构造。

主模型训练/评测读取的打包数组位于 `data_packed_v5/`、`data_packed_v5_largeval/`；
测试用原始波形位于 `data_v5/test_wav/`。
