# Number traceability (paper ↔ code ↔ experiments)

Every number printed in the paper must be reproducible from an experiment
artefact. Run the audit with

```bash
python paper_experiments/table_builder/audit_numbers.py
```

It cross-checks all 3–4-decimal claims in `papaer/main_speech.tex` and
`papaer/sections/*.tex` against `tables_data.json` plus every `results*.json`
produced by the main model and by the external validation.

## Source of each table

| Paper table | Generated from | Result files |
|---|---|---|
| Table 3 (angle) | `24h_plan` angle phase; selection uses validation detected-positive DOA and the table reports both detected-positive and all-positives metrics | `24h_plan/results/angles/step_*/val_allpos.json`, `24h_plan/results/angles/summary.json` |
| Table 4 (λ) | `24h_plan` λ phase | `table4_lambda/results/lw*/val_allpos.json` |
| Table 5 (ablation) | `24h_plan` ablation phase | `table5_ablation/results/A*/val_allpos.json` |
| Table 6 (detection) | `table6_detection/eval_fair_cascade.py` | `main_model/experiment/test_metrics.json`, `24h_plan/results/baselines_retrain/*/results.json`, `external_validation/exp/*/results.json` |
| Table 7 (joint) | `table7_localisation/eval_allpos_v7.py` | `main_model/experiment/test_metrics.json` (`all_positives`), `external_validation/results/*_metrics.json` |
| Table 8 (detected diagnostic) | `table7_localisation/eval_allpos_v7.py`; explicitly checks `detected_positive` + `stratified_detected` | `main_model/experiment/test_metrics.json`, `24h_plan/results/baselines/{cascade_gccphat,cascade_srpphat,fixed_beam3_frozen_mono}/test_allpos.json`, `external_validation/results/*_metrics.json` |
| Table 9 (threshold) | `table9_threshold/threshold_sweep.py` | `main_model/experiment/threshold_sweep.json` |
| Table 10 (streaming) | `table10_streaming/streaming_parallel.py` | `main_model/experiment/streaming_results.json`, `streaming_timing_100.json` |

## Derived (non-literal) quantities in the prose

These are computed from the result files rather than quoted verbatim; the audit
therefore lists them as "non-literal". Each is defined here:

| Value | Definition | Underlying measurement |
|---|---|---|
| `0.0119` | AUC range across ablations (max − min) | Table 5 AUCs |
| `0.6098` | DOA-accuracy range across ablations (max − min) | Table 5 DOA |
| `0.0066` / `0.044` / `0.108` / `0.197` | gap = overall oracle − overall realised accuracy (detected positives) | Table 8 `Gap` column |
| `0.311` / `0.798` / `0.462` | 4-decimal table values rounded to 3 decimals in prose | Tables 6–8 |
| `0.446` / `0.490` / `0.512` / `0.698` / `0.895` | hit ratios on the accepted set (hits / |D|) | `detected_positive` counters |

No other numeric claim is unsupported by an experiment file.

## Reproducibility guard

`paper_experiments/table_builder/verify_paper_numbers.py` now checks Table 8
cell-by-cell against the detected-positive JSON sources and rejects the old
error in which all-positives values were copied into the detected-positive
table. The Fixed-beam-3 in-corpus source is
`24h_plan/results/baselines/fixed_beam3_frozen_mono/test_allpos.json`.

## Dataset–model separation

* In-corpus test results use the main model in `main_model/experiment/` and the
  common in-corpus baseline checkpoints in
  `24h_plan/results/baselines_retrain/`.
* External Speech Commands results use the separately retrained models in
  `external_validation/exp/` (or their result JSONs in
  `external_validation/results/`).
* Table 6–8 only place the two result sets side by side; no checkpoint is
  shared between the in-corpus and external columns.
* Within one dataset, Fixed-beam and Fixed-beam-3 intentionally reuse the Mono
  detector, and the GCC/SRP cascades intentionally reuse the Mono detector.
  This reuse is always within the same dataset and is stated in the captions.
