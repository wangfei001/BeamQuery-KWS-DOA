#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Real-data protocol: adapt the wake decision on region B only, test on A and C.

The middle region B (broadside) is used **only** to fine-tune the wake decision;
the localisation test is run on regions A and C, which lie on the two sides of
the array.  This keeps the scored positives geometrically well separated and
never seen during adaptation.

Pipeline: same energy VAD + Mono boundary refinement, same channel subset, same
70/30 temporal split *inside B* so the adaptation set and the held-out B
segments are disjoint; A and C are test-only.

Outputs a table with the zero-shot model, the B-adapted model, and the three
training-free / simulated baselines, all on the same A+C held-out positives.
"""
from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/real_data'))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
import run_real_eval as R                      # noqa: E402
import run_real_comprehensive as C             # noqa: E402
import finetune_beamquery as FT                # noqa: E402
from paper_experiments.main_model.model import SetMatchingLoss  # noqa: E402

SR = 16000
LEN = 3 * SR
CENTERS = R.CENTERS
FN_A = 'real_a_region1.wav'   # class 0
FN_B = 'real_b_region2.wav'   # class 1  (adaptation only)
FN_C = 'real_c_region3.wav'   # class 2


def stable(segs):
    return sorted([s for s in segs if s.boundary_ok_start and s.boundary_ok_end],
                  key=lambda s: s.start)


def sample_neg(wave, sr, segs, n, rng, lo_s, hi_s, min_rms=0.01):
    M, T = wave.shape
    pos = [(int(s.start * sr), int(s.end * sr)) for s in segs]
    lo = int(lo_s * sr); hi = int(hi_s * sr)
    out, tries = [], 0
    while len(out) < n and tries < n * 200:
        tries += 1
        a = int(rng.integers(lo, max(lo + 1, hi - LEN)))
        b = a + LEN
        if b > T:
            continue
        if any(not (b <= p0 - int(0.3 * sr) or a >= p1 + int(0.3 * sr)) for p0, p1 in pos):
            continue
        if float(np.sqrt(np.mean(wave[:, a:b].mean(axis=0) ** 2))) < min_rms:
            out.append(wave[:, a:b])
    return out


@torch.no_grad()
def prob_of(model, wave, dev):
    x = torch.from_numpy(R.fix_3s(R.common_gain(wave))).float().unsqueeze(0).to(dev)
    out = model(x)
    s = out['s_q'].reshape(-1)
    cls = int(torch.argmax(s).item())
    w = out.get('wake_logit')
    p = float(torch.sigmoid(w).max().item()) if w is not None else float(torch.sigmoid(torch.max(s)).item())
    return cls, p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--channels', default='5,6')
    ap.add_argument('--out_tag', default='ch56')
    ap.add_argument('--epochs', type=int, default=50)
    ap.add_argument('--lr', type=float, default=3e-5)
    ap.add_argument('--lambda_kws', type=float, default=2.0)
    ap.add_argument('--lambda_wake', type=float, default=0.5)
    ap.add_argument('--augment', action='store_true', default=True)
    ap.add_argument('--train_scope', choices=['all','wake_only'], default='all')
    ap.add_argument('--holdout', type=float, default=0.30)
    a = ap.parse_args()
    ch = [int(x) for x in a.channels.split(',')]
    dev = R.device()
    print('device', dev, flush=True)
    mono = R.load_mono(dev)
    fixed3 = R.load_fixed_beam3(dev)
    records = C.build_segments(Path(ROOT / 'data_real'), ch, dev, mono, 0.003, 0.30)
    by = {fn: (wave, sr, segs) for fn, wave, sr, segs in records}

    # --- adaptation set: B only, with an internal 70/30 temporal split ---
    wB, srB, segsB = by[FN_B]
    stB = stable(segsB)
    if a.holdout <= 0:
        train_b, val_b = stB, stB[-max(1, len(stB)//5):]
    else:
        cut = max(1, int(round((1.0 - a.holdout) * len(stB))))
        train_b, val_b = stB[:cut], stB[cut:]
    cutoff = train_b[-1].end
    rng = np.random.default_rng(7)
    train_pos = [(wB, s) for s in train_b]
    val_pos = [(wB, s) for s in val_b]
    train_neg = sample_neg(wB, srB, segsB, 2 * len(train_b), rng, 0.0, cutoff)
    val_neg = sample_neg(wB, srB, segsB, 2 * len(val_b), rng, cutoff, wB.shape[1] / srB)
    print(f'B adaptation positives={len(train_pos)} held-out B positives={len(val_pos)}', flush=True)

    # --- test set: A and C only, all stable segments ---
    test = []
    for fn, cls in [(FN_A, 0), (FN_C, 2)]:
        w, sr, segs = by[fn]
        for s in stable(segs):
            test.append((w, sr, s, cls))
    gts = [t[3] for t in test]
    print(f'A+C test positives={len(test)}', flush=True)

    # test negatives from A and C only
    test_neg = []
    for fn in (FN_A, FN_C):
        w, sr, segs = by[fn]
        test_neg += sample_neg(w, sr, segs, max(2, len(stable(segs))), rng, 0.0, w.shape[1] / sr)

    zero = C.load_beamquery(dev, len(ch), ROOT / 'paper_experiments/main_model/experiment/best_cv.pt')
    model = C.load_beamquery(dev, len(ch), ROOT / 'paper_experiments/main_model/experiment/best_cv.pt')

    if a.train_scope == 'wake_only':
        for n, p in model.named_parameters():
            p.requires_grad = ('wake_fc' in n)
        ntr = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print('wake_only: trainable params =', ntr, flush=True)
    lk = 0.0 if a.train_scope == 'wake_only' else a.lambda_kws
    opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=a.lr, weight_decay=1e-4)
    loss_fn = SetMatchingLoss(lambda_kws=lk, lambda_presence=0.0, lambda_wake=a.lambda_wake)
    best = None
    for epoch in range(1, a.epochs + 1):
        model.train()
        order = list(range(max(len(train_pos), len(train_neg))))
        rng.shuffle(order)
        total = nb = 0.0
        for st in range(0, len(order), 16):
            idx = order[st:st + 16]
            pi = [i for i in idx if i < len(train_pos)]
            ni = [i - len(train_pos) for i in idx if i >= len(train_pos) and i - len(train_pos) < len(train_neg)]
            if not pi and not ni:
                continue
            waves, cls_b = [], []
            for i in pi:
                w0, s = train_pos[i]
                seg = w0[:, int(s.start * SR):int(s.end * SR)]
                cl = 1
                if a.augment and rng.random() < 0.5:
                    seg = seg[::-1].copy(); cl = 2 - cl
                if a.augment:
                    seg = seg * float(rng.uniform(0.6, 1.4))
                waves.append(seg); cls_b.append(cl)
            for i in ni:
                seg = train_neg[i]
                if a.augment:
                    seg = seg * float(rng.uniform(0.6, 1.4))
                waves.append(seg); cls_b.append(-1)
            x = FT.batch_tensor(waves, dev)
            out = model(x)
            b = len(waves)
            gt = torch.zeros(b, 1, dtype=torch.long, device=dev)
            valid = torch.zeros(b, 1, dtype=torch.bool, device=dev)
            kws = torch.zeros(b, dtype=torch.float32, device=dev)
            wa = torch.full((b,), -100, dtype=torch.long, device=dev)
            for j, cl in enumerate(cls_b):
                if cl >= 0:
                    gt[j, 0] = cl; valid[j, 0] = True; kws[j] = 1.0; wa[j] = cl
            loss, _ = loss_fn(pred_s=out['s_q'], gt_doa=gt, gt_valid_mask=valid, kws_label=kws,
                              wake_angle_gt=wa, pred_presence=None, pred_wake=out['wake_logit'])
            opt.zero_grad(); loss.backward(); opt.step()
            total += float(loss.item()); nb += 1
        # validation on held-out B only (wake calibration)
        model.eval()
        vp = FT.evaluate(model, [w[:, int(s.start*SR):int(s.end*SR)] for w, s in val_pos],
                         [1] * len(val_pos), val_neg, dev)
        model.train()
        score = vp['wake_rate@0.5'] - 0.5 * vp['fpr@0.5']
        if best is None or score > best[0]:
            best = (score, epoch, {k: v.detach().cpu().clone() for k, v in model.state_dict().items()})
        if epoch % 10 == 0 or epoch == a.epochs:
            print(f'ep {epoch:3d} loss={total/max(nb,1):.4f} valB wake={vp["wake_rate@0.5"]:.3f} fpr={vp["fpr@0.5"]:.3f}', flush=True)
    model.load_state_dict(best[2]); model.eval()
    print('best B-val epoch', best[1], flush=True)

    methods = ['gcc-phat', 'srp-phat', 'fixed-beam-3', 'beamquery-zero', 'beamquery-Badapt']
    P = {m: {'pred': [], 'prob': []} for m in methods}
    for w, sr, s, cls in test:
        seg = s.wave
        for m in methods:
            if m == 'beamquery-zero':
                p, q = prob_of(zero, seg, dev)
            elif m == 'beamquery-Badapt':
                p, q = prob_of(model, seg, dev)
            elif m == 'fixed-beam-3':
                p, q = R.fixed_beam3_predict(fixed3, seg, dev)
            else:
                p, q = R.cascade_predict(mono, seg, dev, m)
            P[m]['pred'].append(p); P[m]['prob'].append(q)
    report = {'configuration': {'channels_0based': ch, 'channels_1based': [c+1 for c in ch],
                                'adapt_region': 'B/region2', 'test_regions': ['A/region1', 'C/region3'],
                                'n_test_pos': len(test), 'n_test_neg': len(test_neg),
                                'n_adapt_B_pos': len(train_pos), 'epochs': a.epochs, 'lr': a.lr},
              'methods': {}}
    for m in methods:
        met = R.metrics(P[m]['pred'], gts, P[m]['prob'])
        negp = np.asarray([prob_of(zero if m == 'beamquery-zero' else model if m == 'beamquery-Badapt' else None, w, dev)[1]
                           if m.startswith('beamquery') else
                           (R.fixed_beam3_predict(fixed3, w, dev)[1] if m == 'fixed-beam-3'
                            else R.cascade_predict(mono, w, dev, m)[1]) for w in test_neg], dtype=float)
        met['fpr@0.5'] = float(np.mean(negp >= 0.5)) if len(negp) else float('nan')
        met['n_neg'] = int(len(negp))
        report['methods'][m] = met
    out = ROOT / 'paper_experiments/real_data/results'
    (out / f'real_badapt_{a.out_tag}.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    keys = ['method', 'n', 'n_neg', 'wake_rate@0.5', 'fpr@0.5', 'doa_acc_all', 'mae_all',
            'doa_acc_det', 'mae_det', 'joint_rate']
    with (out / f'real_badapt_{a.out_tag}.csv').open('w', newline='', encoding='utf-8') as f:
        wr = csv.writer(f); wr.writerow(keys)
        for m in methods:
            r = report['methods'][m]; wr.writerow([m] + [r.get(k, '') for k in keys[1:]])
    print(json.dumps(report['methods'], indent=2), flush=True)
    print('WROTE', out / f'real_badapt_{a.out_tag}.csv')


if __name__ == '__main__':
    main()
