#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Final real-recording table: adapted BeamQuery vs classical baselines.

Protocol
--------
* 8-channel recordings; region A read with `--pair_A`, region C with `--pair_C`,
  region B used for wake adaptation.
* A and C are split temporally 70/30; the 30% tail is the held-out test.
* BeamQuery: the model is adapted on the real recordings -- azimuth head +
  encoder on the A/C 70%, then the wake head on the B 70% -- and evaluated on
  the held-out A/C 30%.
* Baselines (GCC-PHAT / SRP-PHAT / Fixed-beam-3) receive no adaptation and are
  scored on the same held-out segments.
Outputs wake rate, FPR, DOA accuracy (all positives), MAE and joint.
"""
from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
import numpy as np, soundfile as sf, torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT/'paper_experiments/real_data'))
sys.path.insert(0, str(ROOT/'paper_experiments/shared/code'))
import run_real_eval as R
import run_real_comprehensive as C
import finetune_beamquery as FT
from paper_experiments.main_model.model import SetMatchingLoss

SR=16000; LEN=3*SR; CENTERS=R.CENTERS; REF=5

def stable(s): return sorted([x for x in s if x.boundary_ok_start and x.boundary_ok_end], key=lambda x:x.start)
def cut(w,s,pair): return R.common_gain(w[int(s.start*SR):int(s.end*SR)][:,pair].T)

def sample_neg(w,sr,segs,n,rng,lo_s,hi_s,pair,min_rms=0.01):
    N=w.shape[0]; pos=[(int(s.start*sr),int(s.end*sr)) for s in segs]
    lo,hi=int(lo_s*sr),int(hi_s*sr); out=[]; t=0
    while len(out)<n and t<n*200:
        t+=1
        if hi-LEN<=lo: break
        a=int(rng.integers(lo,hi-LEN)); b=a+LEN
        if b>N: continue
        if any(not(b<=p0-int(0.3*sr) or a>=p1+int(0.3*sr)) for p0,p1 in pos): continue
        ww=w[a:b][:,pair].T
        if float(np.sqrt(np.mean(ww.mean(0)**2)))<min_rms: out.append(ww)
    return out

@torch.no_grad()
def bq(model,wave,dev):
    x=torch.from_numpy(R.fix_3s(R.common_gain(wave))).float().unsqueeze(0).to(dev)
    o=model(x); s=o['s_q'].reshape(-1); w=o.get('wake_logit')
    p=float(torch.sigmoid(w).max().item()) if w is not None else float(torch.sigmoid(torch.max(s)).item())
    return int(torch.argmax(s).item()),p

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--pair_A',default='6,7'); ap.add_argument('--pair_C',default='0,1')
    ap.add_argument('--holdout',type=float,default=0.30)
    ap.add_argument('--doa_epochs',type=int,default=60); ap.add_argument('--doa_lr',type=float,default=1e-3)
    ap.add_argument('--wake_epochs',type=int,default=120); ap.add_argument('--wake_lr',type=float,default=1e-2)
    ap.add_argument('--out_tag',default='A67_C01')
    a=ap.parse_args()
    pA=[int(x) for x in a.pair_A.split(',')]; pC=[int(x) for x in a.pair_C.split(',')]
    dev=R.device(); print('device',dev,flush=True)
    mono=R.load_mono(dev); fixed3=R.load_fixed_beam3(dev)
    audio={}; segs={}
    for fn,reg in [('real_a_region1.wav',0),('real_b_region2.wav',1),('real_c_region3.wav',2)]:
        w,sr=sf.read(ROOT/'data_real'/fn,always_2d=True,dtype='float32')
        ref=w[:,[REF]].T
        iv=R.vad_intervals(ref.mean(0),sr,0.003,0.5,0.35,4.0)
        sg=R.refine_boundaries(iv,ref,sr,mono,dev,0.30)
        for x in sg: x.region=reg
        audio[fn]=w; segs[fn]=sg
    A,B,Cn='real_a_region1.wav','real_b_region2.wav','real_c_region3.wav'
    def split(fn):
        st=stable(segs[fn]); k=max(1,int(round((1-a.holdout)*len(st)))); return st[:k],st[k:]
    trA,teA=split(A); trC,teC=split(Cn); trB,vaB=split(B)
    train=[(cut(audio[A],s,pA),0) for s in trA]+[(cut(audio[Cn],s,pC),2) for s in trC]
    test=[(cut(audio[A],s,pA),0) for s in teA]+[(cut(audio[Cn],s,pC),2) for s in teC]
    print(f'DOA train={len(train)}  test={len(test)}  wake-train-B={len(trB)}',flush=True)
    rng=np.random.default_rng(5)
    train_neg_b=sample_neg(audio[B],SR,segs[B],2*len(trB),rng,0,trB[-1].end,pA)
    test_neg=sample_neg(audio[A],SR,segs[A],len(teA),rng,trA[-1].end,audio[A].shape[0]/SR,pA)\
            +sample_neg(audio[Cn],SR,segs[Cn],len(teC),rng,trC[-1].end,audio[Cn].shape[0]/SR,pC)

    model=C.load_beamquery(dev,2,ROOT/'paper_experiments/main_model/experiment/best_cv.pt')
    # ---- phase 1: azimuth (encoder + heads) on A/C train ----
    opt=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=a.doa_lr,weight_decay=1e-4)
    lf=SetMatchingLoss(lambda_kws=1.0,lambda_presence=0.0,lambda_wake=0.0)
    for ep in range(1,a.doa_epochs+1):
        model.train(); order=list(range(len(train))); rng.shuffle(order)
        for st in range(0,len(order),16):
            ids=order[st:st+16]
            waves=[train[i][0]*float(rng.uniform(0.7,1.4)) for i in ids]; cls=[train[i][1] for i in ids]
            x=FT.batch_tensor(waves,dev); out=model(x); b=len(waves)
            loss,_=lf(pred_s=out['s_q'],gt_doa=torch.tensor(cls,device=dev).unsqueeze(1),
                      gt_valid_mask=torch.ones(b,1,dtype=torch.bool,device=dev),
                      kws_label=torch.ones(b,device=dev),wake_angle_gt=torch.tensor(cls,device=dev),
                      pred_presence=None,pred_wake=None)
            opt.zero_grad(); loss.backward(); opt.step()
    # ---- phase 2: wake head only, on B ----
    for n,p in model.named_parameters(): p.requires_grad=('wake_fc' in n)
    opt=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=a.wake_lr)
    lw=SetMatchingLoss(lambda_kws=0.0,lambda_presence=0.0,lambda_wake=1.0)
    val_pos=[cut(audio[B],s,pA) for s in vaB]
    for ep in range(1,a.wake_epochs+1):
        model.train(); idx=list(range(max(len(trB),len(train_neg_b)))); rng.shuffle(idx)
        for st in range(0,len(idx),16):
            ids=idx[st:st+16]
            pi=[i for i in ids if i<len(trB)]; ni=[i-len(trB) for i in ids if i>=len(trB) and i-len(trB)<len(train_neg_b)]
            if not pi and not ni: continue
            waves=[]; lab=[]
            for i in pi: waves.append(cut(audio[B],trB[i],pA)*float(rng.uniform(0.7,1.4))); lab.append(1.0)
            for i in ni: waves.append(train_neg_b[i]*float(rng.uniform(0.7,1.4))); lab.append(0.0)
            x=FT.batch_tensor(waves,dev); out=model(x); b=len(waves)
            loss,_=lw(pred_s=out['s_q'],gt_doa=torch.zeros(b,1,dtype=torch.long,device=dev),
                      gt_valid_mask=torch.zeros(b,1,dtype=torch.bool,device=dev),
                      kws_label=torch.tensor(lab,device=dev),wake_angle_gt=torch.full((b,),-100,dtype=torch.long,device=dev),
                      pred_presence=None,pred_wake=out['wake_logit'])
            opt.zero_grad(); loss.backward(); opt.step()
    model.eval()
    # ---- evaluate ----
    preds={m:{'p':[],'q':[]} for m in ['gcc-phat','srp-phat','fixed-beam-3','beamquery']}
    gts=[c for _,c in test]
    for w,_ in test:
        for m in preds:
            if m=='beamquery': p,q=bq(model,w,dev)
            elif m=='fixed-beam-3': p,q=R.fixed_beam3_predict(fixed3,w,dev)
            else: p,q=R.cascade_predict(mono,w,dev,m)
            preds[m]['p'].append(p); preds[m]['q'].append(q)
    rep={'configuration':{'pair_A':pA,'pair_C':pC,'holdout':a.holdout,'n_test':len(test),
                          'n_test_neg':len(test_neg),'doa_epochs':a.doa_epochs,'wake_epochs':a.wake_epochs},'methods':{}}
    for m in preds:
        met=R.metrics(preds[m]['p'],gts,preds[m]['q'])
        nps=[]
        for w in test_neg:
            if m=='beamquery': nps.append(bq(model,w,dev)[1])
            elif m=='fixed-beam-3': nps.append(R.fixed_beam3_predict(fixed3,w,dev)[1])
            else: nps.append(R.cascade_predict(mono,w,dev,m)[1])
        met['fpr@0.5']=float(np.mean(np.asarray(nps)>=0.5)) if nps else float('nan')
        met['n_neg']=len(nps)
        cm=np.zeros((3,3),int)
        for p,g in zip(preds[m]['p'],gts): cm[g,p]+=1
        met['confusion']=cm.tolist()
        met['recall']={str(c): (float(cm[c,c]/cm[c].sum()) if cm[c].sum() else None) for c in (0,2)}
        rep['methods'][m]=met
    out=ROOT/'paper_experiments/real_data/results'
    (out/f'real_final_{a.out_tag}.json').write_text(json.dumps(rep,indent=2),encoding='utf-8')
    print(json.dumps({k:{kk:vv for kk,vv in v.items() if kk!='confusion'} for k,v in rep['methods'].items()},indent=2))
    print('WROTE',f'real_final_{a.out_tag}.json')

if __name__=='__main__': main()
