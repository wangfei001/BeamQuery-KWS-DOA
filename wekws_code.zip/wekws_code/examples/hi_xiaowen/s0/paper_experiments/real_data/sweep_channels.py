#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Sweep microphone groups for the main model (BeamQuery) on the real data.

For every adjacent 2-mic pair and 3-mic triplet we run the identical
VAD + boundary-refinement + 70/30 temporal split used everywhere else, then
score BeamQuery (zero-shot) and the GCC-PHAT cascade on the held-out positives.
Reported DOA/MAE are all-positives (no detection conditioning), so they are
comparable across configurations even when the wake rate is low.
"""
from __future__ import annotations
import json, sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/real_data'))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
import run_real_eval as R                      # noqa: E402
import run_real_comprehensive as C             # noqa: E402

PAIRS = [[0,1],[1,2],[2,3],[3,4],[4,5],[5,6],[6,7]]
TRIPLETS = [[0,1,2],[1,2,3],[2,3,4],[3,4,5],[4,5,6],[5,6,7]]


def evaluate(models, ch, mono, fixed3, dev):
    bq = models.get(tuple(ch))
    records = C.build_segments(Path(ROOT / 'data_real'), ch, dev, mono, 0.003, 0.30)
    _, test = C.split_records(records, 0.30)
    gts = [s.region for *_x, s in test]
    waves = [s.wave for *_x, s in test]
    out = {'channels_0based': ch, 'channels_1based': [c + 1 for c in ch],
           'n_test': len(waves)}
    # main model, zero-shot
    preds, probs = [], []
    for w in waves:
        p, q = R.beamquery_predict(bq, w, dev)
        preds.append(p); probs.append(q)
    m = R.metrics(preds, gts, probs)
    out['beamquery'] = {k: m.get(k) for k in ['wake_rate@0.5', 'doa_acc_all', 'mae_all', 'joint_rate']}
    # GCC-PHAT reference
    preds, probs = [], []
    for w in waves:
        p, q = R.cascade_predict(mono, w, dev, 'gcc-phat')
        preds.append(p); probs.append(q)
    m = R.metrics(preds, gts, probs)
    out['gcc_phat'] = {k: m.get(k) for k in ['wake_rate@0.5', 'doa_acc_all', 'mae_all', 'joint_rate']}
    return out


def main():
    dev = R.device()
    print('device', dev, flush=True)
    mono = R.load_mono(dev)
    fixed3 = R.load_fixed_beam3(dev)
    configs = PAIRS
    models = {tuple(ch): C.load_beamquery(dev, len(ch),
              ROOT / 'paper_experiments/main_model/experiment/best_cv.pt') for ch in configs}
    rows = []
    for ch in configs:
        r = evaluate(models, ch, mono, fixed3, dev)
        rows.append(r)
        bq = r['beamquery']; gp = r['gcc_phat']
        print(f"{str(ch):12s} BQ: wake={bq['wake_rate@0.5']:.3f} doa={bq['doa_acc_all']:.3f} "
              f"mae={bq['mae_all']:.1f} joint={bq['joint_rate']:.3f} | "
              f"GCC: doa={gp['doa_acc_all']:.3f} mae={gp['mae_all']:.1f}", flush=True)
    rows.sort(key=lambda r: r['beamquery']['doa_acc_all'], reverse=True)
    print('\n=== sorted by BeamQuery all-positives DOA ===')
    for r in rows:
        print(f"{str(r['channels_0based']):12s} doa={r['beamquery']['doa_acc_all']:.3f} "
              f"mae={r['beamquery']['mae_all']:.1f} wake={r['beamquery']['wake_rate@0.5']:.3f}")
    (ROOT / 'paper_experiments/real_data/results/channel_sweep.json').write_text(
        json.dumps(rows, indent=2), encoding='utf-8')
    print('WROTE results/channel_sweep.json')


if __name__ == '__main__':
    main()
