#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Confusion matrices (true region x predicted class) for the mic-order question.

If the physical array were wired reversed, a correct localiser fed the wrong
order would produce an anti-diagonal (0<->2) confusion.  We tabulate the full
matrix for the classical estimator and both fine-tunes so the mapping is
unambiguous.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/real_data'))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
import run_real_eval as R                      # noqa: E402
import run_real_comprehensive as C             # noqa: E402


@torch.no_grad()
def raw_predict(model, wave, dev):
    x = torch.from_numpy(R.fix_3s(R.common_gain(wave))).float().unsqueeze(0).to(dev)
    s = model(x)['s_q'].reshape(-1)
    return int(torch.argmax(s).item())


def cm(preds, gts):
    M = np.zeros((3, 3), dtype=int)
    for p, g in zip(preds, gts):
        M[g, p] += 1
    return M


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--channels', default='5,6')
    a = ap.parse_args()
    ch = [int(x) for x in a.channels.split(',')]
    dev = R.device()
    mono = R.load_mono(dev)
    records = C.build_segments(Path(ROOT / 'data_real'), ch, dev, mono, 0.003, 0.30)
    _, test = C.split_records(records, 0.30)
    gts = [s.region for *_x, s in test]
    waves = [s.wave for *_x, s in test]

    out = {}
    # classical estimator, both input orders
    for order, mir in [('[5,6]', None), ('[6,5]', False)]:
        preds = []
        for w in waves:
            win = w if mir is None else w[::-1]
            cls = int(R.estimate_doa_class(R.common_gain(win), fs=16000, spacing=0.033, method='gcc-phat'))
            if mir:
                cls = 2 - cls
            preds.append(cls)
        out[f'gcc-phat {order}'] = cm(preds, gts)
    # fine-tuned models on their own order
    for name, ckpt, order, mir in [
        ('ft_ch56 on [5,6]', 'beamquery_finetuned_ch56_loc50.pt', '[5,6]', None),
        ('ft_ch56 on [6,5]', 'beamquery_finetuned_ch56_loc50.pt', '[6,5]', False),
        ('ft_corrected65 on [6,5]', 'beamquery_finetuned_corrected65_loc50.pt', '[6,5]', False),
        ('ft_corrected65 on [5,6]', 'beamquery_finetuned_corrected65_loc50.pt', '[5,6]', None),
    ]:
        model = C.load_beamquery(dev, len(ch), ROOT / 'paper_experiments/real_data/results' / ckpt)
        preds = []
        for w in waves:
            win = w if mir is None else w[::-1]
            cls = raw_predict(model, win, dev)
            if mir:
                cls = 2 - cls
            preds.append(cls)
        out[name] = cm(preds, gts)

    print('rows = true region (0=A,1=B,2=C); cols = predicted class (0,1,2)')
    for k, m in out.items():
        print(f'\n{k}')
        print(m)
        print('  acc =', round(np.trace(m) / m.sum(), 3))
    (ROOT / 'paper_experiments/real_data/results/confusion_mic_order.json').write_text(
        json.dumps({k: v.tolist() for k, v in out.items()}, indent=2), encoding='utf-8')
    print('\nWROTE results/confusion_mic_order.json')


if __name__ == '__main__':
    main()
