#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Per-class microphone selection test.

Requested protocol: class A (region 1) is evaluated with microphones 7-8
(zero-based 6,7) and class C (region 3) with microphones 1-2 (zero-based 0,1).
Region B (middle) is used only to adapt the wake head, exactly as in
``run_real_badapt.py``.

Segmentation is done once on a fixed reference channel (default channel 5) so
that the segment set does not depend on the evaluation pair; the per-class pair
is then cut from the stored 8-channel waveform.

Reported per method on the A+C test set:
  wake rate, FPR, DOA accuracy (all positives), MAE, joint.
"""
from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
import numpy as np
import soundfile as sf
import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/real_data'))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
import run_real_eval as R                      # noqa: E402
import run_real_comprehensive as C             # noqa: E402
import finetune_beamquery as FT                # noqa: E402
from paper_experiments.main_model.model import SetMatchingLoss  # noqa: E402

SR = 16000
LEN = 3 * SR
CENTERS = R.CENTERS
FILES = [('real_a_region1.wav', 0), ('real_b_region2.wav', 1), ('real_c_region3.wav', 2)]


def cut(audio, s, pair):
    return R.common_gain(audio[int(s.start * SR):int(s.end * SR)][:, pair].T)


def stable(segs):
    return sorted([s for s in segs if s.boundary_ok_start and s.boundary_ok_end], key=lambda s: s.start)


def sample_neg(audio, sr, segs, n, rng, lo_s, hi_s, pair, min_rms=0.01):
    # audio is [n_samples, n_channels]
    Nsamp = audio.shape[0]
    pos = [(int(s.start * sr), int(s.end * sr)) for s in segs]
    lo, hi = int(lo_s * sr), int(hi_s * sr)
    out, tries = [], 0
    while len(out) < n and tries < n * 200:
        tries += 1
        if hi - LEN <= lo:
            break
        a = int(rng.integers(lo, hi - LEN))
        b = a + LEN
        if b > Nsamp:
            continue
        if any(not (b <= p0 - int(0.3 * sr) or a >= p1 + int(0.3 * sr)) for p0, p1 in pos):
            continue
        w = audio[a:b][:, pair].T
        if float(np.sqrt(np.mean(w.mean(axis=0) ** 2))) < min_rms:
            out.append(w)
    return out


@torch.no_grad()
def prob_of(model, wave, dev):
    x = torch.from_numpy(R.fix_3s(R.common_gain(wave))).float().unsqueeze(0).to(dev)
    out = model(x)
    s = out['s_q'].reshape(-1)
    cls = int(torch.argmax(s).item())
    w = out.get('wake_logit')
    p = float(torch.sigmoid(w).max().item()) if w is not None else float(torch.sigmoid(torch.max(s)).item())
    return cls, p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pair_A', default='6,7', help='zero-based pair for class A')
    ap.add_argument('--pair_C', default='0,1', help='zero-based pair for class C')
    ap.add_argument('--ref_channel', type=int, default=5)
    ap.add_argument('--out_tag', default='A67_C01')
    ap.add_argument('--epochs', type=int, default=120)
    ap.add_argument('--lr', type=float, default=0.01)
    ap.add_argument('--lambda_wake', type=float, default=1.0)
    a = ap.parse_args()
    pair_A = [int(x) for x in a.pair_A.split(',')]
    pair_C = [int(x) for x in a.pair_C.split(',')]
    dev = R.device()
    print('device', dev, flush=True)
    mono = R.load_mono(dev)
    fixed3 = R.load_fixed_beam3(dev)

    audio = {}
    segs = {}
    for fn, region in FILES:
        w, sr = sf.read(ROOT / 'data_real' / fn, always_2d=True, dtype='float32')
        ref = w[:, [a.ref_channel]].T
        iv = R.vad_intervals(ref.mean(axis=0), sr, 0.003, 0.5, 0.35, 4.0)
        sg = R.refine_boundaries(iv, ref, sr, mono, dev, 0.30)
        for s in sg:
            s.region = region
        audio[fn] = w; segs[fn] = sg
        print(f'{fn}: {len(sg)} accepted / {len(iv)} candidates', flush=True)

    fnA, fnB, fnC = [f for f, _ in FILES]
    stB = stable(segs[fnB])
    cutB = max(1, int(round(0.7 * len(stB))))
    trB, vaB = stB[:cutB], stB[cutB:]
    rng = np.random.default_rng(11)
    # adaptation set: B with BOTH class pairs so the wake head does not favour one
    train_pos = []
    for s in trB:
        for pr in (pair_A, pair_C):
            train_pos.append(cut(audio[fnB], s, pr))
    val_pos = []
    for s in vaB:
        for pr in (pair_A, pair_C):
            val_pos.append(cut(audio[fnB], s, pr))
    cutB_s = trB[-1].end
    train_neg = sample_neg(audio[fnB], SR, segs[fnB], 2 * len(train_pos), rng, 0.0, cutB_s, pair_A)
    train_neg += sample_neg(audio[fnB], SR, segs[fnB], 2 * len(train_pos), rng, 0.0, cutB_s, pair_C)
    val_neg = sample_neg(audio[fnB], SR, segs[fnB], 2 * len(val_pos), rng, cutB_s, audio[fnB].shape[0] / SR, pair_A)
    if not val_neg:
        val_neg = sample_neg(audio[fnB], SR, segs[fnB], max(2, len(val_pos)), rng, 0.0, audio[fnB].shape[0] / SR, pair_A)
    if not val_neg:
        val_neg = train_neg[:max(1, len(val_pos))]

    test = []
    for s in stable(segs[fnA]):
        test.append((cut(audio[fnA], s, pair_A), 0))
    for s in stable(segs[fnC]):
        test.append((cut(audio[fnC], s, pair_C), 2))
    gts = [t[1] for t in test]
    print(f'adaptation positives={len(train_pos)}  A+C test positives={len(test)}', flush=True)

    test_neg = sample_neg(audio[fnA], SR, segs[fnA], len(stable(segs[fnA])), rng, 0.0, audio[fnA].shape[0]/SR, pair_A)
    test_neg += sample_neg(audio[fnC], SR, segs[fnC], len(stable(segs[fnC])), rng, 0.0, audio[fnC].shape[0]/SR, pair_C)

    zero = C.load_beamquery(dev, 2, ROOT / 'paper_experiments/main_model/experiment/best_cv.pt')
    model = C.load_beamquery(dev, 2, ROOT / 'paper_experiments/main_model/experiment/best_cv.pt')
    for n, p in model.named_parameters():
        p.requires_grad = ('wake_fc' in n)
    opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=a.lr)
    loss_fn = SetMatchingLoss(lambda_kws=0.0, lambda_presence=0.0, lambda_wake=a.lambda_wake)
    best = None
    for ep in range(1, a.epochs + 1):
        model.train()
        idx = list(range(max(len(train_pos), len(train_neg))))
        rng.shuffle(idx)
        for st in range(0, len(idx), 16):
            ids = idx[st:st + 16]
            pi = [i for i in ids if i < len(train_pos)]
            ni = [i - len(train_pos) for i in ids if i >= len(train_pos) and i - len(train_pos) < len(train_neg)]
            if not pi and not ni:
                continue
            waves, cl = [], []
            for i in pi:
                w = train_pos[i] * float(rng.uniform(0.6, 1.4)); waves.append(w); cl.append(1)
            for i in ni:
                w = train_neg[i] * float(rng.uniform(0.6, 1.4)); waves.append(w); cl.append(-1)
            x = FT.batch_tensor(waves, dev)
            out = model(x)
            b = len(waves)
            kws = torch.tensor([1.0 if c >= 0 else 0.0 for c in cl], device=dev)
            loss, _ = loss_fn(pred_s=out['s_q'], gt_doa=torch.zeros(b, 1, dtype=torch.long, device=dev),
                              gt_valid_mask=torch.zeros(b, 1, dtype=torch.bool, device=dev),
                              kws_label=kws, wake_angle_gt=torch.full((b,), -100, dtype=torch.long, device=dev),
                              pred_presence=None, pred_wake=out['wake_logit'])
            opt.zero_grad(); loss.backward(); opt.step()
        model.eval()
        vp = FT.evaluate(model, val_pos, [1] * len(val_pos), val_neg, dev)
        model.train()
        sc = vp['wake_rate@0.5'] - 0.5 * vp['fpr@0.5']
        if best is None or sc > best[0]:
            best = (sc, ep, {k: v.detach().cpu().clone() for k, v in model.state_dict().items()})
        if ep % 20 == 0 or ep == a.epochs:
            print(f'ep {ep:3d} valB wake={vp["wake_rate@0.5"]:.3f} fpr={vp["fpr@0.5"]:.3f}', flush=True)
    model.load_state_dict(best[2]); model.eval()
    print('best B-val epoch', best[1], flush=True)

    methods = ['gcc-phat', 'srp-phat', 'beamquery-zero', 'beamquery-Badapt']
    P = {m: {'pred': [], 'prob': []} for m in methods}
    for w, gt in test:
        for m in methods:
            if m == 'beamquery-zero':
                p, q = prob_of(zero, w, dev)
            elif m == 'beamquery-Badapt':
                p, q = prob_of(model, w, dev)
            else:
                p, q = R.cascade_predict(mono, w, dev, m)
            P[m]['pred'].append(p); P[m]['prob'].append(q)
    report = {'configuration': {'pair_A': pair_A, 'pair_C': pair_C, 'ref_channel': a.ref_channel,
                                'test_regions': ['A/region1', 'C/region3'], 'adapt_region': 'B/region2',
                                'n_test_pos': len(test), 'n_test_neg': len(test_neg)},
              'methods': {}}
    for m in methods:
        met = R.metrics(P[m]['pred'], gts, P[m]['prob'])
        nps = []
        for w in test_neg:
            if m == 'beamquery-zero':
                nps.append(prob_of(zero, w, dev)[1])
            elif m == 'beamquery-Badapt':
                nps.append(prob_of(model, w, dev)[1])
            elif m == 'gcc-phat' or m == 'srp-phat':
                nps.append(R.cascade_predict(mono, w, dev, m)[1])
        met['fpr@0.5'] = float(np.mean(np.asarray(nps) >= 0.5)) if nps else float('nan')
        met['n_neg'] = len(nps)
        cm = np.zeros((3, 3), dtype=int)
        for pp, gg in zip(P[m]['pred'], gts):
            cm[gg, pp] += 1
        met['confusion'] = cm.tolist()
        met['per_region_recall'] = {str(r): (float(cm[r, r] / cm[r].sum()) if cm[r].sum() else None) for r in (0, 2)}
        report['methods'][m] = met
    out = ROOT / 'paper_experiments/real_data/results'
    (out / f'real_perclass_{a.out_tag}.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print('rows = true region (0=A, 2=C); cols = predicted class (0,1,2)')
    for m in methods:
        print(f'\n{m}: DOA={report["methods"][m]["doa_acc_all"]:.3f} '
              f'recallA={report["methods"][m]["per_region_recall"]["0"]} '
              f'recallC={report["methods"][m]["per_region_recall"]["2"]}')
        print(np.array(report['methods'][m]['confusion']))
    print(json.dumps(report['methods'], indent=2), flush=True)
    print('WROTE', out / f'real_perclass_{a.out_tag}.json')


if __name__ == '__main__':
    main()
