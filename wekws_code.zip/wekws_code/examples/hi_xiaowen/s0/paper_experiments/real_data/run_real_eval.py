#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Real-recording wake-word segmentation and Table-7 localisation evaluation.

Inputs are the three 8-channel recordings in ``data_real``:
  * real_a_region1.wav  -> ground-truth azimuth class 0 (30 deg)
  * real_b_region2.wav  -> ground-truth azimuth class 1 (90 deg)
  * real_c_region3.wav  -> ground-truth azimuth class 2 (150 deg)

Channels 4,5,6 (1-based) are retained. Wake-word candidates are obtained by
energy VAD, then their start/end boundaries are refined with the trained Mono
wake-word model.  The same model is used for cascade detection; BeamQuery and
Fixed-beam-3 are evaluated with their Table-7 checkpoints/weights.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
sys.path.insert(0, str(ROOT / 'paper_experiments/main_model'))

from paper_experiments.shared.code.models import ModelFactory  # noqa: E402
from paper_experiments.shared.code.batched_model import BatchedSpatialDynamicQuery  # noqa: E402
from paper_experiments.shared.code.doa_classical import estimate_doa_class  # noqa: E402

SPEED = 340.0
CENTERS = np.array([30.0, 90.0, 150.0], dtype=np.float64)


@dataclass
class Segment:
    region: int
    start: float
    end: float
    score: float
    boundary_ok_start: bool
    boundary_ok_end: bool
    wave: np.ndarray  # [3, T], float32


def device() -> torch.device:
    return torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


def common_gain(w: np.ndarray) -> np.ndarray:
    w = np.asarray(w, dtype=np.float32)
    peak = float(np.max(np.abs(w))) if w.size else 1.0
    if peak < 1e-7:
        return w
    return (w / peak) * 0.9


def fix_3s(w: np.ndarray, sr: int = 16000, max_sec: float = 3.0) -> np.ndarray:
    """Pad/truncate to the fixed 3 s training length."""
    n = int(max_sec * sr)
    w = np.asarray(w, dtype=np.float32)
    if w.shape[-1] < n:
        pad = [(0, 0)] * (w.ndim - 1) + [(0, n - w.shape[-1])]
        return np.pad(w, pad)
    return w[..., :n]


def vad_intervals(y: np.ndarray, sr: int, threshold: float,
                  merge_gap_s: float, min_s: float, max_s: float):
    """Energy VAD with hysteresis-free threshold and silence merging."""
    win = int(0.02 * sr)
    hop = int(0.01 * sr)
    if len(y) < win:
        return []
    rms = np.array([
        np.sqrt(np.mean(y[i:i + win] ** 2))
        for i in range(0, len(y) - win + 1, hop)
    ])
    active = rms > threshold
    runs = []
    s = None
    for i, v in enumerate(active):
        if v and s is None:
            s = i
        if not v and s is not None:
            runs.append([s, i - 1])
            s = None
    if s is not None:
        runs.append([s, len(active) - 1])

    merged = []
    for a, b in runs:
        if not merged or (a - merged[-1][1]) * hop / sr > merge_gap_s:
            merged.append([a, b])
        else:
            merged[-1][1] = b

    out = []
    for a, b in merged:
        # VAD frame edges plus a small context, clipped to the recording.
        aa = max(0, a * hop - int(0.15 * sr))
        bb = min(len(y), b * hop + win + int(0.15 * sr))
        dur = (bb - aa) / sr
        if min_s <= dur <= max_s:
            out.append((aa, bb))
    return out


def load_mono(dev: torch.device):
    p = ROOT / 'paper_experiments/24h_plan/results/baselines_retrain/mono/best_cv.pt'
    ck = torch.load(p, map_location='cpu', weights_only=False)
    a = ck['args']
    m = ModelFactory.create(
        'mono', num_layers=a['num_layers'], hidden_dim=a['hidden_dim'],
        pool_type=a['pool_type'], encoder_type=a['encoder_type'],
        causal=a['causal'], norm_type=a['norm_type']).to(dev)
    m.load_state_dict(ck['model'])
    m.eval()
    return m


def load_beamquery(dev: torch.device, num_mic: int):
    import yaml
    cfg_path = ROOT / 'paper_experiments/main_model/experiment/config.yaml'
    cfg = yaml.safe_load(cfg_path.read_text(encoding='utf-8'))
    m = BatchedSpatialDynamicQuery(
        fsmn_num_layers=cfg['fsmn_num_layers'], fsmn_dim=cfg['fsmn_dim'],
        num_query=cfg['num_query'], doa_num_class=cfg['doa_num_class'],
        feat_freq_dim=cfg['feat_freq_dim'], use_ipd=cfg.get('use_ipd', True),
        use_pair_ipd=cfg.get('use_pair_ipd', True), num_mic=num_mic,
        pool_type=cfg['pool_type'], pair_feat_mode=cfg['pair_feat_mode'],
        mic_spacing=cfg['mic_spacing'], sr=cfg['sr'],
        use_query_embed=cfg['use_query_embed'],
        use_presence_head=cfg['use_presence_head'],
        use_wake_head=cfg['use_wake_head'], wake_detach=cfg['wake_detach'],
        query_mode=cfg['query_mode'], beam_step_deg=cfg['beam_step_deg'],
        causal=cfg['causal'], norm_type=cfg['norm_type'],
        mel_compress=cfg.get('mel_compress', 0),
        mel_keep_coh=cfg.get('mel_keep_coh', False),
        encoder_type=cfg.get('encoder_type', 'auto')).to(dev)
    ck = torch.load(ROOT / 'paper_experiments/main_model/experiment/best_cv.pt',
                    map_location='cpu', weights_only=False)
    m.load_state_dict(ck['model'])
    m.eval()
    return m


def load_fixed_beam3(dev: torch.device):
    p = ROOT / 'paper_experiments/24h_plan/results/baselines_retrain/mono/best_cv.pt'
    ck = torch.load(p, map_location='cpu', weights_only=False)
    a = ck['args']
    m = ModelFactory.create(
        'fixed-beam-3', steer_degs=(30.0, 90.0, 150.0), num_mic=3,
        mic_spacing=0.033, sr=16000, num_layers=a['num_layers'],
        hidden_dim=a['hidden_dim'], pool_type=a['pool_type'],
        encoder_type=a['encoder_type'], causal=a['causal'],
        norm_type=a['norm_type']).to(dev)
    mono_sd = {f'kws.{k}': v for k, v in ck['model'].items()}
    missing, unexpected = m.load_state_dict(mono_sd, strict=False)
    if unexpected:
        raise RuntimeError(f'Unexpected fixed-beam-3 weights: {unexpected[:5]}')
    m.eval()
    return m


@torch.no_grad()
def mono_prob(model, wave3: np.ndarray, dev: torch.device) -> float:
    # Mono consumes the first selected channel (channel 4).
    w = fix_3s(common_gain(wave3[0]))
    x = torch.from_numpy(w).float().unsqueeze(0).unsqueeze(0).to(dev)
    s = model(x)['s_q'].reshape(-1)[0].item()
    return float(1.0 / (1.0 + math.exp(-s)))


def refine_boundaries(intervals, wave3, sr, mono, dev, threshold,
                      deltas=(-0.10, 0.0, 0.10)):
    """Use the wake model to select the best small start/end adjustment."""
    out = []
    for aa, bb in intervals:
        base_score = mono_prob(mono, wave3[:, aa:bb], dev)
        if base_score < threshold * 0.75:
            continue
        best = None
        for ds in deltas:
            for de in deltas:
                s0 = max(0, aa + int(ds * sr))
                s1 = min(wave3.shape[1], bb + int(de * sr))
                if s1 - s0 < int(0.3 * sr) or s1 - s0 > int(4.0 * sr):
                    continue
                score = mono_prob(mono, wave3[:, s0:s1], dev)
                if best is None or score > best[0]:
                    best = (score, s0, s1)
        if best is None or best[0] < threshold:
            continue
        score, s0, s1 = best
        base = score
        trim_start = mono_prob(mono, wave3[:, min(s1, s0 + int(0.075 * sr)):s1], dev)
        trim_end = mono_prob(mono, wave3[:, s0:max(s0 + int(0.3 * sr), s1 - int(0.075 * sr))], dev)
        out.append(Segment(
            region=-1, start=s0 / sr, end=s1 / sr, score=base,
            boundary_ok_start=base + 1e-6 >= trim_start,
            boundary_ok_end=base + 1e-6 >= trim_end,
            wave=common_gain(wave3[:, s0:s1])))
    return out


@torch.no_grad()
def beamquery_predict(model, wave3: np.ndarray, dev: torch.device):
    x = torch.from_numpy(fix_3s(common_gain(wave3))).float().unsqueeze(0).to(dev)
    out = model(x)
    s = out['s_q'].reshape(-1)
    pred_cls = int(torch.argmax(s).item())
    wake = out.get('wake_logit')
    if wake is None:
        prob = float(torch.sigmoid(torch.max(s)).item())
    else:
        prob = float(torch.sigmoid(wake).max().item())
    return pred_cls, prob


@torch.no_grad()
def fixed_beam3_predict(model, wave3: np.ndarray, dev: torch.device):
    x = torch.from_numpy(fix_3s(common_gain(wave3))).float().unsqueeze(0).to(dev)
    out = model(x)
    s = out['s_q'].reshape(-1)
    return int(torch.argmax(s).item()), float(torch.sigmoid(torch.max(s)).item())


@torch.no_grad()
def cascade_predict(mono, wave3: np.ndarray, dev: torch.device, method: str):
    w = common_gain(wave3)
    cls = int(estimate_doa_class(w, fs=16000, spacing=0.033, method=method))
    # Delay-and-sum at the estimated class centre, then Mono detection.
    ang = CENTERS[cls]
    M, T = w.shape
    pos = (np.arange(M) - (M - 1) / 2.0) * 0.033
    tau = pos * math.cos(math.radians(float(ang))) / SPEED
    delays = np.round(tau * 16000).astype(int)
    n = T + int(np.max(delays) - np.min(delays))
    acc = np.zeros(n, dtype=np.float64)
    for m in range(M):
        start = int(delays[m] - np.min(delays))
        acc[start:start + T] += w[m]
    beam = fix_3s((acc / M).astype(np.float32))
    prob = mono_prob(mono, np.stack([beam, beam, beam], axis=0), dev)
    return cls, prob


def metrics(pred_cls, gt_cls, probs, threshold=0.5):
    pred_cls = np.asarray(pred_cls, dtype=int)
    gt_cls = np.asarray(gt_cls, dtype=int)
    probs = np.asarray(probs, dtype=float)
    err = np.abs(CENTERS[pred_cls] - CENTERS[gt_cls])
    det = probs >= threshold
    out = {
        'n': int(len(gt_cls)),
        'wake_rate@0.5': float(np.mean(det)) if len(gt_cls) else float('nan'),
        'doa_acc_all': float(np.mean(pred_cls == gt_cls)) if len(gt_cls) else float('nan'),
        'mae_all': float(np.mean(err)) if len(gt_cls) else float('nan'),
    }
    if det.any():
        out.update({
            'n_det': int(det.sum()),
            'doa_acc_det': float(np.mean(pred_cls[det] == gt_cls[det])),
            'mae_det': float(np.mean(err[det])),
            'joint_rate': float(np.mean(det & (pred_cls == gt_cls))),
        })
    else:
        out.update({'n_det': 0, 'doa_acc_det': float('nan'),
                    'mae_det': float('nan'), 'joint_rate': 0.0})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data_dir', default=str(ROOT / 'data_real'))
    ap.add_argument('--out_dir', default=str(ROOT / 'paper_experiments/real_data/results'))
    ap.add_argument('--vad_threshold', type=float, default=0.003)
    ap.add_argument('--wake_threshold', type=float, default=0.30)
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--channels', default='4,5,6', help='two or three zero-based channel indices')
    ap.add_argument('--out_tag', default='ch456')
    a = ap.parse_args()
    data_dir = Path(a.data_dir)
    out_dir = Path(a.out_dir)
    channels = [int(x) for x in a.channels.split(',')]
    if len(channels) not in (2, 3) or any(c < 0 or c >= 8 for c in channels):
        raise SystemExit('--channels must contain two or three zero-based indices in [0,7]')
    out_dir.mkdir(parents=True, exist_ok=True)

    inputs = [
        ('real_a_region1.wav', 0),
        ('real_b_region2.wav', 1),
        ('real_c_region3.wav', 2),
    ]
    dev = device()
    print('device', dev, flush=True)
    mono = load_mono(dev)
    beamquery = load_beamquery(dev, len(channels))
    fixed3 = load_fixed_beam3(dev)

    all_segments = []
    manifest = []
    for file_name, region in inputs:
        path = data_dir / file_name
        audio, sr = sf.read(path, always_2d=True, dtype='float32')
        if audio.shape[1] < 6:
            raise RuntimeError(f'{path}: expected at least 7 channels, got {audio.shape[1]}')
        wave3 = audio[:, channels].T.copy()
        y = wave3.mean(axis=0)
        intervals = vad_intervals(y, sr, a.vad_threshold, 0.5, 0.35, 4.0)
        segs = refine_boundaries(intervals, wave3, sr, mono, dev, a.wake_threshold)
        if a.limit:
            segs = segs[:a.limit]
        for i, seg in enumerate(segs):
            seg.region = region
            all_segments.append(seg)
            manifest.append({
                'file': file_name, 'region': region + 1, 'segment': i,
                'start_s': seg.start, 'end_s': seg.end,
                'wake_prob': seg.score,
                'boundary_ok_start': seg.boundary_ok_start,
                'boundary_ok_end': seg.boundary_ok_end,
            })
            seg_dir = out_dir / 'segments' / f'region{region + 1}'
            seg_dir.mkdir(parents=True, exist_ok=True)
            sf.write(seg_dir / f'{file_name[:6]}_{i:04d}.wav', seg.wave.T, sr)
        print(file_name, 'accepted', len(segs), 'of', len(intervals), flush=True)

    stable_segments = [
        s for s in all_segments
        if s.boundary_ok_start and s.boundary_ok_end
    ]
    methods = ['gcc-phat', 'srp-phat', 'fixed-beam-3', 'beamquery']
    predictions = {m: {'pred': [], 'prob': []} for m in methods}
    gt = []
    for seg in stable_segments:
        gt.append(seg.region)
        for method in methods:
            if method == 'beamquery':
                pred, prob = beamquery_predict(beamquery, seg.wave, dev)
            elif method == 'fixed-beam-3':
                pred, prob = fixed_beam3_predict(fixed3, seg.wave, dev)
            else:
                pred, prob = cascade_predict(mono, seg.wave, dev, method)
            predictions[method]['pred'].append(pred)
            predictions[method]['prob'].append(prob)

    report = {
        'configuration': {
            'input_channels_0based': channels,
            'input_channels_1based': [c + 1 for c in channels],
            'array_spacing_m': 0.033,
            'vad_threshold': a.vad_threshold,
            'wake_threshold': a.wake_threshold,
            'region_centers_deg': CENTERS.tolist(),
            'note': 'A/B/C ground truth regions are 1/2/3; all segments are treated as wake-word positives.'
        },
        'segments': manifest,
        'segment_counts': {
            'all_accepted': len(all_segments),
            'boundary_stable': len(stable_segments),
            'region1': sum(1 for s in all_segments if s.region == 0),
            'region2': sum(1 for s in all_segments if s.region == 1),
            'region3': sum(1 for s in all_segments if s.region == 2),
            'boundary_ok_start': sum(1 for s in all_segments if s.boundary_ok_start),
            'boundary_ok_end': sum(1 for s in all_segments if s.boundary_ok_end),
        },
        'methods': {},
    }
    for method in methods:
        report['methods'][method] = metrics(
            predictions[method]['pred'], gt, predictions[method]['prob'])
    with (out_dir / f'real_predictions_{a.out_tag}.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['segment', 'region', 'method', 'pred_class', 'ground_truth', 'prob'])
        for i, seg in enumerate(stable_segments):
            for method in methods:
                w.writerow([i, seg.region + 1, method,
                            predictions[method]['pred'][i], gt[i],
                            predictions[method]['prob'][i]])
    serial = json.loads(json.dumps(report))
    (out_dir / f'real_table7_report_{a.out_tag}.json').write_text(
        json.dumps(serial, indent=2, ensure_ascii=False), encoding='utf-8')
    with (out_dir / f'real_table7_metrics_{a.out_tag}.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        keys = ['method', 'n', 'wake_rate@0.5', 'n_det', 'doa_acc_all', 'mae_all',
                'doa_acc_det', 'mae_det', 'joint_rate']
        w.writerow(keys)
        for method in methods:
            row = report['methods'][method]
            w.writerow([method] + [row.get(k, '') for k in keys[1:]])
    print(json.dumps({m: report['methods'][m] for m in methods}, indent=2), flush=True)


if __name__ == '__main__':
    main()
