#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Robust per-region TDOA (samples) for every adjacent mic pair.

With 3.3 cm spacing the true inter-mic TDOA cannot exceed d/c = 97 us = 1.55
samples, so the GCC-PHAT lag search is restricted to +/-4 samples and we report
mean and median lag, which removes the large spurious peaks.
"""
from __future__ import annotations
import sys, math
from pathlib import Path
import numpy as np, soundfile as sf, torch
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT/'paper_experiments/real_data'))
sys.path.insert(0, str(ROOT/'paper_experiments/shared/code'))
import run_real_eval as R
from paper_experiments.shared.code.doa_classical import _stft, delay_to_angle

SR=16000; REF=5; SP=0.033

def stable(s): return sorted([x for x in s if x.boundary_ok_start and x.boundary_ok_end], key=lambda x:x.start)

def lag_frames(sig, ref, max_delay=4, n_fft=512, hop=160):
    n=min(len(sig),len(ref)); sig,ref=sig[:n],ref[:n]
    X1=_stft(sig,n_fft,hop); X2=_stft(ref,n_fft,hop)
    X=X1*np.conj(X2); Xp=X/(np.abs(X)+1e-10)
    cc=np.fft.irfft(Xp,n=n_fft,axis=0); cc=np.roll(cc,n_fft//2,axis=0)
    lo,hi=n_fft//2-max_delay,n_fft//2+max_delay+1
    lags=np.argmax(cc[lo:hi],axis=0)-max_delay
    return lags

def main():
    dev=R.device(); mono=R.load_mono(dev)
    segwave={}
    for fn,reg in [('real_a_region1.wav',0),('real_b_region2.wav',1),('real_c_region3.wav',2)]:
        w,sr=sf.read(ROOT/'data_real'/fn, always_2d=True, dtype='float32')
        ref=w[:,[REF]].T
        iv=R.vad_intervals(ref.mean(0),sr,0.003,0.5,0.35,4.0)
        sg=R.refine_boundaries(iv,ref,sr,mono,dev,0.30)
        for s in sg: s.region=reg
        segwave[fn]=(w,sg)
    print('per-pair median lag (samples);  d/c = 1.55 samples max')
    print(f'{"pair":>6s} | {"A":>7s} {"B":>7s} {"C":>7s}   (A=region1, B=2, C=3)')
    for i in range(7):
        pair=[i,i+1]; row=[]
        for fn,_ in [('real_a_region1.wav',0),('real_b_region2.wav',1),('real_l_c',2)][:2]+[('real_c_region3.wav',2)]:
            pass
        for fn in ['real_a_region1.wav','real_b_region2.wav','real_c_region3.wav']:
            w,sg=segwave[fn]; lags=[]
            for s in stable(sg):
                seg=w[int(s.start*SR):int(s.end*SR)][:,pair].T.astype(np.float64)
                seg=seg/(np.max(np.abs(seg))+1e-9)
                lags.extend(lag_frames(seg[1],seg[0]).tolist())
            row.append(np.median(lags) if lags else float('nan'))
        print(f'  {str(pair):>4s} | {row[0]:7.2f} {row[1]:7.2f} {row[2]:7.2f}')

if __name__=='__main__': main()
