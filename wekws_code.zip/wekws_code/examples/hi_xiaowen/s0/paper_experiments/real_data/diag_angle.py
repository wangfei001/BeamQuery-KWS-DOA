#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Model-free orientation check: mean GCC-PHAT azimuth per labelled region.

For a ULA with tau = d cos(theta)/c, region A (class 0, 30 deg) must give a
*positive* delay and region C (class 2, 150 deg) a *negative* one if the channel
order matches the labels.  This decides [5,6] vs [6,5] without any model.
"""
from __future__ import annotations
import argparse, sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/real_data'))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
import run_real_eval as R                      # noqa: E402
import run_real_comprehensive as C             # noqa: E402
from paper_experiments.shared.code.doa_classical import (  # noqa: E402
    gcc_phat_delay, delay_to_angle)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--channels', default='5,6')
    a = ap.parse_args()
    ch = [int(x) for x in a.channels.split(',')]
    import torch
    dev = R.device()
    mono = R.load_mono(dev)
    records = C.build_segments(Path(ROOT / 'data_real'), ch, dev, mono, 0.003, 0.30)
    _, test = C.split_records(records, 0.30)

    names = {0: 'A/region1 (labelled 30deg)', 1: 'B/region2 (labelled 90deg)',
             2: 'C/region3 (labelled 150deg)'}
    print(f'channels {ch}   tau = m1 - m0 (s);  angle = arccos(c*tau/d)')
    print(f'{"region":32s} {"n":>3s} {"med tau(us)":>11s} {"med angle":>10s}')
    for r in (0, 1, 2):
        taus, angs = [], []
        for *_x, s in test:
            if s.region != r:
                continue
            w = R.common_gain(s.wave)
            tau = gcc_phat_delay(w[1], w[0], fs=16000)   # mic1 vs mic0
            taus.append(tau)
            angs.append(delay_to_angle(tau))
        print(f'{names[r]:32s} {len(taus):3d} {np.median(taus)*1e6:11.1f} {np.median(angs):10.1f}')
    print('\nExpected if order is correct: A tau>0 (angle<90), C tau<0 (angle>90).')


if __name__ == '__main__':
    main()
