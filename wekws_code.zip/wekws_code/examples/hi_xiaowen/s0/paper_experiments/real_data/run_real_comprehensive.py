#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Comprehensive real-recording evaluation for the paper's real-data section.

Protocol
--------
* All eight-channel recordings are read; the zero-based channel subset is
  selected with ``--channels`` (default ``4,5,6``).
* Wake-word candidates come from energy VAD and their boundaries are refined
  with the trained Mono wake model (identical to ``run_real_eval.py``).
* Only boundary-stable segments are kept.  Each file is split *temporally*:
  the first 70% of stable segments form the adaptation set and the last 30%
  form the held-out test set.  Low-energy test-region windows give the
  negative set used for the false-positive rate.
* The held-out positives and negatives are scored by five systems:
  GCC-PHAT cascade, SRP-PHAT cascade, Fixed-beam-3, BeamQuery zero-shot and
  BeamQuery adapted on the 70% split.

This guarantees that every method in the final table sees exactly the same
held-out segments, so the numbers are directly comparable.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
import torch
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/real_data'))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))

import run_real_eval as R  # noqa: E402
from paper_experiments.shared.code.batched_model import BatchedSpatialDynamicQuery  # noqa: E402

SR = 16000
LEN = 3 * SR
CENTERS = R.CENTERS
INPUTS = [
    ('real_a_region1.wav', 0),
    ('real_b_region2.wav', 1),
    ('real_c_region3.wav', 2),
]


def load_beamquery(dev, num_mic, ckpt):
    cfg = yaml.safe_load((ROOT / 'paper_experiments/main_model/experiment/config.yaml').read_text())
    m = BatchedSpatialDynamicQuery(
        fsmn_num_layers=cfg['fsmn_num_layers'], fsmn_dim=cfg['fsmn_dim'],
        num_query=cfg['num_query'], doa_num_class=cfg['doa_num_class'],
        feat_freq_dim=cfg['feat_freq_dim'], use_ipd=cfg.get('use_ipd', True),
        use_pair_ipd=cfg.get('use_pair_ipd', True), num_mic=num_mic,
        pool_type=cfg['pool_type'], pair_feat_mode=cfg['pair_feat_mode'],
        mic_spacing=cfg['mic_spacing'], sr=cfg['sr'],
        use_query_embed=cfg['use_query_embed'],
        use_presence_head=cfg['use_presence_head'],
        use_wake_head=cfg['use_wake_head'], wake_detach=cfg['wake_detach'],
        query_mode=cfg['query_mode'], beam_step_deg=cfg['beam_step_deg'],
        causal=cfg['causal'], norm_type=cfg['norm_type'],
        mel_compress=cfg.get('mel_compress', 0),
        mel_keep_coh=cfg.get('mel_keep_coh', False),
        encoder_type=cfg.get('encoder_type', 'auto')).to(dev)
    ck = torch.load(ckpt, map_location='cpu', weights_only=False)
    m.load_state_dict(ck['model'])
    m.eval()
    return m


def build_segments(data_dir, channels, dev, mono, vad_thr, wake_thr):
    records = []
    for fn, region in INPUTS:
        audio, sr = sf.read(data_dir / fn, always_2d=True, dtype='float32')
        if audio.shape[1] <= max(channels):
            raise RuntimeError(f'{fn}: only {audio.shape[1]} channels, need {max(channels)+1}')
        wave = audio[:, channels].T.copy()
        y = wave.mean(axis=0)
        intervals = R.vad_intervals(y, sr, vad_thr, 0.5, 0.35, 4.0)
        segs = R.refine_boundaries(intervals, wave, sr, mono, dev, wake_thr)
        for s in segs:
            s.region = region
        records.append((fn, wave, sr, segs))
        print(f'{fn}: {len(segs)} accepted / {len(intervals)} candidates', flush=True)
    return records


def split_records(records, holdout=0.30):
    """Return (train_records, test_records) with per-file temporal split."""
    train, test = [], []
    for fn, wave, sr, segs in records:
        stable = [s for s in segs if s.boundary_ok_start and s.boundary_ok_end]
        stable.sort(key=lambda s: s.start)
        cut = max(1, int(round((1.0 - holdout) * len(stable))))
        train += [(fn, wave, sr, s) for s in stable[:cut]]
        test += [(fn, wave, sr, s) for s in stable[cut:]]
    return train, test


def sample_negatives(record, n, rng, cutoff_s, min_rms=0.01):
    """Low-energy 3 s windows after ``cutoff_s`` that avoid every wake segment."""
    fn, wave, sr, segs = record
    M, T = wave.shape
    pos = [(int(s.start * sr), int(s.end * sr)) for s in segs]
    lo = int(cutoff_s * sr)
    out, tries = [], 0
    while len(out) < n and tries < n * 200:
        tries += 1
        a = int(rng.integers(lo, max(lo + 1, T - LEN)))
        b = a + LEN
        if b > T:
            continue
        if any(not (b <= p0 - int(0.3 * sr) or a >= p1 + int(0.3 * sr)) for p0, p1 in pos):
            continue
        w = wave[:, a:b]
        if float(np.sqrt(np.mean(w.mean(axis=0) ** 2))) < min_rms:
            out.append(w)
    return out


def metrics(pred_cls, gt_cls, probs, thr=0.5):
    pred_cls = np.asarray(pred_cls, dtype=int)
    gt_cls = np.asarray(gt_cls, dtype=int)
    probs = np.asarray(probs, dtype=float)
    err = np.abs(CENTERS[pred_cls] - CENTERS[gt_cls])
    det = probs >= thr
    out = {
        'n': int(len(gt_cls)),
        'wake_rate@0.5': float(np.mean(det)) if len(gt_cls) else float('nan'),
        'doa_acc_all': float(np.mean(pred_cls == gt_cls)) if len(gt_cls) else float('nan'),
        'mae_all': float(np.mean(err)) if len(gt_cls) else float('nan'),
    }
    if det.any():
        out.update({
            'n_det': int(det.sum()),
            'doa_acc_det': float(np.mean(pred_cls[det] == gt_cls[det])),
            'mae_det': float(np.mean(err[det])),
            'joint_rate': float(np.mean(det & (pred_cls == gt_cls))),
        })
    else:
        out.update({'n_det': 0, 'doa_acc_det': float('nan'), 'mae_det': float('nan'),
                    'joint_rate': 0.0})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data_dir', default=str(ROOT / 'data_real'))
    ap.add_argument('--out_dir', default=str(ROOT / 'paper_experiments/real_data/results'))
    ap.add_argument('--channels', default='4,5,6')
    ap.add_argument('--out_tag', default='ch456')
    ap.add_argument('--vad_threshold', type=float, default=0.003)
    ap.add_argument('--wake_threshold', type=float, default=0.30)
    ap.add_argument('--holdout', type=float, default=0.30)
    ap.add_argument('--beamquery_ckpt', default=str(ROOT / 'paper_experiments/main_model/experiment/best_cv.pt'))
    ap.add_argument('--beamquery_ft_ckpt', default=str(ROOT / 'paper_experiments/real_data/results/beamquery_finetuned_loc50.pt'))
    a = ap.parse_args()

    data_dir = Path(a.data_dir)
    out_dir = Path(a.out_dir)
    channels = [int(x) for x in a.channels.split(',')]
    out_dir.mkdir(parents=True, exist_ok=True)
    dev = R.device()
    print('device', dev, flush=True)

    mono = R.load_mono(dev)
    fixed3 = R.load_fixed_beam3(dev)
    bq_zero = load_beamquery(dev, len(channels), a.beamquery_ckpt)
    bq_ft = load_beamquery(dev, len(channels), a.beamquery_ft_ckpt)

    records = build_segments(data_dir, channels, dev, mono, a.vad_threshold, a.wake_threshold)
    train, test = split_records(records, a.holdout)

    n_pos = len(test)
    pos_waves = [s.wave for _, _, _, s in test]
    gt = [s.region for _, _, _, s in test]

    # negatives sampled after each file's train/test boundary
    rng = np.random.default_rng(1234)
    neg_waves = []
    for fn, wave, sr, segs in records:
        stable = sorted([s for s in segs if s.boundary_ok_start and s.boundary_ok_end], key=lambda s: s.start)
        cut = max(1, int(round((1.0 - a.holdout) * len(stable))))
        cutoff_s = stable[cut - 1].end
        n_neg = 2 * max(1, len(stable) - cut)
        neg_waves += sample_negatives((fn, wave, sr, segs), n_neg, rng, cutoff_s)
    print(f'test positives={n_pos}  negatives={len(neg_waves)}', flush=True)

    methods = ['gcc-phat', 'srp-phat', 'fixed-beam-3', 'beamquery-zero', 'beamquery-ft']
    pos_pred = {m: {'pred': [], 'prob': []} for m in methods}
    neg_pred = {m: {'pred': [], 'prob': []} for m in methods}

    def run(method, wave):
        if method == 'beamquery-zero':
            return R.beamquery_predict(bq_zero, wave, dev)
        if method == 'beamquery-ft':
            return R.beamquery_predict(bq_ft, wave, dev)
        if method == 'fixed-beam-3':
            return R.fixed_beam3_predict(fixed3, wave, dev)
        return R.cascade_predict(mono, wave, dev, method)

    for i, w in enumerate(pos_waves):
        for m in methods:
            p, q = run(m, w)
            pos_pred[m]['pred'].append(p); pos_pred[m]['prob'].append(q)
        if (i + 1) % 10 == 0:
            print(f'  positives {i+1}/{n_pos}', flush=True)
    for i, w in enumerate(neg_waves):
        for m in methods:
            p, q = run(m, w)
            neg_pred[m]['pred'].append(p); neg_pred[m]['prob'].append(q)
        if (i + 1) % 20 == 0:
            print(f'  negatives {i+1}/{len(neg_waves)}', flush=True)

    report = {
        'configuration': {
            'input_channels_0based': channels,
            'input_channels_1based': [c + 1 for c in channels],
            'array_spacing_m': 0.033,
            'holdout_fraction': a.holdout,
            'region_centers_deg': CENTERS.tolist(),
            'n_train_pos': len(train),
            'n_test_pos': n_pos,
            'n_test_neg': len(neg_waves),
            'beamquery_ckpt': str(a.beamquery_ckpt),
            'beamquery_ft_ckpt': str(a.beamquery_ft_ckpt),
        },
        'methods': {},
    }
    for m in methods:
        met = metrics(pos_pred[m]['pred'], gt, pos_pred[m]['prob'])
        negp = np.asarray(neg_pred[m]['prob'], dtype=float)
        met['fpr@0.5'] = float(np.mean(negp >= 0.5)) if len(negp) else float('nan')
        met['n_neg'] = int(len(negp))
        report['methods'][m] = met

    (out_dir / f'real_comprehensive_{a.out_tag}.json').write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    keys = ['method', 'n', 'n_neg', 'wake_rate@0.5', 'fpr@0.5', 'n_det',
            'doa_acc_all', 'mae_all', 'doa_acc_det', 'mae_det', 'joint_rate']
    with (out_dir / f'real_comprehensive_{a.out_tag}.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(keys)
        for m in methods:
            row = report['methods'][m]
            w.writerow([m] + [row.get(k, '') for k in keys[1:]])
    print('WROTE', out_dir / f'real_comprehensive_{a.out_tag}.csv')
    print(json.dumps(report['methods'], indent=2), flush=True)


if __name__ == '__main__':
    main()
