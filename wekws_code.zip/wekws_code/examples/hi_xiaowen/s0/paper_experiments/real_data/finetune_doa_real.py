#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Fine-tune the main model's azimuth head on real A/C data.

Motivation: the frozen simulated class head produces flat s_q logits for
region C, so C's argmax is essentially random (recall ~0.2).  Here a temporal
70/30 split *inside* A and C is used: 70% trains the azimuth head and 30% is the
held-out test, so the reported numbers are on unseen segments.

Scopes:
  score : unfreeze only head.score_fc  (safest)
  head  : unfreeze fc1 / norm / score_fc
  all   : unfreeze the whole model

Segmentation uses reference channel 5; region A is read with pair_A and region C
with pair_C, matching the per-class protocol.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import numpy as np, soundfile as sf, torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT/'paper_experiments/real_data'))
sys.path.insert(0, str(ROOT/'paper_experiments/shared/code'))
import run_real_eval as R
import run_real_comprehensive as C
import finetune_beamquery as FT
from paper_experiments.main_model.model import SetMatchingLoss

SR=16000; LEN=3*SR; CENTERS=R.CENTERS; REF=5

def stable(s): return sorted([x for x in s if x.boundary_ok_start and x.boundary_ok_end], key=lambda x:x.start)

def cut(w,s,pair): return R.common_gain(w[int(s.start*SR):int(s.end*SR)][:,pair].T)

def build(dev, mono):
    out={}
    for fn,reg in [('real_a_region1.wav',0),('real_b_region2.wav',1),('real_c_region3.wav',2)]:
        w,sr=sf.read(ROOT/'data_real'/fn, always_2d=True, dtype='float32')
        ref=w[:,[REF]].T
        iv=R.vad_intervals(ref.mean(0),sr,0.003,0.5,0.35,4.0)
        sg=R.refine_boundaries(iv,ref,sr,mono,dev,0.30)
        for x in sg: x.region=reg
        out[fn]=w
    return out

@torch.no_grad()
def predict(model, wave, dev):
    x=torch.from_numpy(R.fix_3s(R.common_gain(wave))).float().unsqueeze(0).to(dev)
    s=model(x)['s_q'].reshape(-1)
    return int(torch.argmax(s).item()), s.cpu().numpy()

def evaluate(model, items, dev):
    preds=[]; logits=[]
    for w,cls in items:
        p,s=predict(model,w,dev); preds.append(p); logits.append(s)
    preds=np.array(preds); gts=np.array([c for _,c in items])
    acc=float(np.mean(preds==gts))
    rec={str(c): float(np.mean(preds[gts==c]==c)) if (gts==c).any() else None for c in (0,2)}
    cm=np.zeros((3,3),int)
    for p,g in zip(preds,gts): cm[g,p]+=1
    return {'n':len(items),'acc':acc,'recall':rec,'confusion':cm.tolist(),
            'mean_logits':np.mean(logits,axis=0).round(3).tolist()}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--pair_A', default='6,7'); ap.add_argument('--pair_C', default='0,1')
    ap.add_argument('--holdout', type=float, default=0.30)
    ap.add_argument('--scope', choices=['score','head','all'], default='score')
    ap.add_argument('--epochs', type=int, default=60)
    ap.add_argument('--lr', type=float, default=1e-3)
    ap.add_argument('--freeze_encoder', action='store_true', default=True)
    ap.add_argument('--out_tag', default='A67_C01_score')
    a=ap.parse_args()
    pA=[int(x) for x in a.pair_A.split(',')]; pC=[int(x) for x in a.pair_C.split(',')]
    dev=R.device(); print('device',dev,flush=True)
    mono=R.load_mono(dev)
    audio=build(dev,mono)
    sides=[('real_a_region1.wav',0,pA),('real_c_region3.wav',2,pC)]
    train, test = [], []
    segs={}
    for fn,reg in [('real_a_region1.wav',0),('real_c_region3.wav',2)]:
        w,sr=sf.read(ROOT/'data_real'/fn, always_2d=True, dtype='float32')
        ref=w[:,[REF]].T
        iv=R.vad_intervals(ref.mean(0),sr,0.003,0.5,0.35,4.0)
        sg=R.refine_boundaries(iv,ref,sr,mono,dev,0.30)
        segs[fn]=stable(sg)
    for fn,cls,pair in sides:
        w=audio[fn]; st=segs[fn]
        k=max(1,int(round((1-a.holdout)*len(st))))
        for s in st[:k]: train.append((cut(w,s,pair),cls))
        for s in st[k:]: test.append((cut(w,s,pair),cls))
    print(f'train={len(train)} test={len(test)}',flush=True)

    base=C.load_beamquery(dev,2,ROOT/'paper_experiments/main_model/experiment/best_cv.pt')
    frozen=evaluate(base,test,dev)
    print('FROZEN  ',json.dumps(frozen),flush=True)

    model=C.load_beamquery(dev,2,ROOT/'paper_experiments/main_model/experiment/best_cv.pt')
    keep=[]
    if a.scope=='score': keep=['score_fc']
    elif a.scope=='head': keep=['fc1','norm','score_fc','presence_fc']
    else: keep=None
    for n,p in model.named_parameters():
        p.requires_grad = True if keep is None else any(k in n for k in keep)
    ntr=sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f'scope={a.scope} trainable={ntr}',flush=True)
    opt=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=a.lr, weight_decay=1e-4)
    loss_fn=SetMatchingLoss(lambda_kws=1.0, lambda_presence=0.0, lambda_wake=0.0)
    rng=np.random.default_rng(3)
    for ep in range(1,a.epochs+1):
        model.train(); order=list(range(len(train))); rng.shuffle(order); tot=nb=0
        for st in range(0,len(order),16):
            ids=order[st:st+16]
            waves=[train[i][0]*float(rng.uniform(0.7,1.4)) for i in ids]
            cls=[train[i][1] for i in ids]
            x=FT.batch_tensor(waves,dev); out=model(x); b=len(waves)
            gt=torch.tensor(cls,device=dev).unsqueeze(1)
            valid=torch.ones(b,1,dtype=torch.bool,device=dev)
            kws=torch.ones(b,device=dev); wa=torch.tensor(cls,device=dev)
            loss,_=loss_fn(pred_s=out['s_q'],gt_doa=gt,gt_valid_mask=valid,kws_label=kws,
                           wake_angle_gt=wa,pred_presence=None,pred_wake=None)
            opt.zero_grad(); loss.backward(); opt.step(); tot+=float(loss.item()); nb+=1
        if ep%20==0 or ep==a.epochs:
            ev=evaluate(model,test,dev)
            print(f'ep {ep:3d} loss={tot/max(nb,1):.4f} test acc={ev["acc"]:.3f} recA={ev["recall"]["0"]:.2f} recC={ev["recall"]["2"]:.2f}',flush=True)
    final=evaluate(model,test,dev)
    report={'frozen':frozen,'finetuned':final,'scope':a.scope,'pair_A':pA,'pair_C':pC,
            'epochs':a.epochs,'lr':a.lr,'n_train':len(train),'n_test':len(test)}
    (ROOT/'paper_experiments/real_data/results'/f'doa_ft_{a.out_tag}.json').write_text(
        json.dumps(report,indent=2),encoding='utf-8')
    print('FINAL',json.dumps(final,indent=2)); print('WROTE',f'doa_ft_{a.out_tag}.json')

if __name__=='__main__':
    main()
