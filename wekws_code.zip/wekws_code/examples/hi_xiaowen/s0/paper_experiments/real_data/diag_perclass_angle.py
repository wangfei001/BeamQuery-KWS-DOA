#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Per-region angle measured with the per-class mic pair (A:[6,7], C:[0,1])."""
from __future__ import annotations
import sys
from pathlib import Path
import numpy as np, soundfile as sf, torch
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT/'paper_experiments/real_data'))
sys.path.insert(0, str(ROOT/'paper_experiments/shared/code'))
import run_real_eval as R
from paper_experiments.shared.code.doa_classical import gcc_phat_delay, delay_to_angle

SR=16000; REF=5
FILES=[('real_a_region1.wav',0,[6,7]),('real_b_region2.wav',1,[6,7]),('real_c_region3.wav',2,[0,1])]

def stable(s): return sorted([x for x in s if x.boundary_ok_start and x.boundary_ok_end], key=lambda x:x.start)

def main():
    dev=R.device(); mono=R.load_mono(dev)
    print('region   pair    n   med tau(us)  med angle')
    for fn,reg,pair in FILES:
        w,sr=sf.read(ROOT/'data_real'/fn, always_2d=True, dtype='float32')
        ref=w[:,[REF]].T
        iv=R.vad_intervals(ref.mean(0), sr, 0.003, 0.5, 0.35, 4.0)
        sg=R.refine_boundaries(iv, ref, sr, mono, dev, 0.30)
        for s in sg: s.region=reg
        taus, angs = [], []
        for s in stable(sg):
            seg=w[int(s.start*SR):int(s.end*SR)][:,pair].T.astype(np.float64)
            seg=seg/ (np.max(np.abs(seg))+1e-9)
            tau=gcc_phat_delay(seg[1], seg[0], fs=SR)
            taus.append(tau); angs.append(delay_to_angle(tau, spacing=0.033))
        print(f'{reg:6d}  {str(pair):7s} {len(taus):3d} {np.median(taus)*1e6:11.1f} {np.median(angs):10.1f}')

if __name__=='__main__': main()
