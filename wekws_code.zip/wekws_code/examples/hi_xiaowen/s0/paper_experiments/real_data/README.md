# real_data — 主模型在真实录音上的尝试

主模型在真实多通道录音上的微调与评测脚本（`finetune_beamquery.py`、`run_real_eval.py`
等）与结果保存在本目录。该实验未纳入论文正文。
