#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Decisive angle-convention probe.

Build a two-mic pair from a clean mono speech segment by applying the
synthetic delay that the *simulation convention* assigns to a source at a
known angle:

    tau_m = x_m * cos(theta) / c,      x_m = (m-(M-1)/2)*spacing
    mic_m signal = s(t - tau_m)

So a source at theta=30 deg must be recovered as class 0 by any component that
follows the convention.  We ask the classical GCC-PHAT estimator and the
zero-shot main model.  If the model answers 2 for a 30-deg source, its training
handedness is reversed.
"""
from __future__ import annotations
import argparse, sys
from pathlib import Path
import numpy as np
import soundfile as sf
import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/real_data'))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
import run_real_eval as R                      # noqa: E402
import run_real_comprehensive as C             # noqa: E402
from paper_experiments.shared.code.doa_classical import delay_to_angle, angle_to_class  # noqa: E402

SPEED = 340.0
SPACING = 0.033
SR = 16000


def frac_delay(x, dt, sr=SR):
    """Delay x by dt seconds (can be negative) via FFT phase ramp."""
    x = np.asarray(x, dtype=np.float64)
    n = len(x)
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(n, d=1.0 / sr)
    return np.fft.irfft(X * np.exp(-2j * np.pi * f * dt), n=n)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--channels', default='5,6')
    a = ap.parse_args()
    dev = R.device()
    # clean-ish speech source: one real channel, VAD-free, first 2 s of region B
    audio, sr = sf.read(ROOT / 'data_real/real_b_region2.wav', always_2d=True, dtype='float32')
    seg = audio[int(20 * sr):int(22 * sr), 5].astype(np.float64)
    seg = seg / (np.max(np.abs(seg)) + 1e-9)
    print('probe source = channel 5 of region B, 2 s\n')

    model = C.load_beamquery(dev, 2, ROOT / 'paper_experiments/main_model/experiment/best_cv.pt')
    print(f'{"angle":>6s} {"tau0(us)":>9s} {"tau1(us)":>9s} {"GCC est":>8s} {"GCC cls":>8s} {"model cls":>10s} {"model p(wake)":>12s}')
    for theta in (30.0, 60.0, 90.0, 120.0, 150.0):
        x = np.array([-0.5, 0.5]) * SPACING
        tau = x * np.cos(np.radians(theta)) / SPEED      # mic_m = s(t - tau_m)  (mic1 delayed)
        ch0 = frac_delay(seg, tau[0])
        ch1 = frac_delay(seg, tau[1])
        pair = np.stack([ch0, ch1]).astype(np.float32)
        # classical estimate uses tau = mic1 - mic0
        tau_est = tau[1] - tau[0]
        ang_est = delay_to_angle(tau_est, spacing=SPACING)
        gcc_cls = angle_to_class(ang_est)
        cls, p = R.beamquery_predict(model, pair, dev)
        print(f'{theta:6.0f} {tau[0]*1e6:9.1f} {tau[1]*1e6:9.1f} {ang_est:8.1f} {gcc_cls:8d} {cls:10d} {p:12.3f}')
    print('\nIf the model is consistent, its predicted class should track the angle '
          '(30->0, 90->1, 150->2).')


if __name__ == '__main__':
    main()
