#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Fine-tune BeamQuery's prediction head on the real A/B/C recordings."""
from __future__ import annotations

import argparse
import json
import math
import random
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
import torch
import yaml

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))

from paper_experiments.shared.code.batched_model import BatchedSpatialDynamicQuery  # noqa: E402
from paper_experiments.main_model.model import SetMatchingLoss  # noqa: E402

SR = 16000
LEN = 3 * SR
CENTERS = np.array([30.0, 90.0, 150.0], dtype=np.float64)


def gain(w):
    w = np.asarray(w, dtype=np.float32)
    peak = float(np.max(np.abs(w))) if w.size else 1.0
    return w if peak < 1e-7 else (w / peak) * 0.9


def fix_len(w):
    if w.shape[-1] < LEN:
        return np.pad(w, [(0, 0)] * (w.ndim - 1) + [(0, LEN - w.shape[-1])])
    return w[..., :LEN]


def load_model(dev, init=None, num_mic=3):
    cfg = yaml.safe_load((ROOT / 'paper_experiments/main_model/experiment/config.yaml').read_text())
    model = BatchedSpatialDynamicQuery(
        fsmn_num_layers=cfg['fsmn_num_layers'], fsmn_dim=cfg['fsmn_dim'],
        num_query=cfg['num_query'], doa_num_class=cfg['doa_num_class'],
        feat_freq_dim=cfg['feat_freq_dim'], use_ipd=cfg.get('use_ipd', True),
        use_pair_ipd=cfg.get('use_pair_ipd', True), num_mic=num_mic,
        pool_type=cfg['pool_type'], pair_feat_mode=cfg['pair_feat_mode'],
        mic_spacing=cfg['mic_spacing'], sr=cfg['sr'],
        use_query_embed=cfg['use_query_embed'],
        use_presence_head=cfg['use_presence_head'],
        use_wake_head=cfg['use_wake_head'], wake_detach=cfg['wake_detach'],
        query_mode=cfg['query_mode'], beam_step_deg=cfg['beam_step_deg'],
        causal=cfg['causal'], norm_type=cfg['norm_type'],
        mel_compress=cfg.get('mel_compress', 0),
        mel_keep_coh=cfg.get('mel_keep_coh', False),
        encoder_type=cfg.get('encoder_type', 'auto')).to(dev)
    ck = torch.load(ROOT / 'paper_experiments/main_model/experiment/best_cv.pt',
                    map_location='cpu', weights_only=False)
    model.load_state_dict(ck['model'])
    if init:
        ic = torch.load(init, map_location='cpu', weights_only=False)
        model.load_state_dict(ic['model'])
    return model


def load_segments(report_path, stable_only=True):
    d = json.loads(Path(report_path).read_text(encoding='utf-8'))
    segs = d['segments']
    if stable_only:
        segs = [s for s in segs if s['boundary_ok_start'] and s['boundary_ok_end']]
    return segs


def sample_negative_windows(wave3, sr, intervals, n, rng, min_rms=0.01):
    """Sample non-overlapping low-energy 3 s windows."""
    M, T = wave3.shape
    pos = [(int(a * sr), int(b * sr)) for a, b in intervals]
    out = []
    tries = 0
    while len(out) < n and tries < n * 100:
        tries += 1
        a = rng.integers(0, max(1, T - LEN))
        b = a + LEN
        if b > T:
            continue
        if any(not (b <= p0 - int(0.3 * sr) or a >= p1 + int(0.3 * sr)) for p0, p1 in pos):
            continue
        w = wave3[:, a:b]
        rms = float(np.sqrt(np.mean(w.mean(axis=0) ** 2)))
        if rms < min_rms:
            out.append((a, b))
    if len(out) < n:
        raise RuntimeError(f'could only sample {len(out)}/{n} negatives')
    return out


def batch_tensor(waves, dev):
    x = np.stack([fix_len(gain(w)) for w in waves])
    return torch.from_numpy(x).float().to(dev)


@torch.no_grad()
def evaluate(model, pos_waves, pos_cls, neg_waves, dev):
    model.eval()
    p = torch.sigmoid(model(batch_tensor(pos_waves, dev))['wake_logit']).cpu().numpy()
    pc = model(batch_tensor(pos_waves, dev))['s_q'].argmax(-1).cpu().numpy()
    n = torch.sigmoid(model(batch_tensor(neg_waves, dev))['wake_logit']).cpu().numpy()
    fire = p >= 0.5
    acc = float(np.mean(pc == np.asarray(pos_cls)))
    mae = float(np.mean(np.abs(CENTERS[pc] - CENTERS[np.asarray(pos_cls)])))
    det_acc = float(np.mean(pc[fire] == np.asarray(pos_cls)[fire])) if fire.any() else float('nan')
    det_mae = float(np.mean(np.abs(CENTERS[pc[fire]] - CENTERS[np.asarray(pos_cls)[fire]]))) if fire.any() else float('nan')
    joint = float(np.mean(fire & (pc == np.asarray(pos_cls))))
    return {
        'n_pos': len(pos_waves), 'n_neg': len(neg_waves),
        'wake_rate@0.5': float(np.mean(fire)),
        'fpr@0.5': float(np.mean(n >= 0.5)),
        'doa_acc_all': acc, 'mae_all': mae,
        'doa_acc_det': det_acc, 'mae_det': det_mae,
        'joint_rate': joint,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--report', default=str(ROOT / 'paper_experiments/real_data/results/real_table7_report_ch456.json'))
    ap.add_argument('--out', default=str(ROOT / 'paper_experiments/real_data/results/beamquery_finetuned.pt'))
    ap.add_argument('--epochs', type=int, default=30)
    ap.add_argument('--lr', type=float, default=1e-3)
    ap.add_argument('--seed', type=int, default=666)
    ap.add_argument('--scope', choices=['head', 'all'], default='head')
    ap.add_argument('--init', default=None)
    ap.add_argument('--train_all', action='store_true')
    ap.add_argument('--augment', action='store_true')
    ap.add_argument('--lambda_kws', type=float, default=1.0)
    ap.add_argument('--lambda_wake', type=float, default=0.5)
    ap.add_argument('--channels', default='4,5', help='zero-based mic channels')
    a = ap.parse_args()
    rng = np.random.default_rng(a.seed)
    torch.manual_seed(a.seed)
    dev = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    channels = [int(x) for x in a.channels.split(',')]
    if len(channels) not in (2, 3) or any(c < 0 or c >= 8 for c in channels):
        raise SystemExit('--channels must contain two or three zero-based indices in [0,7]')
    model = load_model(dev, a.init, num_mic=len(channels))
    # Train the shared head only; the causal encoder is frozen for stability on
    # the small real-data adaptation set.
    if a.scope == 'head':
        for p in model.parameters():
            p.requires_grad = False
        for p in model.head.parameters():
            p.requires_grad = True
    else:
        for p in model.parameters():
            p.requires_grad = True

    all_segs = load_segments(a.report, stable_only=False)
    stable_segs = load_segments(a.report, stable_only=True)
    files = {'real_a_region1.wav': 0, 'real_b_region2.wav': 1, 'real_c_region3.wav': 2}
    cache = {}
    train_pos, train_cls, val_pos, val_cls = [], [], [], []
    train_neg, val_neg = [], []
    for fn, region in files.items():
        audio, sr = sf.read(ROOT / 'data_real' / fn, always_2d=True, dtype='float32')
        wave3 = audio[:, channels].T.copy()
        rs_all = sorted([s for s in all_segs if s['file'] == fn], key=lambda x: x['start_s'])
        rs_stable = sorted([s for s in stable_segs if s['file'] == fn], key=lambda x: x['start_s'])
        cut = max(1, int(0.7 * len(rs_stable)))
        cutoff = rs_stable[cut - 1]['end_s']
        if a.train_all:
            train_rs = [s for s in rs_all if s['start_s'] < cutoff]
        else:
            train_rs = rs_stable[:cut]
        val_rs = rs_stable[cut:]
        for s in train_rs:
            train_pos.append(wave3[:, int(s['start_s'] * sr):int(s['end_s'] * sr)])
            train_cls.append(region)
        for s in val_rs:
            val_pos.append(wave3[:, int(s['start_s'] * sr):int(s['end_s'] * sr)])
            val_cls.append(region)
        all_int = [(x['start_s'], x['end_s']) for x in rs_all]
        train_neg_times = sample_negative_windows(wave3, sr, all_int, 2 * max(1, len(train_rs)), rng)
        val_neg_times = sample_negative_windows(wave3, sr, all_int, 2 * max(1, len(val_rs)), rng)
        train_neg += [wave3[:, x:y] for x, y in train_neg_times]
        val_neg += [wave3[:, x:y] for x, y in val_neg_times]
        cache[fn] = (wave3, sr)

    opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=a.lr, weight_decay=1e-4)
    loss_fn = SetMatchingLoss(lambda_kws=a.lambda_kws, lambda_presence=0.0, lambda_wake=a.lambda_wake)
    best = None
    for epoch in range(1, a.epochs + 1):
        model.train()
        order = list(range(max(len(train_pos), len(train_neg))))
        rng.shuffle(order)
        total = 0.0
        nbatch = 0
        for start in range(0, len(order), 16):
            idx = order[start:start + 16]
            pos_idx = [i for i in idx if i < len(train_pos)]
            neg_idx = [i - len(train_pos) for i in idx if i >= len(train_pos) and i - len(train_pos) < len(train_neg)]
            if not pos_idx and not neg_idx:
                continue
            waves, batch_cls = [], []
            for i in pos_idx:
                w = train_pos[i]
                cls = train_cls[i]
                if a.augment:
                    if rng.random() < 0.5:
                        w = w[::-1].copy()
                        cls = 2 - cls
                    w = w * float(rng.uniform(0.6, 1.4))
                waves.append(w)
                batch_cls.append(cls)
            for i in neg_idx:
                w = train_neg[i]
                if a.augment:
                    w = w * float(rng.uniform(0.6, 1.4))
                waves.append(w)
                batch_cls.append(-1)
            x = batch_tensor(waves, dev)
            out = model(x)
            b = len(waves)
            gt_doa = torch.zeros(b, 1, dtype=torch.long, device=dev)
            valid = torch.zeros(b, 1, dtype=torch.bool, device=dev)
            kws = torch.zeros(b, dtype=torch.float32, device=dev)
            wake_angle = torch.full((b,), -100, dtype=torch.long, device=dev)
            for j, cls in enumerate(batch_cls):
                if cls >= 0:
                    gt_doa[j, 0] = cls
                    valid[j, 0] = True
                    kws[j] = 1.0
                    wake_angle[j] = cls
            loss, _ = loss_fn(pred_s=out['s_q'], gt_doa=gt_doa,
                              gt_valid_mask=valid, kws_label=kws,
                              wake_angle_gt=wake_angle,
                              pred_presence=None, pred_wake=out['wake_logit'])
            opt.zero_grad(); loss.backward(); opt.step()
            total += float(loss.item()); nbatch += 1
        met = evaluate(model, val_pos, val_cls, val_neg, dev)
        print('epoch', epoch, 'loss', total / max(nbatch, 1),
              'wake', met['wake_rate@0.5'], 'fpr', met['fpr@0.5'],
              'doa', met['doa_acc_all'], 'mae', met['mae_all'], flush=True)
        score = met['doa_acc_all'] + 0.5 * met['wake_rate@0.5'] - 0.5 * met['fpr@0.5']
        if best is None or score > best[0]:
            best = (score, epoch, met, {k: v.detach().cpu().clone() for k, v in model.state_dict().items()})
    model.load_state_dict(best[3])
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    torch.save({'epoch': best[1], 'model': model.state_dict(), 'metrics': best[2],
                'channels': channels, 'note': f'{a.scope} real-data fine-tune, train_all={a.train_all}, augment={a.augment}'}, a.out)
    print('BEST', json.dumps(best[2], indent=2))
    print('saved', a.out)


if __name__ == '__main__':
    main()
