#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Controlled microphone-order diagnostic.

Fixes the data (two-element [5,6] holdout) and the model, then feeds each
segment in three ways:
  as-is      : [5,6]
  swapped    : [6,5]
  sw+mirror  : [6,5] with predicted azimuth class mirrored 0<->2
and reports wake rate, all-positives DOA and joint success.  This isolates the
effect of the input order from any fine-tuning augmentation (the fine-tunes
themselves used channel-reversal + label-flip augmentation, so a raw swap is
expected to hurt unless the mirror is applied).
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/real_data'))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
import run_real_eval as R                      # noqa: E402
import run_real_comprehensive as C             # noqa: E402

CENTERS = R.CENTERS


@torch.no_grad()
def raw_predict(model, wave, dev):
    x = torch.from_numpy(R.fix_3s(R.common_gain(wave))).float().unsqueeze(0).to(dev)
    out = model(x)
    s = out['s_q'].reshape(-1)
    cls = int(torch.argmax(s).item())
    wake = out.get('wake_logit')
    prob = float(torch.sigmoid(wake).max().item()) if wake is not None else float(torch.sigmoid(torch.max(s)).item())
    return cls, prob


def summarize(preds, gts, probs, thr=0.5):
    preds = np.asarray(preds); gts = np.asarray(gts); probs = np.asarray(probs)
    det = probs >= thr
    err = np.abs(CENTERS[preds] - CENTERS[gts])
    return {
        'wake_rate': float(np.mean(det)),
        'doa_all': float(np.mean(preds == gts)),
        'mae_all': float(np.mean(err)),
        'doa_det': float(np.mean(preds[det] == gts[det])) if det.any() else None,
        'joint': float(np.mean(det & (preds == gts))),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--channels', default='5,6')
    ap.add_argument('--data_dir', default=str(ROOT / 'data_real'))
    a = ap.parse_args()
    channels = [int(x) for x in a.channels.split(',')]
    dev = R.device()
    print('device', dev, flush=True)

    mono = R.load_mono(dev)
    records = C.build_segments(Path(a.data_dir), channels, dev, mono, 0.003, 0.30)
    _, test = C.split_records(records, 0.30)
    gts = [s.region for *_x, s in test]
    waves = [s.wave for *_x, s in test]
    print(f'{len(waves)} held-out positives\n', flush=True)

    models = {
        'zeroshot': ROOT / 'paper_experiments/main_model/experiment/best_cv.pt',
        'ft_ch56': ROOT / 'paper_experiments/real_data/results/beamquery_finetuned_ch56_loc50.pt',
        'ft_corrected65': ROOT / 'paper_experiments/real_data/results/beamquery_finetuned_corrected65_loc50.pt',
    }
    report = {}
    for name, ckpt in models.items():
        model = C.load_beamquery(dev, len(channels), ckpt)
        variants = {'as-is [5,6]': None, 'swapped [6,5]': False, 'sw+mirror [6,5]': True}
        report[name] = {}
        for vname, mir in variants.items():
            preds, probs = [], []
            for w in waves:
                win = w if mir is None else w[::-1]
                cls, p = raw_predict(model, win, dev)
                if mir:
                    cls = 2 - cls
                preds.append(cls); probs.append(p)
            report[name][vname] = summarize(preds, gts, probs)
        print(name)
        for vname, m in report[name].items():
            print(f"  {vname:16s} wake={m['wake_rate']:.3f} doa_all={m['doa_all']:.3f} "
                  f"mae={m['mae_all']:.2f} joint={m['joint']:.3f}", flush=True)

    # Classical estimators: the most direct evidence of the true array orientation.
    variants = {'as-is [5,6]': None, 'swapped [6,5]': False, 'sw+mirror [6,5]': True}
    for method in ['gcc-phat', 'srp-phat']:
        report[method] = {}
        for vname, mir in variants.items():
            preds, probs = [], []
            for w in waves:
                win = w if mir is None else w[::-1]
                cls, p = R.cascade_predict(mono, win, dev, method)
                if mir:
                    cls = 2 - cls
                preds.append(cls); probs.append(p)
            report[method][vname] = summarize(preds, gts, probs)
        print(method)
        for vname, m in report[method].items():
            print(f"  {vname:16s} wake={m['wake_rate']:.3f} doa_all={m['doa_all']:.3f} "
                  f"mae={m['mae_all']:.2f} joint={m['joint']:.3f}", flush=True)

    out = ROOT / 'paper_experiments/real_data/results/mic_order_diag.json'
    out.write_text(json.dumps(report, indent=2), encoding='utf-8')
    print('WROTE', out)


if __name__ == '__main__':
    main()
