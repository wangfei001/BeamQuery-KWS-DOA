#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Why is class C misclassified?  Dump per-segment evidence for A and C.

For the best per-class configuration (A on [6,7], C on [0,1]) print, for every
held-out positive: the mono wake score, the GCC-PHAT lag of the chosen pair,
and the main model's three class logits s_q with its argmax.
"""
from __future__ import annotations
import sys
from pathlib import Path
import numpy as np, soundfile as sf, torch
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT/'paper_experiments/real_data'))
sys.path.insert(0, str(ROOT/'paper_experiments/shared/code'))
import run_real_eval as R
import run_real_comprehensive as C
from paper_experiments.shared.code.doa_classical import _stft

SR=16000; REF=5; PAIR_A=[6,7]; PAIR_C=[1,2]

def stable(s): return sorted([x for x in s if x.boundary_ok_start and x.boundary_ok_end], key=lambda x:x.start)

def lag(sig, ref, max_delay=4, n_fft=512, hop=160):
    n=min(len(sig),len(ref)); sig,ref=sig[:n],ref[:n]
    X=_stft(sig,n_fft,hop)*np.conj(_stft(ref,n_fft,hop)); Xp=X/(np.abs(X)+1e-10)
    cc=np.fft.irfft(Xp,n=n_fft,axis=0); cc=np.roll(cc,n_fft//2,axis=0)
    lo,hi=n_fft//2-max_delay,n_fft//2+max_delay+1
    return float(np.median(np.argmax(cc[lo:hi],axis=0)-max_delay))

def main():
    dev=R.device(); mono=R.load_mono(dev)
    bq=C.load_beamquery(dev,2,ROOT/'paper_experiments/main_model/experiment/best_cv.pt')
    for fn,reg,pair in [('real_a_region1.wav',0,PAIR_A),('real_c_region3.wav',2,PAIR_C)]:
        w,sr=sf.read(ROOT/'data_real'/fn, always_2d=True, dtype='float32')
        ref=w[:,[REF]].T
        iv=R.vad_intervals(ref.mean(0),sr,0.003,0.5,0.35,4.0)
        sg=R.refine_boundaries(iv,ref,sr,mono,dev,0.30)
        for s in sg: s.region=reg
        rows=[]
        for s in stable(sg):
            seg=R.common_gain(w[int(s.start*SR):int(s.end*SR)][:,pair].T)
            L=lag(seg[1].astype(np.float64),seg[0].astype(np.float64))
            x=torch.from_numpy(R.fix_3s(seg)).float().unsqueeze(0).to(dev)
            with torch.no_grad(): o=bq(x)
            s_q=o['s_q'].reshape(-1).cpu().numpy()
            rows.append((s.score,L,int(np.argmax(s_q)),s_q))
        name='A' if reg==0 else 'C'
        n=len(rows); acc=np.mean([r[2]==reg for r in rows])
        lags=np.array([r[1] for r in rows]); preds=np.array([r[2] for r in rows]); sc=np.array([r[0] for r in rows])
        print(f'--- {name} (pair {pair})  n={n}  acc={acc:.3f}')
        print(f'  mono score  : mean {sc.mean():.3f} min {sc.min():.3f} max {sc.max():.3f}')
        print(f'  gcc lag     : {np.unique(lags, return_counts=True)}')
        print(f'  pred class  : {np.unique(preds, return_counts=True)}')
        s_qm=np.mean([r[3] for r in rows],axis=0)
        print(f'  mean s_q    : {np.round(s_qm,3)}')
        # a few individual rows
        for i in range(min(6,n)):
            print(f'    seg{i}: mono={rows[i][0]:.2f} lag={rows[i][1]:+.0f} pred={rows[i][2]} s_q={np.round(rows[i][3],2)}')

if __name__=='__main__': main()
