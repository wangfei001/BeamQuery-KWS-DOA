# table8_localisation_detected — 主模型检出后定位诊断

统计范围限定为 **FAR=1/h 下被接受的唤醒正样本**（即检测器触发），并按活跃声源数
`n_src=1/2` 拆分（realised / oracle）给出总体 content gap。与全正样本口径的
`table7_localisation/` 互补。

由 `table7_localisation/eval_allpos_v7.py` 的 `stratified_detected` 段生成。
