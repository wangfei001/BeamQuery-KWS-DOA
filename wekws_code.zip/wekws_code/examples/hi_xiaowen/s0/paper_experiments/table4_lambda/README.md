# table4_lambda — 主模型辅助唤醒头权重 λ_wake

`configs/lw{0.0,0.1,0.3,1.0}_s{1,2}.yaml`：在选定 Δ=8° 下扫描 λ_wake。
`results/lw<λ>/`：checkpoint + `val_allpos.json`；`results/summary.json`。
λ_wake=0 表示关闭该头；发布的主模型用 **λ_wake=0.3**（detached 头）。
