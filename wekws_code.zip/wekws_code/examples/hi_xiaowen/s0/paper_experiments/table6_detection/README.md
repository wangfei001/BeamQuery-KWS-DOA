# table6_detection — 主模型检测指标

`eval_fair_cascade.py`：为主模型（以及其他未存 npz 的系统）生成逐句预测
`test_predictions_fair.npz`，用于计算 AUC / FPR@0.5 / FRR@1/h。
主模型数值来自 `main_model/experiment/test_metrics.json`。
