# BC-ResNet official-parity audit

Reference: `https://github.com/re9ulus/BC-ResNet`, commit
`086ce358885b4b4521b2763c4563f9e681412e74`.

## Shared input contract

The official model is single-channel and uses 40-dimensional log-mel features.
Our BC-ResNet baseline also selects microphone 0 only and uses 40 mel bins.
That input-channel choice is consistent with the official GSC setup.

## Material differences from the official implementation

The repository now uses the official architecture ported from the reference
commit.  The implementation preserves the official frontend
(`MelSpectrogram(n_fft=1024, f_max=8000, n_mels=40)` plus `log2`), channel
widths `16, 8, 12, 16, 20`, all 12 transition/normal blocks, dilation
`1,2,4,8`, `SubSpectralNorm`, SiLU, and Dropout2d.

The only task adaptation is the final head: the official 35-class classifier
is replaced by a one-logit binary wake/non-wake head (9,449 parameters at
`scale=1`), and `log_softmax` is omitted because our task is binary and uses
BCE.  This adaptation is explicitly stated in the paper.  Input is the
official single-channel setting, using microphone 0.

## Final trained result

The official-structure binary BC-ResNet was retrained with the common baseline
recipe (10 epochs, no AMP, lr `1e-3`, batch 128).  Validation best AUC:
`0.9816`; test AUC `0.9726`; FRR@1/h `0.4777`; FPR@0.5 `0.0888`.
