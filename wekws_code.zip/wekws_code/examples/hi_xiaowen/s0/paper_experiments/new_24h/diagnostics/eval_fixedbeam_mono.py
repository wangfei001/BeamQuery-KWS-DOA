#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Evaluate fixed-beam front ends with the already-trained Mono detector frozen."""
import argparse, os, sys
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
os.environ.setdefault('USE_BATCHED_FORWARD', '1')
os.environ.setdefault('KWS_MAX_SEC', '3.0')

from paper_experiments.shared.code.models import FixedBeamKWS, FixedBeamMultiKWS
from paper_experiments.shared.code.train_duibi import PackedClipDataset, collate, evaluate


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--kind', choices=['fixed-beam', 'fixed-beam-3'], required=True)
    ap.add_argument('--mono_ckpt', required=True)
    ap.add_argument('--test_data', required=True)
    ap.add_argument('--test_varcol', required=True)
    ap.add_argument('--packed_dir', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--gpu', default='0')
    ap.add_argument('--batch_size', type=int, default=64)
    args = ap.parse_args()

    dev = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    mono = torch.load(args.mono_ckpt, map_location='cpu', weights_only=False)
    state = mono['model'] if 'model' in mono else mono
    ma = mono.get('args', {})
    kw = dict(num_mic=2, mic_spacing=0.033, num_layers=8, hidden_dim=128,
              pool_type='mean_max', encoder_type=ma.get('encoder_type', 'cnn'),
              causal=ma.get('causal', False), norm_type=ma.get('norm_type', 'auto'))
    if args.kind == 'fixed-beam':
        model = FixedBeamKWS(steer_deg=90.0, **kw)
    else:
        model = FixedBeamMultiKWS(steer_degs=(30.0, 90.0, 150.0), **kw)
    missing, unexpected = model.kws.load_state_dict(state, strict=True)
    print('loaded mono into frozen fixed-beam detector, missing=', missing, 'unexpected=', unexpected)
    for p in model.parameters():
        p.requires_grad_(False)
    model.to(dev).eval()

    ds = PackedClipDataset(args.test_data, args.test_varcol, num_mic=2,
                           max_sec=3.0, packed_dir=args.packed_dir)
    # Packed paths are synthetic; restore the original list paths for metrics.
    orig = []
    with open(args.test_data, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                orig.append(line.split()[0])
    dl = DataLoader(ds, batch_size=args.batch_size, shuffle=False, collate_fn=collate)
    with torch.no_grad():
        res = evaluate(model, dl, dev, doa_method=None)
    arrays = res.pop('_arrays')
    assert len(orig) == len(arrays['paths']), (len(orig), len(arrays['paths']))
    arrays['paths'] = np.array(orig)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    np.savez(out, **arrays)
    print('wrote', out)
    print('metrics', res)


if __name__ == '__main__':
    main()
