# 训练 / 测试一致性审计（BeamQuery 主模型族）

结论：**读出、损失、选模口径一致；但输入长度口径不一致（真实 bug）。**

## 1. 已验证一致的部分

| 项目 | 训练 | 测试 | 一致 |
|---|---|---|---|
| 检测读出 | 独立唤醒头 `wake_logit`（`lambda_wake=0.3>0`，`wake_detach=true`） | `wake_logit` | ✅ |
| 选模口径 | CV 用 `wake_logit` 算 AUC/recall/FPR，`score=recall*loc_acc` | —（仅验证集选模） | ✅ |
| 时序聚合 | `run_max_logit`：逐帧累计 mean/max → head → 时间维 max | 同一 `forward` | ✅ |
| 方位 | query argmax / 训练用 Q+1 CE | `argmax(s_q)` | ✅ |
| 数据划分 | train/val/test 互斥（check_pipeline） | 同 | ✅ |
| 基线族 (train_duibi) | pad 到 3s | pad 到 3s | ✅ |
| Fixed-beam / -3 | 冻结 Mono，无训练 | 同权重 | ✅ |
| 流式 | 真实长度 + flush | 真实长度 | ✅（与训练一致） |

## 2. 发现的不一致：固定长度补零

- 全部音频长度 = **2.75 s (44000 采样)**（`data_packed_v5_largeval/*_meta.json`）。
- **训练**：`PackedSpatialDataset` 忽略 `KWS_MAX_SEC`，逐样本按 **2.75 s 真实长度**前向（`wekws/bin/train.py` 内 `for f in feat_list: model(f.unsqueeze(0))`）。
- **测试**：`PackedClipDataset` / `SpatialClipDataset(max_sec=3.0)` 把每条 **零补齐到 3.0 s**；`batched_model.BatchedSpatialDynamicQuery.forward` 收到 `[B,M,T]` 张量时 `lens=None`，于是把补零的 0.25 s 当作**有效帧**参与 `run_max_logit` 的累计均值/最大值。

主模型在完整 16k 测试集上的两口径对比（`check_train_test_consistency.py`）：

| 口径 | AUC | FPR@0.5 | FRR@1/h |
|---|---:|---:|---:|
| padded（当前论文数值） | 0.98357 | 0.04977 | 0.37867 |
| masked（与训练一致） | 0.98348 | 0.03577 | 0.34767 |

- 2403/16000 条分数变化 > 0.01，最大变化 0.756。
- 排序（AUC）几乎不变，但 0.5 工作点与 FAR=1/h 阈值明显偏移：补零抬高虚警 → **当前报告对主模型偏悲观**。

## 3. 修复选项

- **(A) 免重训（推荐）**：评测时按真实长度屏蔽补零（把每条 `duration` 作为 `lens` 传入）。与训练、流式、因果假设一致；主模型族（主实验 / 消融 / 角度 / lambda）全部重跑离线评测即可。基线族本来自洽（训练=评测=padded），可不重训。
- **(B) 严格统一 3s 协议**：让打包训练集也遵守 `KWS_MAX_SEC` 补零到 3s，主模型族需**重训**。之后全部方法用完全相同的 3s 窗口。

推荐 (A)：零重训、主模型自洽，且结论更保守（虚警更低）。

## 4. 采用方案 (B)：统一固定 3 s 窗口（已执行）

用户最终选择 **(B) 严格统一 3 s 协议**：训练、离线评测、流式推理与基线族全部使用
"补齐到 3 s 且补零视为有效帧"的同一窗口。

改动：

- `paper_experiments/shared/code/packed_dataset.py`：`PackedSpatialDataset` 现在遵守
  `KWS_MAX_SEC`，把训练波形截断/补齐到 3 s（此前忽略，训练用 2.75 s 真实长度）。
- `paper_experiments/shared/code/eval_fair_cascade.py`、`regenerate_nonstreaming.py`、
  `streaming_parallel.py`：评测/流式同样使用完整 3 s 窗口（撤销方案 A 的真实长度切片）。
- `wekws/bin/train.py`：样本已等长，训练/CV 由逐样本前向改为整批一次前向（等价、快 ~5×）。
- 主模型族（角度扫描 6 + λ 扫描 4 + 消融 A1/A8/A2/A4）在 3 s 协议下**全部重训**；
  基线族 `train_duibi` 本就用 3 s，无需改动。

重训结果（验证集选模）：最佳角度 **Δ=8°**（score 0.9644）。主模型测试：

| 指标 | 值 |
|---|---|
| AUC | 0.9864 |
| FPR@0.5 | 0.0347 |
| FRR@1/h | 0.3450 |
| DOA (all pos.) | 0.9310 |
| MAE | 4.48° |
| Joint | 0.6297 |

流式（严格逐帧、100 ms，class-max）：AUC 0.9865、Recall@FAR=1/h 0.6580，
DOA 0.9317、MAE 4.44°、Joint 0.6327；逐帧 wake 复现误差 ≤ 9.6e-4、类别 ≤ 1.1e-3；
100 条 8 线程 RTF 0.42（p95 0.60）。

校验：`check_pipeline` ok=True（52 项）、`verify_paper_numbers` ok=True；
英文 main_sp 21 页 / main 13 页无 undefined；中文 DOCX 12 页。
