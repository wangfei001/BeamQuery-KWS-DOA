#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Quantify the train/test padding-convention mismatch for the main model.

Training (wekws/bin/train.py + PackedSpatialDataset): each clip is forwarded at
its *true* length (no zero padding).  Evaluation (PackedClipDataset /
SpatialClipDataset, max_sec=3.0) zero-pads every clip to 3 s and -- because the
batched forward treats a [B,M,T] tensor as "all frames valid" -- counts the
padded tail as if it were real frames.

This script forwards the same test clips two ways and compares the wake-head
readouts:
  * padded  : current eval path, model(batch_tensor)          (lens = None)
  * masked  : train-consistent, model(list_of_true_len_waves) (lens = true len)
"""
import argparse, json, os, sys
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
os.environ.setdefault('USE_BATCHED_FORWARD', '1')
os.environ.setdefault('KWS_MAX_SEC', '3.0')

import yaml
from paper_experiments.shared.code.train_duibi import PackedClipDataset, collate
from paper_experiments.shared.code.common import detection_metrics, frr_at_far
from wekws.model.spatial_dynamic_query import SpatialDynamicQueryModel


def build(cfg, ckpt, dev):
    model = SpatialDynamicQueryModel(
        fsmn_num_layers=cfg['fsmn_num_layers'], fsmn_dim=cfg['fsmn_dim'],
        num_query=cfg['num_query'], doa_num_class=cfg['doa_num_class'],
        feat_freq_dim=cfg['feat_freq_dim'], use_ipd=cfg.get('use_ipd', True),
        use_pair_ipd=cfg.get('use_pair_ipd', True), num_mic=cfg['num_mic'],
        pool_type=cfg.get('pool_type', 'mean_max'),
        pair_feat_mode=cfg.get('pair_feat_mode', 'tdoa'),
        mic_spacing=cfg.get('mic_spacing', 0.033), sr=cfg.get('sr', 16000),
        use_query_embed=cfg.get('use_query_embed', True),
        use_presence_head=cfg.get('use_presence_head', True),
        use_wake_head=cfg.get('use_wake_head', True),
        wake_detach=cfg.get('wake_detach', False),
        query_mode=cfg.get('query_mode', 'beam'),
        beam_step_deg=cfg.get('beam_step_deg', 15),
        causal=cfg.get('causal', False), norm_type=cfg.get('norm_type', 'auto'),
        encoder_type=cfg.get('encoder_type', 'auto'),
        encoder_kwargs=cfg.get('encoder_kwargs', None),
        mel_compress=cfg.get('mel_compress', 0),
        mel_keep_coh=cfg.get('mel_keep_coh', False))
    st = torch.load(ckpt, map_location='cpu', weights_only=False)
    model.load_state_dict(st['model'] if 'model' in st else st)
    return model.to(dev).eval()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--checkpoint', required=True)
    ap.add_argument('--config', required=True)
    ap.add_argument('--test_data', required=True)
    ap.add_argument('--test_varcol', required=True)
    ap.add_argument('--packed_dir', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--batch_size', type=int, default=64)
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--gpu', default='0')
    args = ap.parse_args()
    cfg = yaml.safe_load(open(args.config, encoding='utf-8'))
    dev = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    model = build(cfg, args.checkpoint, dev)
    ds = PackedClipDataset(args.test_data, args.test_varcol, num_mic=cfg['num_mic'],
                           max_sec=3.0, packed_dir=args.packed_dir)
    if args.limit:
        ds.indices = ds.indices[:args.limit]
    dl = DataLoader(ds, batch_size=args.batch_size, shuffle=False, collate_fn=collate)

    out = {'padded': {'scores': [], 'labels': [], 'durs': []},
           'masked': {'scores': [], 'labels': [], 'durs': []}}
    with torch.no_grad():
        for b in dl:
            wave = b['wave'].to(dev)             # [B,M,48000] zero padded
            dur = b['duration'].numpy()
            # ---- current eval path: tensor -> lens=None -> padding counts ----
            o1 = model(wave)
            s1 = (torch.sigmoid(o1['wake_logit'].float()) if o1.get('wake_logit') is not None
                  else torch.sigmoid(o1['s_q'].float()).max(dim=-1).values)
            # ---- train-consistent: list of true-length waves -> masked ----
            lens = [int(round(d * cfg.get('sr', 16000))) for d in dur]
            wl = [wave[i, :, :lens[i]] for i in range(wave.shape[0])]
            o2 = model(wl)
            s2 = (torch.sigmoid(o2['wake_logit'].float()) if o2.get('wake_logit') is not None
                  else torch.sigmoid(o2['s_q'].float()).max(dim=-1).values)
            out['padded']['scores'].append(s1.cpu().numpy())
            out['padded']['labels'].append(b['label'].numpy())
            out['padded']['durs'].append(dur)
            out['masked']['scores'].append(s2.cpu().numpy())
            out['masked']['labels'].append(b['label'].numpy())
            out['masked']['durs'].append(dur)

    report = {}
    for k in ('padded', 'masked'):
        sc = np.concatenate(out[k]['scores'])
        lb = np.concatenate(out[k]['labels']).astype(int)
        du = np.concatenate(out[k]['durs'])
        det = detection_metrics(sc, lb, threshold=0.5)
        frr = frr_at_far(sc, lb, du, 1.0)
        report[k] = {'n': len(lb), 'auc': det['auc'], 'fpr@0.5': det['fpr'],
                     'frr@1h': frr['frr'], 'thr@1h': frr['threshold']}
    # how different are the per-clip scores?
    p = np.concatenate(out['padded']['scores']); m = np.concatenate(out['masked']['scores'])
    report['delta'] = {'max_abs': float(np.abs(p - m).max()),
                       'mean_abs': float(np.abs(p - m).mean()),
                       'n_changed_gt_0.01': int((np.abs(p - m) > 0.01).sum())}
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    json.dump(report, open(args.out, 'w'), indent=2)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
