#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regenerate full-test non-streaming predictions with the current code."""
import argparse, os, sys
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
os.environ.setdefault('USE_BATCHED_FORWARD', '1')
os.environ.setdefault('KWS_MAX_SEC', '3.0')

import yaml
from paper_experiments.shared.code.train_duibi import PackedClipDataset, collate
from wekws.model.spatial_dynamic_query import SpatialDynamicQueryModel


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--checkpoint', required=True)
    ap.add_argument('--config', required=True)
    ap.add_argument('--test_data', required=True)
    ap.add_argument('--test_varcol', required=True)
    ap.add_argument('--packed_dir', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--batch_size', type=int, default=64)
    ap.add_argument('--gpu', default='0')
    args = ap.parse_args()
    cfg = yaml.safe_load(open(args.config, encoding='utf-8'))
    dev = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    model = SpatialDynamicQueryModel(
        fsmn_num_layers=cfg['fsmn_num_layers'], fsmn_dim=cfg['fsmn_dim'],
        num_query=cfg['num_query'], doa_num_class=cfg['doa_num_class'],
        feat_freq_dim=cfg['feat_freq_dim'], use_ipd=cfg.get('use_ipd', True),
        use_pair_ipd=cfg.get('use_pair_ipd', True), num_mic=cfg['num_mic'],
        pool_type=cfg.get('pool_type', 'mean_max'), pair_feat_mode=cfg.get('pair_feat_mode', 'tdoa'),
        mic_spacing=cfg.get('mic_spacing', 0.033), sr=cfg.get('sr', 16000),
        use_query_embed=cfg.get('use_query_embed', True),
        use_presence_head=cfg.get('use_presence_head', True),
        use_wake_head=cfg.get('use_wake_head', True), wake_detach=cfg.get('wake_detach', False),
        query_mode=cfg.get('query_mode', 'beam'), beam_step_deg=cfg.get('beam_step_deg', 15),
        causal=cfg.get('causal', False), norm_type=cfg.get('norm_type', 'auto'),
        encoder_type=cfg.get('encoder_type', 'auto'), encoder_kwargs=cfg.get('encoder_kwargs', None),
        mel_compress=cfg.get('mel_compress', 0), mel_keep_coh=cfg.get('mel_keep_coh', False))
    state = torch.load(args.checkpoint, map_location='cpu', weights_only=False)
    model.load_state_dict(state['model'] if 'model' in state else state)
    model.to(dev).eval()
    ds = PackedClipDataset(args.test_data, args.test_varcol, num_mic=cfg['num_mic'],
                           max_sec=3.0, packed_dir=args.packed_dir)
    dl = DataLoader(ds, batch_size=args.batch_size, shuffle=False, collate_fn=collate)
    scores, labels, durations, pred_doa, gt_doa, paths = [], [], [], [], [], []
    with torch.no_grad():
        for k, b in enumerate(dl):
            out = model(b['wave'].to(dev))
            s = out['s_q'].float()
            if out.get('wake_logit') is not None:
                sc = torch.sigmoid(out['wake_logit'].float())
            else:
                sc = torch.sigmoid(s).max(dim=-1).values
            scores.append(sc.cpu().numpy())
            labels.append(b['label'].numpy())
            durations.append(b['duration'].numpy())
            pred_doa.append(s.argmax(dim=-1).cpu().numpy())
            gt_doa.append(b['wake_angle'].numpy())
            paths += b['path']
            if (k + 1) % 20 == 0:
                print('batch', k + 1, flush=True)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    np.savez(out, scores=np.concatenate(scores), labels=np.concatenate(labels).astype(int),
             durations=np.concatenate(durations), pred_doa=np.concatenate(pred_doa).astype(int),
             gt_doa=np.concatenate(gt_doa).astype(int), paths=np.array(paths))
    print('wrote', out, 'n', len(paths))


if __name__ == '__main__':
    main()
