#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Combined (B) driver: train lambda sweep and ablation extras together.

Assumes the angle stage-2 checkpoints already exist (train_tag skips them).
Re-evaluates the angle sweep on validation, selects the best angle, then
trains the 4 lambda variants and the 4 ablation variants in ONE parallel pool
to halve wall-clock versus running the two sweeps back to back.
"""
import json, os, shutil, sys, time
from pathlib import Path

ROOT = Path('/242602/wekws/examples/hi_xiaowen_duolu/s0_deepseek_3')
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/24h_plan'))
import run_24h_plan as R  # noqa

CONFIGS, RESULTS = R.CONFIGS, R.RESULTS


def angle_section():
    # training jobs already done; train_tag will skip if ckpts exist
    jobs = [(f'angle_{s}', CONFIGS/f'angles/step_{s}_s1.yaml',
             CONFIGS/f'angles/step_{s}_s2.yaml', RESULTS/f'angles/step_{s}')
            for s in [6, 8, 12, 15, 20, 30]]
    R.run_group(jobs)
    summary = {}
    for step in [6, 8, 12, 15, 20, 30]:
        tag = f'angle_{step}'; outdir = RESULTS/f'angles/step_{step}'
        ck = outdir/'stage2/best_cv.pt'; cfg = CONFIGS/f'angles/step_{step}_s2.yaml'
        if ck.exists():
            d = R.eval_proposed(tag, ck, cfg, outdir, 'val')
            if d: summary[tag] = R.score_candidate(d)
    (RESULTS/'angles/summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    best = R.select_best(summary, list(summary))
    R.write_status('b2_angle_done', best_angle=best)
    if best is None: raise RuntimeError('no angle candidate')
    return int(best[1].split('_')[1])


def lambda_and_ablation(best_step):
    R.make_lambda_configs(best_step)
    R.make_extra_ablation_configs(best_step)
    jobs = []
    for lw in [0.0, 0.1, 0.3, 1.0]:
        jobs.append((f'lambda_{lw:.1f}', CONFIGS/f'lambda/lw{lw:.1f}_s1.yaml',
                     CONFIGS/f'lambda/lw{lw:.1f}_s2.yaml', RESULTS/f'lambda/lw{lw:.1f}'))
    jobs.append(('A1_dynamic', CONFIGS/'ablation/A1_dynamic_s1.yaml', None,
                 RESULTS/'ablation/A1_dynamic'))
    jobs.append(('A2_single_mic', CONFIGS/'ablation/A2_single_mic_s1.yaml',
                 CONFIGS/'ablation/A2_single_mic_s2.yaml', RESULTS/'ablation/A2_single_mic'))
    for extra in ['A3_no_presence', 'A4_pool_attn']:
        jobs.append((extra, CONFIGS/f'ablation/{extra}_s1.yaml',
                     CONFIGS/f'ablation/{extra}_s2.yaml', RESULTS/f'ablation/{extra}'))
    R.write_status('b2_lambda_ablation_training', jobs=[j[0] for j in jobs])
    R.run_group(jobs, max_par=8, stagger=8)

    lam = {}
    for lw in [0.0, 0.1, 0.3, 1.0]:
        tag = f'lambda_{lw:.1f}'; outdir = RESULTS/f'lambda/lw{lw:.1f}'
        ck = outdir/'stage2/best_cv.pt'; cfg = CONFIGS/f'lambda/lw{lw:.1f}_s2.yaml'
        if ck.exists():
            d = R.eval_proposed(tag, ck, cfg, outdir, 'val')
            if d: lam[tag] = R.score_candidate(d)
    (RESULTS/'lambda/summary.json').write_text(json.dumps(lam, indent=2), encoding='utf-8')

    a0_tag = f'A0_bestangle_{best_step}'; a0_dir = RESULTS/'ablation'/a0_tag
    shutil.copytree(RESULTS/f'angles/step_{best_step}', a0_dir, dirs_exist_ok=True)
    a9_tag = 'A9_beam30'; a9_dir = RESULTS/'ablation'/a9_tag
    shutil.copytree(RESULTS/'angles/step_30', a9_dir, dirs_exist_ok=True)
    abl = {}
    for tag, ck, cfg in [
        (a0_tag, a0_dir/'stage2/best_cv.pt', CONFIGS/f'angles/step_{best_step}_s2.yaml'),
        ('A1_dynamic', RESULTS/'ablation/A1_dynamic/stage1/best_cv.pt', CONFIGS/'ablation/A1_dynamic_s1.yaml'),
        ('A2_single_mic', RESULTS/'ablation/A2_single_mic/stage2/best_cv.pt', CONFIGS/'ablation/A2_single_mic_s2.yaml'),
        (a9_tag, a9_dir/'stage2/best_cv.pt', CONFIGS/'angles/step_30_s2.yaml'),
        ('A3_no_presence', RESULTS/'ablation/A3_no_presence/stage2/best_cv.pt', CONFIGS/'ablation/A3_no_presence_s2.yaml'),
        ('A4_pool_attn', RESULTS/'ablation/A4_pool_attn/stage2/best_cv.pt', CONFIGS/'ablation/A4_pool_attn_s2.yaml'),
    ]:
        if Path(ck).exists():
            d = R.eval_proposed(tag, ck, cfg, Path(ck).parent.parent, 'val')
            if d: abl[tag] = R.score_candidate(d)
    (RESULTS/'ablation/summary.json').write_text(json.dumps(abl, indent=2), encoding='utf-8')
    best_main = R.select_best(abl, list(abl))
    R.write_status('b2_ablation_done', best_main=best_main)
    return best_main, a0_tag, a0_dir, a9_tag, a9_dir


def main():
    t0 = time.time()
    best_step = angle_section()
    best_main, a0_tag, a0_dir, a9_tag, a9_dir = lambda_and_ablation(best_step)
    if best_main is None: raise RuntimeError('no main candidate')
    main_dir = ROOT/'paper_experiments/main_experiment'; main_dir.mkdir(parents=True, exist_ok=True)
    main_tag = best_main[1]
    ck_map = {
        a0_tag: (a0_dir/'stage2/best_cv.pt', CONFIGS/f'angles/step_{best_step}_s2.yaml'),
        'A1_dynamic': (RESULTS/'ablation/A1_dynamic/stage1/best_cv.pt', CONFIGS/'ablation/A1_dynamic_s1.yaml'),
        'A2_single_mic': (RESULTS/'ablation/A2_single_mic/stage2/best_cv.pt', CONFIGS/'ablation/A2_single_mic_s2.yaml'),
        a9_tag: (a9_dir/'stage2/best_cv.pt', CONFIGS/'angles/step_30_s2.yaml'),
        'A3_no_presence': (RESULTS/'ablation/A3_no_presence/stage2/best_cv.pt', CONFIGS/'ablation/A3_no_presence_s2.yaml'),
        'A4_pool_attn': (RESULTS/'ablation/A4_pool_attn/stage2/best_cv.pt', CONFIGS/'ablation/A4_pool_attn_s2.yaml'),
    }
    src_ck, src_cfg = ck_map[main_tag]
    shutil.copy2(src_ck, main_dir/'best_cv.pt'); shutil.copy2(src_cfg, main_dir/'config.yaml')
    (main_dir/'selection.json').write_text(json.dumps({'main_tag': main_tag, 'metrics': best_main[2]}, indent=2), encoding='utf-8')
    test_dir = main_dir/'test'; test_dir.mkdir(exist_ok=True)
    d_test = R.eval_proposed('main', main_dir/'best_cv.pt', main_dir/'config.yaml', test_dir, 'test')
    (main_dir/'test_metrics.json').write_text(json.dumps(d_test, indent=2), encoding='utf-8')
    D = ROOT/'paper_experiments/table1_corpus/data_lists'
    env = os.environ.copy(); env.update({'PYTHONPATH': str(ROOT), 'PACKED_DATA_DIR': str(R.PACKED),
        'USE_BATCHED_FORWARD': '1', 'KWS_MAX_SEC': '3.0'})
    R.run([R.PY, 'paper_experiments/shared/code/threshold_sweep.py',
           '--pred', str(main_dir/'test_predictions_fair.npz'),
           '--varcol', str(D/'test_varcol.tmp.list'), '--out', str(main_dir/'threshold_sweep.json')],
          'threshold_sweep.log', env)
    R.write_status('b2_completed', main_tag=main_tag, elapsed_s=time.time()-t0)
    print('DONE', main_tag, 'step', best_step, 'elapsed', time.time()-t0, flush=True)


if __name__ == '__main__':
    main()
