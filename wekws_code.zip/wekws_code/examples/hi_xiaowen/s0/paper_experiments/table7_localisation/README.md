# table7_localisation — 主模型定位指标

`eval_allpos_v7.py`：把预测 npz 转成全正样本 DOA / MAE / Joint，以及检出后的
oracle / 分层诊断。
主模型输入为 `main_model/experiment/test_metrics.json`。
