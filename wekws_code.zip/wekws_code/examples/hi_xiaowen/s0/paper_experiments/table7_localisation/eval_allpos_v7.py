# -*- coding: utf-8 -*-
"""Compute decoupled v7 metrics from a prediction npz.

Outputs both:
  * all-positive localisation and Joint (the paper's main localisation/Joint
    protocols), and
  * detected-positive diagnostics (wake-source/oracle/stratification), which
    are used only inside the stratification and ablation tables.

This mirrors code_duibi/eval_fair_cascade.py, but adds the all-positives
quantities that the current paper reports in Table 4.
"""
import argparse
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, "../../.."))
sys.path.insert(0, HERE)
sys.path.insert(0, REPO)

from paper_experiments.shared.code.common import det_curve, detection_metrics, frr_at_far  # noqa: E402

DOA_CENTERS = np.array([30.0, 90.0, 150.0])


def load_truth(varcol_path):
    truth = {}
    with open(varcol_path, encoding="utf-8") as f:
        for line in f:
            p = line.strip().split()
            if len(p) < 3:
                continue
            name = os.path.basename(p[0])
            label = int(p[1]); n_src = int(p[2])
            cls = [int(x) for x in p[3:6]] if len(p) >= 6 else []
            srcs = [c for c in cls if c >= 0]
            wake = srcs[0] if (label == 1 and srcs) else -100
            truth[name] = {"label": label, "n_src": n_src, "srcs": srcs, "wake": wake}
    return truth


def acc_mae(pred, gt):
    pred = np.asarray(pred, dtype=int); gt = np.asarray(gt, dtype=int)
    if gt.size == 0:
        return float("nan"), float("nan"), 0
    return (float(np.mean(pred == gt)),
            float(np.mean(np.abs(DOA_CENTERS[pred] - DOA_CENTERS[gt]))),
            int(gt.size))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred", required=True)
    ap.add_argument("--varcol", required=True)
    ap.add_argument("--label", default="")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    truth = load_truth(a.varcol)
    z = np.load(a.pred, allow_pickle=True)
    names = [os.path.basename(str(x)) for x in z["paths"]]
    scores = z["scores"].astype(float)
    labels = z["labels"].astype(int)
    durations = z["durations"].astype(float)
    pred = z["pred_doa"].astype(int)
    gt = z["gt_doa"].astype(int)

    lab = np.array([truth[n]["label"] for n in names], dtype=int)
    nsrc = np.array([truth[n]["n_src"] for n in names], dtype=int)
    wake = np.array([truth[n]["wake"] for n in names], dtype=int)
    valid = wake >= 0

    thr = frr_at_far(scores, lab, durations, 1.0)["threshold"]
    det_pos = (lab == 1) & valid & (scores > thr)
    all_pos = (lab == 1) & valid

    det = detection_metrics(scores, lab, 0.5)
    frr = frr_at_far(scores, lab, durations, 1.0)

    acc_all, mae_all, n_all = acc_mae(pred[all_pos], wake[all_pos])
    acc_det, mae_det, n_det = acc_mae(pred[det_pos], wake[det_pos])
    joint_all = float(np.mean((scores[all_pos] > thr) & (pred[all_pos] == wake[all_pos])))

    # Oracle / source-selection diagnostic, computed on detected positives.
    hit_any, hit_wake, hit_interf = [], [], []
    for i in np.where(det_pos)[0]:
        srcs = truth[names[i]]["srcs"]
        hit_any.append(int(pred[i]) in srcs)
        hit_wake.append(int(pred[i]) == int(wake[i]))
        inter = [c for c in srcs if c != int(wake[i])]
        hit_interf.append(int(pred[i]) in inter if inter else False)
    hit_any = np.asarray(hit_any, dtype=bool)
    hit_wake = np.asarray(hit_wake, dtype=bool)
    hit_interf = np.asarray(hit_interf, dtype=bool)

    strat_all, strat_det = {}, {}
    for k in sorted(set(nsrc[all_pos].tolist())):
        m_all = all_pos & (nsrc == k)
        acc_v, mae_v, n_v = acc_mae(pred[m_all], wake[m_all])
        strat_all[f"n_src={k}"] = {"acc": acc_v, "mae": mae_v, "n": n_v}
        m_det = det_pos & (nsrc == k)
        acc_v, mae_v, n_v = acc_mae(pred[m_det], wake[m_det])
        idx = np.where(m_det)[0]
        any_ok = [int(pred[i]) in truth[names[i]]["srcs"] for i in idx]
        strat_det[f"n_src={k}"] = {
            "acc": acc_v, "mae": mae_v, "n": n_v,
            "oracle": float(np.mean(any_ok)) if any_ok else float("nan"),
        }

    out = {
        "label": a.label or os.path.basename(a.pred),
        "pred_file": os.path.abspath(a.pred),
        "varcol": os.path.abspath(a.varcol),
        "n_pos": int(all_pos.sum()), "n_neg": int((lab == 0).sum()),
        "neg_hours": float(durations[lab == 0].sum() / 3600.0),
        "work_threshold": float(thr),
        "detection": {
            "auc": float(det["auc"]),
            "fpr@0.5": float(det["fpr"]),
            "frr@1h": float(frr["frr"]),
        },
        "all_positives": {
            "doa_acc": acc_all, "mae": mae_all, "joint": joint_all, "n": n_all,
        },
        "detected_positive": {
            "doa_acc": acc_det, "mae": mae_det, "n": n_det,
            "oracle_acc": float(hit_any.mean()) if hit_any.size else float("nan"),
            "wake_hits": int(hit_wake.sum()),
            "interferer_hits": int(hit_interf.sum()),
            "content_gap": float(hit_any.mean() - hit_wake.mean()) if hit_any.size else float("nan"),
        },
        "stratified_all": strat_all,
        "stratified_detected": strat_det,
    }

    if a.out:
        os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
        json.dump(out, open(a.out, "w", encoding="utf-8"), indent=2, ensure_ascii=False)

    print(json.dumps(out, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
