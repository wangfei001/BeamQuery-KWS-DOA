#!/usr/bin/env python3
"""Re-evaluate the failed lambda_wake=0.0 model and repair lambda summary.

The first evaluation attempt loaded the no-wake-head checkpoint with the default
wake head enabled, so it failed.  This watchdog waits until no training process
is active, runs the two validation evaluations with the corrected loader, then
merges lambda_0.0 back into results/lambda/summary.json before table creation.
"""
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path('/242602/wekws/examples/hi_xiaowen_duolu/s0_deepseek_3')
PLAN = ROOT / 'paper_experiments/24h_plan'
PY = '/242602/conda/envs/wekws/bin/python'
LOG = PLAN / 'logs/lambda0_reeval.log'


def log(msg):
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open('a', encoding='utf-8') as f:
        f.write(f'[{time.strftime("%Y-%m-%d %H:%M:%S")}] {msg}\n')


def training_active():
    out = subprocess.run(['ps', '-eo', 'args'], text=True, capture_output=True).stdout
    needles = ('wekws/bin/train.py', 'paper_experiments/shared/code/train_duibi.py')
    return any(n in line for line in out.splitlines() for n in needles)


def run(cmd):
    log('run: ' + ' '.join(str(x) for x in cmd))
    with LOG.open('a', encoding='utf-8') as f:
        return subprocess.run([str(x) for x in cmd], cwd=str(ROOT), env=env,
                              stdout=f, stderr=subprocess.STDOUT).returncode


env = os.environ.copy()
env.update({'PYTHONPATH': str(ROOT), 'PACKED_DATA_DIR': str(ROOT / 'data_packed_v5_largeval'),
            'USE_BATCHED_FORWARD': '1', 'KWS_MAX_SEC': '3.0',
            'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1'})
ckpt = PLAN / 'results/lambda/lw0.0/stage2/best_cv.pt'
cfg = PLAN / 'configs/lambda/lw0.0_s2.yaml'
fair = PLAN / 'results/lambda/lw0.0/val_fair.json'
allp = PLAN / 'results/lambda/lw0.0/val_allpos.json'
summary = PLAN / 'results/lambda/summary.json'

log('watchdog started')
while True:
    if not ckpt.exists():
        log('lw0.0 checkpoint missing; waiting')
    elif not training_active():
        log('no training active; starting lambda0 evaluation')
        for p in (fair, allp):
            try:
                p.unlink()
            except FileNotFoundError:
                pass
        cmd1 = [PY, 'paper_experiments/shared/code/eval_fair_cascade.py',
                '--varcol', str(ROOT / 'data_val10k/eval_varcol.tmp.list'),
                '--test_data', str(ROOT / 'data_val10k/eval_spatial.list'),
                '--proposed_ckpt', str(ckpt), '--proposed_config', str(cfg),
                '--num_mic', '2', '--pred_glob',
                'paper_experiments/24h_plan/_none_/*.npz', '--out', str(fair)]
        cmd2 = [PY, 'paper_experiments/shared/code/eval_allpos_v7.py',
                '--pred', str(PLAN / 'results/lambda/lw0.0/stage2/test_predictions_fair.npz'),
                '--varcol', str(ROOT / 'data_val10k/eval_varcol.tmp.list'),
                '--label', 'lambda_0.0_val', '--out', str(allp)]
        if run(cmd1) == 0 and run(cmd2) == 0:
            d = json.loads(allp.read_text(encoding='utf-8'))
            det, pos = d['detection'], d['detected_positive']
            entry = {'auc': det['auc'], 'frr1h': det['frr@1h'],
                     'fpr05': det['fpr@0.5'], 'loc': pos['doa_acc'],
                     'mae': pos['mae'], 'score': det['auc'] * pos['doa_acc']}
            summary_data = json.loads(summary.read_text(encoding='utf-8')) if summary.exists() else {}
            summary_data['lambda_0.0'] = entry
            ordered = {k: summary_data[k] for k in
                       ['lambda_0.0', 'lambda_0.1', 'lambda_0.3', 'lambda_1.0'] if k in summary_data}
            summary.write_text(json.dumps(ordered, indent=2), encoding='utf-8')
            log('lambda0 evaluation complete and summary repaired: ' + json.dumps(entry))
            break
        log('lambda0 evaluation failed; retrying in 60s')
    time.sleep(60)
