#!/bin/bash
set -u
cd /242602/wekws/examples/hi_xiaowen_duolu/s0_deepseek_3
export PYTHONPATH=$PWD
while true; do
  /242602/conda/envs/wekws/bin/python -u paper_experiments/24h_plan/run_24h_plan.py >> paper_experiments/24h_plan/logs/runner.log 2>&1
  rc=$?
  if grep -q "\"stage\": \"completed\"" paper_experiments/24h_plan/STATUS.json 2>/dev/null; then
    echo "[$(date +%T)] completed" >> paper_experiments/24h_plan/logs/runner.log
    exit 0
  fi
  echo "[$(date +%T)] orchestrator exited rc=$rc; restart in 60s" >> paper_experiments/24h_plan/logs/runner.log
  sleep 60
done
