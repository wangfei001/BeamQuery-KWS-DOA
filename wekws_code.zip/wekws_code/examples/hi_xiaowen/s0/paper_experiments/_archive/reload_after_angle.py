#!/usr/bin/env python3
"""Reload the 24h orchestrator after all six angle checkpoints are durable.

The old orchestrator process predates the latest code fixes, so it cannot be
expected to load the corrected selection/ablation logic.  We wait until every
angle stage-2 checkpoint exists, then stop only the running orchestrator and
its direct workers.  run_forever.sh restarts the orchestrator from the fixed
source and all completed training is skipped.
"""
import os
import signal
import subprocess
import time
from pathlib import Path

PLAN = Path('/242602/wekws/examples/hi_xiaowen_duolu/s0_deepseek_3/paper_experiments/24h_plan')
PID = 1701229
STEPS = (6, 8, 12, 15, 20, 30)
LOG = PLAN / 'logs/reload_after_angle.log'
LOCK = PLAN / 'logs/reload_after_angle.lock'


def log(msg):
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open('a', encoding='utf-8') as f:
        f.write(f'{time.strftime("%Y-%m-%d %H:%M:%S")} {msg}\n')


def alive(pid):
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def children(pid):
    try:
        out = subprocess.check_output(['pgrep', '-P', str(pid)], text=True)
        return [int(x) for x in out.split()]
    except Exception:
        return []


def training_active(pid):
    for c in children(pid):
        try:
            cmd = Path(f'/proc/{c}/cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
        except OSError:
            continue
        if 'wekws/bin/train.py' in cmd:
            return True
    return False


if LOCK.exists():
    raise SystemExit(0)
LOCK.write_text(str(os.getpid()), encoding='utf-8')
started = time.time()
log(f'watcher started pid={os.getpid()} target={PID}')

try:
    while alive(PID):
        paths = [PLAN / f'results/angles/step_{s}/stage2/best_cv.pt' for s in STEPS]
        ready = [p for p in paths if p.exists() and p.stat().st_size > 1024 * 1024]
        new_steps_ready = all(
            (PLAN / f'results/angles/step_{s}/stage2/best_cv.pt').exists()
            and (PLAN / f'results/angles/step_{s}/stage2/best_cv.pt').stat().st_mtime >= started - 60
            for s in (15, 20, 30)
        )
        if len(ready) == len(paths) and new_steps_ready and not training_active(PID):
            log('all six angle checkpoints ready; reloading orchestrator')
            kids = children(PID)
            log(f'stopping direct workers: {kids}')
            for c in kids:
                try:
                    os.kill(c, signal.SIGTERM)
                except OSError:
                    pass
            time.sleep(3)
            try:
                os.kill(PID, signal.SIGTERM)
            except OSError:
                pass
            log('orchestrator stopped; run_forever.sh will restart with fixed code')
            break
        time.sleep(10)
    else:
        log('target orchestrator is gone; no reload needed')
finally:
    try:
        LOCK.unlink()
    except OSError:
        pass
