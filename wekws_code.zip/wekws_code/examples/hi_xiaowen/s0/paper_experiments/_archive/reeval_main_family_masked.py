#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Re-evaluate the whole main-model family with the train-consistent
"mask the zero padding" convention (fix option A).

Regenerates, for every checkpoint trained via wekws/bin/train.py:
  * angle sweep  (validation)
  * lambda sweep (validation)
  * component ablation A1/A8/A2/A4 (validation)
  * the shipped main model on the full test split
and rewrites the corresponding *_allpos.json / test_metrics.json consumed by
make_tables.py.  Comparison baselines (train_duibi) are left untouched.
"""
import argparse, json, os, subprocess, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
os.environ.setdefault('USE_BATCHED_FORWARD', '1')
os.environ.setdefault('KWS_MAX_SEC', '3.0')

from paper_experiments.shared.code.eval_fair_cascade import dump_predictions  # noqa

PY = '/242602/conda/envs/wekws/bin/python'
PLAN = ROOT / 'paper_experiments/24h_plan'
RES = PLAN / 'results'
CFG = PLAN / 'configs'
D = ROOT / 'paper_experiments/table1_corpus/data_lists'
V = ROOT / 'data_val10k'
MAIN = ROOT / 'paper_experiments/main_experiment'


def allpos(npz, var, label, out):
    cmd = [PY, 'paper_experiments/shared/code/eval_allpos_v7.py',
           '--pred', str(npz), '--varcol', str(var), '--label', label, '--out', str(out)]
    subprocess.run([str(c) for c in cmd], cwd=str(ROOT), check=True)


def do_one(tag, ckpt, cfg, data, var, out_npz, out_allpos, num_mic=None):
    import yaml
    if not Path(ckpt).exists():
        print(f'[skip] {tag}: missing {ckpt}', flush=True); return
    if num_mic is None:
        num_mic = int(yaml.safe_load(open(cfg, encoding='utf-8')).get('num_mic', 2))
    t0 = time.time()
    print(f'[eval] {tag} ckpt={ckpt} mic={num_mic}', flush=True)
    dump_predictions(str(ckpt), str(cfg), str(data), str(var), str(out_npz),
                     num_mic=num_mic, gpu='0', batch_size=64)
    allpos(out_npz, var, tag, out_allpos)
    d = json.loads(Path(out_allpos).read_text())
    print(f'   -> AUC={d["detection"]["auc"]:.4f} FPR@0.5={d["detection"]["fpr@0.5"]:.4f} '
          f'FRR@1h={d["detection"]["frr@1h"]:.4f} DOA={d["all_positives"]["doa_acc"]:.4f} '
          f'MAE={d["all_positives"]["mae"]:.2f}  ({time.time()-t0:.0f}s)', flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--which', default='all',
                    help='comma list of angle,lambda,ablation,main or all')
    args = ap.parse_args()
    which = set(['angle', 'lambda', 'ablation', 'main']) if args.which == 'all' \
        else set(args.which.split(','))

    if 'angle' in which:
        for step in [6, 8, 12, 15, 20, 30]:
            base = RES / f'angles/step_{step}'
            do_one(f'angle_{step}', base/'stage2/best_cv.pt', CFG/f'angles/step_{step}_s2.yaml',
                   V/'eval_spatial.list', V/'eval_varcol.tmp.list',
                   base/'stage2/val_predictions_fair.npz', base/'val_allpos.json')

    if 'lambda' in which:
        for lw in [0.0, 0.1, 0.3, 1.0]:
            base = RES / f'lambda/lw{lw:.1f}'
            do_one(f'lambda_{lw:.1f}', base/'stage2/best_cv.pt', CFG/f'lambda/lw{lw:.1f}_s2.yaml',
                   V/'eval_spatial.list', V/'eval_varcol.tmp.list',
                   base/'stage2/val_predictions_fair.npz', base/'val_allpos.json')

    if 'ablation' in which:
        spec = [
            ('A1_dynamic', RES/'ablation/A1_dynamic/stage1/best_cv.pt',
             CFG/'ablation/A1_dynamic_s1.yaml'),
            ('A2_single_mic', RES/'ablation/A2_single_mic/stage2/best_cv.pt',
             CFG/'ablation/A2_single_mic_s2.yaml'),
            ('A3_no_presence', RES/'ablation/A3_no_presence/stage2/best_cv.pt',
             CFG/'ablation/A3_no_presence_s2.yaml'),
            ('A4_pool_attn', RES/'ablation/A4_pool_attn/stage2/best_cv.pt',
             CFG/'ablation/A4_pool_attn_s2.yaml'),
        ]
        for tag, ck, cfg in spec:
            do_one(tag, ck, cfg, V/'eval_spatial.list', V/'eval_varcol.tmp.list',
                   Path(ck).parent/'val_predictions_fair.npz',
                   RES/f'ablation/{tag}/val_allpos.json')

    if 'main' in which:
        do_one('main_test', MAIN/'best_cv.pt', MAIN/'config.yaml',
               D/'test_spatial.list', D/'test_varcol.tmp.list',
               MAIN/'test_predictions_fair.npz', MAIN/'test_metrics.json')


if __name__ == '__main__':
    main()
