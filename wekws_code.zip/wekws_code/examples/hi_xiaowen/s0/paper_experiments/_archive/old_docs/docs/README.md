# （归档）主模型早期文档

主模型早期版本的实验报告与状态文档（`EXPERIMENT_REPORT.md`、`EXPERIMENT_STATUS.md`
等）以及旧日志，仅作历史留存，不代表当前主模型配置。
