# Cleanup manifest

Removed legacy datasets and intermediate packs:
data, data_t, data_v2, data_v3, data_v4, data_big_test,
data_rirlib, data_fix, data_fix_sir, data_fix_sir10h, data_fix_sirA,
data_nihao, data_nihao_packed, data_packed, data_packed_fix.

Kept final experiment data:
- data_packed_v5/  (packed train/eval/test arrays)
- data_v5/test_wav/  (raw test waveforms used by final evaluator)
- paper_experiments/table1_corpus/data_lists/  (final list files)

Kept code/results/paper:
- paper_experiments/
- papaer/
- paper_cn/
- wekws/  (training/model/dataset code)

Backup before cleanup:
- backup_before_cleanup_20261012.tar.gz
