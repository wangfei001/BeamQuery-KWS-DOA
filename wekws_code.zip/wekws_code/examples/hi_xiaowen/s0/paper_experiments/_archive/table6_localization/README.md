# （归档）主模型早期定位评测

主模型早期全正样本定位 / Joint / 分层评测产物，`results/final_v6c/`。
当前使用的结果在 `paper_experiments/table7_localisation/`、
`paper_experiments/table8_localisation_detected/`。
