#!/bin/bash
set -u
cd "$(dirname "$0")/../.."
export PYTHONPATH=$PWD OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export PACKED_DATA_DIR=$PWD/data_packed_v5 USE_BATCHED_FORWARD=1 KWS_MAX_SEC=3.0
ulimit -n 65535 2>/dev/null || true
PY=${PY:-/242602/conda/envs/wekws/bin/python}
D=paper_experiments/table1_corpus/data_lists
C=paper_experiments/table3_lambda/configs
E=paper_experiments/table3_lambda/results
for tag in lw0.0 lw0.1 lw0.3 lw1.0; do
  $PY -u wekws/bin/train.py --config $C/${tag}_s1.yaml     --train_data $D/train_spatial.list --train_varcol $D/train_varcol.tmp.list     --cv_data $D/eval_spatial.list --cv_varcol $D/eval_varcol.tmp.list     --test_data $D/test_spatial.list --test_varcol $D/test_varcol.tmp.list     --model_dir $E/$tag/stage1 --eval_interval 1 --gpus 0 --num_workers 3
  $PY -u wekws/bin/train.py --config $C/${tag}_s2.yaml     --train_data $D/train_spatial.list --train_varcol $D/train_varcol.tmp.list     --cv_data $D/eval_spatial.list --cv_varcol $D/eval_varcol.tmp.list     --test_data $D/test_spatial.list --test_varcol $D/test_varcol.tmp.list     --checkpoint $E/$tag/stage1/best_cv.pt     --model_dir $E/$tag/stage2 --eval_interval 1 --gpus 0 --num_workers 3
done
