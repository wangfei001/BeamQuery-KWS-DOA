# （归档）主模型 λ_wake 早期扫描

主模型辅助唤醒头权重 λ_wake 的早期扫描产物：`configs/`（`lw{0.0,0.1,0.3,1.0}` 两阶段
配置）、`results/`（各设置 checkpoint 与测试预测）。当前使用的结果已迁到
`paper_experiments/table4_lambda/`。
