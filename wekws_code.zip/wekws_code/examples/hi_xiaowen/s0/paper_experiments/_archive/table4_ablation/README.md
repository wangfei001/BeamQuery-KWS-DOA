# （归档）主模型早期组件消融

主模型早期消融变体：A0（完整）、A1（dynamic query）、A8（单麦）、A9（波束网格 30°）。
`configs/` 为两阶段配置，`results/` 为各变体 checkpoint 与 `allpos.json`。当前使用的
消融结果已迁到 `paper_experiments/table5_ablation/`。
