# （归档）主模型早期检测评测

主模型早期检测指标（AUC / FPR / FRR@1h）评测产物，`results/final_v6c/`。
当前使用的检测评测脚本与结果在 `paper_experiments/table6_detection/`。
