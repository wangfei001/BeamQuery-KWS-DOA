#!/bin/bash
set -u
cd /242602/wekws/examples/hi_xiaowen_duolu/s0_deepseek_3
L=paper_experiments/24h_plan/logs/hourly.log
S=paper_experiments/24h_plan/STATUS.json
{
  echo "===== $(date -u +%Y-%m-%dT%H:%M:%SZ) ====="
  cat "$S" 2>/dev/null || true
  echo "--- procs ---"
  ps -eo pid,etime,pcpu,pmem,cmd | grep -E "run_24h_plan|run_forever|run_extras|wekws/bin/train.py|gen_multi_channel_wav" | grep -v grep | head -20
  echo "--- gpu ---"
  nvidia-smi --query-gpu=memory.used,utilization.gpu --format=csv,noheader
  echo "--- validation ---"
  find data_val10k/eval_wav -name "*.wav" 2>/dev/null | wc -l
  wc -l data_val10k/eval_varcol.tmp.list 2>/dev/null || true
  echo "--- latest logs ---"
  tail -5 paper_experiments/24h_plan/logs/runner.log 2>/dev/null
  echo "--- extras ---"
  cat paper_experiments/24h_plan/EXTRAS_STATUS.json 2>/dev/null || echo "extras not finished"
  tail -3 paper_experiments/24h_plan/logs/extras.log 2>/dev/null || true
  echo "--- correctness ---"
  /242602/conda/envs/wekws/bin/python paper_experiments/24h_plan/check_pipeline.py 2>&1 | tail -40
  echo
} >> "$L" 2>&1

# 1) restart the main orchestrator if it died before completing
if ! pgrep -f "run_forever.sh" >/dev/null 2>&1 \
   && ! pgrep -f "run_24h_plan.py" >/dev/null 2>&1 \
   && ! grep -q '"stage": "completed"' "$S" 2>/dev/null; then
  echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] restarting pipeline" >> "$L"
  (setsid nohup bash paper_experiments/24h_plan/run_forever.sh \
      >> paper_experiments/24h_plan/logs/runner.log 2>&1 < /dev/null &)
fi

# 2) once the main pipeline is done, keep the extras runner alive until it
#    reports finished (it retrains the baselines and adds TCSN)
if grep -q '"stage": "completed"' "$S" 2>/dev/null \
   && [ ! -f paper_experiments/24h_plan/EXTRAS_STATUS.json ] \
   && ! pgrep -f "[r]un_extras.py" >/dev/null 2>&1; then
  echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] restarting extras" >> "$L"
  (setsid nohup /242602/conda/envs/wekws/bin/python -u \
      paper_experiments/24h_plan/run_extras.py \
      >> paper_experiments/24h_plan/logs/extras_runner.log 2>&1 < /dev/null &)
fi
