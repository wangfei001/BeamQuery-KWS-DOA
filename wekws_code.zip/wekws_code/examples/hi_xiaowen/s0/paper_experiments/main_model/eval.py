#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Evaluate the proposed BeamQuery model on the full test split.

Produces the prediction npz and the metric json that feed the paper's
detection / localisation / threshold / streaming tables.
"""
import argparse, json, os, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
os.environ.setdefault('USE_BATCHED_FORWARD', '1')
os.environ.setdefault('KWS_MAX_SEC', '3.0')

from paper_experiments.shared.code.eval_fair_cascade import dump_predictions  # noqa


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ckpt', default=str(HERE / 'experiment/best_cv.pt'))
    ap.add_argument('--config', default=str(HERE / 'config.yaml'))
    ap.add_argument('--out_dir', default=str(HERE / 'experiment'))
    ap.add_argument('--gpu', default='0')
    ap.add_argument('--batch_size', type=int, default=64)
    a = ap.parse_args()
    out = Path(a.out_dir); out.mkdir(parents=True, exist_ok=True)
    npz = out / 'test_predictions_fair.npz'
    dump_predictions(a.ckpt, a.config,
                     str(ROOT / 'paper_experiments/table1_corpus/data_lists/test_spatial.list'),
                     str(ROOT / 'paper_experiments/table1_corpus/data_lists/test_varcol.tmp.list'),
                     str(npz), num_mic=2, gpu=a.gpu, batch_size=a.batch_size)
    cmd = [sys.executable, str(ROOT / 'paper_experiments/table7_localisation/eval_allpos_v7.py'),
           '--pred', str(npz),
           '--varcol', str(ROOT / 'paper_experiments/table1_corpus/data_lists/test_varcol.tmp.list'),
           '--label', 'main_test', '--out', str(out / 'test_metrics.json')]
    subprocess.run(cmd, check=True)
    print(json.dumps(json.loads((out / 'test_metrics.json').read_text()), indent=2)[:400])


if __name__ == '__main__':
    main()
