#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Run the strict streaming evaluation of the proposed model (paper Table 9)."""
import argparse, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
P = ROOT / 'paper_experiments/table10_streaming/streaming_parallel.py'
D = ROOT / 'paper_experiments/table1_corpus/data_lists'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ckpt', default=str(HERE / 'experiment/best_cv.pt'))
    ap.add_argument('--config', default=str(HERE / 'config.yaml'))
    ap.add_argument('--out', default=str(HERE / 'experiment/streaming_results.json'))
    ap.add_argument('--workers', type=int, default=48)
    ap.add_argument('--limit', type=int, default=0)
    a = ap.parse_args()
    cmd = [sys.executable, str(P),
           '--checkpoint', a.ckpt, '--config', a.config,
           '--test_data', str(D / 'test_spatial.list'),
           '--test_varcol', str(D / 'test_varcol.tmp.list'),
           '--out', a.out, '--workers', str(a.workers)]
    if a.limit:
        cmd += ['--limit', str(a.limit)]
    sys.exit(subprocess.run(cmd).returncode)


if __name__ == '__main__':
    main()
