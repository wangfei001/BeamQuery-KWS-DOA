# main_model — 主模型（BeamQuery）

主模型的唯一代码目录；训练/评测管线通过 `wekws/model/spatial_dynamic_query.py` 等运行时
副本导入同一份实现。

| 文件 | 内容 |
|---|---|
| `model.py` | `SpatialDynamicQueryModel`、`QueryHead`、`SetMatchingLoss`（规范副本） |
| `batched_forward.py` | 训练/评测使用的批量（向量化）前向 |
| `streaming.py` | 因果 `StreamingBeamKWS` + 严格 `StreamingDecoder` |
| `configs/stage1.yaml`、`configs/stage2.yaml` | 两阶段训练配置（最终 Δ=8°） |
| `config.yaml` | 发布配置（Δ=8°、λ_wake=0.3、`run_max_logit`、`causal`、`running` 归一化） |
| `train.sh` | 两阶段训练入口 |
| `eval.py` | 全测试集预测 + `test_metrics.json` |
| `run_streaming.py` | 严格流式评测 |
| `experiment/` | 选中的 checkpoint、预测与指标 |

```bash
bash  paper_experiments/main_model/train.sh
python paper_experiments/main_model/eval.py
python paper_experiments/main_model/run_streaming.py
```

设计要点：每个方位类别拥有一个延迟求和波束 query；检测与方位绑定共用一个 `Q+1` 目标，
并配以 detached 辅助唤醒头；`run_max_logit` 是流式使用的因果统计量。
