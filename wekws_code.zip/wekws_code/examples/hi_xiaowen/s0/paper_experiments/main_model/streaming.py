# Copyright (c) 2026
# -*- coding: utf-8 -*-
"""提出方法的流式（低延迟）推理实现与实测。

创新点对应
----------
beam 模式的波束特征是**逐帧局部**的（只依赖当前 STFT 帧），因此天然可流式化；
真正阻碍流式的只有两处：
  1) 编码器是 kernel=5、左右各 pad 2 的**非因果**卷积 → 改成左 pad 的因果卷积；
  2) 池化是**全段** mean_max → 改成因果 EMA + 滑窗 max(可配置)。

本文件提供
----------
- ``causal_forward``  : 向量化因果前向（用于微调，长度不敏感）
- ``StreamingDecoder``: 严格的"逐帧到达即算"实现，用于测真实延迟/RTF
- ``main``            : 载入非流式 ckpt → 转流式 → (可选)微调 → 评测 KWS/DOA/RTF/延迟

用法：
  python code_duibi/streaming_model.py --checkpoint exp/spatial_model/best_cv.pt \
      --out exp/duibi/streaming_results.json --finetune_epochs 10
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")))

from wekws.dataset.spatial_kws_dataset import SpatialKwsDataset, spatial_collate_fn  # noqa: E402
from wekws.model.spatial_dynamic_query import SpatialDynamicQueryModel  # noqa: E402
from wekws.utils.spatial_metrics import wake_detection_metrics  # noqa: E402
from torch.utils.data import DataLoader  # noqa: E402
from paper_experiments.shared.code.common import detection_metrics, doa_metrics, frr_at_far  # noqa: E402


class StreamingBeamKWS(nn.Module):
    """beam 模式的因果流式版本；权重从非流式/因果模型迁移。

    支持两种编码器归一化：
      * "affine"  ：InstanceNorm1d（带 weight/bias）—— 旧的非因果模型
      * "running" ：nn.Identity，训练时走 causal_running_norm（累计均值/方差）
                    —— 原生流式模型用这一种，流式推理可**逐位复现**训练时的行为
    """

    def __init__(self, base: SpatialDynamicQueryModel, ema_decay=0.98, max_window=50):
        super().__init__()
        self.num_query = base.num_query
        self.n_fft = base.n_fft
        self.hop = base.hop_length
        self.win = base.win_length
        self.sr = base.sr
        self.mic_spacing = base.mic_spacing
        self.speed = base.speed_sound
        self.beam_angles = base.beam_angles_per_class
        self.ema_decay, self.max_window = ema_decay, max_window
        self.register_buffer("window", base.window.clone())

        convs = list(base.encoder.conv_layers[0::3])
        norms = list(base.encoder.conv_layers[1::3])
        self.enc_weight = nn.ParameterList(
            [nn.Parameter(c.weight.detach().clone()) for c in convs])
        self.enc_bias = nn.ParameterList(
            [nn.Parameter(c.bias.detach().clone()) for c in convs])

        # 归一化层：区分 affine(InstanceNorm) 与 running(Identity -> 累计统计)
        self.norm_kind = []
        iw, ib = [], []
        for m in norms:
            if getattr(m, "weight", None) is not None:
                self.norm_kind.append("affine")
                iw.append(nn.Parameter(m.weight.detach().clone()))
                ib.append(nn.Parameter(m.bias.detach().clone()))
            else:
                self.norm_kind.append("running")
                iw.append(nn.Parameter(torch.zeros(1), requires_grad=False))
                ib.append(nn.Parameter(torch.zeros(1), requires_grad=False))
        self.in_w = nn.ParameterList(iw)
        self.in_b = nn.ParameterList(ib)
        self.head = base.head
        self.kernel = self.enc_weight[0].shape[-1]
        self.norm_running = {}

    # ---------------- 特征：逐帧波束（与非流式 _beam_features 等价） ----------------
    def _beam_frame(self, stft_frame, freqs, pos):
        """stft_frame [M,F] -> [Q, 2F]"""
        total_mag = stft_frame.abs().sum(dim=0) + 1e-6        # [F]
        feats = []
        for angles in self.beam_angles:
            mag_max = None
            for ang in angles:
                tau = pos * math.cos(math.radians(ang)) / self.speed     # [M]
                steer = torch.exp(
                    1j * 2.0 * math.pi * freqs.unsqueeze(0) * tau.unsqueeze(1))  # [M,F]
                mag = (stft_frame * steer).sum(dim=0).abs()               # [F]
                mag_max = mag if mag_max is None else torch.maximum(mag_max, mag)
            coh = (mag_max / total_mag).clamp(0.0, 1.0)
            feats.append(torch.cat([torch.log1p(mag_max), coh], dim=0))
        return torch.stack(feats, dim=0)                      # [Q,2F]

    def _causal_conv(self, x, li):
        """x [Q, T, D] -> [Q, T, D_out]，因果（只左 pad k-1）。

        修正记录：原实现写 `x.transpose(0,1).transpose(1,2)` 并按 batch=1 的注释
        理解成 [1,D,T]，但 Q>1 时实际得到 [T,D,Q] —— 卷积沿 query 维(长度3)而非
        时间轴进行，是流式结果退化到随机水平的直接原因。
        """
        w = self.enc_weight[li].to(x.dtype)                   # [D_out, D_in, k]
        b = self.enc_bias[li].to(x.dtype)
        x_t = x.transpose(1, 2)                               # [Q, D, T]
        x_t = F.pad(x_t, (self.kernel - 1, 0))
        y = F.conv1d(x_t, w, b, padding=0)                    # [Q, D_out, T]
        return y.transpose(1, 2)                              # [Q, T, D_out]

    def _norm(self, x, li, running=None):
        """x [Q,T,D]。返回 (归一化结果, 新的累计状态或 None)。

        * running 层：与训练时的 causal_running_norm 完全一致（累计 0..t 帧统计）
        * affine  层：整段/上下文统计 + 仿射（旧模型）
        """
        if self.norm_kind[li] == "running":
            if running is None:
                cnt = torch.arange(1, x.shape[1] + 1, device=x.device,
                                   dtype=x.dtype).view(1, -1, 1)
                mean = x.cumsum(1) / cnt
                var = (x * x).cumsum(1) / cnt - mean * mean
                return (x - mean) / var.clamp_min(1e-6).sqrt(), None
            s, sq, n = running
            n = n + 1
            s = s + x
            sq = sq + x * x
            mean = s / n
            var = (sq / n - mean * mean).clamp_min(1e-6)
            return (x - mean) / var.sqrt(), (s, sq, n)
        w, b = self.in_w[li].to(x.dtype), self.in_b[li].to(x.dtype)
        mean = x.mean(dim=1, keepdim=True)
        var = x.var(dim=1, keepdim=True, unbiased=False)
        return (x - mean) / torch.sqrt(var + 1e-5) * w + b, None

    def forward(self, wave, causal_pool=True):
        """wave [M,T] -> 逐帧 s_logits [T', Q]（向量化，与流式解码器同算子）。"""
        stft = torch.stft(wave, n_fft=self.n_fft, hop_length=self.hop,
                          win_length=self.win, window=self.window, return_complex=True)
        M, Fb, T = stft.shape
        freqs = torch.fft.rfftfreq(self.n_fft, d=1.0 / self.sr).to(stft.device)
        pos = (torch.arange(M, device=stft.device, dtype=torch.float32)
               - (M - 1) / 2.0) * self.mic_spacing
        feat = torch.stack([self._beam_frame(stft[:, :, t], freqs, pos)
                            for t in range(T)], dim=1)        # [Q,T,2F]
        h = feat
        for li in range(len(self.enc_weight)):
            h = self._causal_conv(h, li)
            h, _ = self._norm(h, li, None)
            h = F.gelu(h)
        # run_max_logit 与训练/离线前向一致：逐帧累计均值/最大值，
        # 每个时间点都送入共享头，最后由调用方在时间维取最大。
        n = torch.arange(1, h.shape[1] + 1, device=h.device,
                         dtype=h.dtype).view(1, -1, 1)
        rmean = h.cumsum(dim=1) / n                           # [Q,T,D]
        rmax = h.cummax(dim=1).values                         # [Q,T,D]
        pooled = torch.cat([rmean, rmax], dim=-1)             # [Q,T,2D]
        s, _, wake = self.head(pooled)                        # [Q,T]
        s = s.transpose(0, 1)                                 # [T,Q]
        wake = None if wake is None else wake.transpose(0, 1) # [T,Q] or None
        return s, wake


class StreamingDecoder:
    """逐帧状态机：模拟真实实时推理，测首帧输出延迟与 RTF。

    维护：STFT 重叠缓冲、每层卷积上下文 (k-1 帧)、每层累计归一化状态、
          运行均值与运行最大值。
    """

    def __init__(self, model: StreamingBeamKWS, hist_frames=20):
        self.m = model
        self.k = model.kernel
        self.hist = hist_frames
        self.reset()

    def reset(self):
        m = self.m
        ref = m.window
        self.audio_buf = torch.zeros(0, device=ref.device, dtype=ref.dtype)
        # 保留原始音频末尾至少 m2+1 个样本，flush 时按 torch.stft 的
        # center=True/reflect 语义补右端，避免缓冲区尾部不足时无法反射。
        self.recent = torch.zeros(0, device=ref.device, dtype=ref.dtype)
        self._padded = False
        self._flushed = False
        self.conv_ctx = [torch.zeros(m.num_query, self.hist + self.k - 1,
                                     w.shape[1], device=ref.device, dtype=ref.dtype)
                         for w in m.enc_weight]
        self.norm_state = [None] * len(m.enc_weight)   # 每层累计 (sum, sumsq, count)
        self.run_sum = None
        self.run_max = None
        self.t = 0

    def _pad_left(self):
        """按 stft(center=True, pad_mode='reflect') 补左端。"""
        if self._padded or self.audio_buf.numel() == 0:
            return
        m2 = self.m.n_fft // 2
        # reflect 要求输入长度严格大于 pad 长度；短输入等后续 chunk。
        if self.audio_buf.shape[-1] <= m2:
            return
        self.audio_buf = F.pad(self.audio_buf, (m2, 0), mode="reflect")
        self._padded = True

    def _append_right_pad(self):
        """按中心 STFT 的 reflect 语义补右端；只使用原始音频尾部。"""
        m2 = self.m.n_fft // 2
        if self.recent.shape[-1] <= m2:
            raise RuntimeError(
                f"audio too short for reflect pad: {self.recent.shape[-1]} <= {m2}")
        right = F.pad(self.recent, (0, m2), mode="reflect")[..., -m2:]
        self.audio_buf = torch.cat([self.audio_buf, right], dim=-1)

    def _drain(self):
        """消费当前缓冲区中所有完整窗口，返回 (s_logits, wake_logits)。"""
        m = self.m
        outs_s, outs_w = [], []
        while self.audio_buf.shape[-1] >= m.win:
            frame = self.audio_buf[..., :m.win]
            self.audio_buf = self.audio_buf[..., m.hop:]
            spec = torch.fft.rfft(frame * m.window, dim=-1)     # [M,F]（单帧 STFT）
            M, Fb = spec.shape
            freqs = torch.fft.rfftfreq(m.n_fft, d=1.0 / m.sr).to(spec.device)
            pos = (torch.arange(M, device=spec.device, dtype=torch.float32)
                   - (M - 1) / 2.0) * m.mic_spacing
            feat = m._beam_frame(spec, freqs, pos).unsqueeze(1)  # [Q,1,2F]
            h = feat
            for li in range(len(m.enc_weight)):
                ctx = torch.cat([self.conv_ctx[li], h], dim=1)[:, -(self.hist + self.k - 1):]
                self.conv_ctx[li] = ctx
                y = m._causal_conv(ctx, li)[:, -1:]
                # 首帧必须显式初始化累计状态 (0,0,0)，否则会走"单帧累计"
                # 分支 -> var=0 -> 输出恒为 0 且状态永不累积
                if self.norm_state[li] is None:
                    self.norm_state[li] = (torch.zeros_like(y),
                                           torch.zeros_like(y), 0)
                ny, st = m._norm(y, li, self.norm_state[li])
                self.norm_state[li] = st
                h = F.gelu(ny)
            # running mean/max 与 run_max_logit 的离线训练目标逐帧一致
            cur = h[:, 0]                                     # [Q,D]
            self.t += 1
            if self.run_sum is None:
                self.run_sum = cur.clone()
                self.run_max = cur.clone()
            else:
                self.run_sum = self.run_sum + cur
                self.run_max = torch.maximum(self.run_max, cur)
            rmean = self.run_sum / float(self.t)
            pooled = torch.cat([rmean, self.run_max], dim=-1).unsqueeze(0)  # [1,Q,2D]
            s, _, wake = m.head(pooled)                                   # [1,Q]
            outs_s.append(s[0])                                           # [Q]
            if wake is not None:
                outs_w.append(wake[0])                                    # [Q]
        if not outs_s:
            return torch.zeros(0, m.num_query, device=self.audio_buf.device,
                               dtype=self.audio_buf.dtype), None
        s_out = torch.stack(outs_s, dim=0)
        w_out = torch.stack(outs_w, dim=0) if outs_w else None
        return s_out, w_out

    @torch.no_grad()
    def push(self, chunk):
        """送入一段新音频 [M, n]，返回该 chunk 内每帧的 s_logits [n_frames, Q]。"""
        if self._flushed:
            raise RuntimeError("push() after flush(); call reset() for a new utterance")
        self.audio_buf = torch.cat([self.audio_buf, chunk], dim=-1)
        self.recent = torch.cat([self.recent, chunk.detach()], dim=-1)
        m2 = self.m.n_fft // 2
        keep = m2 + 1
        if self.recent.shape[-1] > keep:
            self.recent = self.recent[..., -keep:]
        self._pad_left()
        return self._drain()

    @torch.no_grad()
    def flush(self):
        """结束当前语句：补右端 reflect padding，并输出剩余完整帧。"""
        if self._flushed:
            return torch.zeros(0, self.m.num_query, device=self.audio_buf.device,
                               dtype=self.audio_buf.dtype), None
        if self.audio_buf.numel() == 0:
            self._flushed = True
            return torch.zeros(0, self.m.num_query, device=self.audio_buf.device,
                               dtype=self.audio_buf.dtype), None
        self._pad_left()
        if not self._padded:
            raise RuntimeError("audio too short for left reflect pad")
        self._append_right_pad()
        out = self._drain()
        self._flushed = True
        return out

def convert(base):
    stream = StreamingBeamKWS(base)
    stream.to(next(base.parameters()).device)
    stream.eval()
    return stream


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", default="exp/spatial_model/best_cv.pt")
    ap.add_argument("--config", default="conf/train_dynamic_query.yaml")
    ap.add_argument("--out", default="exp/duibi/streaming_results.json")
    ap.add_argument("--test_data", default="data/spatial/test_spatial.list")
    ap.add_argument("--test_varcol", default="data/spatial/test_varcol.tmp.list")
    ap.add_argument("--limit", type=int, default=300)
    ap.add_argument("--chunk_ms", type=float, default=100.0)
    ap.add_argument("--target_far", type=float, default=1.0,
                    help="FAR/h used to calibrate the streaming decision threshold")
    ap.add_argument("--work_threshold", type=float, default=None,
                    help="fixed probability threshold; if omitted, calibrate on this split")
    args = ap.parse_args()

    import yaml
    cfg = yaml.safe_load(open(args.config))
    model = SpatialDynamicQueryModel(
        fsmn_num_layers=cfg["fsmn_num_layers"], fsmn_dim=cfg["fsmn_dim"],
        num_query=cfg["num_query"], doa_num_class=cfg["doa_num_class"],
        feat_freq_dim=cfg["feat_freq_dim"], use_ipd=cfg.get("use_ipd", True),
        use_pair_ipd=cfg.get("use_pair_ipd", True), num_mic=cfg["num_mic"],
        pool_type=cfg.get("pool_type", "mean_max"),
        pair_feat_mode=cfg.get("pair_feat_mode", "tdoa"),
        mic_spacing=cfg.get("mic_spacing", 0.033), sr=cfg.get("sr", 16000),
        use_query_embed=cfg.get("use_query_embed", True),
        use_presence_head=cfg.get("use_presence_head", True),
        use_wake_head=cfg.get("use_wake_head", True),
        query_mode=cfg.get("query_mode", "beam"),
        causal=cfg.get("causal", False),
        norm_type=cfg.get("norm_type", "auto"),
        encoder_type=cfg.get("encoder_type", "auto"),
        encoder_kwargs=cfg.get("encoder_kwargs", None),
        mel_compress=cfg.get("mel_compress", 0),
        mel_keep_coh=cfg.get("mel_keep_coh", False))
    state = torch.load(args.checkpoint, map_location="cpu")
    model.load_state_dict(state["model"] if "model" in state else state)
    model.eval()
    stream = convert(model)

    ds = SpatialKwsDataset(args.test_data, args.test_varcol, max_gt=3)
    if args.limit:
        # 分层取样：正负各半，否则列表按类别聚集、AUC 无法计算
        _pos = [it for it in ds.items if it[3] == 1]
        _neg = [it for it in ds.items if it[3] == 0]
        _h = args.limit // 2
        ds.items = _pos[:_h] + _neg[:args.limit - _h]
    loader = DataLoader(ds, batch_size=1, shuffle=False, collate_fn=spatial_collate_fn)

    chunk = int(args.chunk_ms / 1000.0 * 16000)
    lat_list, rtf_list, s_peak, s_last, s_cls, y_list, ang_list = [], [], [], [], [], [], []
    wake_scores, fallback_scores, prob_frames, durations = [], [], [], []
    for wave_list, _, _, _, kws_label, wake_angle in loader:
        wav = wave_list[0]
        dec = StreamingDecoder(stream)
        t0 = time.perf_counter()
        outs_s, outs_w = [], []
        for i in range(0, wav.shape[-1], chunk):
            ss, ww = dec.push(wav[:, i:i + chunk])
            outs_s.append(ss)
            if ww is not None:
                outs_w.append(ww)
        # End-of-utterance flush is part of strict decoding: it consumes the
        # right-reflect-padded frames and must be included in RTF/latency.
        ss, ww = dec.flush()
        outs_s.append(ss)
        if ww is not None:
            outs_w.append(ww)
        elapsed = time.perf_counter() - t0
        s = torch.cat(outs_s, 0) if outs_s else torch.zeros(0, stream.num_query)
        wake = torch.cat(outs_w, 0) if outs_w else None
        dur = wav.shape[-1] / 16000.0
        # 与离线 eval_fair_cascade / run_max_logit 一致：有独立唤醒头时用
        # max_{Q,t} wake_logit 检测（所有帧，含末尾 flush 帧）。
        if wake is not None:
            prob = torch.sigmoid(wake).max(dim=-1).values
            wake_scores.append(float(prob.max()))
        else:
            prob = torch.sigmoid(s).max(dim=-1).values           # 回退到 query max
            fallback_scores.append(float(prob.max()))
            wake_scores.append(None)
        # 流式判决规则 1（peak）：唤醒概率最高的那一帧。
        # 规则 2（last）：句末完整帧，与 run_max_logit 的末帧语义一致。
        # 规则 3（class-max）：每个 query 取历史最强响应，再 argmax 方向。
        best_t = int(prob.argmax()) if prob.numel() else 0
        zero = torch.zeros(stream.num_query)
        s_peak.append(s[best_t].detach().cpu() if s.numel() else zero)
        s_last.append(s[-1].detach().cpu() if s.numel() else zero)
        s_cls.append(s.max(dim=0).values.detach().cpu() if s.numel() else zero)
        prob_frames.append(prob.detach().cpu())
        y_list.append(int(kws_label[0]))
        ang_list.append(int(wake_angle[0]))
        durations.append(dur)
        rtf_list.append(elapsed / dur)

    y = np.asarray(y_list); angles = np.asarray(ang_list)
    durations = np.asarray(durations, dtype=np.float64)
    valid = angles >= 0
    all_pos = (y == 1) & valid
    if wake_scores and wake_scores[0] is not None:
        det_scores = np.asarray(wake_scores, dtype=np.float64)
    else:
        det_scores = np.asarray(fallback_scores, dtype=np.float64)
    # The default work point is FAR=target_far/h on the evaluation split,
    # matching the rest of the paper's operational-point convention.
    far = frr_at_far(det_scores, y, durations, args.target_far)
    work_thr = float(args.work_threshold) if args.work_threshold is not None else float(far["threshold"])
    det = detection_metrics(det_scores, y, threshold=work_thr)
    # If a fixed full-test threshold is supplied, report FRR at that actual
    # work point.  The subset-calibrated FAR point is kept separately because
    # 150 negatives cannot resolve one false alarm per hour.
    frr_work = float(1.0 - det["recall"])
    # Per-frame latency at the selected operational threshold.
    for prob in prob_frames:
        hit = torch.nonzero(prob > work_thr)
        lat_list.append((float(hit[0, 0]) * stream.hop + stream.win) / 16000.0 * 1000.0
                        if hit.numel() else float("nan"))

    res = {}
    for tag, lst in (("peak", s_peak), ("last", s_last), ("class_max", s_cls)):
        sc = torch.stack(lst).numpy()
        pred_cls = sc.argmax(axis=1)
        dm_all = doa_metrics(pred_cls[all_pos], angles[all_pos])
        det_pos = (y == 1) & valid & (det_scores > work_thr)
        dm_det = doa_metrics(pred_cls[det_pos], angles[det_pos])
        joint_all = float(np.mean((det_scores[all_pos] > work_thr) &
                                  (pred_cls[all_pos] == angles[all_pos]))) if all_pos.any() else float("nan")
        res[tag] = {
            "wake_auc": det["auc"],
            "wake_recall": det["recall"],          # at work_thr
            "fpr": det["fpr"],                     # at work_thr
            "frr_at_far1h": frr_work,
            "work_threshold": work_thr,
            "eval_far1h_threshold": float(far["threshold"]),
            "eval_far1h_frr": float(far["frr"]),
            "doa_acc": dm_det["doa_acc"],
            "mean_deg_err": dm_det["mean_deg_err"],
            "doa_acc_all": dm_all["doa_acc"],
            "mean_deg_err_all": dm_all["mean_deg_err"],
            "joint_all": joint_all,
            "n_det_pos": int(det_pos.sum()),
            "n_all_pos": int(all_pos.sum()),
        }
    out = {"streaming": {
        "peak_prob_frame": res["peak"],      # 低延迟判决
        "class_max_time": res["class_max"],  # 与检测同构
        "last_frame": res["last"],           # 与离线 run_max_logit 末帧同构
        "work_threshold": work_thr,
        "target_far": args.target_far,
        "rtf_mean": float(np.mean(rtf_list)),
        "rtf_p95": float(np.percentile(rtf_list, 95)),
        "latency_ms_mean": float(np.nanmean(lat_list)) if not np.all(np.isnan(lat_list)) else None,
        "chunk_ms": args.chunk_ms, "n_samples": len(y_list)}}
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    json.dump(out, open(args.out, "w", encoding="utf-8"), indent=2)
    print(json.dumps(out, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
