# -*- coding: utf-8 -*-
"""提出方法的【批量化前向】——数值等价，速度数量级提升。

原实现 SpatialDynamicQueryModel.forward 逐样本循环(batch=32 就是 32 次串行
单样本前向)，GPU 利用率极低。本文件不改动原文件，用子类覆盖 forward，
复用同一套子模块与权重，因此 state_dict 完全兼容。

等价性处理
----------
1. 波形 pad 到 batch 内最大长度；卷积本身是零 padding，pad 区与 conv 的
   零 padding 数值一致，因此有效帧的卷积结果与原实现相同。
2. InstanceNorm1d 默认统计整段(含 padding 帧) -> 改为【只在有效帧上】统计
   均值/方差，再套用同一组 affine 参数，与原实现(单样本=只有有效帧)一致。
3. 池化 mean/max -> 改为【只在有效帧上】求均值/最大值。
"""
import math
import os
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, REPO)

from wekws.model.spatial_dynamic_query import (  # noqa: E402
    SpatialDynamicQueryModel, causal_running_norm)


def masked_instance_norm(norm_layer, x, mask):
    """nrom_layer: InstanceNorm1d(affine=True)；x [B,C,T]；mask [B,1,T] (1=有效)。"""
    if mask is None:
        return norm_layer(x)
    m = mask.to(x.dtype)                              # [B,1,T]
    denom = m.sum(dim=-1, keepdim=True).clamp(min=1.0)
    mean = (x * m).sum(dim=-1, keepdim=True) / denom
    var = ((x - mean) ** 2 * m).sum(dim=-1, keepdim=True) / denom
    y = (x - mean) / torch.sqrt(var + norm_layer.eps)
    if norm_layer.affine:
        y = y * norm_layer.weight.view(1, -1, 1) + norm_layer.bias.view(1, -1, 1)
    return y


def _align(x, mask):
    """把 mask 扩展到与 x 同秩（在 dim=1 处补 1），避免 [B,Q,D,T] 与 [B,1,T] 广播错位。"""
    m = mask
    while m.dim() < x.dim():
        m = m.unsqueeze(1)
    return m


def masked_mean(x, mask):
    m = _align(x, mask).to(x.dtype)
    return (x * m).sum(dim=-1) / m.sum(dim=-1).clamp(min=1.0)


def masked_max(x, mask):
    m = _align(x, mask)
    neg = torch.finfo(x.dtype).min
    return x.masked_fill(m <= 0, neg).max(dim=-1).values


class BatchedSpatialDynamicQuery(SpatialDynamicQueryModel):
    """与父类数学等价、但按 batch 向量化的 forward。"""

    def _steering_grid(self, M, Fb, device, dtype):
        """预计算并缓存全部角度的导向矢量：[N_ang, M, F]（与输入无关，只需算一次）。

        原实现每次前向都重算 exp(1j*2*pi*f*tau)，15 个角度 x 3 类 = 45 次小算子调用，
        在 CPU 上串行排队，是训练的主要瓶颈（GPU 利用率仅 ~20%）。
        """
        key = (M, Fb, str(device))
        cache = getattr(self, "_steer_cache", None)
        if cache is None:
            cache = {}
            object.__setattr__(self, "_steer_cache", cache)
        if key in cache:
            return cache[key]
        freqs = torch.fft.rfftfreq(self.n_fft, d=1.0 / self.sr).to(device)
        pos = (torch.arange(M, device=device, dtype=torch.float32)
               - (M - 1) / 2.0) * self.mic_spacing
        all_ang, idx = [], []
        for angles in self.beam_angles_per_class:
            idx.append((len(all_ang), len(angles)))
            all_ang.extend(angles)
        tau = torch.stack([pos * math.cos(math.radians(a)) / self.speed_sound
                           for a in all_ang], dim=0)                     # [N,M]
        phase = 2.0 * math.pi * freqs.view(1, 1, -1) * tau.unsqueeze(-1)  # [N,M,F]
        # 存成实数 (cos, sin)，后续用实数 einsum —— PyTorch 的复数算子效率很低
        steer = torch.stack([torch.cos(phase), torch.sin(phase)], dim=-1)  # [N,M,F,2]
        cache[key] = (steer, idx)
        return cache[key]

    def _beam_features_batched(self, stft):
        """stft: [B,M,F,T] -> [B,Q,2F,T]"""
        B, M, Fb, T = stft.shape
        steer, idx = self._steering_grid(M, Fb, stft.device, stft.dtype)
        total_mag = stft.abs().sum(dim=1) + 1e-6                          # [B,F,T]
        outs = []
        for off, cnt in idx:
            s_block = steer[off:off + cnt]                                # [n,M,F,2]
            cr = s_block[..., 0]                                          # cos [n,M,F]
            ci = s_block[..., 1]                                          # sin [n,M,F]
            xr = stft.real                                                # [B,M,F,T]
            xi = stft.imag
            # 实数运算替代复数: (xr + j xi)(cr + j ci)
            re = torch.einsum("bmft,nmf->bnft", xr, cr) - \
                 torch.einsum("bmft,nmf->bnft", xi, ci)
            im = torch.einsum("bmft,nmf->bnft", xr, ci) + \
                 torch.einsum("bmft,nmf->bnft", xi, cr)
            # ===== 关键修复 =====
            # 原写法 sqrt(re^2+im^2+1e-12) 在静音/补零帧(beam=0)会给出 1e-6，
            # 而 total_mag 也含 +1e-6，导致 coh = 1e-6/1e-6 = 1.0；
            # 原始逐样本实现的 |beam| 在静音帧精确为 0 -> coh = 0.0。
            # 两者相差 1.0，占特征元素 ~21%，训练依赖了该伪影。
            # 改为直接对复数取模（与原始实现逐位一致，且在 0 处梯度为 0，不会 NaN）。
            beam = torch.complex(re, im).abs()                            # [B,n,F,T]
            mag_max = beam.max(dim=1).values                              # [B,F,T]
            coh = (mag_max / total_mag).clamp(0.0, 1.0)
            if getattr(self, "mel_compress", 0) > 0:
                fb = self.mel_fb_ab.to(mag_max.dtype)              # [n_mels, F]
                mag_c = torch.matmul(fb, mag_max)                  # [B,n_mels,T]
                if getattr(self, "mel_keep_coh", False):
                    coh_c = torch.matmul(fb, coh)
                    outs.append(torch.cat([torch.log1p(mag_c), coh_c], dim=1))
                else:
                    outs.append(torch.log1p(mag_c))
            else:
                outs.append(torch.cat([torch.log1p(mag_max), coh], dim=1))
        return torch.stack(outs, dim=1)

    def forward(self, wave_list):
        # 非 beam 模式（如消融 A1 的 dynamic query）没有 beam_angles_per_class，
        # 批量波束特征不适用，回退到原始逐样本实现。
        if getattr(self, "query_mode", "beam") != "beam":
            return self._orig_forward(wave_list)
        # 统一成 [B,M,T]，M 必须一致（本实验固定 2 麦）
        if isinstance(wave_list, torch.Tensor) and wave_list.dim() == 3:
            padded, lens = wave_list, None
        else:
            Ms = {w.shape[0] for w in wave_list}
            if len(Ms) != 1:
                raise ValueError('批量化前向要求 batch 内通道数一致')
            M = wave_list[0].shape[0]
            lens = [w.shape[-1] for w in wave_list]
            T_max = max(lens)
            B = len(wave_list)
            padded = torch.zeros(B, M, T_max, device=wave_list[0].device,
                                 dtype=wave_list[0].dtype)
            for i, w in enumerate(wave_list):
                padded[i, :, :w.shape[-1]] = w
        B, M, T_max = padded.shape
        if lens is None:
            lens = [T_max] * B
        valid_len = torch.tensor(lens, device=padded.device)

        # ① 批量 STFT: [B*M, T] -> [B,M,F,T']
        spec = torch.stft(padded.reshape(B * M, T_max), n_fft=self.n_fft,
                          hop_length=self.hop_length, win_length=self.win_length,
                          window=self.window, return_complex=True)
        Fb, Tf = spec.shape[-2], spec.shape[-1]
        spec = spec.view(B, M, Fb, Tf)
        # 帧级有效 mask：按帧中心是否落在样本长度内
        # 原实现 torch.stft(center=True) 对长度 T 产生 1+T//hop 帧，
        # 故有效帧判据为 i*hop <= T（含最后一个边界帧）
        frame_pos = torch.arange(Tf, device=padded.device) * self.hop_length
        fmask = (frame_pos.view(1, 1, Tf) <= valid_len.view(B, 1, 1)).to(padded.dtype)

        # ② 批量化波束特征: [B,Q,2F,T']
        beam = self._beam_features_batched(spec)

        # ③ 每个方位类一次编码器（batch 维是 B，不再是 1）
        # 把 Q 折进 batch 维，编码器只调用一次（原来调用 3 次）：
        # 3 次小 batch -> 1 次大 batch，显著降低 Python/框架开销
        Bq0 = beam.shape[0]
        h = beam.reshape(Bq0 * self.num_query, *beam.shape[2:])   # [B*Q,2F,T']
        if not hasattr(self.encoder, "conv_layers"):
            # 共享编码器 = 官方 wekws FSMN（无 conv_layers）：直接整段前向。
            # FSMN 输入 [B,T,C]，这里 h 是 [B,C,T]，故转置两次。
            h = self.encoder(h.transpose(1, 2)).transpose(1, 2)     # [B*Q,D,T']
        else:
          for li in range(len(self.encoder.conv_layers) // 3):
              conv = self.encoder.conv_layers[3 * li]
              norm = self.encoder.conv_layers[3 * li + 1]
              act = self.encoder.conv_layers[3 * li + 2]
              if getattr(self, "causal", False):
                  h = F.pad(h, (self.encoder.left_pad, 0))
              h = conv(h)
              if isinstance(norm, nn.Identity):
                  # 因果运行归一化（逐帧累计，严格不看未来）
                  h = causal_running_norm(h)
              elif isinstance(norm, nn.LayerNorm):
                  h = norm(h.transpose(1, 2)).transpose(1, 2)
              else:
                  h = masked_instance_norm(norm, h, fmask.repeat(self.num_query, 1, 1))
              h = act(h)                                       # [B*Q,D,T']
        q_enc = h.reshape(Bq0, self.num_query, h.shape[1], h.shape[2])  # [B,Q,D,T']

        # ④ 带 mask 的时间池化（对齐父类 TemporalPool 的 mean_max/mean/attn）
        pt = self.temporal_pool.pool_type
        if pt == "mean_max":
            pooled = torch.cat([masked_mean(q_enc, fmask), masked_max(q_enc, fmask)], dim=-1)
        elif pt == "mean":
            pooled = masked_mean(q_enc, fmask)
        elif pt == "ema_max":
            # 先因果 EMA 平滑，再取平滑轨迹的峰值（可流式增量维护）
            a = float(getattr(self.temporal_pool, "ema_decay", 0.9))
            prev = torch.zeros_like(q_enc[..., 0]); best = prev.clone()
            for t in range(q_enc.shape[-1]):
                prev = a * prev + (1.0 - a) * q_enc[..., t]
                best = torch.maximum(best, prev)
            pooled = best
        elif pt == "max":
            pooled = masked_max(q_enc, fmask)
        elif pt == "max_window":
            # 因果滑窗最大值：每个位置取"向前 W 帧"内的最大值（只看过去）
            W = int(getattr(self.temporal_pool, "win", 50))
            Bq, Qq, Dq, Tq = q_enc.shape
            neg = torch.finfo(q_enc.dtype).min
            xm = q_enc.masked_fill(fmask.view(Bq, 1, 1, Tq) <= 0, neg)
            xr = xm.reshape(Bq * Qq, Dq, Tq)
            # max_pool1d 的 padding 有上限，改用 unfold 实现因果滑窗
            xp = F.pad(xr, (W - 1, 0), value=neg)          # 左侧补 W-1
            win = xp.unfold(dimension=-1, size=W, step=1)  # [N,D,T,W]
            pooled = win.max(dim=-1).values.max(dim=-1).values.reshape(Bq, Qq, Dq)
        elif pt == "run_max_logit":
            # ★与流式推理**逐字一致**的统计量：
            #   pooled_t = [running_mean(0..t), running_max(0..t)]   (因果)
            #   s_c(t)   = head(pooled_t)
            #   S_c      = max_t s_c(t)          <- loss 加在这里
            #   检测 = max_c σ(S_c)，方向 = argmax_c S_c
            Bq, Qq, Dq, Tq = q_enc.shape
            dt = q_enc.dtype
            m = fmask.view(Bq, 1, 1, Tq).to(dt)
            ccnt = m.cumsum(-1).clamp_min(1.0)
            rmean = (q_enc * m).cumsum(-1) / ccnt
            neg = torch.finfo(dt).min
            rmax = q_enc.masked_fill(m <= 0, neg).cummax(-1).values
            rmax = torch.where(m > 0, rmax, torch.zeros_like(rmax))
            pooled_t = torch.cat([rmean, rmax], dim=2)            # [B,Q,2D,Tq]
            Cq = pooled_t.shape[2]
            xt = pooled_t.permute(0, 1, 3, 2).reshape(Bq * Qq * Tq, Cq)
            s_t, p_t, w_t = self.head(xt)                         # [B*Q*T]
            s_t = s_t.view(Bq, Qq, Tq)
            s_q = s_t.max(dim=-1).values                          # [B,Q]
            presence = (p_t.view(Bq, Qq, Tq).max(dim=-1).values
                        if p_t is not None else None)
            # 独立唤醒头：逐帧 logit -> query 维最大 -> 时间维最大（流式一致）
            wake = (w_t.view(Bq, Qq, Tq).max(dim=1).values.max(dim=-1).values
                    if w_t is not None else None)
            return {"s_q": s_q, "presence_logit": presence,
                    "wake_logit": wake, "pred_s": s_q}
        elif pt == "attn":
            w = torch.softmax(self.temporal_pool.pool_score(
                q_enc.permute(0, 1, 3, 2)).squeeze(-1), dim=-1)   # [B,Q,T']
            w = w * fmask.squeeze(1).unsqueeze(1)
            w = w / w.sum(-1, keepdim=True).clamp(min=1e-9)
            pooled = torch.einsum("bqt,bqdt->bqd", w, q_enc)
        else:
            raise ValueError(pt)

        # ⑤ 共享预测头
        s_q, presence, wake = self.head(pooled)
        if wake is not None:
            wake = wake.max(dim=-1).values
        return {"s_q": s_q, "presence_logit": presence,
                "wake_logit": wake, "pred_s": s_q}
