# Copyright (c) 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
import math
import os

import torch
import torch.nn as nn
import torch.nn.functional as F


def causal_running_norm(x):
    """因果运行归一化：[B,C,T] -> 用"截至当前帧"的累计均值/方差归一化。

    解决 per-frame LayerNorm 的问题：LayerNorm 只按通道归一化，
    会让通道值随帧漂移，与全局 max 池化冲突（max 被"最响的帧"主导）。
    这里对每个通道做因果的累计归一化，保留时序统计，且严格不看未来。
    """
    B, C, T = x.shape
    cnt = torch.arange(1, T + 1, device=x.device, dtype=x.dtype).view(1, 1, -1)
    mean = torch.cumsum(x, dim=-1) / cnt
    var = (torch.cumsum(x * x, dim=-1) / cnt - mean * mean).clamp_min(1e-6)
    return (x - mean) / var.sqrt()


def make_mel_filterbank(sr=16000, n_fft=512, n_mels=40, fmin=20.0, fmax=None):
    """构造 mel 滤波器组 [n_mels, n_fft//2+1]，与基线用的完全一致。

    用于 BeamQuery-Mel 消融：把波束特征的频率轴从 257 压到 n_mels，
    使输入维度与基线对齐，从而排除"增益仅来自输入信息量"的解释。
    """
    if fmax is None:
        fmax = sr / 2.0
    def hz2mel(f):
        return 2595.0 * math.log10(1.0 + f / 700.0)
    def mel2hz(m):
        return 700.0 * (10 ** (m / 2595.0) - 1.0)
    m_lo, m_hi = hz2mel(fmin), hz2mel(fmax)
    pts = [mel2hz(m_lo + (m_hi - m_lo) * i / (n_mels + 1)) for i in range(n_mels + 2)]
    freqs = torch.linspace(0, sr / 2.0, n_fft // 2 + 1)
    fb = torch.zeros(n_mels, freqs.numel())
    for i in range(n_mels):
        l, c, r = pts[i], pts[i + 1], pts[i + 2]
        fb[i] = torch.clamp(torch.minimum((freqs - l) / (c - l + 1e-8),
                                          (r - freqs) / (r - c + 1e-8)), min=0.0)
    return fb


class Stacked1DCNNEncoder(nn.Module):
    """
    自实现编码器，完全不依赖wekws内部FSMN，规避版本兼容坑
    输入 [B, T, input_dim]
    输出 [B, T, hidden_dim]

    causal=True 时用于流式：
      * 卷积只做左侧 pad(k-1)，不看未来帧
      * 归一化换成 LayerNorm（逐帧、只依赖当前帧），
        避免 InstanceNorm 依赖整段统计量
    """
    def __init__(self, input_dim, hidden_dim, num_layers, causal=False,
                 kernel_size=5, norm_type="auto"):
        super().__init__()
        self.causal = bool(causal)
        self.norm_type = norm_type
        self.kernel_size = int(kernel_size)
        self.left_pad = self.kernel_size - 1
        layers = []
        in_d = input_dim
        for _ in range(num_layers):
            # 因果模式 padding 由 forward 显式左补，这里一律 0
            pad = 0 if self.causal else self.kernel_size // 2
            layers.append(nn.Conv1d(in_d, hidden_dim,
                                    kernel_size=self.kernel_size, padding=pad))
            if self.causal and norm_type == "running":
                layers.append(nn.Identity())                 # 归一化在 forward 里做
            elif self.causal:
                layers.append(nn.LayerNorm(hidden_dim))      # 逐帧归一化
            else:
                layers.append(nn.InstanceNorm1d(hidden_dim, affine=True,
                                                track_running_stats=False))
            layers.append(nn.GELU())
            in_d = hidden_dim
        self.conv_layers = nn.Sequential(*layers)

    def forward(self, x):
        # x: [B, T, C]
        x = x.transpose(1, 2)            # [B, C, T]
        if self.causal:
            # 逐层左补 k-1 帧，保持时间长度不变且严格因果
            for i in range(0, len(self.conv_layers), 3):
                x = F.pad(x, (self.left_pad, 0))
                x = self.conv_layers[i](x)
                norm = self.conv_layers[i + 1]
                if isinstance(norm, nn.Identity):
                    x = causal_running_norm(x)               # 因果运行归一化
                else:
                    x = norm(x)
                x = self.conv_layers[i + 2](x)
            return x.transpose(1, 2)
        y = self.conv_layers(x)
        return y.transpose(1, 2)


# ========================================================================== #
# 共享编码器：官方 wekws FSMN（统一所有方法的"共有模型"）
# ========================================================================== #
KWS_ENCODER_ENV = "KWS_ENCODER"          # cnn | fsmn
DEFAULT_KWS_ENCODER = os.environ.get(KWS_ENCODER_ENV, "cnn").lower()


class WekwsFSMNEncoder(nn.Module):
    """官方 wekws FSMN 作为**共享编码器**（所有方法统一使用）。

    与 ``Stacked1DCNNEncoder`` 接口完全一致：``[B, T, input_dim] -> [B, T, hidden_dim]``，
    因此可在任何位置直接替换。

    结构对应 wekws 官方 KWS 方案
    ---------------------------
    ``preprocessing(linear) -> FSMN(lorder, rorder) -> (池化与分类头在外层)``

    * ``rorder=0``  → **因果 FSMN**：只依赖历史帧。
      训练时用整段音频（非流式训练），推理时可用 ``in_cache`` 逐帧前向（流式推理），
      与 wekws 官方"非流式训练 / 流式推理"一致。
    * ``rorder>0``  → 非因果（可用未来帧）。

    参数含义与 ``wekws.model.fsmn.FSMN`` 一致（input_affine_dim/linear_dim/proj_dim/
    lorder/rorder 等），默认取 wekws 常用配置。
    """

    def __init__(self, input_dim, hidden_dim, num_layers=4, causal=True,
                 lorder=20, rorder=None, proj_dim=None,
                 input_affine_dim=None, linear_dim=None, output_affine_dim=None):
        super().__init__()
        from wekws.model.fsmn import FSMN
        self.causal = bool(causal)
        self.lorder = int(lorder)
        # 因果 -> rorder=0；非因果 -> rorder=lorder（前后各看 lorder 帧）
        self.rorder = (0 if self.causal else self.lorder) if rorder is None else int(rorder)
        self.fsmn = FSMN(
            input_dim=int(input_dim),
            input_affine_dim=int(input_affine_dim or hidden_dim),
            fsmn_layers=int(num_layers),
            linear_dim=int(linear_dim or hidden_dim),
            proj_dim=int(proj_dim or max(hidden_dim // 2, 1)),
            lorder=self.lorder,
            rorder=self.rorder,
            lstride=1,
            rstride=1,
            output_affine_dim=int(output_affine_dim or hidden_dim),
            output_dim=int(hidden_dim),
        )

    def forward(self, x, in_cache=None):
        """x: [B, T, C] -> [B, T, hidden_dim]；in_cache 非空时返回 (y, out_cache)。"""
        streaming = in_cache is not None
        y, out_cache = self.fsmn(x, in_cache if in_cache is not None
                                 else torch.zeros(0, 0, 0, dtype=torch.float))
        return (y, out_cache) if streaming else y


def build_shared_encoder(input_dim, hidden_dim, num_layers=4, causal=False,
                         norm_type="auto", encoder_type=None, **kw):
    """**统一入口**：构造所有方法共用的编码器。

    ``encoder_type`` 取 ``cnn``（原自实现 CNN）或 ``fsmn``（官方 wekws FSMN）。
    未显式给出时读环境变量 ``KWS_ENCODER``，默认 ``cnn`` 以保持向后兼容。
    """
    et = (encoder_type or os.environ.get(KWS_ENCODER_ENV, DEFAULT_KWS_ENCODER)).lower()
    if et == "fsmn":
        # FSMN 自带因果结构，不受 causal 开关影响（由 rorder 控制）
        return WekwsFSMNEncoder(input_dim=input_dim, hidden_dim=hidden_dim,
                                num_layers=num_layers, causal=causal, **kw)
    return Stacked1DCNNEncoder(input_dim=input_dim, hidden_dim=hidden_dim,
                               num_layers=num_layers, causal=causal,
                               norm_type=norm_type)


class FrameWiseQueryGenerator(nn.Module):
    """
    核心模块：逐帧动态生成Query，无手工波束分支
    输入阵列特征: enc_feat [B, M, D, T]
    返回 queries: [B, T, Q, D]
    """
    def __init__(self, encoder_dim: int, num_query: int):
        super().__init__()
        self.num_query = num_query
        self.dim = encoder_dim
        self.mlp = nn.Sequential(
            nn.Linear(encoder_dim, encoder_dim),
            nn.LayerNorm(encoder_dim),
            nn.ReLU(inplace=True),
            nn.Linear(encoder_dim, num_query * encoder_dim)
        )

    def forward(self, enc_feat: torch.Tensor):
        B, M, D, T = enc_feat.shape
        # 在麦克风维度M求平均，输出 [B,D,T]
        frame_global = torch.mean(enc_feat, dim=1)
        frame_global = frame_global.permute(0, 2, 1)  # [B, T, D]
        q_all = self.mlp(frame_global)  # [B, T, Q*D]
        queries = q_all.reshape(B, T, self.num_query, self.dim)
        return queries


class QueryCrossAggregate(nn.Module):
    """
    Query与阵列多通道特征交叉注意力聚合 + 时间维池化。

    pool_type:
      "mean"     : 全段帧平均（原行为）
      "mean_max" : 拼接 [帧平均, 帧最大]，唤醒词只占短时段时 max 不易被稀释
      "attn"     : 可学习注意力池化（逐 query 对时间维 softmax 加权）

    queries:      [B, T, Q, D]
    array_feat:   [B, M, D, T]
    return：[B, Q, D]  (mean_max 时为 [B, Q, 2D])
    """
    def __init__(self, dim: int, pool_type: str = "mean_max"):
        super().__init__()
        self.dim = dim
        self.pool_type = pool_type
        self.q_proj = nn.Linear(dim, dim)
        self.k_proj = nn.Linear(dim, dim)
        self.v_proj = nn.Linear(dim, dim)
        if pool_type == "attn":
            self.pool_score = nn.Linear(dim, 1)

    def forward(self, queries: torch.Tensor, array_feat: torch.Tensor):
        B, T, Q, D = queries.shape
        B, M, D, T = array_feat.shape
        arr = array_feat.permute(0, 3, 1, 2) # [B, T, M, D]
        q = self.q_proj(queries)          # [B, T, Q, D]
        k = self.k_proj(arr)              # [B, T, M, D]
        v = self.v_proj(arr)              # [B, T, M, D]
        attn_score = torch.einsum("btqd,btmd->btqm", q, k) / (D ** 0.5)
        attn_weight = F.softmax(attn_score, dim=-1)
        frame_agg = torch.einsum("btqm,btmd->btqd", attn_weight, v)  # [B,T,Q,D]

        if self.pool_type == "mean":
            out = frame_agg.mean(dim=1)                      # [B,Q,D]
        elif self.pool_type == "mean_max":
            out = torch.cat([frame_agg.mean(dim=1),
                             frame_agg.max(dim=1).values], dim=-1)   # [B,Q,2D]
        elif self.pool_type == "attn":
            w = torch.softmax(self.pool_score(frame_agg).squeeze(-1), dim=1)  # [B,T,Q]
            out = torch.einsum("btq,btqd->bqd", w, frame_agg)                # [B,Q,D]
        else:
            raise ValueError(f"未知 pool_type: {self.pool_type}")
        return out


class TemporalPool(nn.Module):
    """时间维池化：[B,Q,D,T] -> [B,Q,D] 或 [B,Q,2D]。"""

    def __init__(self, dim: int, pool_type: str = "mean_max"):
        super().__init__()
        self.pool_type = pool_type
        if pool_type == "attn":
            self.pool_score = nn.Linear(dim, 1)
        if pool_type in ("max_window", "ema_max"):
            self.win = 50
        if pool_type == "ema_max":
            self.ema_decay = 0.9

    def forward(self, x: torch.Tensor):
        # x: [B, Q, D, T]
        if self.pool_type == "mean":
            return x.mean(dim=-1)
        if self.pool_type == "max":
            # 全段最大值（流式 KWS 标准做法：训练用全段 max，推理用运行 max）
            return x.max(dim=-1).values
        if self.pool_type == "ema_max":
            # 先做因果 EMA 平滑，再取平滑轨迹上的峰值：
            # 保留"峰值"语义，但不会被单个最响的帧主导（可流式增量维护）
            a = getattr(self, "ema_decay", 0.9)
            prev = torch.zeros_like(x[..., 0])
            best = prev
            for t in range(x.shape[-1]):
                prev = a * prev + (1.0 - a) * x[..., t]
                best = torch.maximum(best, prev)
            return best
        if self.pool_type == "mean_max":
            return torch.cat([x.mean(dim=-1), x.max(dim=-1).values], dim=-1)
        if self.pool_type == "max_window":
            # 因果滑窗最大值：每个位置取"向前 W 帧"内的最大值（可流式增量维护）
            w = getattr(self, "win", 50)
            neg = torch.finfo(x.dtype).min
            xp = F.pad(x, (w - 1, 0), value=neg)            # 左侧补 w-1
            win = xp.unfold(dimension=-1, size=w, step=1)   # [..., T, w]
            return win.max(dim=-1).values.max(dim=-1).values
        if self.pool_type == "attn":
            # 逐 (b,q) 对时间维 softmax 加权
            w = torch.softmax(
                self.pool_score(x.permute(0, 1, 3, 2)).squeeze(-1), dim=-1)
            return torch.einsum("bqt,bqdt->bqd", w, x)
        raise ValueError(f"未知 pool_type: {self.pool_type}")


class SharedPredictHead(nn.Module):
    """精简后的共享预测头。

    score_fc    : 每个 query c 的唤醒 logit，query c 直接代表 DOA 类别 c
    presence_fc : 每个 query 的“该方向是否存在声源”二分类 logit（辅助任务）
                  逼共享表示编码方向信息。
    """
    def __init__(self, in_dim: int, use_presence: bool = True,
                 use_wake_head: bool = True, wake_detach: bool = False):
        super().__init__()
        self.use_presence = use_presence
        self.use_wake_head = use_wake_head
        self.fc1 = nn.Linear(in_dim, in_dim)
        self.norm = nn.LayerNorm(in_dim)
        self.score_fc = nn.Linear(in_dim, 1)
        if use_presence:
            self.presence_fc = nn.Linear(in_dim, 1)
        self.wake_detach = wake_detach
        if use_wake_head:
            # 独立二分类唤醒头(BCE)：与"方位 query 的 4 类 softmax"解耦。
            # 4 类 softmax CE 只要赢出 margin 就收敛、正样本分数不饱和，
            # 在 FAR=1/h 这类极端工作点唤醒率低；独立 BCE 头可饱和到 1。
            # wake_detach=True 时梯度不回传主干 -> 完全不干扰方位任务。
            self.wake_fc = nn.Linear(in_dim, 1)

    def forward(self, q_feat: torch.Tensor):
        x = self.fc1(q_feat)
        x = self.norm(x)
        x = F.relu(x)
        # 输出logit，训练使用 BCEWithLogitsLoss；sigmoid放到推理阶段
        s_logit = self.score_fc(x).squeeze(-1)
        presence_logit = None
        if self.use_presence:
            presence_logit = self.presence_fc(x).squeeze(-1)
        wake_logit = None
        if self.use_wake_head:
            wake_in = x.detach() if getattr(self, "wake_detach", False) else x
            wake_logit = self.wake_fc(wake_in).squeeze(-1)
        return s_logit, presence_logit, wake_logit


class SpatialDynamicQueryModel(nn.Module):
    """
    动态Query多麦克风唤醒+DOA定位模型
    输入 wave_list: List[Tensor]，每个tensor [M_i, T]
    支持batch内部样本麦克风数目不一致；GPU内部执行STFT
    return dict: s_q[ B,Q] / pred_s / presence_logit[B,Q]
    （query c 直接代表 DOA 类别 c，方向由 argmax(s_q) 给出）
    """
    def __init__(
        self,
        fsmn_num_layers: int,
        fsmn_dim: int,
        num_query: int,
        doa_num_class: int,
        feat_freq_dim: int = 257,
        use_ipd: bool = True,
        use_pair_ipd: bool = True,
        num_mic: int = 3,
        pool_type: str = "mean_max",
        pair_feat_mode: str = "tdoa",
        mic_spacing: float = 0.08,
        sr: int = 16000,
        speed_sound: float = 340.0,
        use_query_embed: bool = True,
        use_presence_head: bool = True,
        use_wake_head: bool = True,
        wake_detach: bool = False,
        query_mode: str = "beam",
        beam_step_deg: int = 15,
        causal: bool = False,
        norm_type: str = "auto",
        mel_compress: int = 0,
        mel_keep_coh: bool = False,
        encoder_type: str = "auto",
        encoder_kwargs: dict = None
    ):
        super().__init__()
        self.num_query = num_query
        self.doa_num_class = doa_num_class
        self.feat_freq_dim = feat_freq_dim
        self.use_ipd = use_ipd
        self.use_pair_ipd = use_pair_ipd
        self.num_mic = num_mic
        # 阵列几何(用于时延→角度反解 / 波束形成)
        self.mic_spacing = mic_spacing
        self.sr = sr
        self.speed_sound = speed_sound
        # ===== query 生成方式 =====
        #   "beam"   : 每个 query c 绑定“朝方位 c 的波束特征”，方向绑定是结构性的
        #   "dynamic": 原动态 query + 交叉注意力（保留做回退/对比）
        if query_mode not in ("beam", "dynamic"):
            raise ValueError(f"未知 query_mode: {query_mode}")
        self.query_mode = query_mode
        self.beam_step_deg = beam_step_deg
        # BeamQuery-Mel 消融：mel_compress>0 时把频率轴压到该维数
        self.mel_compress = int(mel_compress)
        self.mel_keep_coh = bool(mel_keep_coh)
        self.use_query_embed = use_query_embed

        # 统一解析 pair_feat_mode（beam 模式下不使用，但保留属性兼容）
        if pair_feat_mode not in ("pair_arctan", "tdoa", "pair_ipd",
                                  "ipd", "mag"):
            pair_feat_mode = ("pair_ipd" if use_pair_ipd else
                              ("ipd" if use_ipd else "mag"))
        self.pair_feat_mode = pair_feat_mode

        if query_mode == "beam":
            # 每个 query：波束特征 = [log1p(|b_c|), coherence_c] -> 2F 通道
            if self.mel_compress > 0:
                # 压缩后：仅幅度 -> n_mels；幅度+相干性 -> 2*n_mels
                encoder_input_dim = (2 if mel_keep_coh else 1) * self.mel_compress
            else:
                encoder_input_dim = 2 * feat_freq_dim
            self.beam_angles_per_class = self._build_beam_grid(
                doa_num_class, beam_step_deg)
        else:
            self.beam_angles_per_class = None
            if pair_feat_mode == "pair_arctan":
                encoder_input_dim = feat_freq_dim * num_mic
            elif pair_feat_mode == "tdoa":
                encoder_input_dim = feat_freq_dim + 3 * (num_mic - 1)
            elif pair_feat_mode == "pair_ipd":
                encoder_input_dim = feat_freq_dim * (1 + 2 * (num_mic - 1))
            elif pair_feat_mode == "ipd":
                encoder_input_dim = feat_freq_dim * 3
            elif pair_feat_mode == "mag":
                encoder_input_dim = feat_freq_dim
            else:
                raise ValueError(f"未知 pair_feat_mode: {pair_feat_mode}")

        if num_query != doa_num_class:
            raise ValueError(
                "class-query 设计要求 num_query == doa_num_class，"
                f"当前 num_query={num_query}, doa_num_class={doa_num_class}")

        self.causal = bool(causal)
        self.encoder_type = encoder_type or os.environ.get(KWS_ENCODER_ENV, "cnn")
        # ===== 共有模型（共享编码器）统一入口 =====
        # encoder_type='fsmn' -> 官方 wekws FSMN；'cnn' -> 原自实现 CNN
        self.encoder = build_shared_encoder(
            input_dim=encoder_input_dim,
            hidden_dim=fsmn_dim,
            num_layers=fsmn_num_layers,
            causal=self.causal,
            norm_type=norm_type,
            encoder_type=encoder_type,
            **(encoder_kwargs or {})
        )
        # mean_max 会把特征维翻倍，这里同步调整预测头输入维
        # run_max_logit 也是 [running_mean, running_max] 拼接 -> 头输入 2D
        head_in = fsmn_dim * 2 if pool_type in ("mean_max", "run_max_logit") else fsmn_dim
        self.use_wake_head = use_wake_head
        self.head = SharedPredictHead(in_dim=head_in,
                                      use_presence=use_presence_head,
                                      use_wake_head=use_wake_head,
                                      wake_detach=wake_detach)

        if query_mode == "beam":
            # 波束已经完成方向选择，这里只需要时间维池化
            self.temporal_pool = TemporalPool(dim=fsmn_dim, pool_type=pool_type)
            self.query_gen = None
            self.cross_agg = None
            self.query_embed = None
        else:
            self.query_gen = FrameWiseQueryGenerator(encoder_dim=fsmn_dim,
                                                     num_query=num_query)
            self.cross_agg = QueryCrossAggregate(dim=fsmn_dim,
                                                 pool_type=pool_type)
            # 每个 query 一个可学习身份向量，防止 3 个 query 塌缩
            if use_query_embed:
                self.query_embed = nn.Parameter(
                    torch.randn(1, 1, num_query, fsmn_dim) * 0.02)
            else:
                self.query_embed = None

        # STFT 窗口注册buffer，GPU使用，采样率16000 -> F=257
        self.n_fft = 512
        self.hop_length = 160
        self.win_length = 512
        self.register_buffer("window", torch.hann_window(self.win_length))
        if self.mel_compress > 0:
            self.register_buffer("mel_fb_ab",
                                 make_mel_filterbank(sr, self.n_fft, self.mel_compress))

    @staticmethod
    def _build_beam_grid(doa_num_class: int, beam_step_deg: int):
        """按 0~180 的 3 个方位类区间生成每类的波束角度网格。"""
        if doa_num_class != 3:
            raise ValueError("beam 模式当前只支持 doa_num_class=3")
        # 每类内部铺角度网格，并额外补上该类区间的最后一度，
        # 避免 59°/119° 这种靠近边界的源被隔壁类的波束抢走。
        ranges = ((0, 60), (60, 120), (120, 181))
        step = max(1, int(beam_step_deg))
        grids = []
        for lo, hi in ranges:
            angles = list(range(lo, hi, step))
            if angles[-1] != hi - 1:
                angles.append(hi - 1)
            grids.append(angles)
        return grids

    def _beam_features(self, stft_out: torch.Tensor):
        """方向条件化特征：按类做延迟求和波束形成。

        对类 c 的角度网格逐个做延迟求和波束，取每个时频点的最大幅度，
        得到该类"最强方向响应"，再拼接 [log1p(mag), coherence]。
        coherence = |Σ_m S_m e^{jφ_m}| / Σ_m |S_m| ∈ [0,1]。

        返回: [Q, 2F, T]
        """
        M, F, T = stft_out.shape
        device = stft_out.device
        freqs = torch.fft.rfftfreq(self.n_fft, d=1.0 / self.sr).to(device)  # [F]
        pos = (torch.arange(M, device=device, dtype=torch.float32)
               - (M - 1) / 2.0) * self.mic_spacing  # [M]
        total_mag = stft_out.abs().sum(dim=0) + 1e-6  # [F,T]
        feats = []
        for angles in self.beam_angles_per_class:
            mag_max = None
            for ang in angles:
                tau = pos * math.cos(math.radians(ang)) / self.speed_sound  # [M]
                steer = torch.exp(
                    1j * 2.0 * math.pi * freqs.unsqueeze(0) * tau.unsqueeze(1)
                )  # [M,F]
                beam = (stft_out * steer.unsqueeze(-1)).sum(dim=0)  # [F,T]
                mag = beam.abs()
                mag_max = mag if mag_max is None else torch.maximum(mag_max, mag)
            coh = (mag_max / total_mag).clamp(0.0, 1.0)
            if self.mel_compress > 0:
                # === BeamQuery-Mel 消融：把频率轴压到 mel 维 ===
                fb = self.mel_fb_ab.to(mag_max.dtype)              # [n_mels, F]
                mag_c = torch.matmul(fb, mag_max)                  # [n_mels, T]
                if self.mel_keep_coh:
                    coh_c = torch.matmul(fb, coh)                  # [n_mels, T]
                    feats.append(torch.cat([torch.log1p(mag_c), coh_c], dim=0))
                else:
                    feats.append(torch.log1p(mag_c))               # [n_mels, T]
            else:
                # 沿频率维拼成 [2F, T]，与 encoder 的输入通道数对应
                feats.append(torch.cat([torch.log1p(mag_max), coh], dim=0))
        return torch.stack(feats, dim=0)  # [Q,C,T]

    def _pair_angle_feature(self, stft_out, i, j):
        """用 GCC-PHAT 估计麦对(i,j)的时延，再按阵列几何反解真实角度。

        原理：
          1) 交叉谱 X = S_i · conj(S_j)，其相位 = 2πf·(τ_i-τ_j)
          2) PHAT 白化 X/|X| 后做 IFFT，峰值位置即两麦时延差(样本)
          3) 抛物线插值取亚采样峰值 → 时延 τ(秒)
          4) 均匀线阵几何：τ = (pos_i-pos_j)·cosθ / c  →  cosθ = c·τ/d_ij
          5) 输出 [sinθ, cosθ, 相干性]：sin/cos 已可直接区分 0~180° 的镜像；
             相干性 = |X|²/(|S_i|²|S_j|²) 的频率均值，作为该帧该对的置信度。
        返回: [3, T]
        """
        n = self.n_fft
        Xi, Xj = stft_out[i], stft_out[j]                 # [F,T] complex
        X = Xi * torch.conj(Xj)                           # 交叉谱
        with torch.no_grad():                             # 手工特征，不需要反传
            Xp = X / (X.abs() + 1e-8)                     # PHAT 白化
            cc = torch.fft.irfft(Xp, n=n, dim=0)          # [n,T] 广义互相关
            T = cc.shape[1]
            ar = torch.arange(T, device=cc.device)
            idx = cc.argmax(dim=0)                        # 整数峰值 [T]
            left = cc[(idx - 1) % n, ar]
            mid = cc[idx, ar]
            right = cc[(idx + 1) % n, ar]
            denom = left - 2 * mid + right
            delta = torch.where(denom.abs() > 1e-8,
                                0.5 * (left - right) / denom,
                                torch.zeros_like(mid))
            lag = idx.float() + delta                     # 亚采样峰值位置
            lag = torch.where(lag > n / 2, lag - n, lag)  # 折回 [-n/2, n/2]
            tau = lag / float(self.sr)                    # 时延(秒)
            # 有符号间距：与生成端 RIR 的物理时延符号对齐。
            # 交叉谱相位是 φ_i-φ_j，因此间距应使用 i-j，避免角度镜像。
            d = (i - j) * self.mic_spacing
            cos_th = (self.speed_sound * tau / d).clamp(-1.0, 1.0)
            sin_th = torch.sqrt(torch.clamp(1.0 - cos_th ** 2, min=0.0))
            # 相干性(置信度)
            num = (X.abs() ** 2).mean(dim=0)
            den = (Xi.abs() ** 2 * Xj.abs() ** 2).mean(dim=0) + 1e-8
            coh = (num / den).clamp(0.0, 1.0)
            feat = torch.stack([sin_th, cos_th, coh], dim=0)   # [3,T]
        return feat

    def forward(self, wave_list):
        """
        Args:
            wave_list: list[torch.Tensor], 每个tensor shape [M_i, T]
            M_i：单样本麦克风数量，batch之间可以不同
        Returns:
            dict同时包含两套key用于兼容旧train.py
        """
        s_q_batch = []
        presence_logit_batch = []
        wake_logit_batch = []

        for wav in wave_list:
            # wav: [M_i, T]
            wav = wav.to(self.window.device)
            # GPU STFT，返回复数谱 [M_i, F, T]
            stft_out = torch.stft(
                wav,
                n_fft=self.n_fft,
                hop_length=self.hop_length,
                win_length=self.win_length,
                window=self.window,
                return_complex=True
            )
            M_i, F, T = stft_out.shape
            mag = stft_out.abs()  # 幅度谱 [M_i, F, T]

            if self.query_mode == "beam":
                # 每个 query 直接绑定一个方位类的波束特征
                beam_feat = self._beam_features(stft_out)  # [Q,2F,T]
                q_enc_list = []
                for c in range(self.num_query):
                    enc = self.encoder(
                        beam_feat[c].transpose(0, 1).unsqueeze(0))  # [1,T,D]
                    q_enc_list.append(enc.transpose(1, 2).unsqueeze(1))  # [1,1,D,T]
                q_enc = torch.cat(q_enc_list, dim=1)  # [1,Q,D,T]
                q_agg_feat = self.temporal_pool(q_enc)  # [1,Q,D or 2D]
                s_q, presence_logit, wake_logit = self.head(q_agg_feat)
                s_q_batch.append(s_q.squeeze(0))
                presence_logit_batch.append(
                    None if presence_logit is None else presence_logit.squeeze(0))
                wake_logit_batch.append(
                    None if wake_logit is None else wake_logit.squeeze(0))
                continue

            if self.pair_feat_mode == "pair_arctan":
                # ===== 只取相位差的 arctan 值 (弧度)，不反解角度 =====
                # 对每对麦 (i,j)：cross = S_i · conj(S_j)，
                #   dphi = atan2(Im(cross), Re(cross))   # 弧度, (-π, π]
                # 每个麦的特征 = [幅度_i, { dphi_ij | j≠i }]，通道数 = F*M (3麦 → 771)
                # 注意：相位在 ±π 处有跳变；若训练不稳，可切回 pair_ipd(cos/sin 编码)。
                angle = torch.angle(stft_out)           # [M_i,F,T]
                per_mic = []
                for i in range(M_i):
                    parts = [mag[i:i + 1]]              # [1,F,T]
                    for j in range(M_i):
                        if j == i:
                            continue
                        # cross 的相位 = φ_i - φ_j
                        dphi = angle[i:i + 1] - angle[j:j + 1]   # (-π,π]
                        parts.append(dphi)
                    per_mic.append(torch.cat(parts, dim=1).squeeze(0))  # [F*M, T]
                feat = torch.stack(per_mic, dim=0)                  # [M_i, C, T]
                feat_dim_in = feat.shape[1]
            elif self.pair_feat_mode == "tdoa":
                # ===== 各麦对：GCC-PHAT 时延 → 真实角度特征 =====
                assert M_i == self.num_mic, (
                    f"tdoa 特征需要固定 {self.num_mic} 麦, 当前 {M_i} 麦")
                pair_list = [(i, j) for i in range(M_i) for j in range(i + 1, M_i)]
                pair_feats = {p: self._pair_angle_feature(stft_out, *p) for p in pair_list}
                per_mic = []
                for m in range(M_i):
                    parts = [mag[m:m + 1]]                       # [1,F,T]
                    for (i, j), pf in pair_feats.items():
                        if m == i or m == j:                     # 该麦参与的麦对
                            parts.append(pf.unsqueeze(0))        # [1,3,T]
                    per_mic.append(torch.cat(parts, dim=1).squeeze(0))   # [F+3*(M-1), T]
                feat = torch.stack(per_mic, dim=0)                # [M_i, C, T]
                feat_dim_in = feat.shape[1]
            elif self.pair_feat_mode == "pair_ipd":
                # ===== 两两麦克风相位差 (所有麦克风对, 共 C(M,2) 对) =====
                # 对每个麦克风 i：
                #   feature_i = [ 幅度_i, { cos(φ_i-φ_j), sin(φ_i-φ_j) | j≠i } ]
                # 3 麦时包含 (0,1)、(0,2)、(1,2) 三对相位关系（比“只相对麦0”更全），
                # 相位用 cos/sin 编码以规避 2π 卷绕；每个麦通道数 = (1+2*(M-1))*F。
                angle = torch.angle(stft_out)  # [M_i, F, T]
                assert M_i == self.num_mic, (
                    f"pair_ipd 特征需要固定 {self.num_mic} 麦, 当前 {M_i} 麦")
                per_mic = []
                for i in range(M_i):
                    parts = [mag[i:i + 1]]                      # [1,F,T]
                    for j in range(M_i):
                        if j == i:
                            continue
                        dij = angle[i:i + 1] - angle[j:j + 1]    # [1,F,T]
                        parts.append(torch.cos(dij))
                        parts.append(torch.sin(dij))
                    # parts 每个是 [1,F,T]，沿“频率维(dim=1)”拼接：
                    # [幅度|cos|sin|...] -> [1, (1+2(M-1))*F, T]，再压掉第0维
                    per_mic.append(torch.cat(parts, dim=1).squeeze(0))  # [C, T]
                feat = torch.stack(per_mic, dim=0)                      # [M_i, C, T]
                feat_dim_in = feat.shape[1]
            elif self.pair_feat_mode == "ipd":
                # ===== IPD 相位差特征(相对第0麦) =====
                # IPD_i(f,t)=arg(S_i)-arg(S_0)=2*pi*f*(tau_i-tau_0)，
                # 相位有 2π 卷绕，用 cos/sin 两个实数通道编码。
                angle = torch.angle(stft_out)
                ipd = angle - angle[0:1]
                feat = torch.cat([mag, torch.cos(ipd), torch.sin(ipd)], dim=1)  # [M_i,3F,T]
                feat_dim_in = 3 * F
            else:
                feat = mag
                feat_dim_in = F

            # 伪造batch维度 B=1，复用原有整套网络逻辑
            feat = feat.unsqueeze(0) # [1, M_i, feat_dim_in, T]

            enc_out_list = []
            for mic_idx in range(M_i):
                single_feat = feat[:, mic_idx, :, :]   # [1, feat_dim_in, T]
                enc_out = self.encoder(single_feat.transpose(1, 2))
                enc_out_list.append(enc_out)

            array_enc = torch.stack(enc_out_list, dim=1).permute(0, 1, 3, 2) # [1, M_i, D, T]
            queries = self.query_gen(array_enc)
            if self.query_embed is not None:
                queries = queries + self.query_embed
            q_agg_feat = self.cross_agg(queries, array_enc)
            s_q, presence_logit, wake_logit = self.head(q_agg_feat)

            s_q_batch.append(s_q.squeeze(0))
            presence_logit_batch.append(
                None if presence_logit is None else presence_logit.squeeze(0))
            wake_logit_batch.append(
                None if wake_logit is None else wake_logit.squeeze(0))

        s_q = torch.stack(s_q_batch, dim=0)
        if self.head.use_presence:
            presence_logit = torch.stack(presence_logit_batch, dim=0)
        else:
            presence_logit = None
        # 方向 = 选中的 query 下标（query c 代表 DOA 类 c），
        # 因此不再需要单独的 DOA 输出分支。
        # 独立唤醒头：query 维取最大 = "任意方向上有唤醒词"
        if (getattr(self.head, "use_wake_head", False) and wake_logit_batch
                and wake_logit_batch[0] is not None):
            wake_logit = torch.stack(wake_logit_batch, dim=0).max(dim=-1).values
        else:
            wake_logit = None
        return {
            "s_q": s_q,
            "presence_logit": presence_logit,
            "wake_logit": wake_logit,
            "pred_s": s_q,
        }


class SetMatchingLoss(nn.Module):
    """精简版损失：Q+1 类 CE（检测 + 方位绑定） + presence 辅助。

    设计：
      - query c 直接代表 DOA 类别 c，方向 = argmax(s_q)；
      - 分类 logits = [s_0, s_1, ..., s_{Q-1}, 0]（最后一位是固定的 0 分“无唤醒”类）；
      - 正样本 target = 唤醒词真实类别 c，负样本 target = Q（无唤醒）；
      - 这一个 CE 同时完成“有没有唤醒词”和“唤醒词在哪个方位”，
        且与评测口径完全一致：det = any(sigmoid(s_q)>0.5)，
        direction = argmax(s_q)（0 logit 正好对应 sigmoid=0.5）。
      - presence 辅助任务：query c 预测“方向 c 上是否存在声源”，
        逼共享表示编码方向信息。

    相比旧版删除了：kws_match / kws_det / kws_select / doa_loss /
    query_mapping / hungarian 匹配 / match_* 权重 / pos_weight / focal 等。
    """

    def __init__(self, lambda_kws: float = 1.0, lambda_presence: float = 0.3,
                 lambda_wake: float = 0.0):
        super().__init__()
        self.lambda_kws = lambda_kws
        self.lambda_presence = lambda_presence
        self.lambda_wake = lambda_wake

    def forward(
        self,
        pred_s: torch.Tensor,
        gt_doa: torch.Tensor,
        gt_valid_mask: torch.Tensor,
        kws_label: torch.Tensor,
        wake_angle_gt: torch.Tensor,
        pred_presence: torch.Tensor = None,
        pred_wake: torch.Tensor = None,
    ):
        """
        pred_s:        [B,Q] 每个 query 的唤醒 logit（query c = DOA 类 c）
        pred_presence: [B,Q] 每个 query 的“该方向是否存在声源” logit（可空）
        gt_doa:        [B,S] 真值声源方位类别，padding=-100
        gt_valid_mask: [B,S] 真值有效 mask
        kws_label:     [B]   0/1
        wake_angle_gt: [B]   唤醒词真实方位类别；负样本=-100
        """
        bsz, qnum = pred_s.shape
        none_logit = torch.zeros(bsz, 1, device=pred_s.device,
                                 dtype=pred_s.dtype)
        # [B, Q+1]，最后一位是固定的“无唤醒”类（logit=0 ↔ sigmoid=0.5）
        logits = torch.cat([pred_s, none_logit], dim=1)

        valid_wake = ((kws_label == 1)
                      & (wake_angle_gt >= 0)
                      & (wake_angle_gt < qnum))
        none_target = torch.full_like(wake_angle_gt, qnum)
        target = torch.where(valid_wake, wake_angle_gt, none_target)
        kws_ce_loss = F.cross_entropy(logits, target)

        # ===== presence 辅助：query c 预测“方向 c 是否存在声源” =====
        presence_loss = 0.0 * pred_s.sum()
        if pred_presence is not None and gt_doa is not None:
            valid = torch.logical_and(gt_valid_mask, gt_doa >= 0)
            class_valid = torch.zeros(bsz, qnum, dtype=torch.bool,
                                      device=pred_s.device)
            safe_cls = gt_doa.clamp(min=0, max=qnum - 1)
            batch_ids = torch.arange(bsz, device=pred_s.device).unsqueeze(1)
            batch_ids = batch_ids.expand_as(gt_doa)
            class_valid[batch_ids[valid], safe_cls[valid]] = True
            presence_loss = F.binary_cross_entropy_with_logits(
                pred_presence, class_valid.to(pred_presence.dtype),
                reduction="mean")

        # 独立二分类唤醒头(BCE)：给检测一个可以饱和的专用分数
        wake_loss = 0.0 * pred_s.sum()
        if pred_wake is not None and self.lambda_wake > 0:
            wake_loss = F.binary_cross_entropy_with_logits(
                pred_wake.float().reshape(-1), kws_label.float().reshape(-1))
        total_loss = (self.lambda_kws * kws_ce_loss
                      + self.lambda_presence * presence_loss
                      + self.lambda_wake * wake_loss)
        loss_dict = {
            "kws_loss": float(kws_ce_loss.item()),
            "kws_ce_loss": float(kws_ce_loss.item()),
            "presence_loss": float(presence_loss.item()),
            "wake_loss": float(wake_loss.item()),
        }
        return total_loss, loss_dict


# ==================== 可选：批量化前向 ====================
# 环境变量 USE_BATCHED_FORWARD=1 时，把 forward 换成按 batch 向量化的实现
# （数值等价、速度数量级提升）。见 code_duibi/batched_model.py 与 README。
import os as _os
if _os.environ.get("USE_BATCHED_FORWARD", "") == "1":
    try:
        from paper_experiments.shared.code.batched_model import BatchedSpatialDynamicQuery as _B
        _ORIG = SpatialDynamicQueryModel.forward   # 保存原始实现用于回退
        SpatialDynamicQueryModel._orig_forward = _ORIG
        SpatialDynamicQueryModel.forward = _B.forward
        # 前向里用到的辅助方法也要一并挂上（self 是基类实例）
        SpatialDynamicQueryModel._beam_features_batched = _B._beam_features_batched
        SpatialDynamicQueryModel._steering_grid = _B._steering_grid
        print("[model] 已启用批量化前向 (USE_BATCHED_FORWARD=1)")
    except Exception as _e:      # 任何问题都回退到原实现，不影响训练
        print(f"[model] 批量化前向启用失败，回退原实现: {_e}")
