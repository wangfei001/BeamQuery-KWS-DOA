#!/bin/bash
# Train the proposed BeamQuery model (two stages) under the fixed 3 s protocol.
# Usage: bash paper_experiments/main_model/train.sh [out_dir]
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$HERE/../.." && pwd)
cd "$ROOT"
PY=${PY:-/242602/conda/envs/wekws/bin/python}
OUT=${1:-$HERE/experiment}
export PYTHONPATH=$ROOT PACKED_DATA_DIR=$ROOT/data_packed_v5_largeval \
       USE_BATCHED_FORWARD=1 KWS_MAX_SEC=3.0
D=$ROOT/paper_experiments/table1_corpus/data_lists
V=$ROOT/data_val10k
COMMON=(--train_data "$D/train_spatial.list" --train_varcol "$D/train_varcol.tmp.list"
        --cv_data "$V/eval_spatial.list" --cv_varcol "$V/eval_varcol.tmp.list"
        --test_data "$D/test_spatial.list" --test_varcol "$D/test_varcol.tmp.list")
"$PY" -u wekws/bin/train.py --config "$HERE/configs/stage1.yaml" "${COMMON[@]}" \
    --model_dir "$OUT/stage1" --eval_interval 1 --gpus 0 --num_workers 6
"$PY" -u wekws/bin/train.py --config "$HERE/configs/stage2.yaml" "${COMMON[@]}" \
    --checkpoint "$OUT/stage1/best_cv.pt" --model_dir "$OUT/stage2" \
    --eval_interval 1 --gpus 0 --num_workers 6
cp -f "$OUT/stage2/best_cv.pt" "$OUT/best_cv.pt"
cp -f "$HERE/configs/stage2.yaml" "$OUT/config.yaml"
echo "trained -> $OUT"
