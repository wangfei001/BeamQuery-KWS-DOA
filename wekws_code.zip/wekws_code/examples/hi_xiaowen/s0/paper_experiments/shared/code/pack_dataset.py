# -*- coding: utf-8 -*-
"""把 wav 数据集打包成单个 mmap 数组（去掉 11,000 次文件 open + WAV 解析开销）。

格式（每个 split 一套）
  wav_i16.npy  平坦 int16 数组，按样本首尾相接；单样本内为 [T, M] 行优先
  offsets.npy  int64[N+1]，第 i 条 = [offsets[i], offsets[i+1])
  meta.json    num_mic / sr / labels / wake_angle / durations / n

用法: python code_duibi/pack_dataset.py --src data_rirlib --out data_packed
"""
import argparse, json, os, sys
import numpy as np
import torch
import torchaudio

SR = 16000


def pack_split(src, out, split, num_mic=2):
    sl = os.path.join(src, f"{split}_spatial.list")
    vl = os.path.join(src, f"{split}_varcol.tmp.list")
    truth = {}
    for ln in open(vl, encoding="utf-8"):
        p = ln.split()
        truth[os.path.abspath(p[0])] = (int(p[1]), int(p[3]))
    paths, rest_ann = [], []
    for l in open(sl, encoding="utf-8"):
        pp = l.split()
        if not pp: continue
        paths.append(os.path.abspath(pp[0]))
        rest = [int(x) for x in pp[2:]]
        s_v, d_v = [], []
        for k in range(min(len(rest)//2, 3)):
            s_v.append(rest[2*k]); d_v.append(rest[2*k+1])
        while len(s_v) < 3: s_v.append(0); d_v.append(-100)
        rest_ann.append((s_v, d_v))

    chunks, offsets = [], [0]
    labels, angles, durs = [], [], []
    gt_s_all, gt_doa_all, gt_mask_all = [], [], []
    for i, p in enumerate(paths):
        w, sr0 = torchaudio.load(p)
        if sr0 != SR:
            w = torchaudio.functional.resample(w, sr0, SR)
        w = w[:num_mic]
        if w.shape[0] < num_mic:
            w = torch.cat([w, w[-1:].repeat(num_mic - w.shape[0], 1)], 0)
        a = (w.clamp(-1, 1) * 32767.0).round().to(torch.int16).numpy()   # [M,T]
        flat = np.ascontiguousarray(a.T.reshape(-1))                     # [T*M]
        chunks.append(flat)
        offsets.append(offsets[-1] + flat.size)
        lab, ang = truth[p]
        labels.append(lab); angles.append(ang); durs.append(w.shape[-1] / SR)
        # 逐声源标注（供 presence 辅助损失使用，原先被硬编码为 -100 导致该任务退化）
        s_v = [int(x) for x in rest_ann[i][0]] if i < len(rest_ann) else [0, 0, 0]
        d_v = [int(x) for x in rest_ann[i][1]] if i < len(rest_ann) else [-100]*3
        gt_s_all.append(s_v); gt_doa_all.append(d_v)
        gt_mask_all.append([int(x) != -100 for x in d_v])
        if (i + 1) % 2000 == 0:
            print(f"    {split}: {i+1}/{len(paths)}", flush=True)

    np.save(os.path.join(out, f"{split}_wav_i16.npy"), np.concatenate(chunks))
    np.save(os.path.join(out, f"{split}_offsets.npy"), np.asarray(offsets, dtype=np.int64))
    json.dump({"num_mic": num_mic, "sr": SR, "n": len(paths), "labels": labels,
               "wake_angle": angles, "durations": durs,
               "gt_s": gt_s_all, "gt_doa": gt_doa_all, "gt_mask": gt_mask_all},
              open(os.path.join(out, f"{split}_meta.json"), "w"), indent=0)
    mb = os.path.getsize(os.path.join(out, f"{split}_wav_i16.npy")) / 1e6
    print(f"  {split}: {len(paths)} 条, {mb:.0f} MB", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default="data_rirlib")
    ap.add_argument("--out", default="data_packed")
    ap.add_argument("--splits", default="train,eval,test")
    ap.add_argument("--num_mic", type=int, default=2)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    for sp in a.splits.split(","):
        print(f"[{sp}] 打包中 ...", flush=True)
        pack_split(a.src, a.out, sp, a.num_mic)
    print("完成 ->", a.out)


if __name__ == "__main__":
    main()
