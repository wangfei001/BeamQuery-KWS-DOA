# -*- coding: utf-8 -*-
"""mmap 版数据集：**签名与 SpatialKwsDataset 完全兼容**，可原地替换（零文件 open）。

split 由 data_list 文件名推断（train/eval/test），打包目录取自参数或环境变量
PACKED_DATA_DIR。因此在 train.py / spatial_eval.py 里直接别名替换即可。
"""
import json
import os

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset

# 与 SpatialKwsDataset 同口径：KWS_MAX_SEC=3 时把每条波形截断/补齐到 3s，
# 使训练与(同样补零到 3s 的)评测、基线族使用完全相同的固定长度窗口。
_KWS_MAX_SEC = float(os.environ.get("KWS_MAX_SEC", "0") or 0)


class PackedSpatialDataset(Dataset):
    def __init__(self, data_list=None, varcol_tmp_list=None, max_gt=3,
                 packed_dir=None, split=None):
        packed_dir = packed_dir or os.environ.get("PACKED_DATA_DIR", "data_packed")
        if split is None:
            base = os.path.basename(str(data_list or ""))
            split = ("train" if "train" in base else
                     "eval" if "eval" in base else "test")
        self.dir, self.split = packed_dir, split
        self.meta = json.load(open(os.path.join(packed_dir, f"{split}_meta.json")))
        self.flat = np.load(os.path.join(packed_dir, f"{split}_wav_i16.npy"), mmap_mode="r")
        self.offsets = np.load(os.path.join(packed_dir, f"{split}_offsets.npy"))
        self.num_mic = int(self.meta["num_mic"])
        self.num_mic_use = int(os.environ.get("KWS_NUM_MIC_USE", self.num_mic))
        self.sr = int(self.meta["sr"])
        self.max_gt = max_gt

    def __len__(self):
        return int(self.meta["n"])

    def __getitem__(self, i):
        s, e = int(self.offsets[i]), int(self.offsets[i + 1])
        T = (e - s) // self.num_mic
        arr = np.asarray(self.flat[s:s + T * self.num_mic], dtype=np.int16)
        wav = torch.from_numpy(arr.reshape(T, self.num_mic).T.copy()).float() / 32767.0
        wav = wav[:self.num_mic_use]
        if _KWS_MAX_SEC > 0:
            n = int(_KWS_MAX_SEC * self.sr)
            if wav.shape[-1] > n:
                wav = wav[:, :n]
            elif wav.shape[-1] < n:
                wav = F.pad(wav, (0, n - wav.shape[-1]))
        gs = self.meta.get("gt_s", [[0]*self.max_gt]*len(self.meta["labels"]))[i]
        gd = self.meta.get("gt_doa", [[-100]*self.max_gt]*len(self.meta["labels"]))[i]
        gm = self.meta.get("gt_mask", [[False]*self.max_gt]*len(self.meta["labels"]))[i]
        return {"wave": wav,
                "gt_s": torch.tensor(gs[:self.max_gt], dtype=torch.float32),
                "gt_doa": torch.tensor(gd[:self.max_gt], dtype=torch.long),
                "gt_valid_mask": torch.tensor(gm[:self.max_gt], dtype=torch.bool),
                "kws_label": torch.tensor(int(self.meta["labels"][i]), dtype=torch.long),
                "wake_angle_gt": torch.tensor(int(self.meta["wake_angle"][i]),
                                              dtype=torch.long)}
