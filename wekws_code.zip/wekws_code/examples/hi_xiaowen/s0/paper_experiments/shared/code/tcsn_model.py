
from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from paper_experiments.shared.code.tcsn_fsmn_stream import *

class Shrinkage(nn.Module):
    def __init__(self,  channel, memory_size):
        super(Shrinkage, self).__init__()
        self.linear1 = nn.Linear(channel, channel)
        self.fsmn1 = CVFSMNv2bid(memory_size, channel, channel, channel//4) #(memory_size, input_size, output_size, projection_size)
        self.bn1 = nn.BatchNorm1d(channel)
        
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, cache_m): # x:[b,64,t]
        x_raw = x
        x = torch.abs(x)
        x_abs = x
        average = x
        
        # block1
        x = self.linear1(x.transpose(1,2))
        x, new_cache_m = self.fsmn1(x, cache_m)
        x = self.bn1(x.transpose(1,2))
        
        x = self.sigmoid(x)
        
        x = torch.mul(average, x)
        # soft thresholding
        sub = x_abs - x
        zeros = sub - sub
        n_sub = torch.max(sub, zeros) #[b,64,t]
        x = torch.mul(torch.sign(x_raw), n_sub) #[b,64,t]
        return x, new_cache_m

class Block(nn.Module):
    def __init__(self,
                 channel: int,
                 kernel_size: int,
                 dilation: int,
                 dropout: float = 0.1):
        super().__init__()
        self.padding = (kernel_size - 1) * dilation
        self.quant = torch.quantization.QuantStub()
        self.dequant = torch.quantization.DeQuantStub()
        self.shrinkage = Shrinkage(channel, memory_size=64)
    def forward(
        self,
        x: torch.Tensor,
        cache: torch.Tensor = torch.zeros(0, 0, 0, dtype=torch.float),
        cache_m: torch.Tensor = torch.zeros(0, 0, 0, dtype=torch.float)
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Args:
            x(torch.Tensor): Input tensor (B, D, T)
            cache(torch.Tensor): Input cache(B, D, self.padding)
        Returns:
            torch.Tensor(B, D, T): output
            torch.Tensor(B, D, self.padding): new cache
        """
        # The CNN used here is causal convolution
        if cache.size(0) == 0:
            y = F.pad(x, (self.padding, 0), value=0.0)
        else:
            y = torch.cat((cache, x), dim=2)
        assert y.size(2) > self.padding
        new_cache = y[:, :, -self.padding:]

        y = self.quant(y)
        # self.cnn is defined in the subclass of Block
        y = self.cnn(y)
        y, new_cache_m = self.shrinkage(y, cache_m) 
        y = self.dequant(y)
        y = y + x  # residual connection
        return y, new_cache, new_cache_m

    def fuse_modules(self):
        self.cnn.fuse_modules()


class CnnBlock(Block):
    def __init__(self,
                 channel: int,
                 kernel_size: int,
                 dilation: int,
                 dropout: float = 0.1):
        super().__init__(channel, kernel_size, dilation, dropout)
        self.cnn = nn.Sequential(
            nn.Conv1d(channel,
                      channel,
                      kernel_size,
                      stride=1,
                      dilation=dilation),
            nn.BatchNorm1d(channel),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

    def fuse_modules(self):
        torch.quantization.fuse_modules(self, [['cnn.0', 'cnn.1', 'cnn.2']],
                                        inplace=True)


class DsCnnBlock(Block):
    """ Depthwise Separable Convolution
    """
    def __init__(self,
                 channel: int,
                 kernel_size: int,
                 dilation: int,
                 dropout: float = 0.1):
        super().__init__(channel, kernel_size, dilation, dropout)
        self.cnn = nn.Sequential(
            nn.Conv1d(channel,
                      channel,
                      kernel_size,
                      stride=1,
                      dilation=dilation,
                      groups=channel),
            nn.BatchNorm1d(channel),
            nn.ReLU(),
            nn.Conv1d(channel, channel, kernel_size=1, stride=1),
        )

    def fuse_modules(self):
        torch.quantization.fuse_modules(
            self, [['cnn.0', 'cnn.1', 'cnn.2'], ['cnn.3']],
            inplace=True)


class TCSN(nn.Module):
    def __init__(self,
                 num_layers: int,
                 channel: int,
                 kernel_size: int,
                 dropout: float = 0.1,
                 block_class=CnnBlock):
        super().__init__()
        self.padding = 0
        self.num_layers = num_layers
        self.network = nn.ModuleList()
        for i in range(num_layers):
            dilation = 2**i
            self.padding += (kernel_size - 1) * dilation
            self.network.append(
                block_class(channel, kernel_size, dilation, dropout))

    def forward(
        self,
        x: torch.Tensor,
        in_cache: torch.Tensor = torch.zeros(0, 0, 0, dtype=torch.float),
        in_cache_m: torch.Tensor = torch.zeros(0, 0, 0, dtype=torch.float)
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Args:
            x (torch.Tensor): Input tensor (B, T, D)
            in_cache(torhc.Tensor): (B, D, C), C is the accumulated cache size

        Returns:
            torch.Tensor(B, T, D)
            torch.Tensor(B, D, C): C is the accumulated cache size
        """

        x = x.transpose(1, 2)  # (B, D, T)
        out_caches = []
        out_caches_m = []
        offset=0
        offset_m=0
        memory_size=64
 
        for i,block in enumerate(self.network):
            if in_cache.size(0) > 0:
                c_in = in_cache[:, :, offset:offset + block.padding]
            else:
                c_in = torch.zeros(0, 0, 0)
            if in_cache_m.size(0) > 0:
                c_in_m = in_cache_m[:, :, offset_m:offset_m + (memory_size-1)]
            else:
                c_in_m = torch.zeros(0, 0, 0)
            x, c_out, m_out = block(x, c_in, c_in_m)
            out_caches.append(c_out)
            out_caches_m.append(m_out)
            offset += block.padding
            offset_m += memory_size-1
        x = x.transpose(1, 2)  # (B, T, D)
        new_cache = torch.cat(out_caches, dim=2)
        new_cache_m = torch.cat(out_caches_m, dim=2) # (B, Proj, T)
        return x, new_cache, new_cache_m

    def fuse_modules(self):
        for m in self.network:
            m.fuse_modules()


if __name__ == '__main__':
    tcsn = TCSN(4, 64, 8, block_class=CnnBlock)
    print(tcn)
    print(tcn.padding)
    num_params = sum(p.numel() for p in tcn.parameters())
    print('the number of model params: {}'.format(num_params))
    x = torch.zeros(3, 15, 64)
    y = tcn(x)
