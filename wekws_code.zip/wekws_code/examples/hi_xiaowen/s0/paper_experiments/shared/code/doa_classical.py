# Copyright (c) 2026
# -*- coding: utf-8 -*-
"""经典（非学习）声源方位估计器：GCC-PHAT 与 SRP-PHAT。

用途
----
论文中的 **级联基线(cascade baseline)**：先用经典方法估方位，再用单通道
KWS 检测唤醒词。这是"联合建模是否必要"这一核心论点的对照方法。
两者都只依赖 numpy/scipy，无需额外依赖、无需训练。
"""
import math

import numpy as np

SPEED_OF_SOUND = 340.0
DOA_CLASS_CENTERS = (30.0, 90.0, 150.0)


def _stft(x, n_fft=512, hop=160, win_len=512):
    win = np.hanning(win_len + 1)[:-1]
    n_frames = 1 + max(0, (len(x) - win_len)) // hop
    if n_frames <= 0:
        n_frames = 1
    pad = max(0, (n_frames - 1) * hop + win_len - len(x))
    x = np.concatenate([x, np.zeros(pad, dtype=x.dtype)])
    frames = np.stack([x[i * hop:i * hop + win_len] * win for i in range(n_frames)], axis=1)
    return np.fft.rfft(frames, n=n_fft, axis=0)


def gcc_phat_delay(sig, ref, fs=16000, n_fft=512, hop=160, max_delay=None):
    """GCC-PHAT 估计 sig 相对 ref 的时延（秒），逐帧估计后取中位数。"""
    sig = np.asarray(sig, dtype=np.float64)
    ref = np.asarray(ref, dtype=np.float64)
    n = min(len(sig), len(ref))
    sig, ref = sig[:n], ref[:n]
    if max_delay is None:
        max_delay = n_fft // 2
    X1 = _stft(sig, n_fft, hop)
    X2 = _stft(ref, n_fft, hop)
    X = X1 * np.conj(X2)
    Xp = X / (np.abs(X) + 1e-10)
    cc = np.fft.irfft(Xp, n=n_fft, axis=0)          # [n_fft, T]
    cc = np.roll(cc, n_fft // 2, axis=0)            # 使 lag 0 居中
    lo, hi = n_fft // 2 - max_delay, n_fft // 2 + max_delay + 1
    seg = cc[lo:hi]
    lags = np.argmax(seg, axis=0) - max_delay
    return float(np.median(lags)) / float(fs)


def delay_to_angle(tau, spacing=0.033, c=SPEED_OF_SOUND):
    """均匀线阵：tau = d*cos(theta)/c  →  theta = arccos(c*tau/d)，归一到 [0,180]。"""
    d = abs(spacing)
    if d <= 0:
        return 90.0
    cos_th = np.clip(c * tau / d, -1.0, 1.0)
    return float(np.degrees(np.arccos(cos_th)))   # 0..180，左右半平面由生成端 half_plane 固定


def angle_to_class(angle, num_class=3):
    """0-60→0, 60-120→1, 120-180→2。"""
    if num_class != 3:
        raise ValueError("当前只支持 3 个方位类")
    if angle < 60.0:
        return 0
    if angle < 120.0:
        return 1
    return 2


def estimate_doa_gccphat(wav, fs=16000, spacing=0.033, class_only=False):
    """GCC-PHAT 方位估计。

    Args:
        wav: [M, T] 或 [T]；多通道时以第 0 麦为参考，逐个麦对求时延再平均角度。
    Returns:
        angle(度) 或 类别(0/1/2)
    """
    wav = np.asarray(wav)
    if wav.ndim == 1:
        return 90.0 if not class_only else 1
    M = wav.shape[0]
    angles = []
    for i in range(1, M):
        tau = gcc_phat_delay(wav[i], wav[0], fs=fs)
        # 麦 i 相对麦 0 的间距（含符号）
        angles.append(delay_to_angle(tau, spacing=spacing * i))
    angle = float(np.median(angles))
    return angle_to_class(angle) if class_only else angle


def estimate_doa_srpphat(wav, fs=16000, spacing=0.033, grid_deg=None, c=SPEED_OF_SOUND,
                         n_fft=512, hop=160):
    """SRP-PHAT：在方位网格上做时延求和，取能量最大方向。

    修正记录：原实现把"频点数(257)"误当成 FFT 长度参与相位计算，
    导致广播维度不匹配 (257,297) vs (129,1)。此处显式使用 n_fft=512 与真实频率。
    """
    if grid_deg is None:
        grid_deg = np.arange(0.0, 180.5, 5.0)
    wav = np.asarray(wav, dtype=np.float64)
    if wav.ndim == 1:
        return 90.0
    M, _ = wav.shape
    positions = (np.arange(M) - (M - 1) / 2.0) * spacing          # 麦克风位置(m)
    Xp = [_stft(wav[m], n_fft, hop) for m in range(M)]
    nfreq, T = Xp[0].shape                                        # nfreq = n_fft//2+1
    freqs = np.fft.rfftfreq(n_fft, d=1.0 / fs)                    # 真实频率(Hz)
    # 预先算好每对的 PHAT 白化互谱
    pairs = []
    for i in range(M):
        for j in range(i + 1, M):
            cross = Xp[i] * np.conj(Xp[j])
            cross = cross / (np.abs(cross) + 1e-10)
            pairs.append((positions[i] - positions[j], cross))
    best_angle, best_score = 90.0, -np.inf
    for ang in grid_deg:
        acc = np.zeros((nfreq, T), dtype=np.float64)
        for d_ij, cross in pairs:
            tau = d_ij * math.cos(math.radians(ang)) / c
            phase = np.exp(-2j * math.pi * freqs[:, None] * tau)   # [nfreq,1]
            acc += np.fft.irfft(cross * phase, n=n_fft, axis=0)[:nfreq] * nfreq
        score = float(np.max(np.sum(acc, axis=0)))
        if score > best_score:
            best_score, best_angle = score, float(ang)
    return best_angle


def estimate_doa_class(wav, fs=16000, spacing=0.033, method="gcc-phat"):
    """统一入口：返回粗方位类别 0/1/2。"""
    if method in ("gcc-phat", "gcc", "gccphat"):
        return estimate_doa_gccphat(wav, fs=fs, spacing=spacing, class_only=True)
    if method in ("srp-phat", "srp", "srpphat"):
        return angle_to_class(estimate_doa_srpphat(wav, fs=fs, spacing=spacing))
    raise ValueError(f"未知方位估计方法: {method}")
