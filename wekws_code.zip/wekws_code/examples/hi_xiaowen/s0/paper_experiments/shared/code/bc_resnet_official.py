# -*- coding: utf-8 -*-
"""Official BC-ResNet architecture ported for binary wake-word detection.

Architecture and SubSpectralNorm follow:
https://github.com/re9ulus/BC-ResNet
commit 086ce358885b4b4521b2763c4563f9e681412e74

The only task adaptation is the final classifier: the official 35-class head is
replaced by a one-logit head for binary wake/non-wake detection, and log_softmax
is omitted so the model can be trained with BCEWithLogitsLoss.  The backbone,
channel widths, dilations, normalization, frontend mel parameters and residual
path are kept identical to the official implementation.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchaudio
from torchaudio import transforms


DROPOUT = 0.1
EPS = 1e-9


class SubSpectralNorm(nn.Module):
    """Sub-spectral normalization from the official BC-ResNet implementation."""

    def __init__(self, channels, sub_bands, eps=1e-5):
        super().__init__()
        self.sub_bands = sub_bands
        self.bn = nn.BatchNorm2d(channels * sub_bands, eps=eps)

    def forward(self, x):
        n, c, f, t = x.size()
        x = x.view(n, c * self.sub_bands, f // self.sub_bands, t)
        x = self.bn(x)
        return x.view(n, c, f, t)


class NormalBlock(nn.Module):
    def __init__(self, n_chan: int, *, dilation: int = 1, dropout: float = DROPOUT,
                 use_subspectral: bool = True):
        super().__init__()
        norm_layer = SubSpectralNorm(n_chan, 5) if use_subspectral else nn.BatchNorm2d(n_chan)
        self.f2 = nn.Sequential(
            nn.Conv2d(n_chan, n_chan, kernel_size=(3, 1), padding="same", groups=n_chan),
            norm_layer,
        )
        self.f1 = nn.Sequential(
            nn.Conv2d(n_chan, n_chan, kernel_size=(1, 3), padding="same",
                      groups=n_chan, dilation=(1, dilation)),
            nn.BatchNorm2d(n_chan),
            nn.SiLU(),
            nn.Conv2d(n_chan, n_chan, kernel_size=1),
            nn.Dropout2d(dropout),
        )
        self.activation = nn.ReLU()

    def forward(self, x):
        n_freq = x.shape[2]
        x1 = self.f2(x)
        x2 = torch.mean(x1, dim=2, keepdim=True)
        x2 = self.f1(x2)
        x2 = x2.repeat(1, 1, n_freq, 1)
        return self.activation(x + x1 + x2)


class TransitionBlock(nn.Module):
    def __init__(self, in_chan: int, out_chan: int, *, dilation: int = 1,
                 stride: int = 1, dropout: float = DROPOUT,
                 use_subspectral: bool = True):
        super().__init__()
        if stride == 1:
            conv = nn.Conv2d(out_chan, out_chan, kernel_size=(3, 1),
                             groups=out_chan, padding="same")
        else:
            conv = nn.Conv2d(out_chan, out_chan, kernel_size=(3, 1),
                             stride=(stride, 1), groups=out_chan, padding=(1, 0))
        norm_layer = SubSpectralNorm(out_chan, 5) if use_subspectral else nn.BatchNorm2d(out_chan)
        self.f2 = nn.Sequential(
            nn.Conv2d(in_chan, out_chan, kernel_size=(1, 1)),
            nn.BatchNorm2d(out_chan),
            nn.ReLU(),
            conv,
            norm_layer,
        )
        self.f1 = nn.Sequential(
            nn.Conv2d(out_chan, out_chan, kernel_size=(1, 3), padding="same",
                      groups=out_chan, dilation=(1, dilation)),
            nn.BatchNorm2d(out_chan),
            nn.SiLU(),
            nn.Conv2d(out_chan, out_chan, kernel_size=1),
            nn.Dropout2d(dropout),
        )
        self.activation = nn.ReLU()

    def forward(self, x):
        x = self.f2(x)
        n_freq = x.shape[2]
        x1 = torch.mean(x, dim=2, keepdim=True)
        x1 = self.f1(x1)
        x1 = x1.repeat(1, 1, n_freq, 1)
        return self.activation(x + x1)


class BcResNetOfficialBackbone(nn.Module):
    """Official BcResNetModel with a one-logit binary head."""

    def __init__(self, *, scale: int = 1, dropout: float = DROPOUT,
                 use_subspectral: bool = True):
        super().__init__()
        self.input_conv = nn.Conv2d(1, 16 * scale, kernel_size=(5, 5),
                                    stride=(2, 1), padding=2)
        self.t1 = TransitionBlock(16 * scale, 8 * scale, dropout=dropout,
                                  use_subspectral=use_subspectral)
        self.n11 = NormalBlock(8 * scale, dropout=dropout,
                               use_subspectral=use_subspectral)
        self.t2 = TransitionBlock(8 * scale, 12 * scale, dilation=2, stride=2,
                                  dropout=dropout, use_subspectral=use_subspectral)
        self.n21 = NormalBlock(12 * scale, dilation=2, dropout=dropout,
                               use_subspectral=use_subspectral)
        self.t3 = TransitionBlock(12 * scale, 16 * scale, dilation=4, stride=2,
                                  dropout=dropout, use_subspectral=use_subspectral)
        self.n31 = NormalBlock(16 * scale, dilation=4, dropout=dropout,
                               use_subspectral=use_subspectral)
        self.n32 = NormalBlock(16 * scale, dilation=4, dropout=dropout,
                               use_subspectral=use_subspectral)
        self.n33 = NormalBlock(16 * scale, dilation=4, dropout=dropout,
                               use_subspectral=use_subspectral)
        self.t4 = TransitionBlock(16 * scale, 20 * scale, dilation=8,
                                  dropout=dropout, use_subspectral=use_subspectral)
        self.n41 = NormalBlock(20 * scale, dilation=8, dropout=dropout,
                               use_subspectral=use_subspectral)
        self.n42 = NormalBlock(20 * scale, dilation=8, dropout=dropout,
                               use_subspectral=use_subspectral)
        self.n43 = NormalBlock(20 * scale, dilation=8, dropout=dropout,
                               use_subspectral=use_subspectral)
        self.dw_conv = nn.Conv2d(20 * scale, 20 * scale, kernel_size=(5, 5),
                                 groups=20 * scale)
        self.onexone_conv = nn.Conv2d(20 * scale, 32 * scale, kernel_size=1)
        self.head_conv = nn.Conv2d(32 * scale, 1, kernel_size=1)

    def forward(self, x):
        x = self.input_conv(x)
        x = self.t1(x)
        x = self.n11(x)
        x = self.t2(x)
        x = self.n21(x)
        x = self.t3(x)
        x = self.n31(x)
        x = self.n32(x)
        x = self.n33(x)
        x = self.t4(x)
        x = self.n41(x)
        x = self.n42(x)
        x = self.n43(x)
        x = self.dw_conv(x)
        x = self.onexone_conv(x)
        x = torch.mean(x, dim=3, keepdim=True)
        x = self.head_conv(x)
        return x.squeeze()


class BCResNetOfficialKWS(nn.Module):
    """Waveform adapter for the official BC-ResNet binary detection baseline."""

    def __init__(self, num_mic=2, scale=1, dropout=DROPOUT,
                 use_subspectral=True, sample_rate=16000,
                 n_fft=1024, f_max=8000, n_mels=40, **kwargs):
        super().__init__()
        self.num_mic = num_mic
        self.sample_rate = sample_rate
        self.frontend = transforms.MelSpectrogram(
            sample_rate=sample_rate, n_fft=n_fft, f_max=f_max, n_mels=n_mels)
        self.model = BcResNetOfficialBackbone(
            scale=scale, dropout=dropout, use_subspectral=use_subspectral)

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(0)
        # Original BC-ResNet is single-channel.  The multi-mic tensor is loaded
        # by the common data pipeline, but only microphone 0 is consumed here.
        wav = x[:, 0, :]                                      # [B,T]
        mel = self.frontend(wav)                              # [B,F,T]
        log_mel = torch.log2(mel + EPS).unsqueeze(1)           # [B,1,F,T]
        logit = self.model(log_mel)
        return {"s_q": logit.reshape(-1, 1), "presence_logit": None}
