# Copyright (c) 2026
# -*- coding: utf-8 -*-
"""code_duibi 公共组件：数据/指标/工具。

设计原则
--------
1. 指标口径与主仓库 ``wekws/utils/spatial_metrics.py`` 保持一致（唤醒率、虚警率、
   检出定位准确率、平均角度误差），保证"提出方法 vs 基线"可比。
2. 额外提供 KWS 领域标准指标 **FRR@FAR=1/h**（以及 DET 曲线采样点），
   这是唤醒词论文最常被要求的横轴固定指标。
3. 所有指标函数都是纯函数，便于单测与复用。
"""
import math
import os
import random
import sys

import numpy as np
import torch
import torch.nn.functional as F

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

DOA_CLASS_CENTERS = (30.0, 90.0, 150.0)
SCENE_CENTERS = (30, 90, 150)
WAV_BYTES_PER_SAMPLE = 2  # 16-bit PCM
BYTES_PER_HOUR_16K_MONO = 16000 * WAV_BYTES_PER_SAMPLE * 3600


# --------------------------------------------------------------------------- #
# 复现性
# --------------------------------------------------------------------------- #
def set_seed(seed: int = 666):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# --------------------------------------------------------------------------- #
# 数据读取
# --------------------------------------------------------------------------- #
def read_varcol_truth(varcol_path):
    """读取 stage5 的 varcol.tmp.list，返回 {绝对wav路径: (label, wake_angle)}。

    格式：``wav_path label n_src doa0 doa1 doa2``
    label=1 时唤醒词方位取 slot0；label=0 时唤醒方位为 -100（不参与定位统计）。
    """
    truth = {}
    with open(varcol_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            wav = os.path.abspath(parts[0])
            label = int(parts[1])
            slots = [int(x) for x in parts[3:6]]
            truth[wav] = (label, slots[0] if label == 1 else -100)
    return truth


def read_spatial_list(list_path):
    """读取 8 列 spatial list，返回 [(wav, num_mic, [s1,doa1,...])]。"""
    items = []
    with open(list_path, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) < 3:
                continue
            items.append((os.path.abspath(parts[0]), int(parts[1]),
                          [int(x) for x in parts[2:]]))
    return items


def wav_duration_sec(path, num_mic=2):
    """不解码音频估计时长(秒)：16-bit PCM + 已知通道数。"""
    try:
        size = os.path.getsize(path)
    except OSError:
        return 2.0
    frames = max(size - 44, 0) // (WAV_BYTES_PER_SAMPLE * max(num_mic, 1))
    return frames / 16000.0


def add_duration_column(list_path, out_path, num_mic=2):
    """给 spatial list 追加一列时长(秒)，供 FAR(次/小时) 换算使用。"""
    items = read_spatial_list(list_path)
    with open(out_path, "w", encoding="utf-8") as f:
        for wav, nm, rest in items:
            dur = wav_duration_sec(wav, nm)
            f.write(" ".join([wav, str(nm)] + [str(x) for x in rest] + [f"{dur:.4f}"]) + "\n")
    return out_path


# --------------------------------------------------------------------------- #
# 指标
# --------------------------------------------------------------------------- #
def binary_auc(scores, labels):
    """无 sklearn 依赖的 AUC（含 ties 平均秩）。"""
    scores = np.asarray(scores, dtype=np.float64).reshape(-1)
    labels = np.asarray(labels).reshape(-1)
    pos = scores[labels == 1]
    neg = scores[labels == 0]
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    all_scores = np.concatenate([pos, neg])
    order = np.argsort(all_scores, kind="mergesort")
    ranks = np.empty_like(all_scores)
    ranks[order] = np.arange(1, all_scores.size + 1, dtype=np.float64)
    sorted_scores = all_scores[order]
    # ties 平均秩
    uniq, inv, counts = np.unique(sorted_scores, return_inverse=True, return_counts=True)
    if np.any(counts > 1):
        start = 0
        for c in counts:
            if c > 1:
                ranks[order[start:start + c]] = (start + 1 + start + c) / 2.0
            start += c
    return float((ranks[:pos.size].sum() - pos.size * (pos.size + 1) / 2.0) / (pos.size * neg.size))


def detection_metrics(scores, labels, threshold=0.5):
    """阈值化检测指标。scores 为 sigmoid 后的唤醒概率。"""
    scores = np.asarray(scores, dtype=np.float64).reshape(-1)
    labels = np.asarray(labels).reshape(-1).astype(int)
    det = scores > threshold
    pos = labels == 1
    neg = ~pos
    tp = int(np.sum(det & pos)); fn = int(np.sum(~det & pos))
    fp = int(np.sum(det & neg)); tn = int(np.sum(~det & neg))
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    fpr = fp / (fp + tn) if (fp + tn) else 0.0
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    acc = (tp + tn) / max(len(labels), 1)
    return {
        "threshold": float(threshold), "tp": tp, "fn": fn, "fp": fp, "tn": tn,
        "recall": recall, "fpr": fpr, "precision": precision, "accuracy": acc,
        "auc": binary_auc(scores, labels),
    }


def far_per_hour(fp, neg_durations_sec):
    """虚警率换算成"次/小时"。"""
    neg_hours = float(np.sum(neg_durations_sec)) / 3600.0
    if neg_hours <= 0:
        return float("nan")
    return float(fp) / neg_hours


def frr_at_far(scores, labels, durations, target_far_per_hour=1.0):
    """固定虚警率下的漏检率（唤醒词领域标准指标）。

    在负样本上按 FAR(次/小时) 递增扫描阈值，取满足 FAR<=target 的最宽松阈值，
    报告该阈值下的 FRR=1-recall，同时返回该工作点的阈值/实际FAR。
    """
    scores = np.asarray(scores, dtype=np.float64).reshape(-1)
    labels = np.asarray(labels).reshape(-1).astype(int)
    durations = np.asarray(durations, dtype=np.float64).reshape(-1)
    pos, neg = labels == 1, labels == 0
    if pos.sum() == 0 or neg.sum() == 0:
        return {"frr": float("nan"), "far_per_hour": float("nan"),
                "threshold": float("nan"), "recall": float("nan")}
    # 候选阈值：升序扫描，取【满足 FAR 约束的最低阈值】以最大化召回。
    # 注意：若按降序扫描，第一个满足条件的永远是最高阈值(全是负样本分数),
    #      会导致 recall=0、FRR=1.0 的退化结果。
    cand = np.unique(np.concatenate([[0.0, 1.0], scores[neg]]))
    best = None
    for thr in np.sort(cand):
        fp = int(np.sum((scores[neg] > thr)))
        far = far_per_hour(fp, durations[neg])
        if far <= target_far_per_hour:
            best = (thr, far)
            break
    if best is None:
        best = (float(np.min(cand)), far_per_hour(int(np.sum(scores[neg] > float(np.min(cand)))),
                                                  durations[neg]))
    thr, far = best
    recall = float(np.sum((scores[pos] > thr))) / float(pos.sum())
    return {"frr": 1.0 - recall, "far_per_hour": far,
            "threshold": float(thr), "recall": recall}


def det_curve(scores, labels, durations, far_points=(0.5, 1.0, 2.0, 5.0, 10.0)):
    """按若干 FAR 目标点采样 DET 曲线，返回 [(far, frr), ...]。"""
    out = []
    for far in far_points:
        r = frr_at_far(scores, labels, durations, target_far_per_hour=far)
        out.append((float(far), float(r["frr"])))
    return out


def doa_metrics(pred_cls, gt_cls, det_mask=None):
    """粗方位分类指标。pred_cls/gt_cls 均为 0/1/2，无效真值请先过滤。

    mean_deg_err 按类中心 (30/90/150) 计算平均绝对角度误差（度）。
    """
    pred_cls = np.asarray(pred_cls).reshape(-1).astype(int)
    gt_cls = np.asarray(gt_cls).reshape(-1).astype(int)
    if det_mask is not None:
        det_mask = np.asarray(det_mask).reshape(-1).astype(bool)
        pred_cls, gt_cls = pred_cls[det_mask], gt_cls[det_mask]
    if gt_cls.size == 0:
        return {"doa_acc": float("nan"), "mean_deg_err": float("nan"), "n": 0}
    centers = np.asarray(DOA_CLASS_CENTERS)
    acc = float(np.mean(pred_cls == gt_cls))
    mae = float(np.mean(np.abs(centers[pred_cls] - centers[gt_cls])))
    return {"doa_acc": acc, "mean_deg_err": mae, "n": int(gt_cls.size)}


def joint_score(det_metrics, doa_metric, det_rate_weight=1.0):
    """单一排序用的联合指标（仅用于跑实验时快速比较，不写入论文表格）。"""
    return det_rate_weight * det_metrics["auc"] + (1.0 - det_rate_weight) * (doa_metric["doa_acc"] or 0.0)


# --------------------------------------------------------------------------- #
# 训练/评测循环
# --------------------------------------------------------------------------- #
def count_parameters(model):
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return {"params": int(total), "trainable_params": int(trainable)}


@torch.no_grad()
def measure_rtf(model, sample, device, warmup=5, repeats=30):
    """测单条音频的实时率 RTF = 推理耗时 / 音频时长。"""
    import time
    model.eval()
    x = sample.to(device)
    dur = x.shape[-1] / 16000.0
    for _ in range(warmup):
        model(x)
    if device.type == "cuda":
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(repeats):
        model(x)
    if device.type == "cuda":
        torch.cuda.synchronize()
    elapsed = (time.perf_counter() - t0) / repeats
    return {"rtf": elapsed / dur, "latency_ms": elapsed * 1000.0, "audio_sec": dur}
