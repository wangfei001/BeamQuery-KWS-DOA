# Copyright (c) 2026
# -*- coding: utf-8 -*-
"""级联基线的**公平对比**评测（方案 A + 方案 B）。

背景 / 为什么需要这个脚本
------------------------
论文里最初写的是"级联 GCC/SRP-PHAT 方位准确率 68.8%、MAE 23.06°，
比本文 96.9% / 2.16° 差一个数量级"。这个说法**不公平**：

* 本文方法估计的是**唤醒词**的方位（content-aware）；
* 级联里的 GCC/SRP-PHAT 是**内容盲**的经典定位器，它估计的是**能量最强的声源**；
* 测试集里一半是 `n_src=2`（唤醒词 + 干扰源，0 dB），此时经典定位器
  有 ~50% 的概率锁定干扰源 —— 这是"选错声源"，不是"估计器精度差"。

公平评测 = 把这两件事拆开：

方案 A（分层）
    按 `n_src`（声源数）拆开统计。`n_src=1` 没有干扰源，级联没有"选错对象"
    的空间；`n_src=2` 才是内容感知起作用的地方。

方案 B（oracle 上界 / any-source）
    定义 `any-source acc`：只要估计方向命中【任一真实声源】就算对。
    这等价于"**给同一个经典估计器配一个完美的内容感知选择器**"能达到的上界。
    `wake-source acc`（实际级联）与 `any-source acc`（oracle 上界）之差
    = **内容感知缺口（content-awareness gap）**，这才是本文方法真正的贡献。

输入
----
1. `--varcol`：测试集 varcol.list，格式 `wav label n_src doa0 doa1 doa2`，
   其中 doa0=唤醒词方位类，doa1/doa2=干扰源方位类（-100 表示该槽为空）。
2. 各方法的逐条预测 `test_predictions.npz`（含 scores/labels/pred_doa/gt_doa/paths），
   由 `train_duibi.py` 评测时自动保存。
3. 可选：`--proposed_ckpt/--proposed_config`，若提出方法没有存 npz，本脚本会现算。

用法
----
python code_duibi/eval_fair_cascade.py \
    --varcol /root/kws_local/test_varcol.tmp.list \
    --pred_glob 'exp/rirlib/*/test_predictions.npz' \
    --proposed_ckpt exp/rirlib/proposed/best_cv.pt \
    --proposed_config code_duibi/configs/train_dynamic_query_v5.yaml \
    --out exp/fair_cascade.json
"""
import argparse, glob, json, os, sys
from collections import defaultdict

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, "../../.."))
sys.path.insert(0, HERE); sys.path.insert(0, REPO)

from paper_experiments.shared.code.common import det_curve, detection_metrics, frr_at_far  # noqa: E402

DOA_CENTERS = np.array([30.0, 90.0, 150.0])


# --------------------------------------------------------------------------- #
# 真值解析
# --------------------------------------------------------------------------- #
def load_truth(varcol_path):
    """返回 {basename: {"label":int, "n_src":int, "srcs":List[int], "wake":int}}。"""
    truth = {}
    with open(varcol_path, encoding="utf-8") as f:
        for line in f:
            p = line.strip().split()
            if len(p) < 3:
                continue
            name = os.path.basename(p[0])
            label = int(p[1]); n_src = int(p[2])
            cls = [int(x) for x in p[3:6]] if len(p) >= 6 else []
            srcs = [c for c in cls if c >= 0]
            wake = srcs[0] if (label == 1 and srcs) else -100
            truth[name] = {"label": label, "n_src": n_src, "srcs": srcs, "wake": wake}
    return truth


def align(names, truth):
    """把 npz 里的 paths（basename）映射到真值，返回 numpy 结构数组。"""
    lab = np.array([truth[n]["label"] for n in names], dtype=int)
    nsrc = np.array([truth[n]["n_src"] for n in names], dtype=int)
    wake = np.array([truth[n]["wake"] for n in names], dtype=int)
    return lab, nsrc, wake


# --------------------------------------------------------------------------- #
# 指标
# --------------------------------------------------------------------------- #
def _acc_mae(pred, gt):
    pred = np.asarray(pred, dtype=int); gt = np.asarray(gt, dtype=int)
    if gt.size == 0:
        return float("nan"), float("nan"), 0
    acc = float(np.mean(pred == gt))
    mae = float(np.mean(np.abs(DOA_CENTERS[pred] - DOA_CENTERS[gt])))
    return acc, mae, int(gt.size)


def evaluate_method(npz_path, truth):
    z = np.load(npz_path, allow_pickle=True)
    names = [os.path.basename(str(x)) for x in z["paths"]]
    scores = z["scores"].astype(float)
    labels = z["labels"].astype(int)
    durs = z["durations"].astype(float)
    pred = z["pred_doa"].astype(int)
    gt = z["gt_doa"].astype(int)

    lab, nsrc, wake = align(names, truth)
    # 与 train_duibi.evaluate 完全一致的工作点：FAR=1/h 的阈值
    thr = frr_at_far(scores, lab, durs, 1.0)["threshold"]
    valid = wake >= 0
    det_pos = (lab == 1) & valid & (scores > thr)

    det = detection_metrics(scores, lab, 0.5)
    frr = frr_at_far(scores, lab, durs, 1.0)

    out = {"n": int(len(lab)), "neg_hours": float(durs[lab == 0].sum() / 3600.0),
           "auc": det["auc"], "recall@0.5": det["recall"], "fpr@0.5": det["fpr"],
           "frr@far1h": frr["frr"], "work_thr": thr,
           "det_curve": det_curve(scores, lab, durs)}

    # ---- 总体（wake-source，与论文表一致） ----
    a, m, n = _acc_mae(pred[det_pos], wake[det_pos])
    out["overall_wake"] = {"acc": a, "mae": m, "n": n}

    # ---- 方案 A：按 n_src 分层 ----
    strat = {}
    for k in sorted(set(nsrc[det_pos & (lab == 1)].tolist())):
        msk = det_pos & (nsrc == k)
        a, m, n = _acc_mae(pred[msk], wake[msk])
        strat[f"n_src={k}"] = {"acc": a, "mae": m, "n": n}
    out["by_n_src"] = strat

    # ---- 方案 B：any-source（oracle 上界） ----
    hit_any, hit_wake, hit_interf = [], [], []
    for i in np.where(det_pos)[0]:
        srcs = truth[names[i]]["srcs"]
        hit_any.append(int(pred[i]) in srcs)
        hit_wake.append(int(pred[i]) == int(wake[i]))
        inter = [c for c in srcs if c != int(wake[i])]
        hit_interf.append(int(pred[i]) in inter if inter else False)
    hit_any = np.array(hit_any, dtype=bool)
    hit_wake = np.array(hit_wake, dtype=bool)
    hit_interf = np.array(hit_interf, dtype=bool)
    out["any_source"] = {"acc": float(hit_any.mean()) if hit_any.size else float("nan"),
                         "n": int(hit_any.size)}
    out["wake_source"] = {"acc": float(hit_wake.mean()) if hit_wake.size else float("nan")}
    out["picked_interferer"] = {"rate": float(hit_interf.mean()) if hit_interf.size else float("nan")}
    out["content_gap"] = (out["any_source"]["acc"] - out["wake_source"]["acc"])
    return out


# --------------------------------------------------------------------------- #
# 可选：为没有 npz 的方法（如提出方法）现场算一遍
# --------------------------------------------------------------------------- #
def dump_predictions(ckpt, config, test_data, test_varcol, out_npz, num_mic=2, gpu="0",
                     batch_size=16):
    import torch
    import yaml
    from torch.utils.data import DataLoader
    from paper_experiments.shared.code.train_duibi import (SpatialClipDataset,
                                                            PackedClipDataset, collate)
    from wekws.model.spatial_dynamic_query import SpatialDynamicQueryModel as M

    cfg = yaml.safe_load(open(os.path.join(REPO, config), encoding="utf-8"))
    dev = torch.device(f"cuda:{gpu}" if torch.cuda.is_available() else "cpu")
    model = M(fsmn_num_layers=cfg["fsmn_num_layers"], fsmn_dim=cfg["fsmn_dim"],
              num_query=cfg["num_query"], doa_num_class=cfg["doa_num_class"],
              feat_freq_dim=cfg["feat_freq_dim"], use_ipd=cfg.get("use_ipd", True),
              use_pair_ipd=cfg.get("use_pair_ipd", True), num_mic=cfg["num_mic"],
              pool_type=cfg.get("pool_type", "mean_max"),
              pair_feat_mode=cfg.get("pair_feat_mode", "tdoa"),
              mic_spacing=cfg.get("mic_spacing", 0.033), sr=cfg.get("sr", 16000),
              use_query_embed=cfg.get("use_query_embed", True),
              use_presence_head=cfg.get("use_presence_head", True),
              use_wake_head=cfg.get("use_wake_head", True),
              query_mode=cfg.get("query_mode", "beam"),
              causal=cfg.get("causal", False),
              norm_type=cfg.get("norm_type", "auto"),
              mel_compress=cfg.get("mel_compress", 0),
              mel_keep_coh=cfg.get("mel_keep_coh", False),
              encoder_type=cfg.get("encoder_type", "auto"),
              encoder_kwargs=cfg.get("encoder_kwargs", None))
    st = torch.load(ckpt, map_location="cpu")
    model.load_state_dict(st["model"] if "model" in st else st)
    model.to(dev).eval()

    # 优先用 mmap 打包数据(与训练同源, 且避免逐条 torchaudio.load 的磁盘瓶颈);
    # 打包数据不带文件名, 故并行读入 spatial list 顺序恢复真实 path 供对齐真值。
    packed_dir = os.environ.get("PACKED_DATA_DIR")
    if packed_dir:
        class _PackedNamed(PackedClipDataset):
            def __init__(self, data_list, varcol, num_mic, max_sec, packed_dir):
                super().__init__(data_list, varcol, num_mic, max_sec,
                                 packed_dir=packed_dir)
                self._paths = [os.path.abspath(ln.split()[0])
                               for ln in open(data_list, encoding="utf-8") if ln.strip()]
            def __getitem__(self, i):
                d = super().__getitem__(i)
                d["path"] = self._paths[self.indices[i]]
                return d
        ds = _PackedNamed(test_data, test_varcol, num_mic, 3.0, packed_dir)
    else:
        ds = SpatialClipDataset(test_data, test_varcol, num_mic, 3.0)
    dl = DataLoader(ds, batch_size=batch_size, shuffle=False, collate_fn=collate,
                    num_workers=8, pin_memory=True)
    sc, lb, du, pd, gd, pt = [], [], [], [], [], []
    with torch.no_grad():
        for b in dl:
            # 方案(B)：统一固定 3s 窗口，补零与训练一致地作为有效帧。
            out = model(b["wave"].to(dev))
            s = out["s_q"].float()
            prob = torch.sigmoid(s)
            # 独立二分类唤醒头(若存在)：检测分用它；方位仍由 query argmax 决定
            if out.get("wake_logit") is not None:
                sc.append(torch.sigmoid(out["wake_logit"].float()).cpu().numpy())
            else:
                sc.append(prob.max(dim=-1).values.cpu().numpy())
            pd.append(prob.argmax(dim=-1).cpu().numpy())
            lb.append(b["label"].numpy()); du.append(b["duration"].numpy())
            gd.append(b["wake_angle"].numpy()); pt += b["path"]
    np.savez(out_npz, scores=np.concatenate(sc), labels=np.concatenate(lb).astype(int),
             durations=np.concatenate(du), pred_doa=np.concatenate(pd).astype(int),
             gt_doa=np.concatenate(gd).astype(int), paths=np.array(pt))
    return out_npz


# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--varcol", required=True)
    ap.add_argument("--pred_glob", default="exp/rirlib/*/test_predictions.npz")
    ap.add_argument("--proposed_ckpt", default=None)
    ap.add_argument("--proposed_config", default="code_duibi/configs/train_dynamic_query_v5.yaml")
    ap.add_argument("--test_data", default=None)
    ap.add_argument("--num_mic", type=int, default=2)
    ap.add_argument("--out", default="exp/fair_cascade.json")
    args = ap.parse_args()

    truth = load_truth(args.varcol)
    paths = sorted(glob.glob(os.path.join(REPO, args.pred_glob)))
    if not paths:
        print("[warn] 未找到预测文件:", args.pred_glob)

    if args.proposed_ckpt and args.test_data:
        cache = os.path.join(REPO, os.path.dirname(args.proposed_ckpt), "test_predictions_fair.npz")
        if not os.path.exists(cache):
            print("[info] 现场计算提出方法逐条预测 ->", cache)
            dump_predictions(os.path.join(REPO, args.proposed_ckpt),
                             args.proposed_config, args.test_data, args.varcol,
                             cache, num_mic=args.num_mic)
        paths.append(cache)

    res = {}
    for p in paths:
        name = os.path.basename(os.path.dirname(p))
        if name == "proposed" or "proposed" in os.path.basename(p):
            name = os.path.basename(os.path.dirname(p)) or "proposed"
        try:
            res[name] = evaluate_method(p, truth)
        except Exception as e:  # noqa
            res[name] = {"error": str(e)}
    res = {"_note": "方案A=按n_src分层; any_source=oracle上界(完美内容感知选择); "
                    "content_gap=any_source-wake_source(内容感知缺口)",
           "methods": res}
    os.makedirs(os.path.dirname(os.path.abspath(os.path.join(REPO, args.out))), exist_ok=True)
    json.dump(res, open(os.path.join(REPO, args.out), "w", encoding="utf-8"),
              indent=2, ensure_ascii=False)

    # ---- 打印结论表 ----
    print("\n%-20s %8s %8s %10s %10s %10s %10s" %
          ("method", "AUC", "FRR1h", "wake_acc", "wake_mae", "any_acc", "gap"))
    for k, v in res["methods"].items():
        if "error" in v:
            print(f"{k:<20} ERROR {v['error']}"); continue
        print("%-20s %8.4f %8.4f %10.4f %10.2f %10.4f %10.4f" %
              (k, v["auc"], v["frr@far1h"], v["wake_source"]["acc"],
               v["overall_wake"]["mae"], v["any_source"]["acc"], v["content_gap"]))
    print("\n按声源数分层 (wake_acc / MAE):")
    for k, v in res["methods"].items():
        if "error" in v:
            continue
        s = v.get("by_n_src", {})
        txt = "  ".join(f"{kk}: {vv['acc']:.3f}/{vv['mae']:.2f}°(n={vv['n']})"
                        for kk, vv in s.items())
        print(f"  {k:<20} {txt}")
    print("\n已写入", args.out)


if __name__ == "__main__":
    main()
