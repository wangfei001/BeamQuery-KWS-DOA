# -*- coding: utf-8 -*-
"""TCSN (ICASSP 2024) KWS adapter for the common waveform interface."""
import torch
import torch.nn as nn

from paper_experiments.shared.code.models import SingleChannelKWS, TemporalPool
from paper_experiments.shared.code.tcsn_model import TCSN, DsCnnBlock


def _stft(x, n_fft, hop, win_len, window):
    return torch.stft(x, n_fft=n_fft, hop_length=hop, win_length=win_len,
                      window=window, return_complex=True)


class TCSNKWS(nn.Module):
    """Official TCSN backbone adapted to the [B, M, T] waveform interface.

    TCSN is a single-channel architecture.  The adapter computes the waveform
    STFT for the full batch but deliberately feeds only microphone 0 to the
    network; this matches the original TCSN input contract and is the input
    description used in the paper.
    """

    def __init__(self, num_mic=2, num_layers=4, hidden_dim=16, kernel_size=3,
                 dropout=0.1, n_fft=512, hop=160, win_len=512, n_mels=40,
                 sr=16000, pool_type="mean_max", **kwargs):
        super().__init__()
        self.num_mic = num_mic
        self.n_fft, self.hop, self.win_len = n_fft, hop, win_len
        self.register_buffer("window", torch.hann_window(win_len))
        self.mel_fb = nn.Parameter(
            SingleChannelKWS._mel_filterbank(sr, n_fft, n_mels),
            requires_grad=False)
        self.frontend = nn.Sequential(
            nn.Conv1d(n_mels, hidden_dim, kernel_size=1),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True))
        self.backbone = TCSN(num_layers, hidden_dim, kernel_size, dropout,
                             block_class=DsCnnBlock)
        self.pool = TemporalPool(hidden_dim, pool_type)
        head_in = hidden_dim * 2 if pool_type == "mean_max" else hidden_dim
        self.head = nn.Sequential(
            nn.Linear(head_in, hidden_dim), nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, 1))

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(0)
        B, M, T = x.shape
        stft = _stft(x.reshape(B * M, T), self.n_fft, self.hop,
                     self.win_len, self.window)
        mag = stft.abs().reshape(B, M, stft.shape[-2], stft.shape[-1])
        mel = torch.matmul(self.mel_fb.to(mag.dtype), mag)
        # TCSN is single-channel: use microphone 0 only.  Do not silently
        # concatenate/average channels, since that would change the baseline.
        feat = self.frontend(mel[:, 0]).transpose(1, 2)
        empty = feat.new_zeros(0, 0, 0)
        y, _, _ = self.backbone(feat, empty, empty)
        s = self.head(self.pool(y.transpose(1, 2)))
        return {"s_q": s, "presence_logit": None}
