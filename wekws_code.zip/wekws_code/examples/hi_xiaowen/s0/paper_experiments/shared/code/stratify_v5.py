# -*- coding: utf-8 -*-
"""分层统计：按 n_src（单/双声源）与 SIR 分档报告检测与方位指标。

用法:
  python code_duibi/stratify_v5.py --pred <npz> --varcol <test_varcol.list> [--label 名字]
"""
import argparse, os, re, json
import numpy as np
from sklearn.metrics import roc_auc_score

SR, WIN = 16000, 2.75
CENTER = np.array([30, 90, 150], float)


def load_meta(varcol):
    nsrc, sir = {}, {}
    for ln in open(varcol, encoding="utf-8"):
        p = ln.split()
        if not p:
            continue
        b = os.path.basename(p[0])
        nsrc[b] = int(p[2])
        m = re.search(r"_sir([+-]\d+)_", b)
        sir[b] = int(m.group(1)) if m else None
    return nsrc, sir


def metrics(s, y, gt, pd, tag):
    if len(set(y)) < 2:
        return None
    neg = (y == 0).sum()
    negh = neg * WIN / 3600.0
    n = max(1, int(round(1.0 * negh)))
    ns = np.sort(s[y == 0])[::-1]
    thr = ns[min(n, len(ns)) - 1]
    det = s >= thr
    out = dict(tag=tag, n_pos=int((y == 1).sum()), n_neg=int(neg), neg_h=round(negh, 2),
               auc=round(float(roc_auc_score(y, s)), 4),
               frr1h=round(float(1 - det[y == 1].mean()), 4),
               fpr05=round(float((s[y == 0] >= 0.5).mean()), 4),
               wake_rate1h=round(float(det[y == 1].mean()), 4))
    m = (y == 1) & (gt >= 0) & det
    if m.sum() > 0:
        out["doa_acc"] = round(float((pd[m] == gt[m]).mean()), 4)
        out["mae"] = round(float(np.abs(CENTER[pd[m]] - CENTER[gt[m]]).mean()), 2)
        out["n_det"] = int(m.sum())
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred", required=True)
    ap.add_argument("--varcol", required=True)
    ap.add_argument("--label", default="")
    a = ap.parse_args()
    nsrc, sir = load_meta(a.varcol)
    d = np.load(a.pred, allow_pickle=True)
    s = d["scores"].astype(float); y = d["labels"].astype(int)
    gt = d["gt_doa"].astype(int) if "gt_doa" in d else np.full(len(y), -100)
    pd = d["pred_doa"].astype(int) if "pred_doa" in d else np.full(len(y), -1)
    N = np.array([nsrc.get(os.path.basename(p), 0) for p in d["paths"]])
    S = np.array([sir.get(os.path.basename(p), None) for p in d["paths"]], dtype=object)
    rows = [metrics(s, y, gt, pd, "ALL")]
    for k in (1, 2):
        m = N == k
        if m.sum():
            rows.append(metrics(s[m], y[m], gt[m], pd[m], "n_src=%d" % k))
    m2 = N == 2
    for sv in sorted({v for v in S[m2] if v is not None}):
        mm = m2 & np.array([v == sv for v in S])
        if mm.sum():
            rows.append(metrics(s[mm], y[mm], gt[mm], pd[mm], "n2_SIR%+d" % sv))
    print("\n===== %s =====" % (a.label or a.pred))
    print("%-14s %6s %6s %7s %8s %8s %8s %8s %8s" %
          ("subset", "n_pos", "n_neg", "AUC", "FRR@1h", "FPR@.5", "wake@1h", "DOAacc", "MAE"))
    for r in rows:
        if r is None:
            continue
        print("%-14s %6d %6d %7.4f %8.4f %8.4f %8.4f %8s %8s" %
              (r["tag"], r["n_pos"], r["n_neg"], r["auc"], r["frr1h"], r["fpr05"],
               r["wake_rate1h"], r.get("doa_acc", "-"), r.get("mae", "-")))
    json.dump(rows, open(a.pred.replace(".npz", "_strat.json"), "w"), indent=1)
    print("-> ", a.pred.replace(".npz", "_strat.json"))


if __name__ == "__main__":
    main()
