# -*- coding: utf-8 -*-
"""按 FAR=1/h 口径在 CV 集上重选模（用已保存的 epoch checkpoint，零训练成本）。

score = AUC * loc_acc_det@1h   （与论文测试口径一致）
"""
import argparse, glob, json, os, sys, re
import numpy as np, torch, yaml
from torch.utils.data import DataLoader
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")))
from paper_experiments.shared.code.train_duibi import SpatialClipDataset, collate
from wekws.model.spatial_dynamic_query import SpatialDynamicQueryModel as M
from sklearn.metrics import roc_auc_score

def build(cfg, ckpt, dev):
    c = yaml.safe_load(open(cfg, encoding="utf-8"))
    m = M(fsmn_num_layers=c["fsmn_num_layers"], fsmn_dim=c["fsmn_dim"],
          num_query=c["num_query"], doa_num_class=c["doa_num_class"],
          feat_freq_dim=c["feat_freq_dim"], use_ipd=c.get("use_ipd", True),
          use_pair_ipd=c.get("use_pair_ipd", True), num_mic=c["num_mic"],
          pool_type=c.get("pool_type", "mean_max"), pair_feat_mode=c.get("pair_feat_mode", "tdoa"),
          mic_spacing=c.get("mic_spacing", 0.033), sr=c.get("sr", 16000),
          use_query_embed=c.get("use_query_embed", True),
          use_presence_head=c.get("use_presence_head", True),
          use_wake_head=c.get("use_wake_head", True),
          query_mode=c.get("query_mode", "beam"), causal=c.get("causal", False),
          norm_type=c.get("norm_type", "auto"), encoder_type=c.get("encoder_type", "auto"))
    st = torch.load(ckpt, map_location="cpu")
    m.load_state_dict(st["model"] if "model" in st else st)
    return m.to(dev).eval(), c

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt_glob", required=True)
    ap.add_argument("--config", required=True)
    ap.add_argument("--data", required=True)      # CV spatial list
    ap.add_argument("--varcol", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--gpu", default="0")
    a = ap.parse_args()
    dev = torch.device(f"cuda:{a.gpu}" if torch.cuda.is_available() else "cpu")
    ds = SpatialClipDataset(a.data, a.varcol, 2, 3.0)
    dl = DataLoader(ds, batch_size=32, shuffle=False, collate_fn=collate)
    res = []
    for ck in sorted(glob.glob(a.ckpt_glob), key=lambda p: int(re.search(r"(\d+)", os.path.basename(p)).group(1))):
        m, c = build(a.config, ck, dev)
        sc, lb, gt, pd = [], [], [], []
        with torch.no_grad():
            for b in dl:
                o = m(b["wave"].to(dev)); s = torch.sigmoid(o["s_q"].float())
                sc.append(s.max(-1).values.cpu().numpy()); pd.append(s.argmax(-1).cpu().numpy())
                lb.append(b["label"].numpy()); gt.append(b["wake_angle"].numpy())
        sc = np.concatenate(sc); lb = np.concatenate(lb); gt = np.concatenate(gt); pd = np.concatenate(pd)
        neg = (lb == 0).sum(); negh = neg * 2.75 / 3600.
        n = max(1, int(round(negh))); ns = np.sort(sc[lb == 0])[::-1]
        thr = ns[min(n, len(ns)) - 1]; det = sc >= thr
        pos = (lb == 1) & (gt >= 0); m2 = pos & det
        loc = float((pd[m2] == gt[m2]).mean()) if m2.sum() else float("nan")
        auc = float(roc_auc_score(lb, sc))
        res.append(dict(ckpt=os.path.basename(ck), auc=auc, loc1h=loc,
                        wake1h=float(det[pos].mean()), score=auc * loc,
                        n_det=int(m2.sum())))
        print("%-16s AUC=%.4f loc@1h=%.4f wake@1h=%.4f score=%.4f" %
              (os.path.basename(ck), auc, loc, det[pos].mean(), auc * loc), flush=True)
    res.sort(key=lambda r: -r["score"])
    json.dump(res, open(a.out, "w"), indent=1)
    print("\n最佳:", res[0]["ckpt"], "score=%.4f" % res[0]["score"])

if __name__ == "__main__":
    main()
