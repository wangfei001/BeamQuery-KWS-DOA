# -*- coding: utf-8 -*-
"""Sweep wake threshold / target FAR and report detection, DOA and Joint."""
import argparse, json, os, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, '../../..'))
sys.path.insert(0, REPO)
from paper_experiments.shared.code.common import detection_metrics, frr_at_far  # noqa
from paper_experiments.shared.code.eval_allpos_v7 import load_truth, DOA_CENTERS  # noqa


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pred', required=True)
    ap.add_argument('--varcol', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--fars', default='0.1,0.5,1,2,5,10')
    a = ap.parse_args()
    truth = load_truth(a.varcol)
    z = np.load(a.pred, allow_pickle=True)
    names = [os.path.basename(str(x)) for x in z['paths']]
    s = z['scores'].astype(float); y = z['labels'].astype(int)
    dur = z['durations'].astype(float); pd = z['pred_doa'].astype(int); gt = z['gt_doa'].astype(int)
    rows = []
    for far in [float(x) for x in a.fars.split(',')]:
        f = frr_at_far(s, y, dur, far)
        thr = float(f['threshold'])
        det = detection_metrics(s, y, thr)
        valid = gt >= 0
        allpos = (y == 1) & valid
        detpos = allpos & (s > thr)
        if detpos.sum():
            acc = float(np.mean(pd[detpos] == gt[detpos]))
            mae = float(np.mean(np.abs(DOA_CENTERS[pd[detpos]] - DOA_CENTERS[gt[detpos]])))
        else:
            acc = mae = float('nan')
        joint = float(np.mean((s[allpos] > thr) & (pd[allpos] == gt[allpos]))) if allpos.sum() else float('nan')
        rows.append({'target_far': far, 'threshold': thr, 'frr': float(f['frr']),
                     'fpr': float(det['fpr']), 'auc': float(det['auc']),
                     'doa_det': acc, 'mae_det': mae, 'joint_all': joint,
                     'n_det': int(detpos.sum())})
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    json.dump(rows, open(a.out, 'w'), indent=2, ensure_ascii=False)
    print(json.dumps(rows, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
