# Copyright (c) 2026
# -*- coding: utf-8 -*-
"""对比实验的基线模型（全部与提出方法共享同一编码器，保证参数量可比）。

模型清单
--------
- MonoKWS      : 单通道（只用第 0 麦）fbank + CNN 编码器 + 二分类头。**下界基线**。
- ConcatMCKWS  : 多通道幅度谱 + 通道间相位差直接拼接到输入通道。**朴素多通道基线**。
- FixedBeamKWS : 固定指向波束（broadside/90°）做前端增强，再单通道 KWS。
                 **"前端与唤醒解耦"的代表**，用于验证方向条件化波束的必要性。
- CascadeKWS   : MonoKWS 检测 + 经典 GCC-PHAT/SRP-PHAT 定位（不需要训练定位分支）。

所有模型 forward(x) 输入 [M, T]（单样本）或 [B, M, T]，输出 dict：
  {"s_q": [B, Q] 或 [B, 1], "presence_logit": None}
其中 Q 为方位类数；MonoKWS/ConcatMCKWS/FixedBeamKWS 的 Q=1（只做检测，
方位由额外的级联模块给出，或在联合指标里标记为不支持）。
"""
import math
import os
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from wekws.model.spatial_dynamic_query import (  # noqa: E402
    Stacked1DCNNEncoder, build_shared_encoder)
from paper_experiments.shared.code.bc_resnet_official import BCResNetOfficialKWS  # noqa: E402

SPEED_OF_SOUND = 340.0


def _stft(wav, n_fft=512, hop=160, win_len=512, window=None):
    return torch.stft(wav, n_fft=n_fft, hop_length=hop, win_length=win_len,
                      window=window, return_complex=True)


class TemporalPool(nn.Module):
    """时间维池化：[B, C, T] -> [B, C] 或 [B, 2C]。"""

    def __init__(self, dim, pool_type="mean_max"):
        super().__init__()
        self.pool_type = pool_type
        if pool_type == "attn":
            self.score = nn.Linear(dim, 1)

    def forward(self, x):
        if self.pool_type == "mean":
            return x.mean(dim=-1)
        if self.pool_type == "mean_max":
            return torch.cat([x.mean(dim=-1), x.max(dim=-1).values], dim=-1)
        if self.pool_type == "attn":
            x_t = x.transpose(1, 2)                       # [B,T,C]
            w = torch.softmax(self.score(x_t).squeeze(-1), dim=1)
            return torch.einsum("bt,btc->bc", w, x_t)
        raise ValueError(f"未知 pool_type: {self.pool_type}")


class SingleChannelKWS(nn.Module):
    """单通道 KWS：fbank(40) → CNN 编码器 → 池化 → 单 logit。

    这是一个"干净"的 KWS 基线：不含任何空间信息，用于回答
    "多通道信息到底带来了多少增益"。
    """

    def __init__(self, num_layers=8, hidden_dim=128, pool_type="mean_max",
                 n_fft=512, hop=160, win_len=512, n_mels=40, sr=16000,
                 encoder_type="auto", causal=False, norm_type="auto"):
        super().__init__()
        self.n_fft, self.hop, self.win_len = n_fft, hop, win_len
        self.register_buffer("window", torch.hann_window(win_len))
        # 用可学习/固定的 mel 滤波器组把幅度谱压到 n_mels
        self.mel_fb = nn.Parameter(self._mel_filterbank(sr, n_fft, n_mels), requires_grad=False)
        # 与主模型完全相同的共享编码器（结构/宽度/归一化/因果性一致）
        self.encoder = build_shared_encoder(input_dim=n_mels, hidden_dim=hidden_dim,
                                           num_layers=num_layers, causal=causal,
                                           norm_type=norm_type,
                                           encoder_type=encoder_type)
        head_in = hidden_dim * 2 if pool_type == "mean_max" else hidden_dim
        self.pool = TemporalPool(hidden_dim, pool_type)
        self.head = nn.Sequential(nn.Linear(head_in, hidden_dim), nn.ReLU(inplace=True),
                                  nn.Linear(hidden_dim, 1))

    @staticmethod
    def _mel_filterbank(sr, n_fft, n_mels, fmin=20.0, fmax=None):
        fmax = fmax or sr / 2.0
        def hz2mel(f): return 2595.0 * math.log10(1.0 + f / 700.0)
        def mel2hz(m): return 700.0 * (10 ** (m / 2595.0) - 1.0)
        pts = mel2hz(torch.linspace(hz2mel(torch.tensor(fmin)), hz2mel(torch.tensor(fmax)),
                                    n_mels + 2))
        freqs = torch.linspace(0, sr / 2.0, n_fft // 2 + 1)
        fb = torch.zeros(n_mels, freqs.numel())
        for i in range(n_mels):
            l, c, r = pts[i], pts[i + 1], pts[i + 2]
            fb[i] = torch.clamp(torch.minimum((freqs - l) / (c - l + 1e-8),
                                              (r - freqs) / (r - c + 1e-8)), min=0.0)
        return fb

    def _features(self, wav):
        """wav [B, T] -> log-mel [B, F, T]。"""
        stft = _stft(wav, self.n_fft, self.hop, self.win_len, self.window)
        mag = stft.abs()                                   # [B, F, T]
        mel = torch.matmul(self.mel_fb.to(mag.dtype), mag)  # [B, M, T]
        return torch.log(mel + 1e-6)

    def forward(self, x):
        # 输入约定：2D = [T]（单样本）或 [T]；3D = [B, M, T]（多通道批量）
        if x.dim() == 3:
            x = x[:, 0, :]                                  # 只取第 0 麦 -> [B, T]
        elif x.dim() == 2:
            x = x.unsqueeze(0)                              # [T] -> [1, T]
        feat = self._features(x)                            # [B, M, T]
        h = self.encoder(feat.transpose(1, 2)).transpose(1, 2)   # [B, D, T]
        s = self.head(self.pool(h))                         # [B, 1]
        return {"s_q": s, "presence_logit": None}


class ConcatMultiChannelKWS(nn.Module):
    """朴素多通道基线：把所有通道的 log-mel 与通道间 cos/sin 相位差拼接后送入编码器。

    这是"不做任何空间建模，只是把多通道堆进网络"的代表性做法，
    用于说明结构化的方向条件化(query-beam)比朴素拼接更有效。
    """

    def __init__(self, num_mic=2, num_layers=8, hidden_dim=128, pool_type="mean_max",
                 n_fft=512, hop=160, win_len=512, n_mels=40, sr=16000,
                 use_ipd=True, encoder_type="auto", causal=False, norm_type="auto"):
        super().__init__()
        self.n_fft, self.hop, self.win_len = n_fft, hop, win_len
        self.num_mic, self.use_ipd = num_mic, use_ipd
        self.register_buffer("window", torch.hann_window(win_len))
        self.mel_fb = nn.Parameter(SingleChannelKWS._mel_filterbank(sr, n_fft, n_mels),
                                   requires_grad=False)
        in_dim = n_mels * num_mic + (2 * n_mels * (num_mic - 1) if use_ipd else 0)
        self.encoder = build_shared_encoder(input_dim=in_dim, hidden_dim=hidden_dim,
                                           num_layers=num_layers, causal=causal,
                                           norm_type=norm_type,
                                           encoder_type=encoder_type)
        head_in = hidden_dim * 2 if pool_type == "mean_max" else hidden_dim
        self.pool = TemporalPool(hidden_dim, pool_type)
        self.head = nn.Sequential(nn.Linear(head_in, hidden_dim), nn.ReLU(inplace=True),
                                  nn.Linear(hidden_dim, 1))

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(0)
        B, M, T = x.shape
        stft = _stft(x.reshape(B * M, T), self.n_fft, self.hop, self.win_len, self.window)
        mag = stft.abs().reshape(B, M, stft.shape[-2], stft.shape[-1])
        fb = self.mel_fb.to(mag.dtype)
        mel = torch.matmul(fb, mag)                         # [B, M, Mels, T]
        feats = [mel.reshape(B, M * mel.shape[2], mel.shape[3])]
        if self.use_ipd and M > 1:
            ang = torch.angle(stft).reshape(B, M, stft.shape[-2], stft.shape[-1])
            for i in range(1, M):
                dphi = ang[:, i] - ang[:, 0]                # [B,F,T]
                cos_d = torch.matmul(fb, torch.cos(dphi))
                sin_d = torch.matmul(fb, torch.sin(dphi))
                feats += [cos_d, sin_d]
        feat = torch.cat(feats, dim=1)                      # [B, D, T]
        h = self.encoder(feat.transpose(1, 2)).transpose(1, 2)
        s = self.head(self.pool(h))
        return {"s_q": s, "presence_logit": None}


class FixedBeamKWS(nn.Module):
    """固定波束前端 + 单通道 KWS。

    波束方向固定（默认 90°，即正前方 broadside），**不随声源方向自适应**。
    这条基线对应"前端分离与唤醒检测解耦"的常规做法：
    先做一级固定空域滤波，再交给 KWS 网络，二者不联合优化。
    """

    def __init__(self, num_mic=2, steer_deg=90.0, mic_spacing=0.033, sr=16000,
                 num_layers=8, hidden_dim=128, pool_type="mean_max",
                 n_fft=512, hop=160, win_len=512, n_mels=40, speed_sound=SPEED_OF_SOUND,
                 encoder_type="auto", causal=False, norm_type="auto"):
        super().__init__()
        self.n_fft, self.hop, self.win_len = n_fft, hop, win_len
        self.num_mic, self.steer_deg = num_mic, float(steer_deg)
        self.mic_spacing, self.sr, self.c = mic_spacing, sr, speed_sound
        self.register_buffer("window", torch.hann_window(win_len))
        self.kws = SingleChannelKWS(num_layers, hidden_dim, pool_type,
                                    n_fft, hop, win_len, n_mels, sr,
                                    encoder_type=encoder_type, causal=causal,
                                    norm_type=norm_type)

    def _steer(self, M, F, device, dtype):
        freqs = torch.fft.rfftfreq(self.n_fft, d=1.0 / self.sr).to(device)
        pos = (torch.arange(M, device=device, dtype=torch.float32)
               - (M - 1) / 2.0) * self.mic_spacing
        tau = pos * math.cos(math.radians(self.steer_deg)) / self.c     # [M]
        steer = torch.exp(1j * 2.0 * math.pi * freqs.unsqueeze(0) * tau.unsqueeze(1))
        return steer.to(dtype).unsqueeze(-1)                            # [M,F,1]

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(0)
        B, M, T = x.shape
        stft = _stft(x.reshape(B * M, T), self.n_fft, self.hop, self.win_len, self.window)
        stft = stft.reshape(B, M, stft.shape[-2], stft.shape[-1])
        steer = self._steer(M, stft.shape[-2], x.device, stft.dtype)
        beam = (stft * steer).sum(dim=1)                     # [B,F,T]
        wav = torch.istft(beam, n_fft=self.n_fft, hop_length=self.hop,
                          win_length=self.win_len, window=self.window, length=T)
        return self.kws(wav.unsqueeze(1))                   # [B,1,T] 走单通道通路


class FixedBeamMultiKWS(nn.Module):
    """多路固定波束基线：每个波束固定指向一个方位类中心（默认 30/90/150 度），
    各自经过**共享的单通道检测器**得到一个 logit。

    与 BeamQuery 的结构对齐（Q 个 logit 对应 Q 个方位类），因此可以：
      * 输出方位（argmax），从而加入方位对比（原来的单固定波束做不到）
      * 复用同一套 Q+1 交叉熵损失与评测口径

    与 BeamQuery 的唯一区别：**每类只有 1 个固定角度的波束**，
    而 BeamQuery 在类内铺角度网格（3 个角度）并取最强响应。
    → 因此它同时是"类内波束网格是否有用"的消融。
    """
    def __init__(self, steer_degs=(30.0, 90.0, 150.0), num_mic=2, mic_spacing=0.033,
                 sr=16000, num_layers=8, hidden_dim=128, pool_type="mean_max",
                 encoder_type="auto", causal=False, norm_type="auto",
                 n_fft=512, hop=160, win_len=512, n_mels=40,
                 speed_sound=SPEED_OF_SOUND, **kwargs):
        super().__init__()
        self.steer_degs = [float(a) for a in steer_degs]
        self.num_query = len(self.steer_degs)
        self.n_fft, self.hop, self.win_len = n_fft, hop, win_len
        self.num_mic, self.mic_spacing = num_mic, mic_spacing
        self.sr, self.c = sr, speed_sound
        self.register_buffer("window", torch.hann_window(win_len))
        # 共享同一个检测器，对每个波束各评估一次（与 BeamQuery 对齐）
        self.kws = SingleChannelKWS(num_layers=num_layers, hidden_dim=hidden_dim,
                                    pool_type=pool_type, n_fft=n_fft, hop=hop,
                                    win_len=win_len, n_mels=n_mels, sr=sr,
                                    encoder_type=encoder_type, causal=causal,
                                    norm_type=norm_type)

    def _steer_vec(self, M, Fb, device, dtype):
        freqs = torch.fft.rfftfreq(self.n_fft, d=1.0 / self.sr).to(device)
        pos = (torch.arange(M, device=device, dtype=torch.float32)
               - (M - 1) / 2.0) * self.mic_spacing
        out = []
        for a in self.steer_degs:
            tau = pos * math.cos(math.radians(a)) / self.c
            out.append(torch.exp(1j * 2.0 * math.pi
                                 * freqs.unsqueeze(0) * tau.unsqueeze(1)))  # [M,F]
        return torch.stack(out, dim=0)                                       # [Q,M,F]

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(0)
        B, M, T = x.shape
        stft = _stft(x.reshape(B * M, T), self.n_fft, self.hop, self.win_len, self.window)
        Fb = stft.shape[-2]
        stft = stft.reshape(B, M, Fb, stft.shape[-1])
        steer = self._steer_vec(M, Fb, x.device, stft.dtype)
        beams = torch.einsum("bmft,qmf->bqft", stft, steer)                  # [B,Q,F,T]
        outs = []
        for q in range(self.num_query):
            wav = torch.istft(beams[:, q], n_fft=self.n_fft, hop_length=self.hop,
                              win_length=self.win_len, window=self.window, length=T)
            outs.append(self.kws(wav.unsqueeze(1))["s_q"])                   # [B,1]
        s_q = torch.cat(outs, dim=-1)                                        # [B,Q]
        return {"s_q": s_q, "presence_logit": None, "pred_s": s_q}


# =========================================================================== #
# 2026 近年基线：端到端方向感知 KWS（学习式空间编码器 + 方向先验）
# --------------------------------------------------------------------------- #
# 复现自（按原文的"部署形态"实现，即 DOA 由经典估计器提供，而非 oracle）：
#   R. Wang et al., "End-to-end direction-aware keyword spotting with spatial
#   priors in noisy environments", 2026.
# 原文三模块：
#   (i)  空间编码器：直接作用于多通道【复数】谱，用复值 Conv2D 做时频降采样
#        （不显式合成波束，保留 IPD/ILD 线索）
#   (ii) 方向嵌入：把离散 DOA 标签经 MLP 映射为向量 e_θ
#   (iii) 融合后送入流式时域骨干，再做分类
# 与原文的唯一差别：原文假设 DOA 在训练与评测时【已知】（oracle）；这里按其
# 原文自己给出的部署建议，用 GCC-PHAT 估计 DOA 喂入。因此这是一个【公平】的
# 近年对比方法，其方向先验同样是内容盲的。
# =========================================================================== #
class SpatialPriorKWS(nn.Module):
    """E2E direction-aware KWS (Wang et al., 2026) with a GCC-PHAT DOA prior."""

    uses_doa_prior = True

    def __init__(self, num_mic=2, num_layers=8, hidden_dim=128, pool_type="mean_max",
                 n_fft=512, hop=160, win_len=512, sr=16000, num_doa_class=3,
                 spatial_channels=32, doa_embed_dim=None, causal=True,
                 norm_type="running", encoder_type="auto", **kwargs):
        super().__init__()
        self.n_fft, self.hop, self.win_len = n_fft, hop, win_len
        self.num_mic, self.num_doa_class = num_mic, num_doa_class
        self.register_buffer("window", torch.hann_window(win_len))
        d = doa_embed_dim or hidden_dim
        # ---- (i) 空间编码器：复数谱当作 2M 个实通道，两级 Conv2D 时频降采样 ----
        # 复值 2D 卷积（实/虚拼成通道）→ ReLU → 实值 2D 卷积（继续降采样）
        self.sp_conv1 = nn.Conv2d(2 * num_mic, spatial_channels,
                                  kernel_size=(3, 3), stride=(2, 1), padding=(1, 1))
        self.sp_conv2 = nn.Conv2d(spatial_channels, spatial_channels,
                                  kernel_size=(3, 3), stride=(2, 1), padding=(1, 1))
        # 频率轴投影到时间对齐的 d 维序列
        self.freq_proj = None            # 延迟到首次前向按 F' 构造
        self.sp_proj_dim = spatial_channels
        # ---- (ii) 方向嵌入：DOA 类 → e_θ ----
        self.doa_embed = nn.Sequential(
            nn.Linear(num_doa_class, d), nn.ReLU(inplace=True),
            nn.Dropout(0.1), nn.LayerNorm(d))
        # ---- (iii) 融合后送入统一主干，再做二分类 ----
        self.enc_in_dim = d
        self.encoder = build_shared_encoder(input_dim=d, hidden_dim=hidden_dim,
                                            num_layers=num_layers, causal=causal,
                                            norm_type=norm_type,
                                            encoder_type=encoder_type)
        head_in = hidden_dim * 2 if pool_type == "mean_max" else hidden_dim
        self.pool = TemporalPool(hidden_dim, pool_type)
        self.head = nn.Sequential(nn.Linear(head_in, hidden_dim), nn.ReLU(inplace=True),
                                  nn.Linear(hidden_dim, 1))

    def _spatial_encode(self, wave):
        """wave [B,M,T] -> [B,T',d]（空间编码器输出，未融合方向先验）"""
        B, M, T = wave.shape
        stft = _stft(wave.reshape(B * M, T), self.n_fft, self.hop,
                     self.win_len, self.window)                 # [B*M,F,Tf] complex
        Fb, Tf = stft.shape[-2], stft.shape[-1]
        x = torch.cat([stft.real, stft.imag], dim=1)            # [B*M,2F,Tf]
        x = x.reshape(B, 2 * M, Fb, Tf)                         # [B,2M,F,Tf]
        h = F.relu(self.sp_conv1(x))
        h = F.relu(self.sp_conv2(h))                            # [B,C,F',Tf]
        C, Fp = h.shape[1], h.shape[2]
        if self.freq_proj is None or self.freq_proj.in_features != C * Fp:
            self.freq_proj = nn.Linear(C * Fp, self.enc_in_dim).to(h.device)
        h = h.permute(0, 3, 1, 2).reshape(B, Tf, C * Fp)        # [B,Tf,C*F']
        return self.freq_proj(h)                               # [B,Tf,d]

    def forward(self, x, doa_prior=None):
        if x.dim() == 2:
            x = x.unsqueeze(0)
        B = x.shape[0]
        h = self._spatial_encode(x)                            # [B,Tf,d]
        # ---- (ii)+(iii) 方向先验嵌入并相加 ----
        if doa_prior is None:
            doa_prior = torch.zeros(B, dtype=torch.long, device=x.device)
        doa_prior = doa_prior.clamp(min=0, max=self.num_doa_class - 1)
        onehot = F.one_hot(doa_prior, self.num_doa_class).to(h.dtype)   # [B,K]
        e_theta = self.doa_embed(onehot).unsqueeze(1)                   # [B,1,d]
        h = h + e_theta
        enc = self.encoder(h)                                  # [B,Tf,D]
        s = self.head(self.pool(enc.transpose(1, 2)))          # [B,1]
        return {"s_q": s, "presence_logit": None}


def _build_tcsn(**cfg):
    """Lazily construct the TCSN baseline (ICASSP 2024)."""
    from paper_experiments.shared.code.tcsn_kws import TCSNKWS
    allowed = {"num_mic", "num_layers", "hidden_dim", "kernel_size",
               "dropout", "n_fft", "hop", "win_len", "n_mels", "sr",
               "pool_type"}
    kw = {k: v for k, v in cfg.items() if k in allowed}
    return TCSNKWS(**kw)


class ModelFactory:
    """统一构造入口，便于训练脚本按名字实例化基线。"""

    BUILDERS = {
        "mono": lambda cfg: SingleChannelKWS(**cfg),
        "concat-mc": lambda cfg: ConcatMultiChannelKWS(**cfg),
        "fixed-beam": lambda cfg: FixedBeamKWS(**cfg),
        "fixed-beam-3": lambda cfg: FixedBeamMultiKWS(**cfg),
        "bc-resnet": lambda cfg: BCResNetOfficialKWS(**cfg),
        "kwt": lambda cfg: KeywordTransformerKWS(**cfg),
        "spatial-prior": lambda cfg: SpatialPriorKWS(**cfg),
        # TCSN: lazy import to avoid a circular import (tcsn_kws imports
        # SingleChannelKWS/TemporalPool from this module).
        "tcsn": lambda cfg: _build_tcsn(**cfg),
    }

    @staticmethod
    def create(name, **kwargs):
        if name not in ModelFactory.BUILDERS:
            raise ValueError(f"未知基线模型: {name}; 可选 {sorted(ModelFactory.BUILDERS)}")
        return ModelFactory.BUILDERS[name](kwargs)


# =========================================================================== #
# 近年（2021+）公开方法的复现，用作现代骨干基线
# --------------------------------------------------------------------------- #
# 说明：这两个模型是按原始论文/公开实现复现的，**不是官方代码**，
# 因此论文中应写成 "we reimplement [ref]" 并说明细节差异。
#   BC-ResNet : B. Kim et al., "Broadcasted Residual Learning for Efficient
#               Keyword Spotting", Interspeech 2021.
#               Official architecture port: https://github.com/re9ulus/BC-ResNet
#               (commit 086ce358885b4b4521b2763c4563f9e681412e74), with only the
#               final 35-class head adapted to one binary wake/non-wake logit.
#   KWT       : A. Berg et al., "Keyword Transformer: A Self-Attention Model
#               for Keyword Spotting", Interspeech 2021.
#               参考实现: https://github.com/mashrurmorshed/Torch-KWT
# 两者均按原论文采用单通道输入，取第 0 麦的对数梅尔；
# single_channel=False 仅保留给明确标注的消融，不作为论文主比较配置。
# =========================================================================== #
class KeywordTransformerKWS(nn.Module):
    """Keyword Transformer（KWT）风格：patch embedding + Transformer + class token。"""

    def __init__(self, num_mic=2, patch_size=16, n_mels=40, n_fft=512, hop=160,
                 win_len=512, sr=16000, d_model=64, n_head=1, num_layers=3, drop=0.1,
                 hidden_dim=64, num_mic_ignored=0, single_channel=True, **kwargs):
        super().__init__()
        self.n_fft, self.hop, self.win_len = n_fft, hop, win_len
        self.num_mic, self.patch_size = num_mic, patch_size
        self.single_channel = single_channel
        self.n_mels = n_mels
        self.register_buffer("window", torch.hann_window(win_len))
        self.mel_fb = nn.Parameter(SingleChannelKWS._mel_filterbank(sr, n_fft, n_mels),
                                   requires_grad=False)
        self.proj = nn.Conv2d(1 if single_channel else num_mic, d_model,
                              kernel_size=(n_mels, patch_size),
                              stride=(n_mels, patch_size))
        n_patch = None
        self.cls = nn.Parameter(torch.zeros(1, 1, d_model))
        # 可学习位置编码（KWT 必需；原先用全零导致模型学不动，loss 卡在 ln2）
        self.pos_emb = nn.Parameter(torch.randn(1, 256, d_model) * 0.02)
        self.pos_drop = nn.Dropout(drop)
        enc = nn.TransformerEncoderLayer(d_model=d_model, nhead=n_head,
                                         dim_feedforward=4 * d_model, dropout=drop,
                                         batch_first=True, activation="gelu")
        self.encoder = nn.TransformerEncoder(enc, num_layers=num_layers)
        self.head = nn.Linear(d_model, 1)

    def forward(self, x):
        if x.dim() == 2:                       # [M,T] 单样本 -> 加 batch 维
            x = x.unsqueeze(0)
        B, M, T = x.shape
        stft = _stft(x.reshape(B * M, T), self.n_fft, self.hop, self.win_len, self.window)
        mag = stft.abs().reshape(B, M, stft.shape[-2], stft.shape[-1])
        mel = torch.matmul(self.mel_fb.to(mag.dtype), mag)        # [B,M,Mels,T]
        if getattr(self, "single_channel", True):
            mel = mel[:, 0:1]                                     # 输入设置与原文一致：KWT 原论文为单通道；主体结构为重实现。
        h = self.proj(mel)                                        # [B,D,T']
        h = h.flatten(2).transpose(1, 2)                          # [B,n_patch,D]
        cls = self.cls.expand(h.shape[0], -1, -1)
        h = torch.cat([cls, h], dim=1)
        n = h.shape[1]
        if n <= self.pos_emb.shape[1]:
            pe = self.pos_emb[:, :n]
        else:   # 语句较长时对位置编码做线性插值
            pe = F.interpolate(self.pos_emb.transpose(1, 2), size=n,
                               mode="linear", align_corners=False).transpose(1, 2)
        h = self.pos_drop(h + pe)
        h = self.encoder(h)
        return {"s_q": self.head(h[:, 0]), "presence_logit": None}
