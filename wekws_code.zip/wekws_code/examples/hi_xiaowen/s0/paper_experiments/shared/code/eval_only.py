# -*- coding: utf-8 -*-
"""Re-evaluate an existing baseline checkpoint on a selected split."""
import argparse, json, os, sys
import numpy as np, torch
from torch.utils.data import DataLoader

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, '../../..'))
sys.path.insert(0, REPO)
from paper_experiments.shared.code.train_duibi import (  # noqa: E402
    PackedClipDataset, SpatialClipDataset, collate, evaluate)
from paper_experiments.shared.code.models import ModelFactory  # noqa: E402


def build_model(a):
    m = a['model']
    kwargs = dict(num_layers=a['num_layers'], hidden_dim=a['hidden_dim'],
                  pool_type=a['pool_type'], encoder_type=a['encoder_type'],
                  causal=a['causal'], norm_type=a['norm_type'])
    if m == 'bc-resnet':
        kwargs = dict(scale=a.get('scale', 1))
    if m == 'kwt':
        kwargs = dict(num_layers=a['num_layers'], single_channel=True)
    if m == 'concat-mc':
        kwargs.update(num_mic=a['num_mic'])
    if m == 'fixed-beam':
        kwargs.update(num_mic=a['num_mic'], mic_spacing=a['mic_spacing'])
    if m == 'spatial-prior':
        kwargs.update(num_mic=a['num_mic'], encoder_type='auto', causal=True,
                      norm_type='running', num_doa_class=3)
    if m == 'tcsn':
        kwargs = dict(num_mic=a['num_mic'], num_layers=a['num_layers'],
                      hidden_dim=a['hidden_dim'], pool_type=a['pool_type'])
    return ModelFactory.create(m, **kwargs)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ckpt', required=True)
    ap.add_argument('--test_data', required=True)
    ap.add_argument('--test_varcol', required=True)
    ap.add_argument('--out_dir', required=True)
    ap.add_argument('--out_tag', default='test')
    ap.add_argument('--gpu', default='0')
    ap.add_argument('--batch_size', type=int, default=32)
    ap.add_argument('--num_workers', type=int, default=8)
    args = ap.parse_args()

    dev = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    ck = torch.load(args.ckpt, map_location='cpu')
    a = ck['args']
    model = build_model(a).to(dev)
    ds_cls = PackedClipDataset if os.environ.get('PACKED_DATA_DIR') else SpatialClipDataset
    ds = ds_cls(args.test_data, args.test_varcol, a['num_mic'],
                a.get('max_sec', 3.0),
                need_doa_prior=(a['model'] == 'spatial-prior'))
    if a['model'] == 'spatial-prior':
        with torch.no_grad():
            b0 = collate([ds[0]])
            model(b0['wave'].to(dev), b0['doa_prior'].to(dev))
    model.load_state_dict(ck['model'])
    model.eval()
    dl = DataLoader(ds, batch_size=args.batch_size, shuffle=False,
                    num_workers=args.num_workers, collate_fn=collate)
    res = evaluate(model, dl, dev, doa_method=a.get('doa_method'))
    arr = res.pop('_arrays', None)
    os.makedirs(args.out_dir, exist_ok=True)
    json.dump({'model': a['model'], 'args_test': vars(args), 'test': res},
              open(os.path.join(args.out_dir, f'results_{args.out_tag}.json'), 'w'), indent=2)
    if arr is not None:
        np.savez(os.path.join(args.out_dir, f'test_predictions_{args.out_tag}.npz'), **arr)
    print(f'[{a["model"]}/{args.out_tag}] AUC={res["detection"]["auc"]:.4f} '
          f'FRR@1h={res["frr_at_far1h"]["frr"]:.4f}', flush=True)


if __name__ == '__main__':
    main()
