# Copyright (c) 2026
# -*- coding: utf-8 -*-
"""对比实验统一训练/评测脚本。

用法示例
--------
# 单通道下界基线
python code_duibi/train_duibi.py --model mono --model_dir exp/duibi/mono

# 朴素多通道拼接基线
python code_duibi/train_duibi.py --model concat-mc --model_dir exp/duibi/concat_mc

# 固定波束前端 + KWS（前端与唤醒解耦）
python code_duibi/train_duibi.py --model fixed-beam --model_dir exp/duibi/fixed_beam

# 级联（单通道KWS + 经典GCC-PHAT定位），与 mono 共用权重
python code_duibi/train_duibi.py --model mono --doa_method gcc-phat \
    --model_dir exp/duibi/cascade_gcc

结果写入 ``<model_dir>/results.json``，供 make_tables.py 汇总成 LaTeX 表格。
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn
import torchaudio
from torch.utils.data import DataLoader, Dataset

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")))

from paper_experiments.shared.code.common import (detection_metrics, det_curve, doa_metrics,  # noqa: E402
                               frr_at_far, read_spatial_list, read_varcol_truth,
                               set_seed, wav_duration_sec)
from paper_experiments.shared.code.doa_classical import estimate_doa_class  # noqa: E402
from paper_experiments.shared.code.models import ModelFactory  # noqa: E402


class SpatialClipDataset(Dataset):
    """定长多通道片段数据集：波形补齐/截断到固定长度，返回真实时长用于 FAR 换算。"""

    def __init__(self, data_list, varcol_list, num_mic=2, max_sec=3.0, sr=16000,
                 need_doa_prior=False, doa_method="gcc-phat"):
        self.items = read_spatial_list(data_list)
        self.truth = read_varcol_truth(varcol_list)
        self.num_mic, self.sr = num_mic, sr
        self.max_len = int(max_sec * sr)
        self.need_doa_prior, self.doa_method = need_doa_prior, doa_method

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        wav_path, nm, _ = self.items[idx]
        label, wake_angle = self.truth[os.path.abspath(wav_path)]
        wav, sr = torchaudio.load(wav_path)
        if sr != self.sr:
            wav = torchaudio.functional.resample(wav, sr, self.sr)
        wav = wav[:self.num_mic]
        if wav.shape[0] < self.num_mic:                      # 通道不足则复制补齐
            wav = torch.cat([wav, wav[-1:].repeat(self.num_mic - wav.shape[0], 1)], dim=0)
        real_sec = wav.shape[-1] / self.sr
        if wav.shape[-1] > self.max_len:
            wav = wav[:, :self.max_len]
        elif wav.shape[-1] < self.max_len:
            wav = torch.nn.functional.pad(wav, (0, self.max_len - wav.shape[-1]))
        pri = -1
        if self.need_doa_prior:
            try:
                pri = int(estimate_doa_class(wav.numpy(), method=self.doa_method))
            except Exception:
                pri = 0
        return {"wave": wav, "label": torch.tensor(label, dtype=torch.float32),
                "wake_angle": torch.tensor(wake_angle, dtype=torch.long),
                "duration": torch.tensor(real_sec, dtype=torch.float32),
                "doa_prior": torch.tensor(pri, dtype=torch.long),
                "path": wav_path}


class PackedClipDataset(Dataset):
    """Same item contract as SpatialClipDataset but reads mmap-packed int16 waves.

    Enabled transparently when the PACKED_DATA_DIR environment variable is set,
    so the baselines can be (re)trained after the raw train wavs are removed.
    """

    def __init__(self, data_list, varcol_list, num_mic=2, max_sec=3.0, sr=16000,
                 need_doa_prior=False, doa_method="gcc-phat", packed_dir=None,
                 split=None):
        packed_dir = packed_dir or os.environ.get("PACKED_DATA_DIR", "data_packed")
        base = os.path.basename(str(data_list or ""))
        split = split or ("train" if "train" in base else
                          "eval" if "eval" in base else "test")
        self.dir, self.split = packed_dir, split
        with open(os.path.join(packed_dir, f"{split}_meta.json"), encoding="utf-8") as f:
            self.meta = json.load(f)
        self.flat = np.load(os.path.join(packed_dir, f"{split}_wav_i16.npy"),
                            mmap_mode="r")
        self.offsets = np.load(os.path.join(packed_dir, f"{split}_offsets.npy"))
        self.native_mic = int(self.meta["num_mic"])
        self.num_mic = max(1, min(int(num_mic), self.native_mic))
        self.sr = sr
        self.max_len = int(max_sec * sr)
        self.need_doa_prior, self.doa_method = need_doa_prior, doa_method
        self.indices = list(range(int(self.meta["n"])))

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, idx):
        idx = self.indices[idx]
        s, e = int(self.offsets[idx]), int(self.offsets[idx + 1])
        T = (e - s) // self.native_mic
        arr = np.asarray(self.flat[s:s + T * self.native_mic], dtype=np.int16)
        wav = torch.from_numpy(arr.reshape(T, self.native_mic).T.copy()).float() / 32767.0
        wav = wav[:self.num_mic]
        real_sec = float(self.meta["durations"][idx])
        if wav.shape[-1] > self.max_len:
            wav = wav[:, :self.max_len]
        elif wav.shape[-1] < self.max_len:
            wav = torch.nn.functional.pad(wav, (0, self.max_len - wav.shape[-1]))
        pri = -1
        if self.need_doa_prior:
            try:
                pri = int(estimate_doa_class(wav.numpy(), method=self.doa_method))
            except Exception:
                pri = 0
        return {"wave": wav,
                "label": torch.tensor(float(self.meta["labels"][idx]), dtype=torch.float32),
                "wake_angle": torch.tensor(int(self.meta["wake_angle"][idx]), dtype=torch.long),
                "duration": torch.tensor(real_sec, dtype=torch.float32),
                "doa_prior": torch.tensor(pri, dtype=torch.long),
                "path": f"{self.split}[{idx}]"}


def collate(batch):
    return {
        "wave": torch.stack([b["wave"] for b in batch]),
        "label": torch.stack([b["label"] for b in batch]),
        "wake_angle": torch.stack([b["wake_angle"] for b in batch]),
        "duration": torch.stack([b["duration"] for b in batch]),
        "doa_prior": torch.stack([b["doa_prior"] for b in batch]),
        "path": [b["path"] for b in batch],
    }


def _forward(model, batch, device):
    """统一前向：声明 uses_doa_prior 的模型额外接收 DOA 先验。"""
    x = batch["wave"].to(device)
    if getattr(model, "uses_doa_prior", False):
        return model(x, batch["doa_prior"].to(device))
    return model(x)


@torch.no_grad()
def evaluate(model, loader, device, doa_method=None):
    model.eval()
    scores, labels, durs, pred_doa, gt_doa, paths = [], [], [], [], [], []
    for batch in loader:
        out = _forward(model, batch, device)
        s = out["s_q"]
        if s.shape[-1] > 1:
            # 多路模型：检测分 = 各路的 sigmoid 最大值；方位 = argmax
            prob = torch.sigmoid(s.float())
            scores.append(prob.max(dim=-1).values.cpu().numpy())
            pred_doa.append(prob.argmax(dim=-1).cpu().numpy())
        else:
            scores.append(torch.sigmoid(s[:, 0].float()).cpu().numpy())
        labels.append(batch["label"].numpy())
        durs.append(batch["duration"].numpy())
        gt_doa.append(batch["wake_angle"].numpy())
        # 经典定位（级联基线）：**每个 batch 都要算**。
        # 原实现写成 `not len(pred_doa)`，导致只在第一个 batch 算了 128 条，
        # 之后 pred_doa 长度与 labels 不匹配 -> 指标其实是无意义的。
        if doa_method:
            pred_doa.append(np.array([estimate_doa_class(w.numpy(), method=doa_method)
                                      for w in batch["wave"]]))
        paths += batch["path"]
    scores = np.concatenate(scores); labels = np.concatenate(labels).astype(int)
    durs = np.concatenate(durs); gt_doa = np.concatenate(gt_doa)
    res = {"detection": detection_metrics(scores, labels, threshold=0.5),
           "frr_at_far1h": frr_at_far(scores, labels, durs, 1.0),
           "det_curve": det_curve(scores, labels, durs)}
    if doa_method or len(pred_doa):
        pred_doa = np.concatenate([np.atleast_1d(x) for x in pred_doa])
        valid = gt_doa >= 0
        det_pos = (labels == 1) & (scores > res["frr_at_far1h"]["threshold"]) & valid
        res["doa"] = doa_metrics(pred_doa[valid], gt_doa[valid], det_mask=det_pos[valid])
        res["doa"]["method"] = doa_method or "argmax_query"
    # 始终保存预测数组（含纯检测基线），便于用修正后的指标离线重算
    res["_arrays"] = {"scores": scores, "labels": labels, "durations": durs,
                      "pred_doa": np.concatenate([np.atleast_1d(x) for x in pred_doa]) if len(pred_doa) else np.zeros(len(labels), int),
                      "gt_doa": gt_doa, "paths": np.array(paths)}
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True,
                    choices=["mono", "concat-mc", "fixed-beam", "fixed-beam-3",
                             "bc-resnet", "kwt", "spatial-prior", "tcsn"])
    ap.add_argument("--model_dir", required=True)
    ap.add_argument("--train_data", default="data/spatial/train_spatial.list")
    ap.add_argument("--train_varcol", default="data/spatial/train_varcol.tmp.list")
    ap.add_argument("--cv_data", default="data/spatial/cv_spatial.list")
    ap.add_argument("--cv_varcol", default="data/spatial/cv_varcol.tmp.list")
    ap.add_argument("--test_data", default="data/spatial/test_spatial.list")
    ap.add_argument("--test_varcol", default="data/spatial/test_varcol.tmp.list")
    ap.add_argument("--epochs", type=int, default=60)
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--weight_decay", type=float, default=1e-4)
    ap.add_argument("--num_mic", type=int, default=2)
    ap.add_argument("--mic_spacing", type=float, default=0.033)
    # ==== 共享主干（共有模型）：默认与主模型完全一致 ====
    # 主模型 config(train_dynamic_query_*.yaml) 用 fsmn_dim / fsmn_num_layers /
    # pool_type / causal / norm_type / encoder_type；这里默认值与之对齐，
    # 保证"基线 vs 本文"只在输入表示/空间机制上不同，主干结构完全相同。
    ap.add_argument("--hidden_dim", type=int, default=128,
                    help="共享主干宽度；必须等于主模型 fsmn_dim")
    ap.add_argument("--num_layers", type=int, default=8,
                    help="共享主干层数；必须等于主模型 fsmn_num_layers")
    ap.add_argument("--pool_type", default="mean_max")
    ap.add_argument("--encoder_type", default="cnn", choices=["cnn", "fsmn", "auto"],
                    help="共享主干类型；主模型默认 cnn(自实现编码器)")
    ap.add_argument("--causal", action="store_true", help="共享主干是否因果(流式)")
    ap.add_argument("--norm_type", default="auto")
    ap.add_argument("--max_sec", type=float, default=3.0)
    ap.add_argument("--gpus", default="0")
    ap.add_argument("--num_workers", type=int, default=8)
    ap.add_argument("--seed", type=int, default=666)
    ap.add_argument("--eval_interval", type=int, default=3,
                    help="每隔多少轮做一次完整 CV 评测(省时间)")
    ap.add_argument("--amp", action="store_true",
                    help="混合精度；注意: concat-mc/fixed-beam 含复数前端，开启可能报错")
    ap.add_argument("--loss", default=None, choices=[None, "qce"],
                    help="qce: 用 Q+1 类交叉熵(多输出模型, 如 fixed-beam-3)")
    ap.add_argument("--doa_method", default=None, choices=[None, "gcc-phat", "srp-phat"],
                    help="给定后额外评测级联定位(检测用本模型, 方位用经典方法)")
    ap.add_argument("--limit", type=int, default=0, help=">0 时只用前N条(调试)")
    ap.add_argument("--select_metric", default="frr", choices=["frr", "auc"],
                    help="best_cv 的验证集判据：frr(默认) 或 auc")
    args = ap.parse_args()

    os.makedirs(args.model_dir, exist_ok=True)
    set_seed(args.seed)
    device = torch.device(f"cuda:{args.gpus.split(',')[0]}" if torch.cuda.is_available() else "cpu")

    _need_prior = (args.model == "spatial-prior")

    _DS = PackedClipDataset if os.environ.get("PACKED_DATA_DIR") else SpatialClipDataset

    def build(list_path, varcol):
        ds = _DS(list_path, varcol, args.num_mic, args.max_sec,
                 need_doa_prior=_need_prior)
        if args.limit:
            # 列表按类别聚集，调试子集必须先打乱，否则只会取到单一类别
            import random as _random
            if hasattr(ds, "indices"):
                _random.Random(args.seed).shuffle(ds.indices)
                ds.indices = ds.indices[:args.limit]
            else:
                _random.Random(args.seed).shuffle(ds.items)
                ds.items = ds.items[:args.limit]
        return DataLoader(ds, batch_size=args.batch_size, shuffle=True,
                          num_workers=args.num_workers, collate_fn=collate, drop_last=False)

    train_loader = build(args.train_data, args.train_varcol)
    cv_loader = build(args.cv_data, args.cv_varcol)
    test_loader = build(args.test_data, args.test_varcol)

    _bb = dict(num_layers=args.num_layers, hidden_dim=args.hidden_dim,
               pool_type=args.pool_type, encoder_type=args.encoder_type,
               causal=args.causal, norm_type=args.norm_type)
    kwargs = dict(_bb)
    # BC-ResNet / KWT 是**专用架构基线**（各自论文的骨干），不属于"共有模型"，
    # 因此只传它们支持的参数，不做主干统一。
    if args.model == "bc-resnet":
        kwargs = dict(scale=1)
    if args.model == "kwt":
        kwargs = dict(num_layers=args.num_layers, single_channel=True)
    if args.model == "concat-mc":
        kwargs.update(num_mic=args.num_mic)
    if args.model == "fixed-beam":
        kwargs.update(num_mic=args.num_mic, mic_spacing=args.mic_spacing)
    if args.model == "spatial-prior":
        kwargs.update(num_mic=args.num_mic, encoder_type="auto", causal=True,
                      norm_type="running", num_doa_class=3)
    if args.model == "tcsn":
        kwargs = dict(num_mic=args.num_mic, num_layers=args.num_layers,
                      hidden_dim=args.hidden_dim, pool_type=args.pool_type)
    model = ModelFactory.create(args.model, **kwargs).to(device)

    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True
    n_params = sum(p.numel() for p in model.parameters())
    use_amp = bool(args.amp) and device.type == "cuda"
    scaler = torch.cuda.amp.GradScaler(enabled=use_amp)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs)
    if args.loss == "qce":
        from wekws.model.spatial_dynamic_query import SetMatchingLoss
        crit = SetMatchingLoss(lambda_kws=1.0, lambda_presence=0.0)
    else:
        crit = nn.BCEWithLogitsLoss()

    log_path = os.path.join(args.model_dir, "train.log")
    best = {"frr": 1e9, "auc": -1.0, "epoch": -1}
    print(f"[{args.model}] params={n_params/1e3:.1f}K  device={device}", flush=True)
    for ep in range(args.epochs):
        model.train()
        t0, tot, n = time.time(), 0.0, 0
        for batch in train_loader:
            wave = batch["wave"].to(device, non_blocking=True)
            y = batch["label"].to(device).unsqueeze(-1)
            with torch.cuda.amp.autocast(enabled=use_amp):
                out = (model(wave, batch["doa_prior"].to(device))
                       if getattr(model, "uses_doa_prior", False) else model(wave))
                s = out["s_q"]
                if args.loss == "qce":
                    loss, _ = crit(pred_s=s, gt_doa=batch["wake_angle"].to(device),
                                   gt_valid_mask=torch.zeros_like(s, dtype=torch.bool),
                                   kws_label=batch["label"].to(device).long(),
                                   wake_angle_gt=batch["wake_angle"].to(device),
                                   pred_presence=None)
                else:
                    loss = crit(s[:, :1], y)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(opt)
            scaler.update()
            tot += float(loss.item()) * len(wave); n += len(wave)
        sched.step()
        do_eval = (ep % max(1, args.eval_interval) == 0) or (ep == args.epochs - 1)
        if do_eval:
            cv = evaluate(model, cv_loader, device, doa_method=args.doa_method)
        else:
            cv = {"detection": {"auc": float("nan"), "fpr": float("nan")},
                  "frr_at_far1h": {"frr": float("nan")}, "doa": None}
        msg = (f"epoch {ep:3d}  loss={tot/max(n,1):.4f}  "
               f"cv_auc={cv['detection']['auc']:.4f}  cv_FRR@1/h={cv['frr_at_far1h']['frr']:.4f}  "
               f"cv_FPR@0.5={cv['detection']['fpr']:.4f}  ({time.time()-t0:.1f}s)")
        if cv.get("doa"):
            msg += f"  doa_acc={cv['doa']['doa_acc']:.4f}"
        print(msg, flush=True)
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(msg + "\n")
        torch.save({"model": model.state_dict(), "args": vars(args), "epoch": ep},
                   os.path.join(args.model_dir, "last.pt"))
        if do_eval:
            cur_frr = cv["frr_at_far1h"]["frr"]
            cur_auc = cv["detection"]["auc"]
            improved = (cur_auc > best["auc"]) if args.select_metric == "auc" else (cur_frr < best["frr"])
            if improved:
                best = {"frr": cur_frr, "auc": cur_auc, "epoch": ep}
                torch.save({"model": model.state_dict(), "args": vars(args), "epoch": ep},
                           os.path.join(args.model_dir, "best_cv.pt"))

    # 若 CV 指标为 NaN（例如调试时子集只含单一类别）则回退到最后一轮
    if best["epoch"] < 0:
        best = {"frr": float("nan"), "auc": float("nan"), "epoch": args.epochs - 1}
        torch.save({"model": model.state_dict(), "args": vars(args),
                    "epoch": args.epochs - 1},
                   os.path.join(args.model_dir, "best_cv.pt"))
        print("[warn] CV metric unavailable (single-class subset?); "
              "falling back to last checkpoint", flush=True)
    ckpt = torch.load(os.path.join(args.model_dir, "best_cv.pt"), map_location=device)
    model.load_state_dict(ckpt["model"])
    test = evaluate(model, test_loader, device, doa_method=args.doa_method)
    arrays = test.pop("_arrays", None)
    result = {"model": args.model, "params": int(n_params), "best_epoch": best["epoch"],
              "best_cv_frr": best["frr"], "best_cv_auc": best["auc"],
              "select_metric": args.select_metric, "test": test, "args": vars(args)}
    with open(os.path.join(args.model_dir, "results.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    if arrays is not None:
        np.savez(os.path.join(args.model_dir, "test_predictions.npz"), **arrays)
    print(f"[done] test AUC={test['detection']['auc']:.4f} "
          f"FRR@1/h={test['frr_at_far1h']['frr']:.4f} "
          f"FPR@0.5={test['detection']['fpr']:.4f}", flush=True)


if __name__ == "__main__":
    main()
