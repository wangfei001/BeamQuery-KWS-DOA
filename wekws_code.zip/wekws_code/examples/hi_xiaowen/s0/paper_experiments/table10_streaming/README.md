# table10_streaming — 主模型严格流式评测

`streaming_parallel.py`：严格逐帧因果解码（100 ms chunk，句末 flush），在完整测试集上
运行，输出 `main_model/experiment/streaming_results.json`。
`diagnose_streaming.py`、`compare_offline_streaming.py`、`check_streaming_flush.py`：
离线与流式一致性诊断。由 `main_model/run_streaming.py` 封装调用。
