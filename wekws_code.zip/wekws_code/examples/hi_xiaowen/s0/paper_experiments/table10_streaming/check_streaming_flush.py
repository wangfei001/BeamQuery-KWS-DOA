#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Check end-of-utterance padding and frame-count equivalence.

This deliberately uses synthetic multi-channel waveforms so the comparison is
independent of the corpus.  It verifies that the vectorised causal reference
and the strict stateful decoder return the same number of STFT frames and the
same frame-wise outputs for several signal lengths and chunk sizes.
"""
import argparse
import os
import sys

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "../../.."))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "paper_experiments/shared/code"))
os.environ.setdefault("USE_BATCHED_FORWARD", "1")

from diagnose_streaming import build_model, run_decoder  # noqa: E402
from paper_experiments.shared.code.streaming_model import StreamingBeamKWS  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--config", required=True)
    ap.add_argument("--lengths", type=int, nargs="+",
                    default=[8000, 16000, 16321, 44000, 44001])
    ap.add_argument("--chunk_ms", type=float, nargs="+", default=[100.0, 200.0])
    args = ap.parse_args()

    torch.manual_seed(0)
    model = build_model(args.checkpoint, args.config)
    stream = StreamingBeamKWS(model).eval()
    print("length chunk_ms vector_frames decoder_frames max_abs_diff")
    worst = 0.0
    for length in args.lengths:
        wave = torch.randn(2, length) * 0.01
        sv, wv = stream.forward(wave)
        for chunk_ms in args.chunk_ms:
            sd, wd = run_decoder(stream, wave, chunk_ms)
            if wv is None or wd is None:
                diff = float("nan")
            else:
                n = min(wv.shape[0], wd.shape[0])
                diff = float((wv[:n] - wd[:n]).abs().max()) if n else float("nan")
            print(f"{length} {chunk_ms:g} {sv.shape[0]} {sd.shape[0]} {diff:.6g}")
            worst = max(worst, diff if diff == diff else 0.0)
    print(f"worst_abs_diff={worst:.6g}")


if __name__ == "__main__":
    main()
