#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Diagnose streaming/non-streaming equivalence sample by sample.

This script intentionally keeps the production streaming decoder untouched.
It compares three computations on the same waveform:
  1. offline batched forward (used for the paper's non-streaming result);
  2. the vectorised causal ``StreamingBeamKWS.forward`` reference;
  3. the strict per-frame ``StreamingDecoder``.

If (2) and (3) disagree before the final unflushed frames, the bug is in the
decoder rather than in the offline evaluation protocol.
"""
import argparse
import os
import sys

import numpy as np
import torch
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "../../.."))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "paper_experiments/shared/code"))
os.environ.setdefault("USE_BATCHED_FORWARD", "1")

from wekws.dataset.spatial_kws_dataset import SpatialKwsDataset, spatial_collate_fn  # noqa: E402
from torch.utils.data import DataLoader  # noqa: E402
from wekws.model.spatial_dynamic_query import SpatialDynamicQueryModel  # noqa: E402
from paper_experiments.shared.code.common import detection_metrics, doa_metrics, frr_at_far  # noqa: E402
from paper_experiments.shared.code.streaming_model import StreamingBeamKWS, StreamingDecoder  # noqa: E402


def build_model(ckpt, cfg_path):
    cfg = yaml.safe_load(open(cfg_path, encoding="utf-8"))
    model = SpatialDynamicQueryModel(
        fsmn_num_layers=cfg["fsmn_num_layers"], fsmn_dim=cfg["fsmn_dim"],
        num_query=cfg["num_query"], doa_num_class=cfg["doa_num_class"],
        feat_freq_dim=cfg["feat_freq_dim"], use_ipd=cfg.get("use_ipd", True),
        use_pair_ipd=cfg.get("use_pair_ipd", True), num_mic=cfg["num_mic"],
        pool_type=cfg.get("pool_type", "mean_max"),
        pair_feat_mode=cfg.get("pair_feat_mode", "tdoa"),
        mic_spacing=cfg.get("mic_spacing", 0.033), sr=cfg.get("sr", 16000),
        use_query_embed=cfg.get("use_query_embed", True),
        use_presence_head=cfg.get("use_presence_head", True),
        use_wake_head=cfg.get("use_wake_head", True),
        wake_detach=cfg.get("wake_detach", False),
        query_mode=cfg.get("query_mode", "beam"),
        beam_step_deg=cfg.get("beam_step_deg", 15),
        causal=cfg.get("causal", False), norm_type=cfg.get("norm_type", "auto"),
        encoder_type=cfg.get("encoder_type", "auto"),
        encoder_kwargs=cfg.get("encoder_kwargs", None),
        mel_compress=cfg.get("mel_compress", 0),
        mel_keep_coh=cfg.get("mel_keep_coh", False))
    state = torch.load(ckpt, map_location="cpu", weights_only=False)
    model.load_state_dict(state["model"] if "model" in state else state)
    return model.eval()


@torch.no_grad()
def run_decoder(stream, wave, chunk_ms=100.0):
    chunk = int(chunk_ms / 1000.0 * stream.sr)
    dec = StreamingDecoder(stream)
    ss, ww = [], []
    for i in range(0, wave.shape[-1], chunk):
        s, w = dec.push(wave[:, i:i + chunk])
        if s.numel():
            ss.append(s)
            if w is not None:
                ww.append(w)
    # Strict streaming systems need an explicit end-of-utterance flush to
    # consume the final right-reflect-padded STFT frames.
    s, w = dec.flush()
    if s.numel():
        ss.append(s)
        if w is not None:
            ww.append(w)
    s = torch.cat(ss, 0) if ss else torch.zeros(0, stream.num_query)
    w = torch.cat(ww, 0) if ww else None
    return s, w


def diff(a, b, name):
    if a is None or b is None:
        print(f"  {name}: unavailable")
        return
    n = min(a.shape[0], b.shape[0])
    if n == 0:
        print(f"  {name}: empty")
        return
    d = (a[:n].float() - b[:n].float()).abs()
    print(f"  {name}: compared={n}/{a.shape[0]}/{b.shape[0]} "
          f"max={float(d.max()):.6g} mean={float(d.mean()):.6g}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--config", required=True)
    ap.add_argument("--test_data", required=True)
    ap.add_argument("--test_varcol", required=True)
    ap.add_argument("--limit", type=int, default=10)
    ap.add_argument("--chunk_ms", type=float, default=100.0)
    args = ap.parse_args()

    model = build_model(args.checkpoint, args.config)
    stream = StreamingBeamKWS(model)
    stream.eval()

    ds = SpatialKwsDataset(args.test_data, args.test_varcol, max_gt=3)
    pos = [it for it in ds.items if it[3] == 1]
    neg = [it for it in ds.items if it[3] == 0]
    n = max(1, args.limit)
    ds.items = pos[:n // 2 + n % 2] + neg[:n // 2]

    y, dur, ang = [], [], []
    off_logits, off_s, dec_logits, dec_s, dec_last = [], [], [], [], []
    frame_diffs_w, frame_diffs_s = [], []
    with torch.no_grad():
        for idx, (wave_list, _, _, _, yb, ab) in enumerate(DataLoader(
                ds, batch_size=1, shuffle=False, collate_fn=spatial_collate_fn)):
            wave = wave_list[0]
            off = model([wave])
            sv, wv = stream.forward(wave)
            sd, wd = run_decoder(stream, wave, args.chunk_ms)
            print(f"[sample {idx}] T={wave.shape[-1]} frames vector={sv.shape[0]} dec={sd.shape[0]}")
            diff(sv, sd, "class per-frame")
            diff(wv, wd, "wake per-frame")
            if sv.shape[0] and sd.shape[0]:
                m = min(sv.shape[0], sd.shape[0])
                diff(sv[:m].max(0).values, sd[:m].max(0).values, "class aggregate (common frames)")
                if wv is not None and wd is not None:
                    diff(wv[:m].max(0).values, wd[:m].max(0).values, "wake aggregate (common frames)")
            off_s.append(off["s_q"][0].detach().cpu())
            off_logits.append(off["wake_logit"][0].detach().cpu())
            dec_s.append(sd.max(0).values.detach().cpu() if sd.numel() else torch.zeros(stream.num_query))
            dec_logits.append(wd.max().detach().cpu() if wd is not None and wd.numel() else torch.tensor(float("nan")))
            dec_last.append(sd[-1].detach().cpu() if sd.numel() else torch.zeros(stream.num_query))
            y.append(int(yb[0]))
            dur.append(wave.shape[-1] / stream.sr)
            ang.append(int(ab[0]))
            if wv is not None and wd is not None and wv.shape[0] and wd.shape[0]:
                m = min(wv.shape[0], wd.shape[0])
                frame_diffs_w.append(float((wv[:m] - wd[:m]).abs().max()))
            if sv.shape[0] and sd.shape[0]:
                m = min(sv.shape[0], sd.shape[0])
                frame_diffs_s.append(float((sv[:m] - sd[:m]).abs().max()))

    y = np.asarray(y); dur = np.asarray(dur); ang = np.asarray(ang)
    print("\nMetric comparison on the diagnostic subset:")
    for name, logits, s in [
            ("offline", torch.stack(off_logits), torch.stack(off_s)),
            ("decoder/common-max", torch.tensor(dec_logits), torch.stack(dec_s))]:
        prob = torch.sigmoid(logits).numpy()
        far = frr_at_far(prob, y, dur, 1.0)
        det = detection_metrics(prob, y, threshold=0.5)
        pred = s.numpy().argmax(1)
        valid = ang >= 0
        pos = y == 1
        dm_all = doa_metrics(pred[valid], ang[valid])
        dm_far = doa_metrics(pred[valid], ang[valid], det_mask=(pos & valid & (prob > far["threshold"]))[valid])
        joint = float(np.mean(pos & valid & (prob > far["threshold"]) & (pred == ang)))
        print(f"{name}: AUC={det['auc']:.4f} FPR@.5={det['fpr']:.4f} "
              f"FRR@1h={far['frr']:.4f} thr={far['threshold']:.5f} "
              f"DOA_all={dm_all['doa_acc']:.4f}/{dm_all['mean_deg_err']:.3f} "
              f"DOA_far={dm_far['doa_acc']:.4f}/{dm_far['mean_deg_err']:.3f} joint={joint:.4f}")
    if frame_diffs_w:
        print(f"per-frame wake max diff across samples: {max(frame_diffs_w):.6g}")
    if frame_diffs_s:
        print(f"per-frame class max diff across samples: {max(frame_diffs_s):.6g}")


if __name__ == "__main__":
    main()
