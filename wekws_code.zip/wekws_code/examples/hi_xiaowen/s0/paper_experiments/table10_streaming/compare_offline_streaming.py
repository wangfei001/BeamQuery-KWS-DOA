#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Compare non-streaming batched, strict streaming, and the stored NPZ."""
import argparse, os, sys, time
from pathlib import Path
import numpy as np
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'paper_experiments/shared/code'))
os.environ.setdefault('USE_BATCHED_FORWARD', '1')
os.environ.setdefault('KWS_MAX_SEC', '3.0')

from diagnose_streaming import build_model, run_decoder  # noqa: E402
from paper_experiments.shared.code.streaming_model import StreamingDecoder  # noqa: E402
from wekws.dataset.spatial_kws_dataset import SpatialKwsDataset  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--checkpoint', required=True)
    ap.add_argument('--config', required=True)
    ap.add_argument('--test_data', required=True)
    ap.add_argument('--test_varcol', required=True)
    ap.add_argument('--npz', required=True)
    ap.add_argument('--limit', type=int, default=32)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()

    ds = SpatialKwsDataset(args.test_data, args.test_varcol, max_gt=3)
    n = min(args.limit, len(ds.items))
    model = build_model(args.checkpoint, args.config)
    stream = __import__('paper_experiments.shared.code.streaming_model',
                        fromlist=['convert']).convert(model)
    stream.eval()

    z = np.load(args.npz, allow_pickle=True)
    npz = {os.path.basename(str(p)): (float(s), int(pd), int(y))
           for p, s, pd, y in zip(z['paths'], z['scores'], z['pred_doa'], z['labels'])}

    rows = []
    with torch.no_grad():
        for i in range(n):
            item = ds[i]
            wave = item['wave']
            path = os.path.basename(item.get('path', ds.items[i][0]))
            off = model([wave])
            off_w = off.get('wake_logit')
            off_score = float(torch.sigmoid(off_w.float()).max()) if off_w is not None else float(torch.sigmoid(off['s_q'].float()).max())
            off_s = off['s_q'][0].detach().cpu().numpy()
            off_sq_score = float(torch.sigmoid(off['s_q'].float()).max())
            off_pred = int(np.argmax(off_s))
            t0 = time.perf_counter()
            dec = StreamingDecoder(stream)
            ss, ww = [], []
            for j in range(0, wave.shape[-1], 1600):
                s, w = dec.push(wave[:, j:j + 1600])
                if s.numel(): ss.append(s)
                if w is not None and w.numel(): ww.append(w)
            s, w = dec.flush()
            if s.numel(): ss.append(s)
            if w is not None and w.numel(): ww.append(w)
            s = torch.cat(ss, 0)
            w = torch.cat(ww, 0) if ww else None
            st_score = float(torch.sigmoid(w.float()).max()) if w is not None else float(torch.sigmoid(s.float()).max())
            st_last = s[-1].detach().cpu().numpy()
            st_class = s.max(dim=0).values.detach().cpu().numpy()
            st_pred = int(np.argmax(st_class))
            npz_s, npz_pred, npz_y = npz[path]
            rows.append(dict(path=path, label=int(item['kws_label']), angle=int(item['wake_angle_gt']),
                             off_score=off_score, off_sq_score=off_sq_score,
                             st_score=st_score, npz_score=npz_s,
                             off_pred=off_pred, st_last_pred=int(np.argmax(st_last)), st_class_pred=st_pred,
                             npz_pred=npz_pred, max_s_last=float(np.max(np.abs(off_s - st_last))),
                             max_s_class=float(np.max(np.abs(off_s - st_class)))))
            print(i, path, f'off={off_score:.8g} st={st_score:.8g} npz={npz_s:.8g} '
                  f's_last={rows[-1]["max_s_last"]:.3g} s_class={rows[-1]["max_s_class"]:.3g}', flush=True)

    a = np.array([r['off_score'] for r in rows], dtype=float)
    b = np.array([r['st_score'] for r in rows], dtype=float)
    c = np.array([r['npz_score'] for r in rows], dtype=float)
    d = np.array([r['off_sq_score'] for r in rows], dtype=float)
    print('\nSUMMARY')
    print('n', n)
    print('off_st_max_abs', float(np.max(np.abs(a-b))))
    print('off_npz_max_abs', float(np.max(np.abs(a-c))))
    print('st_npz_max_abs', float(np.max(np.abs(b-c))))
    print('corr_off_st', float(np.corrcoef(a,b)[0,1]) if n>1 else float('nan'))
    print('corr_off_npz', float(np.corrcoef(a,c)[0,1]) if n>1 else float('nan'))
    print('off_sq_npz_max_abs', float(np.max(np.abs(d-c))))
    print('corr_off_sq_npz', float(np.corrcoef(d,c)[0,1]) if n>1 else float('nan'))
    print('pred_agree_off_st_class', int(np.mean([r['off_pred']==r['st_class_pred'] for r in rows])*n))
    print('pred_agree_off_npz', int(np.mean([r['off_pred']==r['npz_pred'] for r in rows])*n))
    np.savez(args.out, rows=np.array(rows, dtype=object))


if __name__ == '__main__':
    main()
