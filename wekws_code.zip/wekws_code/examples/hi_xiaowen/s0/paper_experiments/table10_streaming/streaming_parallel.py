#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Parallel strict-streaming evaluation on the full corpus.

Each worker owns a copy of the model and runs the stateful decoder for one
utterance at a time.  This is intentionally a CPU-only evaluator: it measures
the actual frame-by-frame implementation rather than a GPU batched surrogate.
"""
import argparse
import json
import multiprocessing as mp
import os
import sys
import time
from pathlib import Path

import numpy as np

os.environ.setdefault("USE_BATCHED_FORWARD", "1")
os.environ.setdefault("KWS_MAX_SEC", "3.0")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "paper_experiments/shared/code"))

import torch  # noqa: E402
from wekws.dataset.spatial_kws_dataset import SpatialKwsDataset  # noqa: E402
from paper_experiments.shared.code.common import detection_metrics, doa_metrics, frr_at_far  # noqa: E402
from paper_experiments.shared.code.streaming_model import StreamingDecoder  # noqa: E402
from paper_experiments.shared.code.train_duibi import PackedClipDataset  # noqa: E402
from diagnose_streaming import build_model  # noqa: E402


_DS = None
_STREAM = None


def _init_worker(checkpoint, config, test_data, test_varcol):
    global _DS, _STREAM
    torch.set_num_threads(1)
    model = build_model(checkpoint, config)
    _STREAM = __import__(
        "paper_experiments.shared.code.streaming_model",
        fromlist=["convert"],
    ).convert(model)
    packed_dir = os.environ.get("PACKED_DATA_DIR")
    if packed_dir:
        _DS = PackedClipDataset(test_data, test_varcol, num_mic=2,
                                max_sec=3.0, packed_dir=packed_dir)
    else:
        _DS = SpatialKwsDataset(test_data, test_varcol, max_gt=3)


def _process_one(i):
    item = _DS[i]
    wave = item["wave"]
    if "label" in item:
        y = int(item["label"])
        angle = int(item["wake_angle"])
        real_dur = float(item["duration"])
    else:
        y = int(item["kws_label"])
        angle = int(item["wake_angle_gt"])
        real_dur = float(wave.shape[-1] / _STREAM.sr)
    chunk = int(0.1 * _STREAM.sr)
    dec = StreamingDecoder(_STREAM)
    t0 = time.perf_counter()
    ss, ww = [], []
    for j in range(0, wave.shape[-1], chunk):
        s, w = dec.push(wave[:, j:j + chunk])
        if s.numel():
            ss.append(s)
            if w is not None:
                ww.append(w)
    s, w = dec.flush()
    if s.numel():
        ss.append(s)
        if w is not None:
            ww.append(w)
    elapsed = time.perf_counter() - t0
    s = torch.cat(ss, 0) if ss else torch.zeros(0, _STREAM.num_query)
    w = torch.cat(ww, 0) if ww else None
    if w is not None:
        prob = torch.sigmoid(w).max(dim=-1).values
        det_score = float(prob.max())
    else:
        prob = torch.sigmoid(s).max(dim=-1).values
        det_score = float(prob.max())
    best_t = int(prob.argmax()) if prob.numel() else 0
    s_peak = s[best_t].detach().cpu().numpy() if s.numel() else np.zeros(_STREAM.num_query, np.float32)
    s_last = s[-1].detach().cpu().numpy() if s.numel() else np.zeros(_STREAM.num_query, np.float32)
    s_cls = s.max(dim=0).values.detach().cpu().numpy() if s.numel() else np.zeros(_STREAM.num_query, np.float32)
    proc_dur = float(wave.shape[-1] / _STREAM.sr)
    return {
        "index": int(i), "label": y, "angle": angle, "duration": real_dur,
        "score": det_score, "prob": prob.detach().cpu().numpy().astype(np.float32),
        "s_peak": s_peak, "s_last": s_last, "s_cls": s_cls,
        "rtf": float(elapsed / max(proc_dur, 1e-9)),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--config", required=True)
    ap.add_argument("--test_data", required=True)
    ap.add_argument("--test_varcol", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--workers", type=int, default=32)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--target_far", type=float, default=1.0)
    ap.add_argument("--work_threshold", type=float, default=None)
    args = ap.parse_args()

    ds = SpatialKwsDataset(args.test_data, args.test_varcol, max_gt=3)
    indices = list(range(len(ds)))
    if args.limit:
        indices = indices[:args.limit]
    # Keep the dataset construction out of the worker initializer: the
    # metadata is small and fork shares it through copy-on-write.
    ctx = mp.get_context("fork")
    with ctx.Pool(processes=args.workers, initializer=_init_worker,
                  initargs=(args.checkpoint, args.config, args.test_data,
                            args.test_varcol)) as pool:
        records = []
        for k, rec in enumerate(pool.imap_unordered(_process_one, indices, chunksize=4), 1):
            records.append(rec)
            if k % 500 == 0:
                print(f"processed {k}/{len(indices)}", flush=True)
    records.sort(key=lambda x: x["index"])

    y = np.asarray([r["label"] for r in records], dtype=int)
    angles = np.asarray([r["angle"] for r in records], dtype=int)
    durs = np.asarray([r["duration"] for r in records], dtype=np.float64)
    scores = np.asarray([r["score"] for r in records], dtype=np.float64)
    valid = angles >= 0
    all_pos = (y == 1) & valid

    far = frr_at_far(scores, y, durs, args.target_far)
    work_thr = float(args.work_threshold) if args.work_threshold is not None else float(far["threshold"])
    det = detection_metrics(scores, y, threshold=work_thr)
    det_pos = (y == 1) & valid & (scores > work_thr)
    rules = {}
    for tag, key in (("peak_prob_frame", "s_peak"), ("class_max_time", "s_cls"), ("last_frame", "s_last")):
        sc = np.stack([r[key] for r in records], axis=0)
        pred = sc.argmax(axis=1)
        dm_all = doa_metrics(pred[all_pos], angles[all_pos])
        dm_det = doa_metrics(pred[det_pos], angles[det_pos])
        joint = float(np.mean((scores[all_pos] > work_thr) & (pred[all_pos] == angles[all_pos]))) if all_pos.any() else float("nan")
        lat = []
        for r in records:
            hit = np.flatnonzero(r["prob"] > work_thr)
            lat.append(((float(hit[0]) * 160 + 512) / 16000.0 * 1000.0) if hit.size else float("nan"))
        rules[tag] = {
            "wake_auc": float(det["auc"]),
            "wake_recall": float(det["recall"]),
            "fpr": float(det["fpr"]),
            "frr_at_far1h": float(1.0 - det["recall"]),
            "eval_far1h_threshold": float(far["threshold"]),
            "eval_far1h_frr": float(far["frr"]),
            "work_threshold": work_thr,
            "doa_acc": float(dm_det["doa_acc"]),
            "mean_deg_err": float(dm_det["mean_deg_err"]),
            "doa_acc_all": float(dm_all["doa_acc"]),
            "mean_deg_err_all": float(dm_all["mean_deg_err"]),
            "joint_all": joint,
            "n_det_pos": int(det_pos.sum()),
            "n_all_pos": int(all_pos.sum()),
            "latency_ms_mean": float(np.nanmean(lat)) if np.any(np.isfinite(lat)) else None,
        }
    out = {"streaming": {
        "peak_prob_frame": rules["peak_prob_frame"],
        "class_max_time": rules["class_max_time"],
        "last_frame": rules["last_frame"],
        "work_threshold": work_thr,
        "target_far": args.target_far,
        "rtf_mean": float(np.mean([r["rtf"] for r in records])),
        "rtf_p95": float(np.percentile([r["rtf"] for r in records], 95)),
        "latency_ms_mean": rules["last_frame"]["latency_ms_mean"],
        "chunk_ms": 100.0,
        "n_samples": len(records),
        "workers": args.workers,
    }}
    os.makedirs(Path(args.out).parent, exist_ok=True)
    Path(args.out).write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(out, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
