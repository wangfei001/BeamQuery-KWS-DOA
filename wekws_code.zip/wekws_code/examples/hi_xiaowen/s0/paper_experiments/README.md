# 主模型实验代码（paper_experiments）

**主模型代码只放在 `main_model/`**；其余目录是主模型训练/评测所必需的依赖。

| 目录 | 作用 |
|---|---|
| `main_model/` | **主模型**：`model.py`、`batched_forward.py`、`streaming.py`、`train.sh`、`eval.py`、`run_streaming.py`、`config.yaml`、`configs/stage{1,2}.yaml`、`experiment/` |
| `table1_corpus/` | 主模型语料生成配置（`configs/gen_v5.yaml`）、关键词池脚本、数据清单目录 `data_lists/` |
| `table7_localisation/` | 指标计算 `eval_allpos_v7.py`（被 `main_model/eval.py` 调用） |
| `table10_streaming/` | 严格流式评测 `streaming_parallel.py` 与一致性诊断脚本（被 `main_model/run_streaming.py` 调用） |
| `shared/code/` | 主模型训练/评测调用的公共库：`batched_model.py`、`eval_fair_cascade.py`、`eval_allpos_v7.py`、`common.py` 等 |

```bash
bash  paper_experiments/main_model/train.sh
python paper_experiments/main_model/eval.py
python paper_experiments/main_model/run_streaming.py
```

数据清单由 recipe 的 stage 1 / 5 生成，放在
`paper_experiments/table1_corpus/data_lists/`：
`{train,eval,test}_spatial.list` 与 `{train,eval,test}_varcol.tmp.list`。
