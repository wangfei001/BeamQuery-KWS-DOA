# 主模型实验代码（paper_experiments）

本目录按论文表格组织；**主模型代码只放在 `main_model/`**。

| 目录 | 与主模型的关系 |
|---|---|
| `main_model/` | **主模型**：`model.py`、`batched_forward.py`、`streaming.py`、`train.sh`、`eval.py`、`run_streaming.py`、`config.yaml`、`configs/stage{1,2}.yaml`、选中的 checkpoint |
| `table1_corpus/` | 主模型训练/评测用的语料与数据清单（train / eval / test） |
| `table2_systems/` | 主模型的对比系统配置与结果 |
| `table3_angle/` | 主模型的波束网格步长 Δ 扫描 |
| `table4_lambda/` | 主模型的 λ_wake 扫描 |
| `table5_ablation/` | 主模型的组件消融 |
| `table6_detection/` | 主模型的检测指标评测脚本 |
| `table7_localisation/` | 主模型的全正样本定位指标（`eval_allpos_v7.py`） |
| `table8_localisation_detected/` | 主模型检出后定位诊断 |
| `table9_threshold/` | 主模型的唤醒阈值扫描 |
| `table10_streaming/` | 主模型的严格流式评测 |
| `table_builder/` | 主模型数值的表格生成与校验 |
| `shared/` | 主模型训练/评测调用的公共库（指标、数据集、批处理前向等） |
| `24h_plan/` | 主模型各消融/评测的批处理编排与表格生成 |

运行（在 recipe 目录下）：

```bash
export PYTHONPATH=$PWD PACKED_DATA_DIR=$PWD/data_packed_v5_largeval USE_BATCHED_FORWARD=1 KWS_MAX_SEC=3.0
python paper_experiments/24h_plan/run_24h_plan.py     # 主模型消融与评测
python paper_experiments/24h_plan/make_tables.py      # 生成 docs/tables/*.tex
python paper_experiments/table_builder/verify_paper_numbers.py --tables_dir paper_experiments/24h_plan/docs/tables
```
