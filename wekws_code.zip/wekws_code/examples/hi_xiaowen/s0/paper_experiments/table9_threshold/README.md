# table9_threshold — 主模型唤醒阈值影响

`threshold_sweep.py`：在 `main_model/experiment/test_predictions_fair.npz` 上扫描
不同 FAR 目标，输出 `main_model/experiment/threshold_sweep.json`
（各工作点的 FRR、FPR、DOA / MAE / Joint）。
