# -*- coding: utf-8 -*-
"""Consistency + correctness checks for the 24h experiment pipeline.

Two layers:
  * data integrity  : splits exist, counts, no train/val/test overlap, packing.
  * code correctness: every generated config matches the experiment it names,
                      and no two *different* variants collapse to an identical
                      model (the failure mode that silently invalidated an
                      earlier ablation: a flag that the code ignored).
"""
import hashlib
import json
import os
from pathlib import Path

import yaml  # noqa: E402

ROOT = Path('/242602/wekws/examples/hi_xiaowen_duolu/s0_deepseek_3')
P = ROOT / 'paper_experiments/24h_plan'
CFG = P / 'configs'
RES = P / 'results'
D = ROOT / 'paper_experiments/table1_corpus/data_lists'
V = ROOT / 'data_val10k'
PACK = ROOT / 'data_packed_v5_largeval'

errors = []
warnings = []
info = {}
checks = []


def read_varcol(path):
    rows = []
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        p = line.split()
        if p:
            rows.append(p)
    return rows


def cfg_of(path):
    try:
        return yaml.safe_load(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return None


def check(name, ok, detail=''):
    checks.append({'check': name, 'ok': bool(ok), 'detail': detail})
    if not ok:
        errors.append(f'{name}: {detail}')


# --------------------------------------------------------------------------- #
# 1. data integrity
# --------------------------------------------------------------------------- #
for name, path in [('train', D / 'train_varcol.tmp.list'),
                   ('eval10k', V / 'eval_varcol.tmp.list'),
                   ('test', D / 'test_varcol.tmp.list')]:
    if not path.exists():
        errors.append(f'missing {path}')
        continue
    rows = read_varcol(path)
    pos = sum(int(r[1]) == 1 for r in rows)
    neg = sum(int(r[1]) == 0 for r in rows)
    info[name] = {'n': len(rows), 'pos': pos, 'neg': neg}
    if name == 'eval10k' and (len(rows) != 10000 or pos != 5000 or neg != 5000):
        errors.append(f'eval10k counts wrong: {len(rows)}/{pos}/{neg}')

if all(k in info for k in ['train', 'eval10k', 'test']):
    sets = {k: {r[0] for r in read_varcol(path)} for k, path in [
        ('train', D / 'train_varcol.tmp.list'),
        ('eval10k', V / 'eval_varcol.tmp.list'),
        ('test', D / 'test_varcol.tmp.list')]}
    for a, b in [('train', 'eval10k'), ('train', 'test'), ('eval10k', 'test')]:
        inter = len(sets[a] & sets[b])
        info[f'overlap_{a}_{b}'] = inter
        if inter:
            errors.append(f'overlap {a}/{b}: {inter}')

mp = PACK / 'eval_meta.json'
if not mp.exists():
    errors.append(f'missing {mp}')
else:
    m = json.loads(mp.read_text())
    info['packed_eval'] = {'n': m.get('n'), 'num_mic': m.get('num_mic')}
    if m.get('n') != 10000:
        errors.append(f'packed eval n != 10000: {m.get("n")}')

pd_src = (ROOT / 'paper_experiments/shared/code/packed_dataset.py').read_text(encoding='utf-8')
check('packed_dataset has KWS_NUM_MIC_USE', 'KWS_NUM_MIC_USE' in pd_src, 'single-mic support')

# --------------------------------------------------------------------------- #
# 2. config invariants (only for configs that already exist)
# --------------------------------------------------------------------------- #
for step in [6, 8, 12, 15, 20, 30]:
    for s in (1, 2):
        f = CFG / f'angles/step_{step}_s{s}.yaml'
        if not f.exists():
            continue
        c = cfg_of(f) or {}
        check(f'angle step_{step}_s{s} beam_step_deg=={step}',
              c.get('beam_step_deg') == step, f'got {c.get("beam_step_deg")}')
        check(f'angle step_{step}_s{s} num_mic==2', c.get('num_mic') == 2,
              f'got {c.get("num_mic")}')

for lw in [0.0, 0.1, 0.3, 1.0]:
    for s in (1, 2):
        f = CFG / f'lambda/lw{lw:.1f}_s{s}.yaml'
        if not f.exists():
            continue
        c = cfg_of(f) or {}
        got = c.get('lambda_wake')
        check(f'lambda lw{lw:.1f}_s{s} lambda_wake=={lw}',
              got is not None and abs(float(got) - lw) < 1e-9, f'got {got}')

abl = CFG / 'ablation'
if (abl / 'A1_dynamic_s1.yaml').exists():
    c = cfg_of(abl / 'A1_dynamic_s1.yaml') or {}
    check('A1_dynamic query_mode==dynamic', c.get('query_mode') == 'dynamic',
          f'got {c.get("query_mode")}')
if (abl / 'A8_single_mic_s1.yaml').exists():
    c = cfg_of(abl / 'A8_single_mic_s1.yaml') or {}
    check('A8_single_mic num_mic==1', c.get('num_mic') == 1, f'got {c.get("num_mic")}')
if (abl / 'A2_no_presence_s1.yaml').exists():
    c = cfg_of(abl / 'A2_no_presence_s1.yaml') or {}
    check('A2_no_presence disables presence head', c.get('use_presence_head') is False,
          f'got {c.get("use_presence_head")}')
if (abl / 'A4_pool_attn_s1.yaml').exists():
    c = cfg_of(abl / 'A4_pool_attn_s1.yaml') or {}
    check('A4_pool_attn pool_type==attn', c.get('pool_type') == 'attn',
          f'got {c.get("pool_type")}')

# every stage-2 config resumes from a stage-1 checkpoint, so it must count
# epochs relative to the stage (train.py: `relative_epochs: true`). Without it
# max_epoch is an absolute index and the fine-tune length silently shrinks by
# the stage-1 best epoch.
for sub in ('angles', 'lambda', 'ablation'):
    for f in sorted((CFG / sub).glob('*_s2.yaml')):
        c = cfg_of(f) or {}
        check(f'{f.name} relative_epochs=true', c.get('relative_epochs') is True,
              f'got {c.get("relative_epochs")}')

# extra ablations must inherit the angle selected on validation (Table angle)
ang_sum = RES / 'angles/summary.json'
best_step = None
if ang_sum.exists():
    try:
        s = json.loads(ang_sum.read_text())
        if s:
            best_step = int(max(s, key=lambda k: s[k].get('score', 0)).split('_')[1])
            info['best_angle_step'] = best_step
    except Exception:
        pass
if best_step is not None:
    for tag in ['A2_no_presence', 'A4_pool_attn']:
        f = abl / f'{tag}_s2.yaml'
        if f.exists():
            c = cfg_of(f) or {}
            check(f'{tag} uses best angle {best_step}',
                  c.get('beam_step_deg') == best_step, f'got {c.get("beam_step_deg")}')

# --------------------------------------------------------------------------- #
# 3. no-test-leakage guard: selection summaries must not mention test metrics
# --------------------------------------------------------------------------- #
for name in ['angles/summary.json', 'lambda/summary.json', 'ablation/summary.json']:
    f = RES / name
    if not f.exists():
        continue
    txt = f.read_text(encoding='utf-8')
    if 'test' in txt.lower():
        warnings.append(f'{name} mentions "test": selection must be validation-only')

# --------------------------------------------------------------------------- #
# 4. checkpoint distinctness: different variants must not be identical
# --------------------------------------------------------------------------- #
def param_hash(path):
    import torch
    ck = torch.load(path, map_location='cpu')
    sd = ck.get('model', ck) if isinstance(ck, dict) else ck
    h = hashlib.md5()
    for k in sorted(sd):
        v = sd[k]
        if hasattr(v, 'detach'):
            h.update(k.encode())
            h.update(v.detach().float().cpu().numpy().tobytes())
    return h.hexdigest()


variant_ckpts = {}
for tag, rel in [
    ('A1_dynamic', 'ablation/A1_dynamic/stage1/best_cv.pt'),
    ('A8_single_mic', 'ablation/A8_single_mic/stage2/best_cv.pt'),
    ('A2_no_presence', 'ablation/A2_no_presence/stage2/best_cv.pt'),
    ('A4_pool_attn', 'ablation/A4_pool_attn/stage2/best_cv.pt'),
]:
    p = RES / rel
    if p.exists():
        variant_ckpts[tag] = p
if best_step is not None:
    a0 = RES / f'angles/step_{best_step}/stage2/best_cv.pt'
    if a0.exists():
        variant_ckpts[f'A0_step{best_step}'] = a0

hashes = {}
for tag, p in variant_ckpts.items():
    try:
        hashes[tag] = param_hash(p)
    except Exception as e:  # pragma: no cover
        warnings.append(f'could not hash {tag}: {e!r}')
seen = {}
for tag, h in hashes.items():
    if h in seen:
        errors.append(f'identical checkpoints: {seen[h]} == {tag} '
                      '(a variant flag is probably being ignored)')
    seen[h] = tag
info['variant_param_hashes'] = hashes

# --------------------------------------------------------------------------- #
main_dir = ROOT / 'paper_experiments/main_experiment'
if main_dir.exists():
    info['main_experiment'] = sorted(p.name for p in main_dir.iterdir())

out = {'ok': not errors, 'errors': errors, 'warnings': warnings,
       'failed_checks': [c for c in checks if not c['ok']],
       'n_checks': len(checks), 'info': info}
print(json.dumps(out, indent=2, ensure_ascii=False))
raise SystemExit(1 if errors else 0)
