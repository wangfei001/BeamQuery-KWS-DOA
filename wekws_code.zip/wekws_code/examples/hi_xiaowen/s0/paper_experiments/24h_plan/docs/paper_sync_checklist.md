# Paper sync checklist (result-dependent claims)

Sources of truth after the run:
* `data_val10k` -> validation curves, `24h_plan/results/angles/summary.json`
* `paper_experiments/main_experiment/{selection.json,test_metrics.json,threshold_sweep.json}`
* `24h_plan/results/baselines/*/{val,test}/results_*.json` and `*_allpos.json`
* `24h_plan/docs/tables/tab_{angle,lambda,ablation,main,strat,threshold}.tex`

## main_sp.tex (abstract)
| line | claim | replace with |
|---|---|---|
| 61-62 | detection AUC 0.9825 | main `test_metrics.detection.auc` |
| 61-62 | 87.4 % azimuth (all pos), MAE 8.16 | main `all_positives.doa_acc / .mae` |
| 62 | 52.7 % joint at FAR=1/h | main `all_positives.joint` |
| 64 | cascades 57.2 % / 33.24 deg, 47.4 % joint | cascade_gccphat `test_allpos.json` |
| 66-67 | n_src=1 88.5 %/6.97 deg, n_src=2 31.4 %/54.70 deg | cascade stratified_detected |
| 69 | A1 collapses azimuth to 34.5 % | ablation A1 `val_allpos.json` (or test if reported) |

## sections/discussion.tex
| line | claim | replace with |
|---|---|---|
| 28-29 | 57.2 %/33.24 deg GCC; 39.0 %/55.58 deg SRP | cascade test_allpos |
| 34-37 | 0.895 vs 0.894, 0.698, SRP oracle 0.516 | `stratified_detected[n_src=2].oracle/acc` |
| 62 | BC-ResNet 0.9529 with 43K | baselines_retrain/bc_resnet results.json params + val/test auc |

## sections/conclusion.tex
| line | claim | replace with |
|---|---|---|
| 27-30 | 87.4 %/8.16 deg; 57.2 %/33.24 deg; 39.0 %/55.58 deg; 52.7 %/47.4 %/27.7 % | main + both cascades |
| 33-35 | 88.5 %/6.97 deg; 31.4 %/54.70 deg; 91.4 %/5.59 deg | cascade + main stratified_detected |
| 37 | 0.9825 | main test auc |

## sections/experiments.tex
* §3.1.2: beam step `Delta = 12 deg` -> angle selected in `tab_angle`
  (also the "six look directions per class" phrase depends on the step).
* §3.2.1: lambda paragraph numbers -> `tab_lambda`; add one paragraph
  introducing `tab_angle` (beam-step independence) before it.
* §3.2.1: ablation paragraph numbers -> `tab_ablation`; the table now has
  six rows (A0, A1, A8, A9, A2, A4), so the narrative must cover the
  presence-head / pooling variants too.
* §3.2.2: detection table numbers -> `tab_main`; add TCSN row discussion.
* §3.2.2: add one paragraph introducing `tab_threshold` (wake threshold vs
  localisation).
* Streaming section: verify the streaming numbers still match the new model.

## paper_cn/build_cn_docx.py
Mirror every edit above; the Chinese tables are hard-coded rows in
`build_cn_docx.py` (tables 1-6) and must be regenerated from the same JSONs.

## Added since the first pass (already done, keep for the record)

* Table 1 (corpus): validation 2,000 -> 10,000; negative-audio hours corrected to
  the caption's own definition (train 8.40, val 3.82, test 9.93).  Both papers.
* Table 2 (systems): TCSN added as baseline (7); spatial-prior -> (8);
  proposed -> (9).  Bibliography entry `zhu2024tcsn` present.  Both papers.
* Training recipe text: 10 + 10 (20 epochs) -> 5 + 8 (13 epochs); baselines 10.
  Both papers.
* Ablation reference wording: "no-detach reference A0" -> "full model A0"
  (every main-model candidate uses a detached head, lambda=0.3).  Both papers.
* New narrative paragraphs (result-independent): "Beam-grid resolution" before
  the lambda table, "Threshold sensitivity" before the threshold table, plus a
  "Threshold sensitivity" paragraph in 3.1.4.  Both papers.
* Paper structure: `\input{tables/tab_angle}` and `\input{tables/tab_threshold}`
  wired; placeholder .tex files keep the document compilable (21 pages, 0
  undefined references).  `sync_paper_tables.py` overwrites them with the real
  tables.

## Still pending results (the only remaining work)

1. Fill the 7 generated tables and re-run `sync_paper_tables.py`.
2. Rewrite the numeric prose listed above from `tables_data.json` / the
   `*_allpos.json` files.
3. `tab_complexity` + the streaming paragraph: refresh RTF, p95 and the
   equivalence figures from `main_experiment/streaming_results.json`.
4. Chinese mirror: copy `tables_data.json` into `paper_cn/`, renumber the
   Chinese tables (angle becomes 表 3, so lambda/ablation/detection/
   localisation shift by one; threshold = 表 8, complexity = 表 9), rebuild.
5. Final verification: `pdflatex` (expect 0 undefined), DOCX render check,
   `check_pipeline.py` green.
