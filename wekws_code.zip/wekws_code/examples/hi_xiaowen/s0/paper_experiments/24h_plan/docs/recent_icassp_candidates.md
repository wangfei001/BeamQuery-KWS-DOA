# Recent ICASSP comparison candidates (2020-2025)

Retrieved from Crossref on 2026-10-12. Priority order:

| Priority | Paper | Venue/Year | Task | Why relevant | Implementation plan |
|---|---|---|---|---|---|
| 1 | Temporal Convolution Shrinkage Network for Keyword Spotting | ICASSP 2024 | KWS detection | Recent ICASSP KWS architecture, directly comparable to KWT/BC-ResNet | Port TCSN encoder into `ModelFactory`, train 10 epochs on packed v5, evaluate full test |
| 2 | Wake Word Detection with Streaming Transformers | ICASSP 2021 | streaming KWS | Streaming wake-word baseline | Implement a small streaming Transformer encoder, train/evaluate under same protocol |
| 3 | Lightweight Feature Encoder for Wake-Up Word Detection Based on Self-Supervised Speech Representation | ICASSP 2023 | wake-word detection | Self-supervised front end for wake words | Requires a pretrained SSL checkpoint; add if checkpoint is available |
| 4 | Deep Enhancement Spotting Network for Low-complexity Keyword Spotting in Noisy Environments | ICASSP 2025 | noisy KWS | Recent low-complexity noisy KWS baseline | Port if enhancement/spotting code is available |
| 5 | Direction-of-Arrival Estimation Using Gaussian Process Interpolation | ICASSP 2023 | DOA estimation | Recent DOA estimator, suitable for cascade comparison | Adapt to 2-mic 3-class coarse DOA; reuse Mono detector for cascade |
| 6 | Fast Direction-of-Arrival Estimation of Multiple Targets Using Deep Learning and Sparse Arrays | ICASSP 2020 | multi-target DOA | Multi-source DOA; relevant to n_src=2 failure mode | Adapt model to 2-mic/3-class and cascade with Mono detector |
| 7 | Two-stage streaming keyword detection and localization with multi-scale depthwise temporal convolution | Neural Networks 2022 (not ICASSP) | joint KWS + localization | Direct joint detection/localization baseline | Port if code is available; otherwise cite as related work only |

Already included in the paper:
- BC-ResNet (INTERSPEECH 2021)
- KWT (INTERSPEECH 2021)
- Spatial-prior direction-aware KWS (2026)
- GCC-PHAT / SRP-PHAT cascades

Implementation note: new baselines must use the same packed v5 train split, the 10k expanded validation split for checkpoint selection, and the 16k full test split for final reporting.


## Exact identifiers

- TCSN, ICASSP 2024: DOI 10.1109/ICASSP48485.2024.10446268; official code `zhu1hai/wekws-tcsn` (downloaded under `paper_experiments/third_party/wekws-tcsn/`).
- Wake Word Detection with Streaming Transformers, ICASSP 2021: DOI 10.1109/ICASSP39728.2021.9414777.
- Lightweight Feature Encoder for Wake-Up Word Detection, ICASSP 2023: DOI 10.1109/ICASSP49357.2023.10094623.
- Deep Enhancement Spotting Network, ICASSP 2025: DOI 10.1109/ICASSP49660.2025.10890683.
- DOA Estimation Using Gaussian Process Interpolation, ICASSP 2023: DOI 10.1109/ICASSP49357.2023.10094761.
- Fast DOA Estimation of Multiple Targets Using Deep Learning and Sparse Arrays, ICASSP 2020: DOI 10.1109/ICASSP40776.2020.9054380.
