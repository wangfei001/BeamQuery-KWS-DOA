### Table: beam-angle independence (validation, 10k)

| Delta (deg) | AUC | FRR@1h | DOA (all pos) | MAE (deg) |
|---|---|---|---|---|
| 6 | 0.9921 | 0.3268 | 0.9398 | 4.07 |
| 8 | 0.9913 | 0.3138 | 0.9474 | 3.40 |
| 12 | 0.9925 | 0.2044 | 0.9466 | 3.50 |
| 15 | 0.9917 | 0.2222 | 0.9408 | 3.80 |
| 20 | 0.9914 | 0.2720 | 0.9332 | 4.37 |
| 30 | 0.9909 | 0.2460 | 0.9374 | 4.16 |

### Table: auxiliary wake-head weight (validation, 10k)

| lambda_wake | AUC | FRR@1h | DOA (all pos) | MAE (deg) |
|---|---|---|---|---|
| 0 (no head) | 0.9911 | 0.2646 | 0.9360 | 4.14 |
| 0.1 | 0.9910 | 0.2298 | 0.9394 | 3.90 |
| 0.3 | 0.9913 | 0.2446 | 0.9454 | 3.52 |
| 1.0 | 0.9919 | 0.2458 | 0.9458 | 3.60 |

### Table: component ablation (validation, 10k)

| ID | AUC | FRR@1h | DOA (all pos) | MAE (deg) |
|---|---|---|---|---|
| A0 (full) | 0.9913 | 0.3138 | 0.9474 | 3.40 |
| A1 (dynamic query) | 0.9794 | 0.6396 | 0.4438 | 45.54 |
| A2 (single mic) | 0.9860 | 0.2906 | 0.3376 | 60.12 |
| A3 (no presence head) | 0.9910 | 0.3462 | 0.9324 | 4.39 |
| A4 (attention pooling) | 0.9879 | 0.2906 | 0.9228 | 4.97 |

### Table: detection comparison (test)

| Method | Params (K) | AUC | FPR@0.5 | FRR@1h |
|---|---|---|---|---|
| Mono | 645 | 0.9815 | 0.0435 | 0.3210 |
| Concat-MC | 722 | 0.9741 | 0.0906 | 0.4500 |
| Fixed-beam | 645 | 0.9806 | 0.0824 | 0.3423 |
| Fixed-beam-3 | 645 | 0.9828 | 0.0922 | 0.3180 |
| KWT | 468 | 0.9333 | 0.1162 | 0.6830 |
| BC-ResNet | 9 | 0.9726 | 0.0888 | 0.4777 |
| TCSN | 454 | 0.9849 | 0.0520 | 0.3450 |
| Spatial-prior | 967 | 0.9734 | 0.0729 | 0.4430 |
| BeamQuery (ours) | 971 | 0.9864 | 0.0347 | 0.3450 |

### Table: localisation / joint / stratified (test)

| Method | DOA (all) | MAE | Joint | n_src=1 real/oracle | n_src=2 real/oracle | Gap |
|---|---|---|---|---|---|---|
| Cascade GCC-PHAT | 0.5723 | 33.24 | 0.4740 | 0.8853 / 0.8853 | 0.3144 / 0.9162 | 0.1973 |
| Cascade SRP-PHAT | 0.3900 | 55.58 | 0.2773 | 0.4478 / 0.4478 | 0.3278 / 0.6557 | 0.1075 |
| Fixed-beam-3 | 0.4767 | 35.92 | 0.3043 | 0.3546 / 0.3546 | 0.6300 / 0.7621 | 0.0440 |
| BeamQuery (ours) | 0.9310 | 4.48 | 0.6297 | 0.9756 / 0.9756 | 0.9352 / 0.9539 | 0.0066 |

### Table: wake-threshold influence (main model, test)

| Target FAR (1/h) | Threshold | FRR | FPR | DOA (det) | MAE (deg) | Joint (all) |
|---|---|---|---|---|---|---|
| 0.1 | 1.0000 | 0.6443 | 0.0000 | 0.9784 | 1.29 | 0.3480 |
| 0.5 | 0.9997 | 0.4073 | 0.0003 | 0.9657 | 2.09 | 0.5723 |
| 1.0 | 0.9992 | 0.3450 | 0.0007 | 0.9613 | 2.35 | 0.6297 |
| 2.0 | 0.9967 | 0.2747 | 0.0015 | 0.9596 | 2.45 | 0.6960 |
| 5.0 | 0.9878 | 0.2117 | 0.0038 | 0.9539 | 2.82 | 0.7520 |
| 10.0 | 0.9657 | 0.1650 | 0.0076 | 0.9529 | 2.90 | 0.7957 |

### Table: streaming behaviour of the selected main model

| Quantity | Non-streaming | Streaming |
|---|---|---|
| Parameters (K) | 971 | 971 |
| AUC | 0.9864 | 0.9865 |
| Recall@1/h | 0.6550 | 0.6580 |
| DOA Acc. | 0.9310 | 0.9317 |
| MAE (deg) | 4.48 | 4.44 |
| Joint | 0.6297 | 0.6327 |
| RTF | -- | 0.42 |
| RTF, p95 | -- | 0.60 |
| Chunk (ms) | -- | 100 |
