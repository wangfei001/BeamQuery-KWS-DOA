# 24h experiment protocol (authoritative, derived from the on-disk configs)

All runs: packed v5 corpus, 22k train / **10k validation** (5k+5k, 3.82 h of
negative audio) / 16k test (3k+13k, 9.93 h). Model selection uses the
validation split only; the test split is never used for any decision.

## Stage 1 / 2 recipe
`train_conf.max_epoch` per experiment (verified by `check_pipeline.py`):

| Experiment | stage-1 (mean_max) | stage-2 (run_max_logit) | total |
|---|---|---|---|
| Angle sweep (A9) | 5 | 8 | 13 |
| Lambda sweep (Table 3) | 5 | 8 | 13 |
| A0 (best angle, full model) | 5 | 5 | 10 |
| A8 single-mic | 5 | 8 | 13 |
| A2 / A4 | 5 | 8 | 13 |
| A1 dynamic query | 8 | -- | 8 |
| Comparison baselines | 10 | -- | 10 |
| Fixed-beam-3 | 10 (Q+1 CE) | -- | 10 |
| TCSN baseline | 10 | -- | 10 |

For the selected A0 model (`beam_step_deg=8`), the reported training recipe is
`5+5=10` epochs. This matches the learned baselines' 10-epoch budget. The
remaining difference is the two-stage optimisation schedule and optimiser
configuration, not the number of selected-model epochs.

TCSN, BC-ResNet and KWT are single-channel in their official designs.  Their
adapters consume the waveform batch but feed only microphone 0 to the network;
no channel concatenation or averaging is applied.  The `single_channel=True`
switch is explicit in the training and evaluation factories.

`lambda_wake = 0.3` and `wake_detach = true` are used by every main-model
candidate; the lambda sweep varies `lambda_wake` with the head detached and
disables the head entirely at `lambda_wake = 0`.

## Known design note: lambda sweep grid
`make_configs()` writes the lambda sweep with `beam_step_deg = 12` (it runs
before the angle study exists). The orchestrator now regenerates the lambda
configs with the *selected* angle via `make_lambda_configs(best_angle_step)`;
that path only takes effect if the orchestrator is restarted before the lambda
stage. If the sweep ends up on the 12 deg grid, Table 3 is reported as a
*fixed-grid* sensitivity study, and the final model's own row is A0 in the
ablation table (best angle, lambda = 0.3, detached). Both framings are
internally consistent; the caption must state which grid was used.

## Selection rule (main model)
`score = AUC x DOA_acc(detected positives)`, gated on `AUC >= 0.98` and
`detected-positive DOA >= 0.90`, computed on the 10k validation split over the candidates
{A0, A1_dynamic, A8_single_mic, A9_beam30, A2_no_presence,
A4_pool_attn}. The winner is copied to `paper_experiments/main_experiment/`.

## Extra comparison experiments (run_extras.py)
Retrains mono, concat-mc, fixed-beam, fixed-beam-3, KWT, BC-ResNet,
spatial-prior and TCSN (ICASSP 2024) on the packed train split, selecting the
checkpoint by **validation AUC** on the 10k split, then re-evaluates every
system on the 10k validation and the 16k test split. TCSN remains a
single-channel baseline and receives microphone 0 only. The additional
The two cascades reuse the mono checkpoint bit-for-bit (their azimuth comes from
GCC-PHAT / SRP-PHAT, which is not trained).

The final streaming table is produced on the complete 16k test split with
`KWS_MAX_SEC=3.0`, 100 ms chunks, explicit end-of-utterance `flush()` and
FAR=1/h calibration on the complete negative set.  The 300-utterance stratified
subset is retained only as a diagnostic.
