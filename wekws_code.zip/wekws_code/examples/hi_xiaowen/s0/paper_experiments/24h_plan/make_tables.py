# -*- coding: utf-8 -*-
"""Build the paper tables from 24h_plan results.

Emits LaTeX tables in the style of papaer/tables/*.tex plus a markdown review
file. Every number is read from JSON produced by the pipeline; nothing is
hard-coded except row order and captions.
"""
import argparse
import json
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

ROOT = Path('/242602/wekws/examples/hi_xiaowen_duolu/s0_deepseek_3')
PLAN = ROOT / 'paper_experiments/24h_plan'
RES = PLAN / 'results'
DOCS = PLAN / 'docs'
OUT = DOCS / 'tables'

ANGLE_STEPS = [6, 8, 12, 15, 20, 30]
LAMBDAS = [0.0, 0.1, 0.3, 1.0]

# baselines that emit an azimuth, for the localisation table
AZIMUTH_BASELINES = [('cascade_gccphat', 'Cascade GCC-PHAT'),
                     ('cascade_srpphat', 'Cascade SRP-PHAT'),
                     ('fixed_beam3_frozen_mono', 'Fixed-beam-3')]

MAIN_NAMES = [('mono', 'Mono'), ('concat_mc', 'Concat-MC'),
              ('fixed_beam_frozen_mono', 'Fixed-beam'), ('fixed_beam3_frozen_mono', 'Fixed-beam-3'),
              ('kwt', 'KWT~\\cite{berg2021kwt}'),
              ('bc_resnet_official', 'BC-ResNet~\\cite{kim2021bcresnet}'),
              ('tcsn', 'TCSN~\\cite{zhu2024tcsn}'),
              ('spatial_prior', 'Spatial-prior~\\cite{wang2026spatial}')]


def plain(s):
    import re
    s = re.sub(r'~?\\cite\{[^}]*\}', '', s)
    s = re.sub(r'\\textbf\{([^}]*)\}', r'\1', s)
    s = s.replace('~', ' ').replace('\\,', ' ')
    return s.strip()


def load(path):
    path = Path(path)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except json.JSONDecodeError:
        return None


def r(v, nd=4):
    if v is None:
        return None
    return float(Decimal(str(v)).quantize(Decimal('1.' + '0' * nd), rounding=ROUND_HALF_UP))


def f4(v):
    return '--' if v is None else f'{r(v):.4f}'


def f2(v):
    return '--' if v is None else f'{r(v, 2):.2f}'


def bold(s, on):
    return f'\\textbf{{{s}}}' if on else s


def best_idx(rows, key, higher=True):
    vals = [(i, x[key]) for i, x in enumerate(rows)
            if x and x.get(key) is not None]
    if not vals:
        return -1
    tgt = (max if higher else min)(v for _, v in vals)
    for i, v in vals:
        if v == tgt:
            return i
    return -1


def m_allpos(d):
    """Five reported numbers from an eval_allpos JSON."""
    if not d:
        return None
    det, ap = d.get('detection', {}), d.get('all_positives', {})
    dp = d.get('detected_positive', {})
    return {'auc': det.get('auc'), 'fpr05': det.get('fpr@0.5'),
            'frr1h': det.get('frr@1h'), 'loc': ap.get('doa_acc'),
            'mae': ap.get('mae'), 'joint': ap.get('joint'),
            'loc_det': dp.get('doa_acc'), 'mae_det': dp.get('mae'),
            'strat_all': d.get('stratified_all', {}),
            'strat_det': d.get('stratified_detected', {})}


def m_evalonly(d):
    """Normalise an eval_only.py result dict to the same schema."""
    if not d:
        return None
    det, doa = d.get('detection', {}), (d.get('doa') or {})
    return {'auc': det.get('auc'), 'fpr05': det.get('fpr'),
            'frr1h': (d.get('frr_at_far1h') or {}).get('frr'),
            'loc': doa.get('doa_acc'), 'mae': doa.get('mean_deg_err'),
            'joint': None, 'loc_det': doa.get('doa_acc'),
            'mae_det': doa.get('mean_deg_err'), 'strat_all': {}, 'strat_det': {}}


def params_of(name):
    d = load(RES / f'baselines_retrain/{name}/results.json')
    if d and d.get('params'):
        return int(round(d['params'] / 1000.0))
    # Some newly added controls are evaluated with eval_only.py after training;
    # derive the parameter count from the saved checkpoint when no results.json
    # was written by the training process.
    ck = RES / f'baselines_retrain/{name}/best_cv.pt'
    if ck.exists():
        try:
            import torch
            state = torch.load(ck, map_location='cpu', weights_only=False)
            sd = state.get('model', state)
            return int(round(sum(v.numel() for v in sd.values()) / 1000.0))
        except Exception:
            pass
    d = load(ROOT / f'paper_experiments/table2_systems/results/{name}/results_v5.json')
    if d and d.get('params'):
        return int(round(d['params'] / 1000.0))
    return None


def main_params():
    p = ROOT / 'paper_experiments/main_experiment/best_cv.pt'
    if not p.exists():
        return None
    try:
        import torch
        ck = torch.load(p, map_location='cpu', weights_only=False)
        sd = ck.get('model', ck)
        return int(round(sum(v.numel() for v in sd.values()) / 1000.0))
    except Exception:
        return None


# --------------------------------------------------------------------------- #
def emit_angle():
    rows, steps = [], []
    for step in ANGLE_STEPS:
        rows.append(m_allpos(load(RES / f'angles/step_{step}/val_allpos.json')))
        steps.append(step)
    if not any(x and x.get('auc') is not None for x in rows):
        return None
    for x in rows:
        if x:
            x['score'] = (x['auc'] * x['loc_det']
                          if x.get('auc') is not None and x.get('loc_det') is not None
                          else None)
    eligible = [x for x in rows if x and x.get('auc') is not None
                and x.get('loc_det') is not None
                and x['auc'] >= 0.98 and x['loc_det'] >= 0.90]
    selected_i = -1
    if eligible:
        selected_i = rows.index(max(eligible, key=lambda x: x['score']))
    b = {k: best_idx(rows, k, hi) for k, hi in
         [('auc', True), ('frr1h', False), ('loc', True), ('mae', False),
          ('loc_det', True), ('mae_det', False), ('score', True)]}
    md = ['### Table: beam-grid resolution (validation, 10k)', '',
          '| Delta (deg) | AUC | FRR@1h | DOA (all) | MAE (all) | DOA (det) | MAE (det) | Score |',
          '|---|---|---|---|---|---|---|---|']
    for st, x in zip(steps, rows):
        if not x:
            continue
        md.append(f'| {st} | {f4(x["auc"])} | {f4(x["frr1h"])} | {f4(x["loc"])} | '
                  f'{f2(x["mae"])} | {f4(x["loc_det"])} | {f2(x["mae_det"])} | {f4(x["score"])} |')
    L = [r'\begin{widetable}', r'\centering',
         r'\caption{Beam-grid resolution on the expanded validation split',
         r'($10{,}000$ utterances, $5{,}000$ positives). The test split is not',
         r'used. Model selection is validation-only: candidates must satisfy',
         r'AUC${}\ge0.98$ and detected-positive DOA${}\ge0.90$, and the selected',
         r'configuration maximises AUC${}\times{}$detected-positive DOA. DOA and',
         r'MAE are reported both over all positives and over accepted positives;',
         r'the final model uses the $\Delta=8^\circ$ row marked by $\ast$.',
         r'Best value in each column is bold.}',
         r'\label{tab:angle}', r'\small',
         r'\resizebox{\textwidth}{!}{%',
         r'\begin{tabular}{lrrrrrrr}', r'\toprule',
         r'$\Delta$ (deg) & AUC $\uparrow$ & FRR@1/h $\downarrow$ & DOA (all) $\uparrow$ & MAE (all) $\downarrow$ & DOA (det) $\uparrow$ & MAE (det) $\downarrow$ & Score $\uparrow$ \\',
         r'\midrule']
    for i, (st, x) in enumerate(zip(steps, rows)):
        if not x:
            continue
        star = r'$^\ast$' if i == selected_i else ''
        L.append('{}{} & {} & {} & {} & {} & {} & {} & {} \\\\'.format(
            st, star, bold(f4(x['auc']), i == b['auc']),
            bold(f4(x['frr1h']), i == b['frr1h']),
            bold(f4(x['loc']), i == b['loc']),
            bold(f2(x['mae']), i == b['mae']),
            bold(f4(x['loc_det']), i == b['loc_det']),
            bold(f2(x['mae_det']), i == b['mae_det']),
            bold(f4(x['score']), i == b['score'])))
    L += [r'\bottomrule', r'\end{tabular}}', r'\end{widetable}']
    return md, L

def emit_lambda():
    rows, lams = [], []
    for lw in LAMBDAS:
        rows.append(m_allpos(load(RES / f'lambda/lw{lw:.1f}/val_allpos.json')))
        lams.append(lw)
    if not any(x and x.get('auc') is not None for x in rows):
        return None
    b = {k: best_idx(rows, k, hi) for k, hi in
         [('auc', True), ('frr1h', False), ('loc', True), ('mae', False)]}
    md = ['### Table: auxiliary wake-head weight (validation, 10k)', '',
          '| lambda_wake | AUC | FRR@1h | DOA (all pos) | MAE (deg) |',
          '|---|---|---|---|---|']
    for lw, x in zip(lams, rows):
        if not x:
            continue
        lab = '0 (no head)' if lw == 0 else str(lw)
        md.append(f'| {lab} | {f4(x["auc"])} | {f4(x["frr1h"])} | {f4(x["loc"])} | {f2(x["mae"])} |')
    L = [r'\begin{widetable}', r'\centering',
         r'\caption{Effect of the auxiliary binary wake-word head, selected on the',
         r'expanded validation split ($10{,}000$ utterances). The head is trained',
         r'with a BCE term weighted by $\lambda_{\mathrm{wake}}$ on a detached copy',
         r'of the shared features; $\lambda_{\mathrm{wake}}{=}0$ disables it. DOA',
         r'accuracy and MAE are measured over all positives. Best per column in bold.}',
         r'\label{tab:lambda}', r'\small',
         r'\resizebox{\textwidth}{!}{%',
         r'\begin{tabular}{lrrrr}', r'\toprule',
         r'$\lambda_{\mathrm{wake}}$ & AUC $\uparrow$ & FRR@1/h $\downarrow$ & DOA Acc. $\uparrow$ & MAE (deg) $\downarrow$ \\',
         r'\midrule']
    for i, (lw, x) in enumerate(zip(lams, rows)):
        if not x:
            continue
        lab = '$0$ (no head)' if lw == 0 else f'${lw}$'
        L.append('{} & {} & {} & {} & {} \\\\'.format(
            lab, bold(f4(x['auc']), i == b['auc']),
            bold(f4(x['frr1h']), i == b['frr1h']),
            bold(f4(x['loc']), i == b['loc']),
            bold(f2(x['mae']), i == b['mae'])))
    L += [r'\bottomrule', r'\end{tabular}}', r'\end{widetable}']
    return md, L


ABL_LABEL = {
    'A0': 'A0 (full)',
    'A1_dynamic': 'A1 (dynamic query)',
    'A2_single_mic': 'A2 (single mic)',
    'A9_beam30': 'A9 ($30^\\circ$ beams)',
    'A3_no_presence': 'A3 (no presence head)',
    'A4_pool_attn': 'A4 (attention pooling)',
}
ABL_ORDER = ['A0', 'A1_dynamic', 'A2_single_mic', 'A3_no_presence', 'A4_pool_attn']


def _abl(tag, split='val'):
    base = RES / 'ablation'
    if tag == 'A0':
        for d in sorted(base.glob('A0_bestangle_*')):
            x = m_allpos(load(d / f'{split}_allpos.json'))
            if x:
                return x
        return None
    return m_allpos(load(base / tag / f'{split}_allpos.json'))


def _best_angle_deg():
    """Validation-selected look-direction step (Table 3 argmax by AUC*DOA)."""
    s = load(RES / 'angles/summary.json') or {}
    if not s:
        return None
    try:
        return int(max(s, key=lambda k: s[k].get('score', 0)).split('_')[1])
    except Exception:
        return None


def emit_ablation():
    deg = _best_angle_deg()
    dstr = f'{deg}' if deg is not None else '6'
    rows = [_abl(t) for t in ABL_ORDER]
    if not any(x and x.get('auc') is not None for x in rows):
        return None
    b = {k: best_idx(rows, k, hi) for k, hi in
         [('auc', True), ('frr1h', False), ('loc', True), ('mae', False)]}
    md = ['### Table: component ablation (validation, 10k)', '',
          '| ID | AUC | FRR@1h | DOA (all pos) | MAE (deg) |',
          '|---|---|---|---|---|']
    for tag, x in zip(ABL_ORDER, rows):
        if not x:
            continue
        md.append(f'| {ABL_LABEL[tag]} | {f4(x["auc"])} | {f4(x["frr1h"])} '
                  f'| {f4(x["loc"])} | {f2(x["mae"])} |')
    L = [r'\begin{widetable}', r'\centering',
         r'\caption{Component ablation on the expanded validation split',
         r'($10{,}000$ utterances). A0 is the full model (also the',
         r'$\Delta=' + dstr + r'^\circ$ row of Table~\ref{tab:angle} and the',
         r'$\lambda_{\mathrm{wake}}=0.3$ row of Table~\ref{tab:lambda});',
         r'A9 is the $\Delta=30^\circ$ row of Table~\ref{tab:angle} and is',
         r'not repeated because it has already been compared there. All variants',
         r'share the same corpus, backbone and optimizer family. A0, A2, A3 and A4',
         r'use the reported two-stage $5{+}5$ recipe; A1 (dynamic query) is trained',
         r'with a mean-max-only objective because the structural beam binding is',
         r'removed in that ablation. DOA accuracy and MAE are measured over all',
         r'positives. Best per column in bold.}',
         r'\label{tab:ablation}', r'\small',
         r'\resizebox{\textwidth}{!}{%',
         r'\begin{tabular}{lrrrr}', r'\toprule',
         r'ID & AUC $\uparrow$ & FRR@1/h $\downarrow$ & DOA Acc. $\uparrow$ & MAE (deg) $\downarrow$ \\',
         r'\midrule']
    for i, (tag, x) in enumerate(zip(ABL_ORDER, rows)):
        if not x:
            continue
        L.append('{} & {} & {} & {} & {} \\\\'.format(
            ABL_LABEL[tag], bold(f4(x['auc']), i == b['auc']),
            bold(f4(x['frr1h']), i == b['frr1h']),
            bold(f4(x['loc']), i == b['loc']),
            bold(f2(x['mae']), i == b['mae'])))
    L += [r'\bottomrule', r'\end{tabular}}', r'\end{widetable}']
    return md, L


def _baseline_split(name, split):
    d = load(RES / f'baselines/{name}/{split}/results_{split}.json')
    if d:
        return m_evalonly(d.get('test', {}))
    # New baselines written directly by train_duibi.py keep the final test
    # metrics in baselines_retrain/<name>/results.json.
    if split == 'test':
        d = load(RES / f'baselines_retrain/{name}/results.json')
        if d:
            return m_evalonly(d.get('test', {}))
    return None


def emit_main(split='test'):
    main = m_allpos(load(ROOT / f'paper_experiments/main_experiment/{split}_metrics.json'))
    rows, names, labels = [], [], []
    for name, lab in MAIN_NAMES:
        x = _baseline_split(name, split)
        if x and x.get('auc') is not None:
            rows.append(x); names.append(name); labels.append(lab)
    if main and main.get('auc') is not None:
        rows.append(main); names.append('__main__'); labels.append('\\textbf{BeamQuery (ours)}')
    if not rows:
        return None
    b = {k: best_idx(rows, k, hi) for k, hi in
         [('auc', True), ('fpr05', False), ('frr1h', False)]}
    md = [f'### Table: detection comparison ({split})', '',
          '| Method | Params (K) | AUC | FPR@0.5 | FRR@1h |',
          '|---|---|---|---|---|']
    for n, lab, x in zip(names, labels, rows):
        p = main_params() if n == '__main__' else params_of(n)
        md.append(f'| {plain(lab)} | {p or "--"} '
                  f'| {f4(x["auc"])} | {f4(x["fpr05"])} | {f4(x["frr1h"])} |')
    L = [r'\begin{table}[t]', r'\centering',
         r'\caption{Detection only: does the wake word fire? Azimuth is ignored',
         r'entirely. All methods share the corpus, backbone settings and the',
         r'$3$\,s protocol. Fixed-beam and Fixed-beam-3 reuse the frozen Mono',
         r'detector and train no detector parameters; the remaining learned models',
         r'are trained independently from scratch. TCSN follows its official',
         r'single-channel contract and receives microphone 0',
         r'only. The two cascades train no detector of their own: they reuse the unmodified',
         r'Mono detector and append a classical azimuth estimator. Best per column',
         r'in bold.}',
         r'\label{tab:main}', r'\small',
         r'\begin{tabular}{lrrrr}', r'\toprule',
         r'Method & Params (K) & AUC $\uparrow$ & FPR@0.5 $\downarrow$ & FRR@1/h $\downarrow$ \\',
         r'\midrule']
    for i, (n, lab, x) in enumerate(zip(names, labels, rows)):
        p = main_params() if n == '__main__' else params_of(n)
        L.append('{} & {} & {} & {} & {} \\\\'.format(
            lab, p if p else '--', bold(f4(x['auc']), i == b['auc']),
            bold(f4(x['fpr05']), i == b['fpr05']),
            bold(f4(x['frr1h']), i == b['frr1h'])))
    L += [r'\bottomrule', r'\end{tabular}}', r'\end{widetable}']
    return md, L


def _strat_row(name, label, d):
    if not d:
        return None
    ap = d.get('all_positives', {})
    dp = d.get('detected_positive', {})
    sd = d.get('stratified_detected', {})
    if ap.get('doa_acc') is None:
        return None
    d1, d2 = sd.get('n_src=1', {}), sd.get('n_src=2', {})
    gap = None
    if dp.get('oracle_acc') is not None and dp.get('doa_acc') is not None:
        gap = dp['oracle_acc'] - dp['doa_acc']
    return {'label': label, 'loc': ap.get('doa_acc'), 'mae': ap.get('mae'),
            'joint': ap.get('joint'),
            's1_real': d1.get('acc'), 's1_or': d1.get('oracle'),
            's2_real': d2.get('acc'), 's2_or': d2.get('oracle'),
            'oracle_all': dp.get('oracle_acc'), 'gap': gap}


def _pair(a, b):
    if a is None and b is None:
        return '--'
    return f'{f4(a)} / {f4(b)}'


def emit_strat(split='test'):
    rows = []
    for name, lab in AZIMUTH_BASELINES:
        rows.append(_strat_row(name, lab, load(RES / f'baselines/{name}/{split}_allpos.json')))
    rows.append(_strat_row('__main__', '\\textbf{BeamQuery (ours)}',
                           load(ROOT / f'paper_experiments/main_experiment/{split}_metrics.json')))
    if not any(rows):
        return None
    md = [f'### Table: localisation / joint / stratified ({split})', '',
          '| Method | DOA (all) | MAE | Joint | n_src=1 real/oracle | n_src=2 real/oracle | Gap |',
          '|---|---|---|---|---|---|---|']
    for x in rows:
        if not x:
            continue
        md.append(f'| {plain(x["label"])} | {f4(x["loc"])} | {f2(x["mae"])} | {f4(x["joint"])} '
                  f'| {_pair(x["s1_real"], x["s1_or"])} | {_pair(x["s2_real"], x["s2_or"])} '
                  f'| {f4(x["gap"])} |')
    L = [r'\begin{table*}[t]', r'\centering',
         r'\caption{Localisation and joint performance for the four systems that',
         r'emit an azimuth. Fixed-beam-3 is a fixed-front-end diagnostic: each of',
         r'its three beams is scored by the same Mono detector and the azimuth is',
         r'the argmax of those detector scores, so it is not a jointly learned',
         r'detector-localiser. If several beams exceed the threshold, only the',
         r'highest-scoring beam is reported; the output is one azimuth per utterance,',
         r'not multiple simultaneous wake-word locations. DOA accuracy and MAE are averaged over \emph{all} positives,',
         r'without conditioning on detection; Joint is the fraction of all positives',
         r'that both fire and are correct at FAR${=}1$/h. The last columns are the',
         r'detected-positive diagnostic: realised accuracy for one- and two-source',
         r'mixtures with the oracle for two sources (an estimate matching \emph{any}',
         r'source present), and the overall gap (mean oracle minus mean realised on',
         r'the accepted set). Best per column in bold.}',
         r'\label{tab:strat}', r'\small',
         r'\resizebox{\textwidth}{!}{%',
         r'\begin{tabular}{lrrrrrr}', r'\toprule',
         r'Method & DOA Acc. $\uparrow$ & MAE (deg) $\downarrow$ & Joint $\uparrow$',
         r'       & $n_{\mathrm{src}}{=}1$ & $n_{\mathrm{src}}{=}2$ & Gap \\',
         r'       & (all pos.) & (all pos.) & & real.\ / oracle & real.\ / oracle & \\',
         r'\midrule']
    for x in rows:
        if not x:
            continue
        L.append('{} & {} & {} & {} & {} & {} & {} \\\\'.format(
            x['label'], f4(x['loc']), f2(x['mae']), f4(x['joint']),
            _pair(x['s1_real'], x['s1_or']), _pair(x['s2_real'], x['s2_or']),
            f4(x['gap'])))
    L += [r'\bottomrule', r'\end{tabular}}', r'\end{table*}']
    return md, L


def emit_threshold():
    rows = load(ROOT / 'paper_experiments/main_experiment/threshold_sweep.json')
    if not rows:
        return None
    md = ['### Table: wake-threshold influence (main model, test)', '',
          '| Target FAR (1/h) | Threshold | FRR | FPR | DOA (det) | MAE (deg) | Joint (all) |',
          '|---|---|---|---|---|---|---|']
    for x in rows:
        md.append(f'| {x["target_far"]} | {f4(x["threshold"])} | {f4(x["frr"])} | {f4(x["fpr"])} '
                  f'| {f4(x["doa_det"])} | {f2(x["mae_det"])} | {f4(x["joint_all"])} |')
    L = [r'\begin{widetable}', r'\centering',
         r'\caption{Effect of the wake-word decision threshold on localisation,',
         r'expressed as a target false-alarm rate (FAR). Each row picks the',
         r'threshold that realises that FAR on the test split and reports the',
         r'resulting miss rate, detection false-positive rate, and the azimuth',
         r'accuracy over all positives (Joint) versus the accepted positives',
         r'(DOA).}',
         r'\label{tab:threshold}', r'\small',
         r'\resizebox{\textwidth}{!}{%',
         r'\begin{tabular}{rrrrrrr}', r'\toprule',
         r'FAR (1/h) & Thr. & FRR $\downarrow$ & FPR $\downarrow$ & DOA Acc. $\uparrow$ & MAE (deg) $\downarrow$ & Joint $\uparrow$ \\',
         r'\midrule']
    for x in rows:
        L.append('{} & {} & {} & {} & {} & {} & {} \\\\'.format(
            x['target_far'], f4(x['threshold']), f4(x['frr']), f4(x['fpr']),
            f4(x['doa_det']), f2(x['mae_det']), f4(x['joint_all'])))
    L += [r'\bottomrule', r'\end{tabular}}', r'\end{widetable}']
    return md, L


def emit_complexity():
    """Streaming behaviour of the selected main model (final paper table).

    Both columns use the same operational point (FAR=1/h) and the same
    all-positives localisation scope.  The streaming column is the strict
    frame-by-frame decoder with an explicit end-of-utterance flush.
    """
    st = load(ROOT / 'paper_experiments/main_experiment/streaming_results.json')
    timing = load(ROOT / 'paper_experiments/main_experiment/streaming_timing_100.json') or st
    off = load(ROOT / 'paper_experiments/main_experiment/test_metrics.json')
    if not st or not off:
        return None
    s = st.get('streaming', {})
    ts = timing.get('streaming', {})
    last = s.get('class_max_time', s.get('last_frame', {}))
    det = off.get('detection', {})
    ap = off.get('all_positives', {})
    params = main_params()
    rows = [
        ('Parameters (K)', params, params),
        ('AUC', det.get('auc'), last.get('wake_auc')),
        ('Recall@1/h', (1.0 - det.get('frr@1h')) if det.get('frr@1h') is not None else None,
         last.get('wake_recall')),
        ('DOA Acc.', ap.get('doa_acc'), last.get('doa_acc_all')),
        ('MAE (deg)', ap.get('mae'), last.get('mean_deg_err_all')),
        ('Joint', ap.get('joint'), last.get('joint_all')),
        ('RTF', None, ts.get('rtf_mean')),
        ('RTF, p95', None, ts.get('rtf_p95')),
        ('Chunk (ms)', None, s.get('chunk_ms')),
    ]
    def cell(label, v):
        if v is None:
            return '--'
        if label.startswith('Parameters'):
            return str(v)
        if label.startswith('Chunk'):
            return str(int(v))
        if label.startswith('RTF') or label.startswith('MAE'):
            return f2(v)
        return f4(v)

    md = ['### Table: streaming behaviour of the selected main model', '',
          '| Quantity | Non-streaming | Streaming |', '|---|---|---|']
    for label, a, b in rows:
        md.append(f'| {label} | {cell(label, a)} | {cell(label, b)} |')
    L = [r'\begin{widetable}', r'\centering',
         r'\caption{Streaming behaviour of the selected main model. Both columns',
         r'use the same FAR${=}1$/h operating point; recall is reported there and',
         r'DOA/MAE/Joint are averaged over all positives. The streaming column is',
         r'the strict frame-by-frame causal decoder at a $100$\,ms chunk hop with',
         r'an explicit end-of-utterance flush. Accuracy is measured on the complete',
         r'16k test split; RTF is measured on a 100-utterance timing subset with an',
         r'8-thread CPU process.}',
         r'\label{tab:complexity}', r'\small',
         r'\resizebox{\textwidth}{!}{%',
         r'\begin{tabular}{lrr}', r'\toprule',
         r'Quantity & Non-streaming & Streaming \\', r'\midrule']
    for label, a, b in rows:
        if label.startswith('Parameters'):
            fa = str(a) if a is not None else '--'
            fb = str(b) if b is not None else '--'
        elif label.startswith('Chunk'):
            fa, fb = '--', (str(int(b)) if b is not None else '--')
        elif label.startswith('RTF') or label.startswith('MAE'):
            fa, fb = f2(a), f2(b)
        else:
            fa, fb = f4(a), f4(b)
        L.append(f'{label} & {fa} & {fb} \\\\')
    L += [r'\bottomrule', r'\end{tabular}', r'\end{table}']
    return md, L


BUILDERS = [('tab_angle', emit_angle), ('tab_lambda', emit_lambda),
            ('tab_ablation', emit_ablation), ('tab_main', emit_main),
            ('tab_strat', emit_strat), ('tab_threshold', emit_threshold),
            ('tab_complexity', emit_complexity)]


def md_plain(s):
    """Return a LaTeX-free cell for tables_data.json."""
    import re
    s = str(s)
    s = re.sub(r'\\textbf\{([^{}]*)\}', r'\1', s)
    s = re.sub(r'\\mathrm\{([^{}]*)\}', r'\1', s)
    s = re.sub(r'\\text\{([^{}]*)\}', r'\1', s)
    s = re.sub(r'~?\\cite\{[^}]*\}', '', s)
    s = s.replace('^\\circ', '°').replace('\\circ', '°')
    s = s.replace('\\Delta', 'Δ').replace('\\lambda', 'λ')
    s = s.replace('\\%', '%').replace('\\,', ' ')
    s = s.replace('$', '').replace('~', ' ')
    s = re.sub(r'\\[a-zA-Z]+\{([^{}]*)\}', r'\1', s)
    s = re.sub(r'\\[a-zA-Z]+', '', s)
    s = re.sub(r'\s+', ' ', s).strip()
    return s


def md_table_rows(md_lines):
    """Extract the markdown table (header + body) from an emitter's md block."""
    rows = []
    for ln in md_lines:
        ln = ln.strip()
        if not ln.startswith('|'):
            continue
        cells = [md_plain(c.strip()) for c in ln.strip('|').split('|')]
        if all(set(c) <= set('-: ') for c in cells):
            continue
        rows.append(cells)
    if not rows:
        return None
    return {'headers': rows[0], 'rows': rows[1:]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out_dir', default=str(OUT))
    a = ap.parse_args()
    out = Path(a.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    md, built, data = [], [], {}
    for name, fn in BUILDERS:
        res = fn()
        if not res:
            md.append(f'### {name}\n\n_(not available yet)_\n')
            continue
        md.append('\n'.join(res[0]))
        (out / f'{name}.tex').write_text('\n'.join(res[1]) + '\n', encoding='utf-8')
        tab = md_table_rows(res[0])
        if tab:
            data[name] = tab
        built.append(name)
    DOCS.mkdir(parents=True, exist_ok=True)
    (DOCS / 'tables_generated.md').write_text('\n\n'.join(md) + '\n', encoding='utf-8')
    (out / 'tables_data.json').write_text(
        json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
    print('built:', ', '.join(built) if built else '(none)')
    print('missing:', ', '.join(n for n, _ in BUILDERS if n not in built))


if __name__ == '__main__':
    main()
