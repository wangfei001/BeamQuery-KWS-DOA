# -*- coding: utf-8 -*-
"""Extra comparison experiments, run after the main 24h pipeline completes.

Everything here is validation-only for model selection (no test leakage):

  * retrain the comparison baselines on the packed v5 train split, selecting the
    checkpoint by the expanded 10k validation AUC (the earlier checkpoints were
    selected on a 2000-utterance validation split);
  * add TCSN (ICASSP 2024) as a recent-architecture baseline;
  * re-evaluate all of them on the 10k validation and the 16k test split;
  * rebuild the paper tables.

The cascades share the *mono* checkpoint (their azimuth comes from a classical
GCC/SRP-PHAT estimator), so only one detector is trained for them.
"""
import json
import os
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

try:
    import resource
    soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    resource.setrlimit(resource.RLIMIT_NOFILE, (min(65535, hard), hard))
except Exception:
    pass

ROOT = Path('/242602/wekws/examples/hi_xiaowen_duolu/s0_deepseek_3')
PLAN = ROOT / 'paper_experiments/24h_plan'
RES = PLAN / 'results'
LOGS = PLAN / 'logs'
RETRAIN = RES / 'baselines_retrain'
PY = '/242602/conda/envs/wekws/bin/python'
D = ROOT / 'paper_experiments/table1_corpus/data_lists'
V = ROOT / 'data_val10k'
PACKED = ROOT / 'data_packed_v5_largeval'

EPOCHS = 10
MAX_PAR = 3

# (name, --model value, batch size)
TRAIN_SPECS = [
    ('mono', 'mono', 128),
    ('concat_mc', 'concat-mc', 128),
    ('fixed_beam', 'fixed-beam', 32),
    ('fixed_beam3_qce', 'fixed-beam-3', 16),
    ('kwt', 'kwt', 128),
    ('bc_resnet_official', 'bc-resnet', 128),
    ('spatial_prior', 'spatial-prior', 32),
    ('tcsn', 'tcsn', 128),
]

# evaluation entries: (name, checkpoint owner). cascades reuse mono's weights.
EVAL_SPECS = [
    ('mono', 'mono', None),
    ('concat_mc', 'concat_mc', None),
    ('fixed_beam', 'fixed_beam', None),
    ('fixed_beam3_qce', 'fixed_beam3_qce', None),
    ('kwt', 'kwt', None),
    ('bc_resnet_official', 'bc_resnet_official', None),
    ('spatial_prior', 'spatial_prior', None),
    ('tcsn', 'tcsn', None),
    ('cascade_gccphat', 'mono', 'gcc-phat'),
    ('cascade_srpphat', 'mono', 'srp-phat'),
]


def log(msg):
    ts = time.strftime('%Y-%m-%d %H:%M:%S')
    line = f'[{ts}] {msg}'
    print(line, flush=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    with open(LOGS / 'extras.log', 'a', encoding='utf-8') as f:
        f.write(line + '\n')


def base_env():
    env = os.environ.copy()
    env.update({
        'PYTHONPATH': str(ROOT),
        'PACKED_DATA_DIR': str(PACKED),
        'USE_BATCHED_FORWARD': '1',
        'KWS_MAX_SEC': '3.0',
        'KWS_NUM_MIC_USE': '2',
        'OMP_NUM_THREADS': '1',
        'MKL_NUM_THREADS': '1',
    })
    return env


def run(cmd, log_name, env, retries=1):
    LOGS.mkdir(parents=True, exist_ok=True)
    path = LOGS / log_name
    for attempt in range(retries + 1):
        with open(path, 'a', encoding='utf-8') as f:
            f.write('\n$ ' + ' '.join(str(c) for c in cmd) + '\n')
            rc = subprocess.run([str(c) for c in cmd], cwd=str(ROOT), env=env,
                                stdout=f, stderr=subprocess.STDOUT).returncode
        if rc == 0:
            return True
        log(f'{log_name} failed rc={rc} (attempt {attempt + 1})')
        time.sleep(20)
    return False


def wait_for_main(max_wait_h=18):
    """Block until the main orchestrator reports completion."""
    deadline = time.time() + max_wait_h * 3600
    while time.time() < deadline:
        st = PLAN / 'STATUS.json'
        if st.exists():
            try:
                s = json.loads(st.read_text(encoding='utf-8'))
            except Exception:
                s = {}
            stage = s.get('stage')
            if stage == 'completed':
                log('main pipeline completed; starting extras')
                return True
            if stage == 'failed':
                log(f'main pipeline failed: {s.get("error")!r}; waiting for restart')
        time.sleep(120)
    log(f'wait_for_main timed out after {max_wait_h}h; starting extras anyway')
    return False


def train_one(spec):
    name, model, bs = spec
    outdir = RETRAIN / name
    ck = outdir / 'best_cv.pt'
    if ck.exists():
        log(f'skip completed training {name}')
        return name, True
    outdir.mkdir(parents=True, exist_ok=True)
    cmd = [PY, '-u', 'paper_experiments/shared/code/train_duibi.py',
           '--model', model, '--model_dir', str(outdir),
           '--train_data', str(D / 'train_spatial.list'),
           '--train_varcol', str(D / 'train_varcol.tmp.list'),
           '--cv_data', str(V / 'eval_spatial.list'),
           '--cv_varcol', str(V / 'eval_varcol.tmp.list'),
           '--test_data', str(D / 'test_spatial.list'),
           '--test_varcol', str(D / 'test_varcol.tmp.list'),
           '--epochs', str(EPOCHS), '--batch_size', str(bs),
           '--eval_interval', '1', '--select_metric', 'auc',
           '--num_mic', '2', '--num_workers', '3', '--gpus', '0']
    if model == 'fixed-beam-3':
        # Fixed-beam-3 has three query logits and must use the Q+1 CE loss;
        # the default BCE branch trains only s_q[:, 0] (the 30-degree beam).
        cmd += ['--loss', 'qce']
    log(f'training {name} ({model}, bs={bs})')
    ok = run(cmd, f'extras_train_{name}.log', base_env(), retries=1)
    return name, ok


def make_cascade_alias(owner, doa_method, dest):
    """Copy the detector checkpoint and stamp the classical DOA method."""
    import torch
    src = RETRAIN / owner / 'best_cv.pt'
    if not src.exists():
        return False
    dest.parent.mkdir(parents=True, exist_ok=True)
    ck = torch.load(src, map_location='cpu', weights_only=False)
    ck = dict(ck)
    args = dict(ck.get('args', {}))
    args['doa_method'] = doa_method
    ck['args'] = args
    torch.save(ck, dest)
    return True


def eval_one(name, owner, doa_method):
    fresh_ref = RETRAIN / owner / 'best_cv.pt'
    ck = fresh_ref
    if doa_method:
        alias = RETRAIN / name / 'best_cv.pt'
        if not make_cascade_alias(owner, doa_method, alias):
            log(f'alias {name}: missing {ck}')
            return name, None, False
        ck = alias
    if not ck.exists():
        log(f'eval {name}: missing checkpoint {ck}')
        return name, None, False
    env = base_env()
    env.pop('PACKED_DATA_DIR', None)  # evaluate the raw wavs (val/test exist)
    outs = []
    for split, data, var in [
        ('val', V / 'eval_spatial.list', V / 'eval_varcol.tmp.list'),
        ('test', D / 'test_spatial.list', D / 'test_varcol.tmp.list'),
    ]:
        out = RES / 'baselines' / name / split
        out.mkdir(parents=True, exist_ok=True)
        done = out / f'results_{split}.json'
        if done.exists() and done.stat().st_mtime >= fresh_ref.stat().st_mtime:
            try:                       # only trust a parseable result
                json.loads(done.read_text(encoding='utf-8'))
                log(f'eval {name}/{split}: already done, skipping')
                outs.append((split, True))
                continue
            except Exception:
                pass
        cmd = [PY, 'paper_experiments/shared/code/eval_only.py',
               '--ckpt', str(ck), '--test_data', str(data),
               '--test_varcol', str(var), '--out_dir', str(out),
               '--out_tag', split, '--num_workers', '3']
        ok = run(cmd, f'extras_eval_{name}_{split}.log', env, retries=1)
        outs.append((split, ok))
    return name, outs, all(o for _, o in outs)


def main():
    wait_for_main()

    t0 = time.time()
    results = {}
    with ThreadPoolExecutor(max_workers=MAX_PAR) as ex:
        futs = [ex.submit(train_one, s) for s in TRAIN_SPECS]
        for f in futs:
            name, ok = f.result()
            results[name] = ok
    log(f'training finished in {(time.time() - t0) / 3600:.2f}h: {results}')

    eval_results = {}
    for name, owner, doa in EVAL_SPECS:
        n, outs, ok = eval_one(name, owner, doa)
        eval_results[n] = ok
    log(f'evaluation finished: {eval_results}')

    # all-positive / stratified metrics for the azimuth-emitting baselines,
    # which the localisation table (tab_strat) needs.
    for name in ('cascade_gccphat', 'cascade_srpphat'):
        npz = RES / 'baselines' / name / 'test' / 'test_predictions_test.npz'
        if not npz.exists():
            log(f'allpos {name}: missing {npz}')
            continue
        out = RES / 'baselines' / name / 'test_allpos.json'
        run([PY, 'paper_experiments/shared/code/eval_allpos_v7.py',
             '--pred', str(npz), '--varcol', str(D / 'test_varcol.tmp.list'),
             '--label', name, '--out', str(out)],
            f'extras_allpos_{name}.log', base_env(), retries=1)

    # Streaming validation for the selected main model (paper 3.2.2): strict
    # frame-by-frame decoder, 100 ms chunks -> equivalence + RTF for the model
    # that is actually shipped, not for the previous checkpoint.
    main_ck = ROOT / 'paper_experiments/main_experiment/best_cv.pt'
    main_cfg = ROOT / 'paper_experiments/main_experiment/config.yaml'
    if main_ck.exists() and main_cfg.exists():
        run([PY, 'paper_experiments/shared/code/streaming_model.py',
             '--checkpoint', str(main_ck), '--config', str(main_cfg),
             '--out', str(ROOT / 'paper_experiments/main_experiment/streaming_results.json'),
             '--test_data', str(D / 'test_spatial.list'),
             '--test_varcol', str(D / 'test_varcol.tmp.list'),
             '--limit', '300', '--chunk_ms', '100'],
            'extras_streaming.log', base_env(), retries=1)
    else:
        log(f'streaming: main model not found ({main_ck})')

    # rebuild the paper tables
    run([PY, 'paper_experiments/24h_plan/make_tables.py'],
        'extras_make_tables.log', base_env(), retries=0)
    (PLAN / 'EXTRAS_STATUS.json').write_text(
        json.dumps({'training': results, 'evaluation': eval_results,
                    'updated': time.strftime('%Y-%m-%d %H:%M:%S')},
                   indent=2, ensure_ascii=False), encoding='utf-8')
    log('extras finished')


if __name__ == '__main__':
    main()
