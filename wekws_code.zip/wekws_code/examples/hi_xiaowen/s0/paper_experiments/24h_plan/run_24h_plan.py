# -*- coding: utf-8 -*-
"""24h autonomous experiment pipeline for the final paper."""
import concurrent.futures as cf
import json
import os
import shutil
import subprocess
import sys
import tarfile
import time
from datetime import datetime
from pathlib import Path

import yaml

ROOT = Path('/242602/wekws/examples/hi_xiaowen_duolu/s0_deepseek_3')
PY = '/242602/conda/envs/wekws/bin/python'
P = ROOT / 'paper_experiments' / '24h_plan'
PACKED = ROOT / 'data_packed_v5_largeval'
VALDIR = ROOT / 'data_val10k'
LOGS = P / 'logs'
RESULTS = P / 'results'
CONFIGS = P / 'configs'
BASE = P / 'base_configs'
STATUS = P / 'STATUS.json'
BACKUP = ROOT / 'backup_before_cleanup_20261012.tar.gz'

for d in [P, LOGS, RESULTS, CONFIGS, BASE]:
    d.mkdir(parents=True, exist_ok=True)


def now():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def log(msg):
    line = f'[{now()}] {msg}'
    print(line, flush=True)
    with open(LOGS / 'orchestrator.log', 'a', encoding='utf-8') as f:
        f.write(line + '\n')


def write_status(stage, **kw):
    obj = {'updated': now(), 'stage': stage, 'pid': os.getpid()}
    obj.update(kw)
    STATUS.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str), encoding='utf-8')


def run(cmd, logname, env=None, retries=1, cwd=ROOT):
    logpath = LOGS / logname
    for attempt in range(retries + 1):
        with open(logpath, 'a', encoding='utf-8') as f:
            f.write(f'\n[{now()}] attempt {attempt+1}: {" ".join(map(str, cmd))}\n')
            p = subprocess.run([str(x) for x in cmd], cwd=str(cwd),
                               env=env, stdout=f, stderr=subprocess.STDOUT)
        if p.returncode == 0:
            return True
        log(f'FAIL {logname} rc={p.returncode} attempt={attempt+1}')
        time.sleep(10)
    return False


def wait_generation():
    write_status('waiting_validation_generation')
    while True:
        vc = VALDIR / 'eval_varcol.tmp.list'
        n = 0
        if vc.exists():
            with open(vc, encoding='utf-8') as f:
                n = sum(1 for _ in f)
        ps = subprocess.run(['pgrep', '-f', 'gen_multi_channel_wav.py.*data_val10k'],
                            capture_output=True, text=True)
        if n >= 10000 and ps.returncode != 0:
            log(f'validation generation complete: {n} lines')
            return
        log(f'waiting validation: {n}/10000 lines')
        time.sleep(60)


def prepare_validation_data():
    write_status('packing_validation')
    vc = VALDIR / 'eval_varcol.tmp.list'
    sp = VALDIR / 'eval_spatial.list'
    with open(vc, encoding='utf-8') as fin, open(sp, 'w', encoding='utf-8') as fout:
        for line in fin:
            p = line.split()
            if len(p) < 3:
                continue
            fout.write(' '.join([p[0], '2'] + p[1:]) + '\n')
    if not run([PY, 'paper_experiments/shared/code/pack_dataset.py',
                '--src', str(VALDIR), '--out', str(PACKED), '--splits', 'eval'],
               'pack_validation.log'):
        raise RuntimeError('pack validation failed')
    # Reuse the original train/test packed arrays.
    for stem in ['train_wav_i16.npy', 'train_offsets.npy', 'train_meta.json',
                 'test_wav_i16.npy', 'test_offsets.npy', 'test_meta.json']:
        src = ROOT / 'data_packed_v5' / stem
        dst = PACKED / stem
        if dst.exists() or dst.is_symlink():
            dst.unlink()
        dst.symlink_to(src)


def load_v6c_base():
    tar = tarfile.open(BACKUP)
    out = {}
    for name, key in [('code_duibi/configs/train_stream_stage1_v6c.yaml', 's1'),
                      ('code_duibi/configs/train_stream_stage2_v6c.yaml', 's2')]:
        f = tar.extractfile(name)
        out[key] = yaml.safe_load(f.read().decode('utf-8'))
    return out


def dump_yaml(obj, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        yaml.safe_dump(obj, f, allow_unicode=True, sort_keys=False)


def make_configs():
    base = load_v6c_base()
    dump_yaml(base['s1'], BASE / 'v6c_s1.yaml')
    dump_yaml(base['s2'], BASE / 'v6c_s2.yaml')
    import copy
    # Angle sweep.
    for step in [6, 8, 12, 15, 20, 30]:
        c1 = copy.deepcopy(base['s1']); c2 = copy.deepcopy(base['s2'])
        c2['relative_epochs'] = True
        c1['beam_step_deg'] = step; c2['beam_step_deg'] = step
        c1['train_conf']['max_epoch'] = 5; c2['train_conf']['max_epoch'] = 8
        dump_yaml(c1, CONFIGS / f'angles/step_{step}_s1.yaml')
        dump_yaml(c2, CONFIGS / f'angles/step_{step}_s2.yaml')
    # Lambda sweep.
    for lw in [0.0, 0.1, 0.3, 1.0]:
        c1 = copy.deepcopy(base['s1']); c2 = copy.deepcopy(base['s2'])
        c2['relative_epochs'] = True
        c1['lambda_wake'] = lw; c2['lambda_wake'] = lw
        c1['use_wake_head'] = bool(lw > 0); c2['use_wake_head'] = bool(lw > 0)
        c1['wake_detach'] = bool(lw > 0); c2['wake_detach'] = bool(lw > 0)
        # Keep the lambda sweep on exactly the same recipe as the
        # main-model candidates (angle sweep / ablation): 5 + 8 epochs.
        c1['train_conf']['max_epoch'] = 5; c2['train_conf']['max_epoch'] = 8
        dump_yaml(c1, CONFIGS / f'lambda/lw{lw:.1f}_s1.yaml')
        dump_yaml(c2, CONFIGS / f'lambda/lw{lw:.1f}_s2.yaml')
    # A1 dynamic query (mean_max only).
    c1 = copy.deepcopy(base['s1'])
    c1['query_mode'] = 'dynamic'; c1['pool_type'] = 'mean_max'
    c1['train_conf']['max_epoch'] = 8
    dump_yaml(c1, CONFIGS / 'ablation/A1_dynamic_s1.yaml')
    # A2 single microphone.
    c1 = copy.deepcopy(base['s1']); c2 = copy.deepcopy(base['s2'])
    c2['relative_epochs'] = True
    c1['num_mic'] = 1; c2['num_mic'] = 1
    c1['train_conf']['max_epoch'] = 5; c2['train_conf']['max_epoch'] = 8
    dump_yaml(c1, CONFIGS / 'ablation/A2_single_mic_s1.yaml')
    dump_yaml(c2, CONFIGS / 'ablation/A2_single_mic_s2.yaml')


def make_lambda_configs(angle):
    import copy
    base = load_v6c_base()
    for lw in [0.0, 0.1, 0.3, 1.0]:
        c1 = copy.deepcopy(base['s1']); c2 = copy.deepcopy(base['s2'])
        c2['relative_epochs'] = True
        c1['lambda_wake'] = lw; c2['lambda_wake'] = lw
        c1['use_wake_head'] = bool(lw > 0); c2['use_wake_head'] = bool(lw > 0)
        c1['wake_detach'] = bool(lw > 0); c2['wake_detach'] = bool(lw > 0)
        c1['beam_step_deg'] = angle; c2['beam_step_deg'] = angle
        c1['train_conf']['max_epoch'] = 5; c2['train_conf']['max_epoch'] = 8
        dump_yaml(c1, CONFIGS / f'lambda/lw{lw:.1f}_s1.yaml')
        dump_yaml(c2, CONFIGS / f'lambda/lw{lw:.1f}_s2.yaml')


def make_extra_ablation_configs(angle):
    import copy
    base = load_v6c_base()
    variants = {
        'A3_no_presence': {'use_presence_head': False, 'lambda_presence': 0.0},
        'A4_pool_attn': {'pool_type': 'attn'},
    }
    for tag, mods in variants.items():
        c1 = copy.deepcopy(base['s1']); c2 = copy.deepcopy(base['s2'])
        c2['relative_epochs'] = True
        c1['beam_step_deg'] = angle; c2['beam_step_deg'] = angle
        for k, v in mods.items():
            c1[k] = v; c2[k] = v
        c1['train_conf']['max_epoch'] = 5; c2['train_conf']['max_epoch'] = 8
        dump_yaml(c1, CONFIGS / f'ablation/{tag}_s1.yaml')
        dump_yaml(c2, CONFIGS / f'ablation/{tag}_s2.yaml')


def train_tag(tag, s1cfg, s2cfg, outdir):
    final_ck = Path(outdir)/('stage2/best_cv.pt' if (s2cfg is not None and Path(s2cfg).exists()) else 'stage1/best_cv.pt')
    if final_ck.exists():
        log(f'skip completed training {tag}')
        return tag, True
    env = os.environ.copy()
    cfg_meta = yaml.safe_load(open(s1cfg, encoding='utf-8'))
    num_mic_use = int(cfg_meta.get('num_mic', 2))
    env.update({'PYTHONPATH': str(ROOT), 'PACKED_DATA_DIR': str(PACKED),
                'KWS_NUM_MIC_USE': str(num_mic_use),
                'USE_BATCHED_FORWARD': '1', 'KWS_MAX_SEC': '3.0',
                'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1'})
    D = ROOT / 'paper_experiments/table1_corpus/data_lists'
    V = VALDIR
    common = ['--train_data', str(D/'train_spatial.list'), '--train_varcol', str(D/'train_varcol.tmp.list'),
              '--cv_data', str(V/'eval_spatial.list'), '--cv_varcol', str(V/'eval_varcol.tmp.list'),
              '--test_data', str(D/'test_spatial.list'), '--test_varcol', str(D/'test_varcol.tmp.list')]
    cmd1 = [PY, '-u', 'wekws/bin/train.py', '--config', str(s1cfg)] + common + \
           ['--model_dir', str(outdir/'stage1'), '--eval_interval', '1', '--gpus', '0', '--num_workers', '6']
    ok = run(cmd1, f'{tag}_s1.log', env=env, retries=1)
    if not ok:
        return tag, False
    if s2cfg is not None and Path(s2cfg).exists():
        cmd2 = [PY, '-u', 'wekws/bin/train.py', '--config', str(s2cfg)] + common + \
               ['--checkpoint', str(outdir/'stage1/best_cv.pt'), '--model_dir', str(outdir/'stage2'),
                '--eval_interval', '1', '--gpus', '0', '--num_workers', '6']
        ok = run(cmd2, f'{tag}_s2.log', env=env, retries=1)
    return tag, ok


def run_group(jobs, max_par=6, stagger=12):
    """jobs: list of (tag, s1cfg, s2cfg, outdir)."""
    with cf.ThreadPoolExecutor(max_workers=max_par) as ex:
        futs = []
        for j in jobs:
            futs.append(ex.submit(train_tag, *j))
            time.sleep(stagger)
        results = [f.result() for f in futs]
    return dict(results)


def eval_proposed(tag, ckpt, cfg, outdir, split='val'):
    outdir.mkdir(parents=True, exist_ok=True)
    D = ROOT / 'paper_experiments/table1_corpus/data_lists'
    V = VALDIR
    if split == 'val':
        data, var = V/'eval_spatial.list', V/'eval_varcol.tmp.list'
    else:
        data, var = D/'test_spatial.list', D/'test_varcol.tmp.list'
    fair = outdir / f'{split}_fair.json'
    allp = outdir / f'{split}_allpos.json'
    if allp.exists() and allp.stat().st_mtime >= Path(ckpt).stat().st_mtime:
        log(f'skip completed evaluation {tag} {split}')
        return json.loads(allp.read_text(encoding='utf-8'))
    env = os.environ.copy()
    env.update({'PYTHONPATH': str(ROOT), 'PACKED_DATA_DIR': str(PACKED),
                'USE_BATCHED_FORWARD': '1', 'KWS_MAX_SEC': '3.0'})
    cfg_meta = yaml.safe_load(open(cfg, encoding='utf-8'))
    num_mic_use = int(cfg_meta.get('num_mic', 2))
    cmd = [PY, 'paper_experiments/shared/code/eval_fair_cascade.py',
           '--varcol', str(var), '--test_data', str(data),
           '--proposed_ckpt', str(ckpt), '--proposed_config', str(cfg),
           '--num_mic', str(num_mic_use),
           '--pred_glob', 'paper_experiments/24h_plan/_none_/*.npz',
           '--out', str(fair)]
    if not run(cmd, f'eval_{tag}_{split}_fair.log', env=env, retries=1):
        return None
    npz = Path(ckpt).parent / 'test_predictions_fair.npz'
    cmd = [PY, 'paper_experiments/shared/code/eval_allpos_v7.py',
           '--pred', str(npz), '--varcol', str(var),
           '--label', f'{tag}_{split}', '--out', str(allp)]
    if not run(cmd, f'eval_{tag}_{split}_allpos.log', env=env, retries=1):
        return None
    return json.loads(allp.read_text(encoding='utf-8'))


def score_candidate(d):
    m = d['detection']; p = d['detected_positive']
    return {'auc': m['auc'], 'frr1h': m['frr@1h'], 'fpr05': m['fpr@0.5'],
            'loc': p['doa_acc'], 'mae': p['mae'],
            'score': m['auc'] * p['doa_acc']}


def select_best(summary, names):
    best = None
    for n in names:
        if n not in summary:
            continue
        s = summary[n]
        ok = s['auc'] >= 0.98 and s['loc'] >= 0.90
        key = (1 if ok else 0, s['score'])
        if best is None or key > best[0]:
            best = (key, n, s)
    return best


def main():
    try:
        wait_generation()
        prepare_validation_data()
        make_configs()

        # Angle sweep.
        angle_jobs = []
        for step in [6, 8, 12, 15, 20, 30]:
            angle_jobs.append((f'angle_{step}',
                               CONFIGS/f'angles/step_{step}_s1.yaml',
                               CONFIGS/f'angles/step_{step}_s2.yaml',
                               RESULTS/f'angles/step_{step}'))
        write_status('angle_training', jobs=[j[0] for j in angle_jobs])
        run_group(angle_jobs)
        angle_summary = {}
        for step in [6, 8, 12, 15, 20, 30]:
            tag = f'angle_{step}'
            outdir = RESULTS/f'angles/step_{step}'
            ck = outdir/'stage2/best_cv.pt'
            cfg = CONFIGS/f'angles/step_{step}_s2.yaml'
            if ck.exists():
                d = eval_proposed(tag, ck, cfg, outdir, 'val')
                if d: angle_summary[tag] = score_candidate(d)
        best_angle = select_best(angle_summary, list(angle_summary))
        (RESULTS/'angles/summary.json').write_text(json.dumps(angle_summary, indent=2), encoding='utf-8')
        write_status('angle_done', best_angle=best_angle, angle_summary=angle_summary)
        if best_angle is None:
            raise RuntimeError('no angle candidate')
        best_angle_name = best_angle[1]
        best_angle_step = int(best_angle_name.split('_')[1])

        # Lambda sweep (regenerate at the angle selected above so the
        # sweep matches the shipped model apart from lambda itself).
        make_lambda_configs(best_angle_step)
        lam_jobs = []
        for lw in [0.0, 0.1, 0.3, 1.0]:
            lam_jobs.append((f'lambda_{lw:.1f}',
                             CONFIGS/f'lambda/lw{lw:.1f}_s1.yaml',
                             CONFIGS/f'lambda/lw{lw:.1f}_s2.yaml',
                             RESULTS/f'lambda/lw{lw:.1f}'))
        write_status('lambda_training', jobs=[j[0] for j in lam_jobs])
        run_group(lam_jobs)
        lam_summary = {}
        for lw in [0.0, 0.1, 0.3, 1.0]:
            tag = f'lambda_{lw:.1f}'
            outdir = RESULTS/f'lambda/lw{lw:.1f}'
            ck = outdir/'stage2/best_cv.pt'
            cfg = CONFIGS/f'lambda/lw{lw:.1f}_s2.yaml'
            if ck.exists():
                d = eval_proposed(tag, ck, cfg, outdir, 'val')
                if d: lam_summary[tag] = score_candidate(d)
        (RESULTS/'lambda/summary.json').write_text(json.dumps(lam_summary, indent=2), encoding='utf-8')
        write_status('lambda_done', lambda_summary=lam_summary)

        # A1 dynamic and A2 single mic; A0/A9 reuse angle results.
        abl_jobs = []
        abl_jobs.append(('A1_dynamic', CONFIGS/'ablation/A1_dynamic_s1.yaml', None,
                         RESULTS/'ablation/A1_dynamic'))
        abl_jobs.append(('A2_single_mic', CONFIGS/'ablation/A2_single_mic_s1.yaml',
                         CONFIGS/'ablation/A2_single_mic_s2.yaml',
                         RESULTS/'ablation/A2_single_mic'))
        make_extra_ablation_configs(best_angle_step)
        for extra in ['A3_no_presence', 'A4_pool_attn']:
            abl_jobs.append((extra,
                             CONFIGS/f'ablation/{extra}_s1.yaml',
                             CONFIGS/f'ablation/{extra}_s2.yaml',
                             RESULTS/f'ablation/{extra}'))
        write_status('ablation_training', jobs=[j[0] for j in abl_jobs])
        run_group(abl_jobs)
        # A0 = best angle full model (already trained in angle sweep).
        a0_tag = f'A0_bestangle_{best_angle_step}'
        a0_dir = RESULTS/'ablation'/a0_tag
        shutil.copytree(RESULTS/f'angles/step_{best_angle_step}', a0_dir, dirs_exist_ok=True)
        # A9 = 30 degree coarse grid.
        a9_tag = 'A9_beam30'
        a9_dir = RESULTS/'ablation'/a9_tag
        shutil.copytree(RESULTS/'angles/step_30', a9_dir, dirs_exist_ok=True)

        abl_summary = {}
        for tag, ck, cfg in [
            (a0_tag, a0_dir/'stage2/best_cv.pt', CONFIGS/f'angles/step_{best_angle_step}_s2.yaml'),
            ('A1_dynamic', RESULTS/'ablation/A1_dynamic/stage1/best_cv.pt', CONFIGS/'ablation/A1_dynamic_s1.yaml'),
            ('A2_single_mic', RESULTS/'ablation/A2_single_mic/stage2/best_cv.pt', CONFIGS/'ablation/A2_single_mic_s2.yaml'),
            (a9_tag, a9_dir/'stage2/best_cv.pt', CONFIGS/'angles/step_30_s2.yaml'),
            ('A3_no_presence', RESULTS/'ablation/A3_no_presence/stage2/best_cv.pt', CONFIGS/'ablation/A3_no_presence_s2.yaml'),
            ('A4_pool_attn', RESULTS/'ablation/A4_pool_attn/stage2/best_cv.pt', CONFIGS/'ablation/A4_pool_attn_s2.yaml'),
        ]:
            if Path(ck).exists():
                d = eval_proposed(tag, ck, cfg, Path(ck).parent.parent, 'val')
                if d: abl_summary[tag] = score_candidate(d)
        (RESULTS/'ablation/summary.json').write_text(json.dumps(abl_summary, indent=2), encoding='utf-8')
        best_main = select_best(abl_summary, list(abl_summary))
        write_status('ablation_done', best_main=best_main, ablation_summary=abl_summary)
        if best_main is None:
            raise RuntimeError('no main-model candidate')

        # Copy selected main model out of comparison experiments.
        main_dir = ROOT/'paper_experiments/main_experiment'
        main_dir.mkdir(parents=True, exist_ok=True)
        main_tag = best_main[1]
        ck_map = {
            a0_tag: (a0_dir/'stage2/best_cv.pt', CONFIGS/f'angles/step_{best_angle_step}_s2.yaml'),
            'A1_dynamic': (RESULTS/'ablation/A1_dynamic/stage1/best_cv.pt', CONFIGS/'ablation/A1_dynamic_s1.yaml'),
            'A2_single_mic': (RESULTS/'ablation/A2_single_mic/stage2/best_cv.pt', CONFIGS/'ablation/A2_single_mic_s2.yaml'),
            a9_tag: (a9_dir/'stage2/best_cv.pt', CONFIGS/'angles/step_30_s2.yaml'),
            'A3_no_presence': (RESULTS/'ablation/A3_no_presence/stage2/best_cv.pt', CONFIGS/'ablation/A3_no_presence_s2.yaml'),
            'A4_pool_attn': (RESULTS/'ablation/A4_pool_attn/stage2/best_cv.pt', CONFIGS/'ablation/A4_pool_attn_s2.yaml'),
        }
        src_ck, src_cfg = ck_map[main_tag]
        shutil.copy2(src_ck, main_dir/'best_cv.pt')
        shutil.copy2(src_cfg, main_dir/'config.yaml')
        (main_dir/'selection.json').write_text(json.dumps({'main_tag': main_tag, 'metrics': best_main[2]}, indent=2), encoding='utf-8')

        # Evaluate main model on full test and build threshold table.
        test_dir = main_dir/'test'
        test_dir.mkdir(exist_ok=True)
        d_test = eval_proposed('main', main_dir/'best_cv.pt', main_dir/'config.yaml', test_dir, 'test')
        (main_dir/'test_metrics.json').write_text(json.dumps(d_test, indent=2), encoding='utf-8')
        write_status('main_selected', main_tag=main_tag, metrics=best_main[2], test=d_test)

        # Re-evaluate the retained comparison baselines on validation and test.
        baseline_names = ['mono', 'concat_mc', 'fixed_beam', 'fixed_beam3',
                          'kwt', 'bc_resnet', 'spatial_prior',
                          'cascade_gccphat', 'cascade_srpphat']
        D = ROOT / 'paper_experiments/table1_corpus/data_lists'
        V = VALDIR
        env = os.environ.copy()
        env.update({'PYTHONPATH': str(ROOT), 'USE_BATCHED_FORWARD': '1', 'KWS_MAX_SEC': '3.0'})
        write_status('baseline_reeval', baselines=baseline_names)
        for name in baseline_names:
            ck = ROOT / f'paper_experiments/table2_systems/results/{name}/best_cv.pt'
            if not ck.exists():
                continue
            for split, data, var in [
                ('val', V/'eval_spatial.list', V/'eval_varcol.tmp.list'),
                ('test', D/'test_spatial.list', D/'test_varcol.tmp.list'),
            ]:
                out = RESULTS / 'baselines' / name / split
                out.mkdir(parents=True, exist_ok=True)
                cmd = [PY, 'paper_experiments/shared/code/eval_only.py',
                       '--ckpt', str(ck), '--test_data', str(data), '--test_varcol', str(var),
                       '--out_dir', str(out), '--out_tag', split]
                run(cmd, f'baseline_{name}_{split}.log', env=env, retries=1)

        # Wake-threshold influence table for the selected main model.
        main_npz = main_dir / 'test_predictions_fair.npz'
        threshold_log = LOGS / 'threshold_sweep.log'
        cmd = [PY, 'paper_experiments/shared/code/threshold_sweep.py',
               '--pred', str(main_npz), '--varcol', str(D/'test_varcol.tmp.list'),
               '--out', str(main_dir/'threshold_sweep.json')]
        run(cmd, 'threshold_sweep.log', env=env, retries=1)
        write_status('completed', main_tag=main_tag, threshold=str(main_dir/'threshold_sweep.json'))
    except Exception as e:
        log(f'FATAL: {e!r}')
        write_status('failed', error=repr(e))
        raise


if __name__ == '__main__':
    main()
