# table2_systems — 主模型的对比系统

本目录保存用于评价主模型的对照系统配置与结果（`results/<name>/`：最终 checkpoint、
测试预测与 `results_v5.json`）。对照系统与主模型使用同一套语料与数据清单
（`table1_corpus/data_lists/`）。
