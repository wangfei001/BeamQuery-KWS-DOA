#!/bin/bash
# Copyright 2021  Binbin Zhang(binbzha@qq.com)
. ./path.sh
stage=$1
stop_stage=$2
num_keywords=2
config=conf/ds_tcn.yaml
norm_mean=true
norm_var=true
gpus="0"
checkpoint=
dir=exp/ds_tcn
num_average=30
score_checkpoint=

# ====================动态Query新增参数====================
aishell3_root="data/aishell-3"
spatial_data_dir=./data_spatial
spatial_exp_dir=exp/dynamic_query_exp
spatial_config=./conf/train_dynamic_query.yaml
max_aishell3_num=12000
# 此处只声明，默认值放在parse_options之后
# =========================================================

. tools/parse_options.sh || exit 1;

window_shift=50
# 【shell语法：等号两边绝对不能有空格】
# 阵列: 与 conf/train_dynamic_query.yaml / 原作者脚本一致 = 2 麦 8cm
# 阵列: 默认从 conf/train_dynamic_query.yaml 读取(单一真值来源)，避免"数据用A间距、
# 模型用B间距"这种不报错但会把波束指向算错的情况；命令行/env 显式指定时优先。
if [ -z "${num_mic}" ] || [ -z "${mic_spacing}" ]; then
  _mic_cfg=""
  for _py in python python3; do
    _mic_cfg=$($_py -c "
import yaml
c = yaml.safe_load(open('${spatial_config}'))
print(c.get('num_mic', 2), c.get('mic_spacing', 0.033))
" 2>/dev/null) || _mic_cfg=""
    [ -n "${_mic_cfg}" ] && break
  done
  if [ -n "${_mic_cfg}" ]; then
    num_mic=${num_mic:-$(echo ${_mic_cfg} | awk '{print $1}')}
    mic_spacing=${mic_spacing:-$(echo ${_mic_cfg} | awk '{print $2}')}
  fi
fi
num_mic=${num_mic:-2}
mic_spacing=${mic_spacing:-0.033}
# 可选透传给 tools/gen_multi_channel_wav.py：rir_mode(direct 复现旧的直达声数据)
# t60(覆盖配置里的 T60)；留空则都用 conf/train_dynamic_query.yaml 的值
rir_mode=
t60=
angle_num=${angle_num:-3}
sr=${sr:-16000}

echo "INFO: stage=${stage}, stop_stage=${stop_stage}, num_mic=${num_mic}, mic_spacing=${mic_spacing}, doa_num_class=${angle_num} (0:0-60, 1:60-120, 2:120-180)"

if [ "${angle_num}" -ne 3 ]; then
  echo "ERROR: 当前只支持3个粗方位DOA类别，angle_num=${angle_num}"
  exit 1
fi

if [ ${stage} -le -1 ] && [ ${stop_stage} -ge -1 ]; then
  echo "Download and extracte all datasets"
  local/mobvoi_data_download.sh --dl_dir $download_dir
fi

if [ ${stage} -le 0 ] && [ ${stop_stage} -ge 0 ]; then
  echo "Preparing datasets..."
  mkdir -p dict
  echo "<FILLER> -1" > dict/dict.txt
  echo "<HI_XIAOWEN> 0" >> dict/dict.txt
  echo "<NIHAO_WENWEN> 1" >> dict/dict.txt
  awk '{print $1}' dict/dict.txt > dict/words.txt
  for folder in train dev test; do
    mkdir -p data/$folder
    for prefix in p n; do
      mkdir -p data/${prefix}_$folder
      json_path=$download_dir/mobvoi_hotword_dataset_resources/${prefix}_$folder.json
      local/prepare_data.py $download_dir/mobvoi_hotword_dataset $json_path \
        dict/dict.txt data/${prefix}_$folder
    done
    cat data/p_$folder/wav.scp data/n_$folder/wav.scp > data/$folder/wav.scp
    cat data/p_$folder/text data/n_$folder/text > data/$folder/text
    rm -rf data/p_$folder data/n_$folder
  done
fi

if [ ${stage} -le 1 ] && [ ${stop_stage} -ge 1 ]; then
  echo "Format datasets"
  # CMVN 只被已移除的 DSTCN 基线使用；主模型在模型内部完成特征提取与归一化，
  # 因此仅在对应配置存在时才计算 CMVN。
  if [ -f "$config" ]; then
    tools/compute_cmvn_stats.py --num_workers 16 --train_config $config \
      --in_scp data/train/wav.scp \
      --out_cmvn data/train/global_cmvn
  fi
  for x in train dev test; do
    tools/wav_to_duration.sh --nj 16 data/$x/wav.scp data/$x/wav.dur
    tools/make_list.py data/$x/wav.scp data/$x/text \
      data/$x/wav.dur data/$x/data.list
  done
fi

# stage 2 / 3 / 4 原为 DSTCN 基线的「训练 / 模型平均+评分 / 导出」；
# 基线与对应配置已移除，主模型的训练与评测见 stage 6 / 7。

# ====================== stage5‑8 空间流水线【只保留一份！删除旧stage5片段】======================
if [ ${stage} -le 5 ] && [ ${stop_stage} -ge 5 ]; then
    # 注意: 不要再覆盖 num_mic/mic_spacing，保持与配置文件一致
    sr=16000
    spatial_data_dir=./data/spatial

    mkdir -p ${spatial_data_dir}/train_wav
    mkdir -p ${spatial_data_dir}/cv_wav
    mkdir -p ${spatial_data_dir}/test_wav

    # 每份数据条数和最小角度间隔由 ${spatial_config} 的 data_gen 配置控制

    # train set seed=666
    python ./tools/gen_multi_channel_wav.py \
        --config ${spatial_config} \
        --wav_scp ./data/train/wav.scp \
        --text_scp ./data/train/text \
        --out_wav_dir ${spatial_data_dir}/train_wav \
        --out_temp_list ${spatial_data_dir}/train_varcol.tmp.list \
        --num_mic ${num_mic} \
        --mic_spacing ${mic_spacing} \
        --sr ${sr} \
        --num_workers ${spatial_gen_nj:-8} \
        --seed 666 \
        ${rir_mode:+--rir_mode ${rir_mode}} \
        ${t60:+--t60 ${t60}}

    python ./tools/append_doa_to_list.py \
        --in_list ${spatial_data_dir}/train_varcol.tmp.list \
        --out_list ${spatial_data_dir}/train_spatial.list \
        --num_mic ${num_mic}

    # cv set seed=888
    if [ -f ./data/dev/wav.scp ] && [ -f ./data/dev/text ]; then
        echo "===== generate cv spatial dataset ====="
        python ./tools/gen_multi_channel_wav.py \
            --config ${spatial_config} \
            --wav_scp ./data/dev/wav.scp \
            --text_scp ./data/dev/text \
            --out_wav_dir ${spatial_data_dir}/cv_wav \
            --out_temp_list ${spatial_data_dir}/cv_varcol.tmp.list \
            --num_mic ${num_mic} \
            --mic_spacing ${mic_spacing} \
            --sr ${sr} \
            --num_workers ${spatial_gen_nj:-8} \
            --seed 888 \
            ${rir_mode:+--rir_mode ${rir_mode}} \
            ${t60:+--t60 ${t60}}

        python ./tools/append_doa_to_list.py \
            --in_list ${spatial_data_dir}/cv_varcol.tmp.list \
            --out_list ${spatial_data_dir}/cv_spatial.list \
            --num_mic ${num_mic}
    else
        echo "WARNING: cv wav.scp/text not found, skip cv spatial generation, please run stage0‑4 first"
    fi

    # test set seed=999
    if [ -f ./data/test/wav.scp ] && [ -f ./data/test/text ]; then
        echo "===== generate test spatial dataset ====="
        python ./tools/gen_multi_channel_wav.py \
            --config ${spatial_config} \
            --wav_scp ./data/test/wav.scp \
            --text_scp ./data/test/text \
            --out_wav_dir ${spatial_data_dir}/test_wav \
            --out_temp_list ${spatial_data_dir}/test_varcol.tmp.list \
            --num_mic ${num_mic} \
            --mic_spacing ${mic_spacing} \
            --sr ${sr} \
            --num_workers ${spatial_gen_nj:-8} \
            --seed 999 \
            ${rir_mode:+--rir_mode ${rir_mode}} \
            ${t60:+--t60 ${t60}}

        python ./tools/append_doa_to_list.py \
            --in_list ${spatial_data_dir}/test_varcol.tmp.list \
            --out_list ${spatial_data_dir}/test_spatial.list \
            --num_mic ${num_mic}
    else
        echo "WARNING: test wav.scp/text not found, skip test spatial generation, please run stage0‑4 first"
    fi

fi

if [ ${stage} -le 6 ] && [ ${stop_stage} -ge 6 ]; then
  python ./wekws/bin/train.py \
    --config ${spatial_config} \
    --train_data ./data/spatial/train_spatial.list \
    --train_varcol ./data/spatial/train_varcol.tmp.list \
    --cv_data ./data/spatial/cv_spatial.list \
    --cv_varcol ./data/spatial/cv_varcol.tmp.list \
    --model_dir ./exp/spatial_model \
    --tensorboard_dir ./tensorboard/spatial \
    --eval_interval ${spatial_eval_interval:-1} \
    --test_data ./data/spatial/test_spatial.list \
    --test_varcol ./data/spatial/test_varcol.tmp.list \
    --gpus 0 \
    --num_workers 8
  if [ $? -ne 0 ]; then
    echo "ERROR: stage6 训练失败(见上面日志)，请先解决报错"; exit 1
  fi
  echo "stage6 完成。评测产物: exp/spatial_model/eval_epoch*_cv.txt (每轮cv), eval_best_test.txt (结束时test), best_cv.pt (cv最优模型)"
fi




# ====================== stage7：dynamic-query 空间模型配套评测(可选/仅手动重评) ======================
# 说明：stage6 训练内部已经自动评测(cv 每轮 + test 训练结束时一次)，并写
#       exp/spatial_model/eval_epoch{N}_cv.* 与 eval_best_test.*。
#       stage7 只是“用 best_cv.pt 再单独重评一次”(写 eval_cv.*/eval_test.*)，
#       若紧跟 stage6 执行会重复计算；平时用 `bash run.sh 6 6` 即可，
#       只有在“想重评但不重新训练”时才单独跑 `bash run.sh 7 7`。
# 指标：唤醒率 / 虚警率 / 定位准确率 / 平均角度误差，含阈值扫描 txt+csv
if [ ${stage} -le 7 ] && [ ${stop_stage} -ge 7 ]; then
  echo "################# stage7: dynamic-query 评测(唤醒率/虚警/定位) #################"
  spatial_eval_ckpt=./exp/spatial_model/best_cv.pt
  if [ -f ${spatial_eval_ckpt} ]; then
    python wekws/bin/eval_dynamic_query.py \
      --config ${spatial_config} \
      --checkpoint ${spatial_eval_ckpt} \
      --test_data ./data/spatial/cv_spatial.list \
      --test_varcol ./data/spatial/cv_varcol.tmp.list \
      --output_prefix ./exp/spatial_model/eval_cv \
      --gpus 0 \
      --num_workers 4 || { echo "ERROR: stage7 cv 评测失败"; exit 1; }

    python wekws/bin/eval_dynamic_query.py \
      --config ${spatial_config} \
      --checkpoint ${spatial_eval_ckpt} \
      --test_data ./data/spatial/test_spatial.list \
      --test_varcol ./data/spatial/test_varcol.tmp.list \
      --output_prefix ./exp/spatial_model/eval_test \
      --gpus 0 \
      --num_workers 4 || { echo "ERROR: stage7 test 评测失败"; exit 1; }
  else
    echo "WARNING: ${spatial_eval_ckpt} 不存在，请先运行 stage6 训练（会自动生成 best_cv.pt）"
  fi
fi


# ====================== stage8：旧的分类KWS评测(默认禁用) ======================
# 该段是给旧的关键词分类模型写的：average_model --val_best 需要 epoch_*.yaml、
# 目录用 exp/dynamic_query_exp、score.py/compute_det 接口都是逐帧关键词后验，
# 与 dynamic-query 模型(s_q + 3类粗方位DOA)不兼容，而且功能与 stage6/stage7 重复。
# 默认跳过；确需回看旧流程时用: spatial_enable_legacy_stage8=1 bash run.sh 8 8
if [ "${spatial_enable_legacy_stage8:-0}" = "1" ] && [ ${stage} -le 8 ] && [ ${stop_stage} -ge 8 ]; then
  echo "################# stage8: spatial model evaluate (legacy) #################"
  spatial_score_ckpt=${spatial_exp_dir}/avg_30.pt
  python wekws/bin/average_model.py \
    --dst_model ${spatial_score_ckpt} \
    --src_path ${spatial_exp_dir} \
    --num ${num_average} \
    --val_best

  spatial_result_dir=${spatial_exp_dir}/test_spatial_$(basename ${spatial_score_ckpt})
  mkdir -p ${spatial_result_dir}

  python wekws/bin/score.py \
    --config ${spatial_exp_dir}/config.yaml \
    --test_data ${spatial_data_dir}/test_spatial.list \
    --gpu 0 \
    --batch_size 128 \
    --checkpoint ${spatial_score_ckpt} \
    --score_file ${spatial_result_dir}/score.txt \
    --dict ./dict \
    --num_workers 4

  for keyword in `tail -n +2 dict/words.txt`; do
    python wekws/bin/compute_det.py \
      --keyword $keyword \
      --test_data ${spatial_data_dir}/test_spatial.list \
      --window_shift $window_shift \
      --score_file ${spatial_result_dir}/score.txt \
      --stats_file ${spatial_result_dir}/stats.${keyword}.txt
  done

  python wekws/bin/plot_det_curve.py \
    --keywords_dict dict/dict.txt \
    --stats_dir  ${spatial_result_dir} \
    --xlim 2 \
    --x_step 1 \
    --ylim 5 \
    --y_step 1 \
    --figure_file ${spatial_result_dir}/det.png

  echo "Spatial evaluation done, result: ${spatial_result_dir}"
fi
