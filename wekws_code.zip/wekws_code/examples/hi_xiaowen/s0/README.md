# 主模型 recipe — examples/hi_xiaowen/s0

本目录是 **BeamQuery** 主模型的运行 recipe。创新点见仓库根 `README.md`。

| 路径 | 内容 |
|---|---|
| `run.sh` | 数据准备 / 多通道仿真 / 主模型训练与评测入口（stage -1、0、1、5、6、7） |
| `conf/train_dynamic_query.yaml` | 主模型 + 阵列 + RIR 仿真配置（单一真值来源） |
| `tools/` | `gen_multi_channel_wav.py`（多通道 + 房间 RIR 生成）、`append_doa_to_list.py`、`check_room_rir.py`（RIR/方位约定校验）、`compute_cmvn_stats.py`、`make_list.py` 等 |
| `local/` | Mobvoi Hotwords 语料下载与清单生成 |
| `paper_experiments/main_model/` | **主模型代码**（训练 / 评测 / 流式入口 + 配置） |
| `paper_experiments/table3_angle/`、`table4_lambda/`、`table5_ablation/` | 主模型的波束网格 Δ、λ_wake、组件消融 |
| `paper_experiments/table6_detection/` 至 `table10_streaming/` | 主模型的检测 / 定位 / 阈值 / 流式评测 |
| `paper_experiments/table1_corpus/` | 主模型训练与评测用的语料与数据清单 |
| `paper_experiments/shared/` | 主模型训练/评测调用的公共库 |
| `wekws/` | 框架副本（含主模型运行时模块 `model/spatial_dynamic_query.py`、`utils/room_rir.py`、`dataset/spatial_kws_dataset.py`） |

运行：

```bash
. ./path.sh

download_dir=data/download bash run.sh -1 -1   # 语料下载解压
bash run.sh 0 1                                # 数据准备 + CMVN + 列表
bash run.sh 5 5                                # 多通道 + 房间 RIR 仿真
bash run.sh 6 6                                # 主模型训练
bash run.sh 7 7                                # 主模型评测

bash paper_experiments/main_model/train.sh     # 主模型两阶段训练（推荐）
python paper_experiments/main_model/eval.py    # 全测试集指标
python paper_experiments/main_model/run_streaming.py   # 严格流式
```

> stage 号必须写在最前：`bash run.sh 5 5 --rir_mode direct`
