#!/usr/bin/env python3
# Copyright (c) 2026
# Licensed under the Apache License, Version 2.0 (the "License");
"""
stage5：生成多麦克风多声源仿真数据集
规则：
1. max_src = num_mic：1mic最多1声源；2mic最多2声源；3mic最多3声源
2. 角度范围0~180，按粗方位分为3类：0:[0,60), 1:[60,120), 2:[120,180]；
   同一条样本内每个声源占用不同粗方位类别，且任意两个声源角度间隔>10°。
3. 正样本：1个唤醒词 + 0~max_src‑1路干扰；负样本：1~max_src路干扰，无唤醒词
4. 每个声源经**房间冲激响应(RIR)** 卷积后再按 SIR=0dB 混合。
   RIR 由镜像法生成(见 wekws/utils/room_rir.py)，默认含墙面反射与混响
   (T60 默认 0.4s，可标量或列表做多条件)，可选加性噪声(noise_snr_db)。
   rir_mode=direct 时退化为旧的"自由场直达声冲激"版本(仅作消融/复现旧结果)。
5. 声源位置：距阵列中心 source_distance_range 米、方位角 theta(0~180°，
   theta 与模型端 tau_m = x_m·cos(theta)/c 严格一致，由 check_room_rir.py 校验)。
6. 默认每份数据生成约2000条：正样本最多1000条，负样本最多1000条。
输出临时list：wav_path label n_src doa0 doa1 doa2
无效槽位填充-100，DOA已经映射为0/1/2三个类别id
"""
import argparse
import hashlib
import math
import os
import random
import sys
from collections import OrderedDict
from concurrent.futures import ProcessPoolExecutor

import numpy as np
import torch
import torchaudio
import yaml

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:      # 保证多进程(spawn)子进程也能 import wekws
    sys.path.insert(0, _REPO_ROOT)

from wekws.utils.room_rir import (  # noqa: E402
    build_simulator, missing_backend_dependency, vertical_z_factor_bounds)


NUM_DOA_CLASSES = 3
DOA_CLASS_RANGES = ((0, 60), (60, 120), (120, 180))
MIN_ANGLE_GAP_DEG = 10
DEFAULT_NUM_SAMPLES = 2000
DEFAULT_POSITIVE_RATIO = 0.5


def angle_to_class(phys_deg: int):
    """物理角度0~180 -> 3类粗方位：0:[0,60), 1:[60,120), 2:[120,180]。"""
    if phys_deg < 0 or phys_deg > 180:
        raise ValueError(f"物理角度超出范围[0,180]: {phys_deg}")
    if phys_deg < 60:
        return 0
    if phys_deg < 120:
        return 1
    return 2


def _angles_are_separated(angles, gap_min: int):
    """线阵角度不是圆周角度，使用绝对角度间隔。"""
    for i in range(len(angles)):
        for j in range(i):
            if abs(angles[i] - angles[j]) <= gap_min:
                return False
    return True


def sample_angles(num_need: int, angle_min: int = 0, angle_max: int = 180, gap_min: int = MIN_ANGLE_GAP_DEG):
    """采样一组角度，两两绝对夹角 > gap_min，增加防死循环保护。"""
    angles = []
    max_retry = 10000
    retry_cnt = 0
    while len(angles) < num_need and retry_cnt < max_retry:
        cand = random.randint(angle_min, angle_max)
        if _angles_are_separated(angles + [cand], gap_min):
            angles.append(cand)
        retry_cnt += 1
    assert len(angles) == num_need, f"无法采样满足角度间隔{gap_min}的{num_need}个角度"
    return angles


def sample_angles_by_class(num_need: int, gap_min: int = MIN_ANGLE_GAP_DEG):
    _lib = _ensure_rir_lib().get(_RIR_LIB_SPLIT) if _ensure_rir_lib() else None
    if _lib is not None:
        for _ in range(200):
            cand = [random.choice(_lib["angles_by_class"][c])["theta"]
                    for c in random.sample([0, 1, 2], num_need)] if num_need <= 3 \
                else [random.choice(_lib["by_theta"]) for _ in range(num_need)]
            cand = [int(x) for x in cand]
            if _angles_are_separated(cand, gap_min):
                return cand
    """从3个粗方位类别中不重复抽取类别，并在类别内采样物理角度。

    约束：
    1. 任意两个物理角度间隔严格大于 gap_min，默认 >10°；
    2. 同一条训练样本中每个声源占用不同DOA类别，避免后续KWS目标槽位
       和DOA目标槽位产生类别歧义。
    """
    assert 1 <= num_need <= NUM_DOA_CLASSES, (
        f"声源数必须在[1,{NUM_DOA_CLASSES}]内, 当前={num_need}"
    )
    max_retry = 10000
    for _ in range(max_retry):
        class_ids = random.sample(range(NUM_DOA_CLASSES), num_need)
        angles = []
        for cid in class_ids:
            lo, hi = DOA_CLASS_RANGES[cid]
            # 除最后一类外使用左闭右开区间；最后一类包含180°
            cand = random.randint(lo, hi) if cid == NUM_DOA_CLASSES - 1 else random.randint(lo, hi - 1)
            angles.append(cand)
        if _angles_are_separated(angles, gap_min):
            return angles
    raise RuntimeError(
        f"无法采样{num_need}个不同粗方位类别且物理间隔>{gap_min}°的角度"
    )


def generate_array_rir(angle_deg: int, num_mic: int, mic_spacing: float, sr: int, speed_sound: float = 340.0):
    """均匀线阵自由场RIR，仅直达声无时域混响。
    以最早到达的麦克风为时间零点，把所有通道时延统一平移到非负区间，
    避免负相对时延对应的麦克风整路静音（修复原实现只保留一半通道的问题）。
    """
    angle_rad = math.radians(angle_deg)
    rir_len = 256
    rir_tensor = torch.zeros((num_mic, rir_len), dtype=torch.float32)
    positions = []
    delays = []
    for mic_idx in range(num_mic):
        pos_x = (mic_idx - (num_mic - 1) / 2.0) * mic_spacing
        positions.append(pos_x)
        tau = pos_x * math.cos(angle_rad) / speed_sound
        delays.append(tau * sr)
    offset = -min(delays)  # >=0：保证所有麦克风都落在因果区间
    for mic_idx, sample_delay in enumerate(delays):
        sample_delay = sample_delay + offset
        delay_int = int(math.floor(sample_delay))
        frac = sample_delay - delay_int
        amp = 1.0 / (1.0 + abs(positions[mic_idx]))
        if 0 <= delay_int < rir_len - 1:
            rir_tensor[mic_idx, delay_int] = amp * (1.0 - frac)
            rir_tensor[mic_idx, delay_int + 1] = amp * frac
    return rir_tensor


def convolve_rir(single_audio: torch.Tensor, rir: torch.Tensor) -> torch.Tensor:
    """稀疏RIR快速卷积（直接延时叠加）。

    RIR 每个麦克风只有少量非零抽头。对抽头 (d, amp)：
        out[t + d] += amp * x[t]
    这和直接与RIR做线性卷积等价，但不用做长度256的全核卷积。
    输出长度固定为 T+L-1，尾部保留零填充。
    """
    M, L = rir.shape
    T = single_audio.shape[-1]
    audio_mc = torch.zeros((M, T + L - 1), dtype=single_audio.dtype)
    for mic_idx in range(M):
        # 取出该麦 RIR 的非零抽头 (delay, amp)，逐抽头做延时加权叠加
        nz = torch.nonzero(rir[mic_idx], as_tuple=False)
        for tap in nz:
            d = int(tap[0])
            amp = rir[mic_idx, d].item()
            # 标准RIR卷积：RIR抽头在d处，则输入x整体延时d。
            e = d
            audio_mc[mic_idx, e:e + T].add_(single_audio[0] * amp)
    return audio_mc


def _fit_len(x, T, rng):
    """把单路信号裁成/循环填充成恰好 T 个样本。

    随机裁剪（而非从头截断）保证"内容长度"与位置都不携带标签信息；
    过短时循环填充（而非补零），避免引入"静音尾巴"这一可学捷径。
    """
    n = x.shape[-1]
    if n == 0:
        return torch.zeros(*x.shape[:-1], T, dtype=x.dtype, device=x.device)
    if n >= T:
        off = int(rng.integers(0, n - T + 1))
        return x[..., off:off + T]
    reps = int(math.ceil(T / n))
    idx = torch.arange(T, device=x.device) % n
    return x[..., idx]


def _active_power(s, frame=512, hop=256, thresh_db=35.0):
    """只统计"有音频的帧"的平均功率。

    按整段(含静音)求 mean(s^2) 会把含静音多的那一路的语音段放大，
    使实际 SIR 偏离设定值(实测正负样本电平线索 AUC≈0.73)。
    这里先逐帧算能量，保留比峰值低 thresh_db 以内的帧(=有效语音)，
    再用这些帧的平均功率做归一 —— 使各路"有效语音段"功率相等，
    SIR 才是真正的信干比。
    """
    x = s.mean(dim=0) if s.dim() > 1 else s          # [T]
    T = x.shape[-1]
    if T < frame:
        return torch.mean(x ** 2) + 1e-8
    fr = x.unfold(0, frame, hop)                     # [nf, frame]
    p = (fr ** 2).mean(dim=-1)
    pdb = 10.0 * torch.log10(p + 1e-12)
    keep = pdb > (pdb.max() - thresh_db)
    if int(keep.sum()) < 3:
        keep = pdb > (pdb.max() - 60.0)
    if int(keep.sum()) < 1:
        return torch.mean(x ** 2) + 1e-8
    return p[keep].mean() + 1e-8


def mix_multi_sir0db(signals_mc, target_len=None, rng=None, sir_db=None,
                     power_mode="full"):
    """多通道多声源混合。

    逻辑：
    1) 每一路先按“自身有效语音段”的平均功率归一化（各路 RMS 相等，
       任意两路之间近似 SIR=0dB）；
    2) 各路补零到 batch 内最长后再等权相加；
    3) 相加后整体峰值可能 >1，写 wav 前统一限幅到 0.99，防止 int16 削波。

    注意：功率归一必须在补零之前完成——若先补零再对整段求 mean，
    短句会被尾部大量零稀释、功率被低估，从而被错误放大，SIR 不再等于 0dB。
    """
    if len(signals_mc) == 0:
        return None
    if rng is None:
        rng = np.random.default_rng()
    # ===== 关键修复（时长捷径）=====
    # 原实现把各路补零到 batch 内最长（T_max = max(源长)），而唤醒词片段天然比
    # FILLER 片段短，于是"混合后长度"与标签相关；截断到固定窗口后，
    # 正样本更容易出现静音尾（实测尾部/头部能量比 0.0063 vs 0.0897）。
    # 现改为：所有源都裁/填到同一个目标长度 target_len，
    # 使"内容长度"与"静音占比"在正负样本间完全不可区分。
    if target_len is None:
        target_len = int(rng.uniform(2.5, 3.0) * 16000)
    signals_mc = [_fit_len(s, target_len, rng) for s in signals_mc]
    scaled_list = []
    T_max = target_len
    # SIR(信干比)：第 0 路为主声源(目标)，其余各路按 10^(-SIR/20) 缩放。
    # sir_db=None 时退化为"等功率叠加(=0dB SIR)"的旧行为。
    _g = 1.0 if sir_db is None else 10.0 ** (-float(sir_db) / 20.0)
    for _i, s in enumerate(signals_mc):
        # power_mode="active": 只统计有效语音帧(静音不计)，SIR 才准确
        power = (_active_power(s) if power_mode == "active"
                 else torch.mean(s ** 2) + 1e-8)
        s_scaled = s / torch.sqrt(power)  # 归一后该路平均功率 = 1
        if _i > 0 and sir_db is not None:
            s_scaled = s_scaled * _g
        # 归一化之后再补零到最长长度，供后面等权叠加
        s_pad = torch.nn.functional.pad(s_scaled, (0, T_max - s.shape[-1]))
        scaled_list.append(s_pad)
    # K 路等功率叠加：各路相对混合总功率 = 1/K（两两之间 SIR≈0dB）
    out = torch.zeros_like(scaled_list[0])
    for s in scaled_list:
        out += s
    # 整体限幅：叠加后峰值 >1 的部分会被 wav 编码截断(削波)，
    # 这里把峰值压到 0.99，保留少量 headroom；缩放不改变各路相对比例。
    peak = out.abs().max()
    if peak > 1.0:
        out = out * (0.99 / peak)
    return out


# stage5 提速：同一干扰音频常被多条混合重复加载。
# 这里做“按路径缓存 + 简单FIFO逐出”，避免每次都对同一文件重新读盘/解码。
_audio_cache = {}
_AUDIO_CACHE_LIMIT = 2048


def convolve_rir_fft(audio: torch.Tensor, rir: torch.Tensor) -> torch.Tensor:
    """FFT 线性卷积：audio [1,T] 与 rir [M,L] → [M, T+L-1]。

    房间 RIR 长度可达上万抽头(如 0.4s @16k = 6400+)，用稀疏抽头循环卷积
    会非常慢，这里统一走 FFT。
    """
    a = audio.reshape(-1)
    t_len, r_len = int(a.shape[-1]), int(rir.shape[-1])
    out_len = t_len + r_len - 1
    nfft = 1 << int(math.ceil(math.log2(out_len)))
    spec_a = torch.fft.rfft(a, n=nfft)
    spec_r = torch.fft.rfft(rir.to(torch.float32), n=nfft, dim=-1)
    y = torch.fft.irfft(spec_r * spec_a.unsqueeze(0), n=nfft, dim=-1)
    return y[:, :out_len]


def _t60_key(t60) -> float:
    return round(float(t60), 4)


def _seed_from_text(text: str) -> int:
    """由输出文件名派生稳定随机种子(与多进程调度顺序无关)。"""
    return int(hashlib.md5(str(text).encode("utf-8")).hexdigest()[:8], 16)


def _validate_placement(cfg) -> None:
    """确认 source_distance_range 在 0~180° 全方向都落在房间内。"""
    from wekws.utils.room_rir import validate_placement
    for t60 in cfg["t60_values"]:
        sim = cfg["sims"][_t60_key(t60)]
        bad = validate_placement(sim, cfg["distance_range"],
                                 cfg["height_jitter"])
        if bad:
            raise ValueError(
                "声源会超出房间，请缩小 data_gen.room_rir.source_distance_range "
                f"或调整 array_center (T60={t60})。示例越界点: {bad[0]}")


def _rir_disk_path(key):
    """RIR 磁盘库路径；设置环境变量 RIR_CACHE_DIR 后启用。

    RIR 只由量化键 (t60, theta, distance, z_factor, y_sign) 决定，但可能在
    多个样本 / 多个 worker 进程 / 多次运行(train,cv,test)中被反复请求。
    内存 LRU 只在单进程内有效，多进程下同一 RIR 会被重复计算几十次；
    落到磁盘后每个键全局只计算一次。
    """
    d = os.environ.get("RIR_CACHE_DIR", "").strip()
    if not d:
        return None
    h = hashlib.md5(repr(key).encode("utf-8")).hexdigest()
    return os.path.join(d, f"{h}.npy")


def _get_room_rir(theta: float, distance: float, z_factor: float,
                  y_sign: float, t60) -> torch.Tensor:
    """取(或生成)房间 RIR：内存 LRU + 可选磁盘共享库。"""
    cfg = _WORKER_CFG
    sim = cfg["sims"][_t60_key(t60)]
    # cache_key 同时是"量化后的生成参数"，保证缓存内容与键严格对应
    key = (_t60_key(t60),) + sim.cache_key(theta, distance, z_factor, y_sign)
    cache = cfg["rir_cache"]
    if key in cache:
        cache.move_to_end(key)
        return cache[key]

    # ---- 磁盘共享库命中 ----
    path = _rir_disk_path(key)
    if path is not None and os.path.exists(path):
        try:
            tensor = torch.from_numpy(np.load(path))
            cache[key] = tensor
            return tensor
        except Exception:
            pass  # 损坏/正在写入 -> 退回计算

    # ---- 未命中：真正计算一次 ----
    rir = sim.rir(key[1], key[2], key[3], key[4])
    tensor = torch.from_numpy(rir)

    if path is not None:
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            tmp = f"{path}.{os.getpid()}.tmp.npy"
            np.save(tmp, tensor.numpy())
            os.replace(tmp, path)   # 原子替换，多进程并发安全
        except Exception:
            pass

    cache[key] = tensor
    if len(cache) > cfg["cache_size"]:
        cache.popitem(last=False)
    return tensor



# ==================== RIR 库模式 (RIR_LIB_MANIFEST) ====================
# 启用后：方位角与几何不再从连续分布随机抽，而是从预生成 RIR 库的 manifest
# 中采样 —— 保证"共用同一 RIR 的音频共用同一声学场景与方位标签"。
_RIR_LIB = None
_RIR_LIB_SPLIT = os.environ.get("RIR_LIB_SPLIT", "train")


def _ensure_rir_lib():
    """按需载入 manifest；返回 {split: {'angles_by_class':..., 'by_theta':...}}"""
    global _RIR_LIB
    if _RIR_LIB is not None:
        return _RIR_LIB
    path = os.environ.get("RIR_LIB_MANIFEST", "").strip()
    if not path:
        _RIR_LIB = {}
        return _RIR_LIB
    import json as _json
    lib = {}
    for split in ("train", "eval", "test"):
        f = os.path.join(path, f"manifest_{split}.json")
        if not os.path.exists(f):
            continue
        d = _json.load(open(f, encoding="utf-8"))
        by_cls, by_th = {0: [], 1: [], 2: []}, {}
        for sc in d["scenes"]:
            by_cls[sc["class"]].append(sc)
            by_th.setdefault(int(sc["theta"]), sc)
        lib[split] = {"angles_by_class": by_cls, "by_theta": by_th,
                      "t60_values": d["t60_values"]}
    _RIR_LIB = lib
    if lib:
        print("RIR 库已载入:", {k: sum(len(v) for v in d["angles_by_class"].values())
                                for k, d in lib.items()})
    return _RIR_LIB

def _add_noise(mix: torch.Tensor, snr_db, seed_text: str) -> torch.Tensor:
    """按目标 SNR 加入噪声(可选)。

    noise_mode=white: 各通道独立白噪声(空间不相干)；
    noise_mode=point: 随机位置点噪声源经房间 RIR(空间相干，更接近干扰声源)。
    """
    if snr_db is None:
        return mix
    cfg = _WORKER_CFG
    m = mix.shape[0]
    gen = torch.Generator().manual_seed(_seed_from_text("noise:" + seed_text))
    if cfg["noise_mode"] == "point" and cfg["rir_mode"] == "room":
        rng = random.Random(_seed_from_text("noisepos:" + seed_text))
        theta = rng.uniform(0.0, 180.0)
        d_lo, d_hi = cfg["distance_range"]
        noise = torch.randn(1, mix.shape[-1], generator=gen)
        rir = _get_room_rir(theta, rng.uniform(d_lo, d_hi), 0.0,
                            1.0 if rng.random() < 0.5 else -1.0,
                            rng.choice(cfg["t60_values"]))
        noise = convolve_rir_fft(noise, rir)
        noise = torch.nn.functional.pad(noise, (0, mix.shape[-1] - noise.shape[-1]))
    else:
        noise = torch.randn(m, mix.shape[-1], generator=gen)
    p_sig = float((mix ** 2).mean())
    p_noise = float((noise ** 2).mean()) + 1e-12
    target = p_sig / (10.0 ** (float(snr_db) / 10.0))
    return mix + noise * math.sqrt(target / p_noise)


def load_source_audio(wav_path: str, sr: int):
    """读取单条语音并统一到 16k 单声道；命中缓存则直接返回。"""
    if wav_path in _audio_cache:
        return _audio_cache[wav_path]
    wav, wav_sr = torchaudio.load(wav_path)
    if wav_sr != sr:
        wav = torchaudio.transforms.Resample(wav_sr, sr)(wav)
    wav = wav[:1, :]  # 取单通道（Mobvoi 数据均为单声道）
    if len(_audio_cache) >= _AUDIO_CACHE_LIMIT:
        # FIFO：逐出最早缓存项，防止无限占用内存
        _audio_cache.pop(next(iter(_audio_cache)))
    _audio_cache[wav_path] = wav
    return wav


def load_scp(wav_scp_path, text_scp_path):
    """读取wekws scp，拆分唤醒词正样本池、干扰负样本池"""
    wav_dict = {}
    with open(wav_scp_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            utt, wav = line.split(maxsplit=1)
            wav_dict[utt] = wav
    text_dict = {}
    with open(text_scp_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            utt, txt = line.split(maxsplit=1)
            text_dict[utt] = txt
    pos_pool = []
    neg_pool = []
    for utt in wav_dict:
        wav_path = wav_dict[utt]
        txt = text_dict.get(utt, "")
        # 正样本标签可由环境变量指定，用于"双唤醒词泛化"实验
        pos_tag = os.environ.get("RIR_POS_TAG", "<HI_XIAOWEN>")
        label = 1 if pos_tag in txt else 0
        if label == 1:
            pos_pool.append(wav_path)
        else:
            neg_pool.append(wav_path)
    return pos_pool, neg_pool


# ==================== 多进程支持 ====================
# 并行思路（两阶段）：
#   阶段1(主进程, 串行)：只消费随机数、生成每条样本的“配方”
#        job = (label, 输出wav路径, [(声源wav, 角度), ...])
#        音频I/O/卷积全部不做 → 很快；随机调用顺序与原串行版本完全一致，结果可复现。
#   阶段2(并行)：把配方分给 N 个 worker，各自 读音频→RIR→混合→保存。
#        每条混合相互独立，天然适合多进程；进程内再做音频缓存进一步省IO。
# 注意不要用多线程：GIL 下这段“纯Python循环+小tensor”基本无法并行。
_WORKER_CFG = None  # 每个 worker 的全局配置，由 _init_worker 设置


def _init_worker(num_mic: int, mic_spacing: float, sr: int, gen_cfg=None):
    """worker 初始化：构建 RIR 仿真器、清空缓存。"""
    global _WORKER_CFG
    gen_cfg = dict(gen_cfg or {})
    rir_mode = str(gen_cfg.get("rir_mode", "direct"))
    cfg = {
        "num_mic": num_mic,
        "mic_spacing": mic_spacing,
        "sr": sr,
        "rir_mode": rir_mode,
        "noise_mode": str(gen_cfg.get("noise_mode", "white")),
        "distance_range": tuple(gen_cfg.get("distance_range", (0.8, 1.5))),
        "height_jitter": gen_cfg.get("height_jitter", 0.15),
        "half_plane": str(gen_cfg.get("half_plane", "both")),
        "t60_values": list(gen_cfg.get("t60_values", [])),
        "cache_size": int(gen_cfg.get("cache_size", 4096)),
        "sims": {},
        "rir_cache": OrderedDict(),
    }
    if rir_mode == "room":
        from wekws.utils.room_rir import RoomRirConfig
        room_cfg = gen_cfg.get("room_rir") or {}
        base_cfg = RoomRirConfig.from_dict(room_cfg)
        missing = missing_backend_dependency(base_cfg)
        if missing:
            raise RuntimeError(
                f"RIR 后端 {base_cfg.backend} 缺少依赖，请先安装: {missing}")
        for t60 in cfg["t60_values"]:
            one = dict(room_cfg)
            one["t60"] = float(t60)
            sim_cfg = RoomRirConfig.from_dict(one)
            cfg["sims"][_t60_key(t60)] = build_simulator(
                sim_cfg, num_mic, mic_spacing, sr)
        _validate_placement(cfg)
    _WORKER_CFG = cfg
    # 【关键】多进程下必须限制每进程的线程数，否则 32 进程 x 64 线程
    # 会把 128 核打成严重超订，吞吐反而暴跌
    torch.set_num_threads(1)
    _audio_cache.clear()


def _limit_pool(pool, limit: int):
    """等间隔抽样裁剪语料池（保持确定性，可复现）。

    - limit<=0 或 >=len(pool)：不裁剪，返回原池；
    - 否则严格返回 min(limit, len(pool)) 条，避免因步长取整导致数量不足。
    """
    if limit is None or limit <= 0 or limit >= len(pool):
        return list(pool)
    n = len(pool)
    if limit == 1:
        indices = [0]
    else:
        # 在 [0, n-1] 上等间隔取 limit 个点，包含首尾。
        indices = [int(round(i * (n - 1) / (limit - 1)))
                   for i in range(limit)]
    # 理论上不会重复；这里仍做一次去重保护并保持顺序。
    indices = sorted(set(indices))
    assert len(indices) == limit, (n, limit, indices)
    return [pool[i] for i in indices]


def _sample_source_geometry(theta_deg, gen_opts):
    _lib = _ensure_rir_lib().get(_RIR_LIB_SPLIT) if _ensure_rir_lib() else None
    if _lib is not None:
        sc = _lib["by_theta"].get(int(theta_deg))
        if sc is None:
            sc = min(_lib["by_theta"].values(),
                     key=lambda x: abs(x["theta"] - int(theta_deg)))
        return sc["distance"], sc["z_factor"], sc["y_sign"]
    """采样单个声源的距离/垂直偏移/半平面符号(配方在阶段1生成，保证可复现)。

    垂直偏移按"米"给定(height_jitter)，再用 vertical_z_factor_bounds 换算成
    方向向量的 z 分量比例，保证与 validate_placement 的校验口径一致。
    """
    d_lo, d_hi = gen_opts["distance_range"]
    distance = random.uniform(d_lo, d_hi)
    z_lo, z_hi = vertical_z_factor_bounds(theta_deg, distance,
                                          gen_opts.get("height_jitter", 0.0))
    z_factor = random.uniform(z_lo, z_hi) if z_hi > z_lo else z_lo
    half_plane = str(gen_opts.get("half_plane", "both"))
    if half_plane == "+":
        y_sign = 1.0
    elif half_plane == "-":
        y_sign = -1.0
    else:
        y_sign = 1.0 if random.random() < 0.5 else -1.0
    return distance, z_factor, y_sign


def _build_jobs(pos_pool, neg_pool, max_src: int, gap_min: int, out_wav_dir: str,
                neg_job_pool=None, gen_opts=None):
    """阶段1：按原实现的随机序列生成所有样本的配方（无任何音频I/O）。

    neg_pool: 正样本中可选的干扰语料池，通常保留完整池以保证干扰多样性。
    neg_job_pool: 用于生成负样本任务的语料池；默认与neg_pool相同。
    """
    if neg_job_pool is None:
        neg_job_pool = neg_pool
    gen_opts = dict(gen_opts or {})
    t60_values = list(gen_opts.get("t60_values") or [None])
    snr_values = list(gen_opts.get("noise_snr_values") or [None])
    sir_values = list(gen_opts.get("sir_values") or [None])

    def _source(wav_path, theta):
        d, z, y = _sample_source_geometry(theta, gen_opts)
        return (wav_path, theta, d, z, y)

    jobs = []
    # 正样本：1 个唤醒词 + 0~max_src-1 路干扰（数量已由 max_pos 在 main 中裁剪）
    for idx, target_wav_path in enumerate(pos_pool):
        num_interf = random.randint(0, max_src - 1)
        total_src_num = 1 + num_interf
        src_angles = sample_angles_by_class(total_src_num, gap_min)
        sources = [_source(target_wav_path, src_angles[0])]
        for ia in src_angles[1:]:
            sources.append(_source(random.choice(neg_pool), ia))
        basename = os.path.splitext(os.path.basename(target_wav_path))[0]
        _sir = random.choice(sir_values)
        _tag = "" if _sir is None else f"_sir{int(round(_sir)):+d}"
        out_wav_full = os.path.join(out_wav_dir, f"{basename}{_tag}_mc.wav")
        jobs.append((1, out_wav_full, tuple(sources),
                     random.choice(t60_values), random.choice(snr_values), _sir))
        if (idx + 1) % 200 == 0:
            print(f"计划正样本 {idx + 1}")
    n_pos = len(jobs)
    # 负样本：1~max_src 路全干扰，无唤醒词
    for idx, neg_wav_path in enumerate(neg_job_pool):
        num_src = random.randint(1, max_src)
        src_angles = sample_angles_by_class(num_src, gap_min)
        sources = []
        for ang in src_angles:
            sources.append(_source(random.choice(neg_pool), ang))
        basename = os.path.splitext(os.path.basename(neg_wav_path))[0]
        _sir = random.choice(sir_values)
        _tag = "" if _sir is None else f"_sir{int(round(_sir)):+d}"
        out_wav_full = os.path.join(out_wav_dir, f"{basename}{_tag}_mc.wav")
        jobs.append((0, out_wav_full, tuple(sources),
                     random.choice(t60_values), random.choice(snr_values), _sir))
    print(f"计划样本数: 正 {n_pos}, 负 {len(jobs) - n_pos}, 共 {len(jobs)}")
    return jobs


def _render_job(job):
    """阶段2：渲染单条混合样本（在 worker 进程中执行，job 可 pickle）。"""
    if len(job) == 6:
        label, out_wav_full, sources, t60, noise_snr, sir_db = job
    else:
        label, out_wav_full, sources, t60, noise_snr = job
        sir_db = None
    cfg = _WORKER_CFG
    assert cfg is not None, "_init_worker 未执行"
    num_mic = cfg["num_mic"]
    mic_spacing = cfg["mic_spacing"]
    sr = cfg["sr"]

    src_multichannel = []
    for wav_path, ang, distance, z_factor, y_sign in sources:
        audio = load_source_audio(wav_path, sr)
        if cfg["rir_mode"] == "room":
            rir = _get_room_rir(ang, distance, z_factor, y_sign, t60)
            src_multichannel.append(convolve_rir_fft(audio, rir))
        else:
            rir = generate_array_rir(ang, num_mic, mic_spacing, sr)
            src_multichannel.append(convolve_rir(audio, rir))
    mixed_audio = mix_multi_sir0db(
        src_multichannel,
        target_len=int(cfg.get("mix_target_sec", 2.75) * sr),
        rng=np.random.default_rng(abs(hash((wav_path, t60))) % (2 ** 32)),
        sir_db=sir_db,
        power_mode=cfg.get("power_mode", "full"))
    mixed_audio = _add_noise(mixed_audio, noise_snr, out_wav_full)
    torchaudio.save(out_wav_full, mixed_audio, sr)

    class_ids = [angle_to_class(a) for _, a, _, _, _ in sources]
    out_slots = [-100] * 3
    for i, c in enumerate(class_ids):
        if i < 3:
            out_slots[i] = c
    slot_str = " ".join(str(x) for x in out_slots)
    return f"{out_wav_full} {label} {len(sources)} {slot_str}\n"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--wav_scp", required=True, help="data/train/wav.scp from wekws")
    parser.add_argument("--text_scp", required=True, help="data/train/text from wekws")
    parser.add_argument("--out_wav_dir", required=True, help="output multi‑channel wav dir")
    parser.add_argument("--out_temp_list", required=True, help="output variable‑column temp list")
    parser.add_argument("--num_mic", type=int, required=True)
    parser.add_argument("--mic_spacing", type=float, default=0.033, help="麦克风间距 m")
    parser.add_argument("--sr", type=int, default=16000)
    parser.add_argument("--seed", type=int, default=666)
    parser.add_argument("--num_workers", type=int, default=1,
                        help="并行渲染进程数：1=串行(默认)，>1=多进程(建议=CPU核数)")
    parser.add_argument("--config", type=str, default="./conf/train_dynamic_query.yaml",
                        help="stage5数据生成配置文件；读取其中data_gen字段")
    parser.add_argument("--max_pos", type=int, default=None,
                        help="正样本数量上限；不指定时读取配置data_gen.num_positive")
    parser.add_argument("--max_neg", type=int, default=None,
                        help="负样本数量上限；不指定时读取配置data_gen.num_negative")
    parser.add_argument("--min_angle_gap_deg", type=int, default=None,
                        help="任意两个声源最低角度间隔；不指定时读取配置data_gen.min_angle_gap_deg")
    parser.add_argument("--rir_mode", type=str, default=None,
                        help="room(镜像法房间RIR, 默认) | direct(自由场直达声, 旧行为)")
    parser.add_argument("--t60", type=float, default=None,
                        help="覆盖 data_gen.room_rir.t60(秒)")
    args = parser.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        full_config = yaml.safe_load(f) or {}
    gen_cfg = full_config.get("data_gen", {}) or {}

    num_samples = int(gen_cfg.get("num_samples", DEFAULT_NUM_SAMPLES))
    positive_ratio = float(gen_cfg.get("positive_ratio", DEFAULT_POSITIVE_RATIO))
    if not 0.0 <= positive_ratio <= 1.0:
        raise ValueError(f"data_gen.positive_ratio 必须在[0,1]内: {positive_ratio}")

    default_num_pos = int(round(num_samples * positive_ratio))
    default_num_neg = num_samples - default_num_pos
    max_pos = (args.max_pos if args.max_pos is not None
               else int(gen_cfg.get("num_positive", default_num_pos)))
    max_neg = (args.max_neg if args.max_neg is not None
               else int(gen_cfg.get("num_negative", default_num_neg)))
    gap_min = (args.min_angle_gap_deg if args.min_angle_gap_deg is not None
               else int(gen_cfg.get("min_angle_gap_deg", MIN_ANGLE_GAP_DEG)))

    # ===== RIR / 声源放置 / 噪声配置 =====
    room_cfg = dict(gen_cfg.get("room_rir") or {})
    rir_mode = str(args.rir_mode or gen_cfg.get("rir_mode", "room")).lower()
    if rir_mode not in ("room", "direct"):
        raise ValueError(f"rir_mode 只能是 room/direct，当前={rir_mode}")
    if args.t60 is not None:
        t60_values = [float(args.t60)]
    elif room_cfg.get("t60_range"):
        lo, hi = (float(x) for x in room_cfg["t60_range"])
        grid = max(2, int(room_cfg.get("t60_grid", 8)))
        t60_values = [round(lo + (hi - lo) * i / (grid - 1), 4)
                      for i in range(grid)]
        print(f"T60 多条件: range=[{lo}, {hi}] → {len(t60_values)} 档 {t60_values}")
    else:
        t60_raw = room_cfg.get("t60", 0.2)
        t60_values = [float(x) for x in
                      (t60_raw if isinstance(t60_raw, (list, tuple))
                       else [t60_raw])]
    if any(v <= 0 for v in t60_values):
        raise ValueError(f"t60 必须为正数: {t60_values}")
    dist_raw = room_cfg.get("source_distance_range", [0.8, 1.5])
    distance_range = (float(dist_raw[0]), float(dist_raw[1]))
    if not 0 < distance_range[0] <= distance_range[1]:
        raise ValueError(f"source_distance_range 非法: {distance_range}")
    # 垂直偏移：标量(±h) 或 [lo, hi] 区间
    hj_raw = room_cfg.get("height_jitter", 0.15)
    height_jitter = ([float(x) for x in hj_raw]
                     if isinstance(hj_raw, (list, tuple)) else float(hj_raw))
    noise_raw = gen_cfg.get("noise_snr_db")
    if noise_raw is None:
        snr_values = [None]
    elif isinstance(noise_raw, dict) and noise_raw.get("range"):
        _nl, _nh = (float(x) for x in noise_raw["range"])
        _ng = max(2, int(noise_raw.get("grid", 16)))
        snr_values = [round(_nl + (_nh - _nl) * i / (_ng - 1), 3) for i in range(_ng)]
    elif isinstance(noise_raw, (list, tuple)):
        snr_values = [None if v is None else float(v) for v in noise_raw]
    else:
        snr_values = [float(noise_raw)]
    sir_raw = gen_cfg.get("sir_range_db")
    if sir_raw is None:
        sir_values = [None]
    else:
        _sl, _sh = (float(x) for x in sir_raw)
        _sg = max(2, int(gen_cfg.get("sir_grid", 16)))
        sir_values = [round(_sl + (_sh - _sl) * i / (_sg - 1), 3) for i in range(_sg)]
    noise_mode = str(gen_cfg.get("noise_mode", "white")).lower()
    if noise_mode not in ("white", "point"):
        raise ValueError(f"noise_mode 只能是 white/point，当前={noise_mode}")
    if rir_mode == "room":
        from wekws.utils.room_rir import RoomRirConfig
        missing = missing_backend_dependency(RoomRirConfig.from_dict(room_cfg))
        if missing:
            raise RuntimeError(
                f"RIR 后端 {room_cfg.get('backend', 'pyroomacoustics')} "
                f"缺少依赖，请先安装: {missing}")
    gen_opts = {
        "rir_mode": rir_mode,
        "room_rir": room_cfg,
        "t60_values": t60_values,
        "distance_range": distance_range,
        "height_jitter": height_jitter,
        "noise_snr_values": snr_values,
        "noise_mode": noise_mode,
        "sir_values": sir_values,
        "power_mode": str(gen_cfg.get("power_mode", "full")).lower(),
        "half_plane": str(room_cfg.get("half_plane", "both")),
        "cache_size": int(room_cfg.get("cache_size", 4096)),
    }

    if max_pos < 0 or max_neg < 0:
        raise ValueError(f"max_pos/max_neg 不能为负数: max_pos={max_pos}, max_neg={max_neg}")
    if gap_min <= 0:
        raise ValueError(f"min_angle_gap_deg 必须大于0: {gap_min}")

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    os.makedirs(args.out_wav_dir, exist_ok=True)

    pos_pool, neg_pool = load_scp(args.wav_scp, args.text_scp)
    print(f"positive pool {len(pos_pool)}, negative/interf pool {len(neg_pool)}")
    assert len(pos_pool) > 0 and len(neg_pool) > 0, "数据集正负样本不能为空"

    max_src = args.num_mic
    # 固定3麦：声源数<=3，与3个标注槽、3个query一致，避免声源被静默丢弃
    assert args.num_mic in (2, 3), (
        f"num_mic 只支持 2 或 3(与 num_query/方位类数配套)，当前={args.num_mic}")
    print(f"数据生成配置: config_num_samples={num_samples}, pos={max_pos}, "
          f"neg={max_neg}, effective_total={max_pos + max_neg}, "
          f"min_angle_gap>{gap_min}°, config={args.config}")
    print(f"DOA粗方位类别=3, RIR模式={rir_mode}")
    if rir_mode == "room":
        print(f"RIR 后端: {room_cfg.get('backend', 'pyroomacoustics')}")
        backend = str(room_cfg.get("backend", "pyroomacoustics"))
        if backend == "rir_generator":
            extra = (f"nsample={room_cfg.get('nsample')}, "
                     f"order={room_cfg.get('order')}, "
                     f"oversample={room_cfg.get('oversample')}")
        elif backend == "roomsimove":
            extra = (f"directivity={room_cfg.get('mic_directivity', 'omnidirectional')}, "
                     f"roomsimove_path={room_cfg.get('roomsimove_path')}")
        else:
            extra = f"wall_material={room_cfg.get('wall_material') or 'Sabine+标定'}"
        print(f"房间参数: room_dim={room_cfg.get('room_dim', [5.0, 4.0, 2.8])}m, "
              f"array_center={room_cfg.get('array_center', '房间中心')}, "
              f"array_axis={room_cfg.get('array_axis', 'x')}, "
              f"T60={t60_values}s, {extra}, "
              f"声源距离={distance_range}m, 垂直偏移={height_jitter}m, "
              f"半平面={room_cfg.get('half_plane', 'both')}")
        print("提示: 几何自检在每个 worker 启动时执行一次；"
              "pyroomacoustics 后端还会做 T60 吸声标定(各约数秒)")
        print("提示: 正式实验前建议先跑 tools/check_room_rir.py 核对几何约定")
    else:
        print("警告: rir_mode=direct 为自由场直达声(无混响)，仅用于消融/复现旧结果")
    if any(v is not None for v in snr_values):
        print(f"加性噪声: SNR={snr_values} dB, mode={noise_mode}")

    # 默认生成约2000条：正样本最多1000条 + 负样本最多1000条；
    # 如果对应语料池不足，则按实际可用数量生成。
    # 注意：负样本任务池和正样本干扰池分开，避免限制负样本数量时
    # 同时缩减了正样本中干扰语料的多样性。
    if max_pos > 0 and max_pos < len(pos_pool):
        pos_job_pool = _limit_pool(pos_pool, max_pos)
    else:
        pos_job_pool = list(pos_pool)
    if max_neg > 0 and max_neg < len(neg_pool):
        neg_job_pool = _limit_pool(neg_pool, max_neg)
    else:
        neg_job_pool = list(neg_pool)

    print(f"目标任务池: 正 {len(pos_job_pool)}, 负 {len(neg_job_pool)}; "
          f"正样本干扰池 {len(neg_pool)}")
    print(f"预计生成: 正 {len(pos_job_pool)} + 负 {len(neg_job_pool)} "
          f"= {len(pos_job_pool) + len(neg_job_pool)} 条")

    # ===== 阶段1：主进程串行生成配方（随机序列由裁剪后的池决定，同样可复现）=====
    jobs = _build_jobs(pos_job_pool, neg_pool, max_src, gap_min, args.out_wav_dir,
                       neg_job_pool=neg_job_pool, gen_opts=gen_opts)
    n_pos = sum(1 for j in jobs if j[0] == 1)

    # ===== 阶段2：渲染（串行 or 多进程）=====
    _init_worker(args.num_mic, args.mic_spacing, args.sr, gen_opts)  # 串行路径也需要配置
    fout = open(args.out_temp_list, "w", encoding="utf-8")

    if args.num_workers <= 1:
        # 串行：与改造前的执行方式一致
        for i, job in enumerate(jobs):
            fout.write(_render_job(job))
            if (i + 1) % 500 == 0:
                print(f"rendered {i + 1}/{len(jobs)}")
    else:
        # 多进程：executor.map 保持输入顺序返回，逐条写盘
        init_args = (args.num_mic, args.mic_spacing, args.sr, gen_opts)
        with ProcessPoolExecutor(max_workers=args.num_workers,
                                 initializer=_init_worker,
                                 initargs=init_args) as executor:
            for i, line in enumerate(executor.map(_render_job, jobs)):
                fout.write(line)
                if (i + 1) % 500 == 0:
                    print(f"rendered {i + 1}/{len(jobs)}")
        print(f"多进程渲染完成，共 {len(jobs)} 条, workers={args.num_workers}")

    fout.close()
    print(f"stage5 gen_multi_channel_wav.py done (pos={n_pos}, neg={len(jobs)-n_pos})")


if __name__ == "__main__":
    main()
