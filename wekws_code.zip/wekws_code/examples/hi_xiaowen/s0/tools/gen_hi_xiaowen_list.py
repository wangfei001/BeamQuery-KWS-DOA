#!/usr/bin/env python3
import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--wav_scp", type=str, required=True)
    parser.add_argument("--text", type=str, required=True)
    parser.add_argument("--out_list", type=str, required=True)
    args = parser.parse_args()

    wav_table = dict()
    with open(args.wav_scp, "r", encoding="utf8") as f:
        for line in f:
            utt, wav = line.strip().split(maxsplit=1)
            wav_table[utt] = wav

    out_lines = []
    with open(args.text, "r", encoding="utf8") as f:
        for line in f:
            utt, txt = line.strip().split(maxsplit=1)
            wav_path = wav_table[utt]
            label = 1 if txt.strip() == "<HI_XIAOWEN>" else 0
            out_lines.append(f"{wav_path} {label}")

    with open(args.out_list, "w", encoding="utf8") as f:
        f.write("\n".join(out_lines))
    print(f"write {len(out_lines)} items to {args.out_list}")

if __name__ == "__main__":
    main()

