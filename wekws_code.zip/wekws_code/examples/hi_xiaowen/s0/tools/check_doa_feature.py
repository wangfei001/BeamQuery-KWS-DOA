#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""单声源/多声源 DOA 特征 sanity check。

目的：不做 KWS，只验证“从 tdoa 特征能不能解出方位类别”。
做法：
  1) 读 varcol tmp list（wav label n_src doa0 doa1 doa2）；
  2) 按 --n_src 过滤（默认只取单声源 n_src=1）；
  3) 对每条样本算 3 个麦对的 GCC-PHAT 角度特征 [sinθ, cosθ, coh]，
     时间维取平均 → 9 维特征；
  4) 训练一个线性分类器预测 DOA 类别 0/1/2，报告 train/test 准确率和混淆矩阵。

用法：
  python tools/check_doa_feature.py \
      --varcol ./data/spatial/train_varcol.tmp.list \
      --config ./conf/train_dynamic_query.yaml \
      --n_src 1 --num_samples 3000 --pool mean

如果单声源都达不到 0.6 以上，说明特征/标签链路有问题，
而不是模型或 loss 的问题。
"""
import argparse
import os
import random

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchaudio
import yaml

from wekws.model.spatial_dynamic_query import SpatialDynamicQueryModel


def read_varcol(path, n_src_filter):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) < 6:
                continue
            wav = os.path.abspath(parts[0])
            label = int(parts[1])
            n_src = int(parts[2])
            doas = [int(x) for x in parts[3:6]]
            if n_src_filter >= 0 and n_src != n_src_filter:
                continue
            valid = [d for d in doas if d >= 0]
            if not valid:
                continue
            # 单声源时 valid[0] 就是它；多声源时取第一个有效类别（仅作粗诊断）
            rows.append((wav, n_src, valid[0]))
    return rows


def build_model(config_path):
    cfg = yaml.safe_load(open(config_path, "r", encoding="utf-8"))
    return SpatialDynamicQueryModel(
        fsmn_num_layers=cfg["fsmn_num_layers"],
        fsmn_dim=cfg["fsmn_dim"],
        num_query=cfg["num_query"],
        doa_num_class=cfg["doa_num_class"],
        feat_freq_dim=cfg["feat_freq_dim"],
        num_mic=cfg.get("num_mic", 3),
        pool_type=cfg.get("pool_type", "mean_max"),
        pair_feat_mode=cfg.get("pair_feat_mode", "tdoa"),
        mic_spacing=cfg.get("mic_spacing", 0.033),
        sr=cfg.get("sr", 16000),
    )


@torch.no_grad()
def extract_feature(model, wav_path, pool="mean"):
    wav, sr = torchaudio.load(wav_path)
    if sr != model.sr:
        wav = torchaudio.functional.resample(wav, sr, model.sr)
    wav = wav[:model.num_mic, :].float()
    stft_out = torch.stft(
        wav, n_fft=model.n_fft, hop_length=model.hop_length,
        win_length=model.win_length, window=model.window,
        return_complex=True)
    feats = []
    pairs = [(i, j) for i in range(model.num_mic) for j in range(i + 1, model.num_mic)]
    for (i, j) in pairs:
        pf = model._pair_angle_feature(stft_out, i, j)   # [3,T]
        if pool == "mean":
            feats.append(pf.mean(dim=1))
        elif pool == "median":
            feats.append(pf.median(dim=1).values)
        elif pool == "max":
            feats.append(pf.max(dim=1).values)
        else:
            raise ValueError(f"未知 pool: {pool}")
    return torch.cat(feats)   # [3*n_pairs]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--varcol", required=True)
    ap.add_argument("--config", default="./conf/train_dynamic_query.yaml")
    ap.add_argument("--n_src", type=int, default=1,
                    help="筛选声源数；-1 表示不筛")
    ap.add_argument("--num_samples", type=int, default=3000)
    ap.add_argument("--pool", default="mean", choices=["mean", "median", "max"])
    ap.add_argument("--steps", type=int, default=1500)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    random.seed(args.seed)
    torch.manual_seed(args.seed)

    rows = read_varcol(args.varcol, args.n_src)
    if len(rows) == 0:
        raise SystemExit("没有符合条件的样本，检查 --varcol / --n_src")
    random.shuffle(rows)
    rows = rows[:args.num_samples]
    print(f"使用样本 {len(rows)} 条 (n_src={args.n_src})")

    model = build_model(args.config)
    model.eval()

    X, y = [], []
    for idx, (wav_path, n_src, cls) in enumerate(rows):
        try:
            X.append(extract_feature(model, wav_path, pool=args.pool))
            y.append(cls)
        except Exception as exc:
            print(f"skip {wav_path}: {exc}")
        if (idx + 1) % 200 == 0:
            print(f"  提取特征 {idx + 1}/{len(rows)}")

    X = torch.stack(X)
    y = torch.tensor(y, dtype=torch.long)
    N = X.size(0)
    print(f"特征维度 {X.size(1)}, 类别分布 {torch.bincount(y, minlength=3).tolist()}")

    perm = torch.randperm(N)
    n_tr = int(N * 0.8)
    tr, te = perm[:n_tr], perm[n_tr:]
    mu, sd = X[tr].mean(0), X[tr].std(0) + 1e-6
    Xn = (X - mu) / sd

    clf = nn.Linear(X.size(1), 3)
    opt = torch.optim.Adam(clf.parameters(), lr=0.05, weight_decay=1e-4)
    for step in range(args.steps):
        loss = F.cross_entropy(clf(Xn[tr]), y[tr])
        opt.zero_grad(); loss.backward(); opt.step()

    with torch.no_grad():
        tr_acc = (clf(Xn[tr]).argmax(1) == y[tr]).float().mean().item()
        te_acc = (clf(Xn[te]).argmax(1) == y[te]).float().mean().item()
        cm = torch.zeros(3, 3, dtype=torch.long)
        for t, p in zip(y[te].tolist(), clf(Xn[te]).argmax(1).tolist()):
            cm[t, p] += 1

    print(f"\n=== DOA feature sanity check (n_src={args.n_src}, pool={args.pool}) ===")
    print(f"train acc = {tr_acc:.4f}")
    print(f"test  acc = {te_acc:.4f}   (随机基线 ≈ 0.333)")
    print("混淆矩阵 (行=真实, 列=预测):")
    print(cm.numpy())
    if te_acc < 0.6:
        print("\n[结论] 单声源也解不出方位 → 优先排查特征/标签链路"
              "(GCC-PHAT 符号、mic_spacing、angle_to_class 映射)。")
    else:
        print("\n[结论] 特征本身能解出方位 → 问题在多源混合下的 query 绑定，"
              "考虑课程学习/换特征/加空间结构。")


if __name__ == "__main__":
    main()
