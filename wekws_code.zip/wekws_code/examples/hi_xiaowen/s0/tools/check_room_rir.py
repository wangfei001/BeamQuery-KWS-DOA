#!/usr/bin/env python3
# Copyright (c) 2026
#
# Licensed under the Apache License, Version 2.0 (the "License")
"""房间 RIR 数据生成自检：几何一致性 + 物理量是否合理。

检查项
------
1. 几何一致性（最关键）：仿真 RIR 的通道间相对时延 == 模型端解析式
   tau_m = x_m cos(theta)/c。符号或轴向反了会得到镜像的方位标签，
   训练出来的模型方位就是错的，所以这一项作为 PASS/FAIL 判定依据：
     - 用**消声对照**(wall_material=anechoic, max_order=1)算亚样本互相关时延，
       容差 tolerance_sample(默认 0.25 样本)；
     - 混响 RIR 上再报一次"围绕解析位置的直达峰位"误差(整数样本，供参考)。
2. 实测 T60 是否命中目标(Sabine + 二分标定)。
3. DRR(直达混响比)与通道间幅值平方相干 MSC —— 房间 RIR 下 MSC 应明显 < 1
   (旧的自由场直达声数据里恒为 1)。
4. GCC-PHAT 麦对测向误差 —— 混响 + 小孔径(3.3cm)下手工 TDOA 特征会明显退化，
   这也是本工作需要"方向绑定特征"的动机之一。

用法
----
    python tools/check_room_rir.py --config conf/train_dynamic_query.yaml
    python tools/check_room_rir.py --thetas 0,30,60,90,120,150,180 --distances 0.8,1.5
"""
import argparse
import csv
import os
import sys
from dataclasses import asdict

import numpy as np
import yaml

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from wekws.utils.room_rir import (  # noqa: E402
    RoomRirConfig, build_simulator, convolved_coherence, direct_index,
    drr_db, gcc_phat_tdoa, measure_t60, measured_tdoa,
    missing_backend_dependency, tdoa_to_theta, validate_placement,
    xcorr_delay_samples)


def parse_args():
    p = argparse.ArgumentParser(description="房间 RIR 生成自检")
    p.add_argument("--config", default="./conf/train_dynamic_query.yaml")
    p.add_argument("--num_mic", type=int, default=None)
    p.add_argument("--mic_spacing", type=float, default=None)
    p.add_argument("--sr", type=int, default=None)
    p.add_argument("--thetas", default="15,45,75,90,105,135,165")
    p.add_argument("--distances", default=None,
                   help="逗号分隔；默认取 source_distance_range 的 min/mid/max")
    p.add_argument("--tolerance_sample", type=float, default=0.25,
                   help="亚样本时延容许误差(样本)，超过判定约定不一致")
    p.add_argument("--out_csv", default=None)
    return p.parse_args()


def make_anechoic_sim(cfg, num_mic, mic_spacing, sr):
    """消声对照仿真器：只保留直达声，用于精确校验时延约定。"""
    d = asdict(cfg)
    d.update(anechoic=True, calibrate=False, air_absorption=False)
    if str(cfg.backend) == "rir_generator":
        d.update(order=10)                   # 消声下降低阶数即可
    return build_simulator(RoomRirConfig(**d), num_mic, mic_spacing, sr)


def main():
    args = parse_args()
    with open(args.config, "r", encoding="utf-8") as f:
        full = yaml.safe_load(f) or {}
    gen = full.get("data_gen", {}) or {}
    room_cfg_dict = gen.get("room_rir") or {}

    # 与 run.sh / 模型一致：优先取配置顶层，其次 data_gen，最后默认值
    num_mic = int(args.num_mic or full.get("num_mic")
                  or gen.get("num_mic", 3))
    mic_spacing = float(args.mic_spacing or full.get("mic_spacing")
                        or gen.get("mic_spacing", 0.033))
    sr = int(args.sr or full.get("sr", 16000))
    thetas = [float(x) for x in args.thetas.split(",") if x.strip()]
    if args.distances:
        dists = [float(x) for x in args.distances.split(",") if x.strip()]
    else:
        lo, hi = (float(x) for x in room_cfg_dict.get(
            "source_distance_range", [0.8, 1.5]))
        dists = [lo, 0.5 * (lo + hi), hi]

    cfg = RoomRirConfig.from_dict(room_cfg_dict)
    missing = missing_backend_dependency(cfg)
    if missing:
        print(f"ERROR: backend={cfg.backend} 缺少依赖，请先安装: {missing}",
              file=sys.stderr)
        return 2
    sim = build_simulator(cfg, num_mic, mic_spacing, sr)
    sim_ac = make_anechoic_sim(cfg, num_mic, mic_spacing, sr)
    ref = num_mic // 2  # 阵列中心通道

    bad = validate_placement(sim, cfg.source_distance_range,
                             cfg.height_jitter)
    if bad:
        print(f"WARNING: 声源放置越界 {len(bad)} 处，示例 {bad[0]}", file=sys.stderr)

    print("=" * 78)
    print("房间 RIR 自检")
    print("=" * 78)
    print(f"房间尺寸        : {tuple(sim.room_dim)} m")
    print(f"阵列中心/轴向   : {sim.center.tolist()} / {cfg.array_axis}")
    print(f"麦克风数/间距   : {num_mic} / {mic_spacing*100:.1f} cm, 采样率 {sr}")
    print(f"RIR 后端        : {cfg.backend}")
    cal_t60 = getattr(sim, "calibrated_t60", float("nan"))
    if np.isfinite(cal_t60):
        print(f"T60 目标/实测   : {cfg.t60:.3f} s / {cal_t60:.3f} s")
    else:
        print(f"T60 目标        : {cfg.t60:.3f} s (由后端 reverberation_time 决定)")
    if cfg.backend == "rir_generator":
        print(f"nsample/阶数/过采样: {cfg.nsample} / {cfg.order} / {cfg.oversample}")
    if getattr(sim, "absorption", None) is not None:
        print(f"吸声系数        : {sim.absorption:.4f}"
              f" (Sabine 初值 {sim.sabine_absorption0:.4f})")
    elif cfg.wall_material:
        print(f"吸声材料        : {cfg.wall_material} (频带相关吸声, 未做标定)")
    gd = float(getattr(sim, "group_delay_samples", 0.0))
    print(f"共模群延时      : {gd:.0f} 样本 ({gd/sr*1e3:.2f} ms)")
    rir0 = sim.rir(thetas[0], dists[0])
    print(f"RIR 长度        : {rir0.shape[1]} 样本 ({rir0.shape[1]/sr:.2f} s)")

    rows = []
    max_sub_err = 0.0
    print("\n" + "-" * 78)
    print("1) 几何一致性：通道间相对时延 vs 解析式 (参考通道 = 阵列中心 mic%d)" % ref)
    print("-" * 78)
    print(f"{'theta':>6} {'dist':>5} | {'解析Δτ(样本)':>25} {'混响峰位Δτ':>25} "
          f"{'峰位误差':>8} {'亚样本误差':>10}")
    for th in thetas:
        for d in dists:
            pred = sim.predicted_tdoa(th) - sim.predicted_tdoa(th)[ref]
            pred_str = "[" + " ".join(f"{v*sr:+.2f}" for v in pred) + "]"

            # (a) 混响 RIR：在解析直达峰位附近 ±1.5ms 搜峰(避开更强的早期反射)
            rir = sim.rir(th, d)
            center = float(sim.analytic_direct_samples(th, d)[ref])
            meas = measured_tdoa(rir, sr, ref=ref, center_sample=center)
            peak_err = float(np.max(np.abs((meas - pred) * sr)))
            meas_str = "[" + " ".join(f"{v*sr:+.2f}" for v in meas) + "]"

            # (b) 消声对照：亚样本互相关，作为判定依据
            rir_ac = sim_ac.rir(th, d)
            sub_err = float(np.max(np.abs(
                [xcorr_delay_samples(rir_ac[m], rir_ac[ref])
                 for m in range(rir_ac.shape[0])] - pred * sr)))
            max_sub_err = max(max_sub_err, sub_err)

            print(f"{th:6.1f} {d:5.2f} | {pred_str:>25} {meas_str:>25} "
                  f"{peak_err:8.3f} {sub_err:10.3f}")

            bands, msc = convolved_coherence(rir, sr)
            keys = list(bands.keys())
            th_gcc = tdoa_to_theta(gcc_phat_tdoa(rir, sr, (0, 1)),
                                   mic_spacing, (0, 1))
            th_lb = tdoa_to_theta(gcc_phat_tdoa(rir, sr, (0, 1), fmin=300.0,
                                                fmax=4000.0),
                                  mic_spacing, (0, 1))
            rows.append({
                "theta_deg": th, "distance_m": d,
                "pred_tdoa_us_mic0": float(pred[0] * 1e6),
                "peak_tdoa_us_mic0": float(meas[0] * 1e6),
                "peak_delay_err_sample": peak_err,
                "subsample_delay_err_sample": sub_err,
                "t60_measured_s": measure_t60(rir, sr),
                "drr_db": float(np.mean(drr_db(rir, sr, center_sample=center))),
                "msc_mean": msc,
                "msc_low": bands[keys[0]], "msc_mid": bands[keys[1]],
                "msc_high": bands[keys[2]],
                "gcc_theta_fullband_deg": th_gcc,
                "gcc_theta_lowband_deg": th_lb,
                "gcc_theta_err_deg": abs(th_gcc - th),
            })

    print("\n" + "-" * 78)
    print("2) 空间/混响物理量（每个 theta 取最小距离 %s m）" % dists[0])
    print("-" * 78)
    print(f"{'theta':>6} | {'T60(s)':>7} {'DRR(dB)':>8} {'MSC低频':>8} {'MSC中频':>8} "
          f"{'MSC高频':>8} {'GCC全带':>8} {'GCC<4k':>8} {'GCC误差':>8}")
    for th in thetas:
        rir = sim.rir(th, dists[0])
        center = float(sim.analytic_direct_samples(th, dists[0])[ref])
        bands, _ = convolved_coherence(rir, sr)
        keys = list(bands.keys())
        th_full = tdoa_to_theta(gcc_phat_tdoa(rir, sr, (0, 1)),
                                mic_spacing, (0, 1))
        th_lb = tdoa_to_theta(gcc_phat_tdoa(rir, sr, (0, 1), fmin=300.0,
                                            fmax=4000.0), mic_spacing, (0, 1))
        print(f"{th:6.1f} | {measure_t60(rir, sr):7.3f} "
              f"{np.mean(drr_db(rir, sr, center_sample=center)):8.2f} "
              f"{bands[keys[0]]:8.3f} {bands[keys[1]]:8.3f} {bands[keys[2]]:8.3f} "
              f"{th_full:8.1f} {th_lb:8.1f} {abs(th_full-th):8.1f}")

    print("\n" + "=" * 78)
    print(f"亚样本时延最大误差: {max_sub_err:.3f} 样本 (容许 {args.tolerance_sample})")
    if max_sub_err <= args.tolerance_sample:
        print("PASS: 仿真 RIR 与模型端解析式一致，可用于生成训练数据。")
        rc = 0
    else:
        print("FAIL: 时延约定不一致，请勿用于训练（会得到镜像的方位标签）。")
        rc = 1

    if args.out_csv:
        out_dir = os.path.dirname(os.path.abspath(args.out_csv))
        os.makedirs(out_dir, exist_ok=True)
        with open(args.out_csv, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print(f"逐点结果已写入 {args.out_csv}")
    print("=" * 78)
    return rc


if __name__ == "__main__":
    sys.exit(main())
