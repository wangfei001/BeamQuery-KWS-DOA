#!/usr/bin/env python3
import random
import argparse

def read_list(path):
    items = []
    with open(path,"r",encoding="utf8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            items.append(line)
    return items

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--hi_xiaowen_train", type=str)
    parser.add_argument("--hi_xiaowen_dev", type=str)
    parser.add_argument("--aishell3_all", type=str)
    parser.add_argument("--max_aishell3_num", type=int, default=120000)
    parser.add_argument("--train_out", type=str)
    parser.add_argument("--cv_out", type=str)
    parser.add_argument("--seed", type=int, default=666)
    args = parser.parse_args()
    random.seed(args.seed)

    hi_train = read_list(args.hi_xiaowen_train)
    hi_dev = read_list(args.hi_xiaowen_dev)
    aishell_all = read_list(args.aishell3_all)

    random.shuffle(aishell_all)
    aishell_sampled = aishell_all[:args.max_aishell3_num]

    train_total = hi_train + aishell_sampled
    random.shuffle(train_total)
    cv_total = hi_dev

    with open(args.train_out, "w", encoding="utf8") as f:
        f.write("\n".join(train_total))
    with open(args.cv_out, "w", encoding="utf8") as f:
        f.write("\n".join(cv_total))

    pos_train = sum(1 for x in train_total if x.split()[-1]=="1")
    neg_train = len(train_total)-pos_train
    pos_cv = sum(1 for x in cv_total if x.split()[-1]=="1")
    neg_cv = len(cv_total)-pos_cv

    print(f"train total:{len(train_total)}, pos(wake):{pos_train}, neg:{neg_train}")
    print(f"cv total:{len(cv_total)}, pos(wake):{pos_cv}, neg:{neg_cv}")

if __name__ == "__main__":
    main()

