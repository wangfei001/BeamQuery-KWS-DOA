#!/usr/bin/env python3
# Copyright (c) 2026
# Licensed under the Apache License, Version 2.0 (the "License");
"""
由 run.sh 的 stage5 调用
输入stage5可变列临时list：wav_path label n_src doa0 doa1 doa2
输出固定8字段 spatial list：
wav_path num_mic gt_s1 gt_doa1 gt_s2 gt_doa2 gt_s3 gt_doa3
规则：
1. max_src = num_mic；1mic最多1声源；2mic最多2声源；3mic最多3声源
2. 全部声源按DOA类别从小到大排序；唤醒词不一定排在首位
3. DOA类别为0/1/2，对应[0,60)、[60,120)、[120,180]；
   不足3个声源的位置填充 (gt_s=0, gt_doa=-100)，-100表示无效槽位
"""
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--in_list", required=True, help="stage5输出可变列临时list")
    parser.add_argument("--out_list", required=True, help="输出8列 spatial list")
    parser.add_argument("--num_mic", type=int, required=True)
    args = parser.parse_args()

    fin = open(args.in_list, "r", encoding="utf-8")
    fout = open(args.out_list, "w", encoding="utf-8")
    line_count = 0
    max_output_src = 3

    for line in fin:
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        wav_path = parts[0]
        label = int(parts[1])
        n_src = int(parts[2])
        angles = [int(x) for x in parts[3: 3 + n_src]]

        if any(a not in (0, 1, 2) for a in angles):
            raise ValueError(f"{wav_path}: DOA类别必须在0/1/2内, 当前={angles}")
        if len(set(angles)) != len(angles):
            raise ValueError(f"{wav_path}: 同一句音频出现重复DOA类别, 当前={angles}")

        src_list = []
        for ang in angles:
            src_list.append((1, ang))

        # 按DOA类别升序排序核心
        src_list.sort(key=lambda x: x[1])

        # 不足 max_output_src(=3) 个声源时补占位槽。
        # 占位写成 (gt_s=0, gt_doa=-100)：
        #   - gt_s    = 0：表示该槽没有实际声源；
        #   - gt_doa  = -100：与 dataset/loss 的约定一致
        #     （gt_valid_mask[i] = (gt_doa[i] != -100)），占位槽因此不参与 DOA 分类。
        # 注意不能填 (0, 0)：0 是合法DOA类别，会被当成“0类处存在一个声源”，
        # 既污染 DOA 训练，又可能让 KWS 真值在唤醒词为0类时出现多个正槽。
        while len(src_list) < max_output_src:
            src_list.append((0, -100))

        gt_s1, gt_doa1 = src_list[0]
        gt_s2, gt_doa2 = src_list[1]
        gt_s3, gt_doa3 = src_list[2]

        fout.write(f"{wav_path} {args.num_mic} {gt_s1} {gt_doa1} {gt_s2} {gt_doa2} {gt_s3} {gt_doa3}\n")
        line_count += 1
        if line_count % 50000 == 0:
            print(f"processed {line_count} lines")

    fin.close()
    fout.close()
    print(f"append_doa_to_list.py finished (run.sh stage5), total {line_count}, output {args.out_list}")


if __name__ == "__main__":
    main()
