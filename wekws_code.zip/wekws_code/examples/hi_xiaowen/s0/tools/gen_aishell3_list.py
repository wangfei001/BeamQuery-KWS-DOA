#!/usr/bin/env python3
import os
import argparse

def scan_wav(root_dir):
    wav_paths = []
    for dirpath, _, filenames in os.walk(root_dir):
        for fname in filenames:
            if fname.endswith(".wav"):
                full = os.path.abspath(os.path.join(dirpath, fname))
                wav_paths.append(full)
    return wav_paths

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--aishell3_root", type=str, required=True)
    parser.add_argument("--out_list", type=str, required=True)
    args = parser.parse_args()

    wav_train = scan_wav(os.path.join(args.aishell3_root, "wav/train"))
    wav_test = scan_wav(os.path.join(args.aishell3_root, "wav/test"))
    all_wav = wav_train + wav_test

    lines = []
    for p in all_wav:
        lines.append(f"{p} 0")

    with open(args.out_list, "w", encoding="utf8") as f:
        f.write("\n".join(lines))
    print(f"Aishell‑3 total wav:{len(lines)}, save {args.out_list}")

if __name__ == "__main__":
    main()

