# Copyright (c) 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
import os
import torch
import torchaudio
from torch.utils.data import Dataset


class SpatialKwsDataset(Dataset):
    """
    多麦克风空间Kws‑DOA数据集
    Args:
        data_list: spatial list 每行：wav_path num_mic gt_s1 gt_doa1 gt_s2 gt_doa2 gt_s3 gt_doa3
        varcol_tmp_list: stage5输出 varcol.tmp.list，格式：wav_path label n_src ang0 ang1 ang2
        max_gt: 最大声源数量，当前=3
    Note:
        ※ Dataset只读取原始波形，STFT移动到模型GPU内部执行，提升训练速度
        ※ 全部无效DOA真值统一使用‑100，禁止‑1
        ※ gt_valid_mask[i] = True 严格等价 gt_doa[i] !=‑100
    """
    def __init__(self, data_list, varcol_tmp_list, max_gt=3):
        self.max_gt = max_gt
        self.items = []
        # wav绝对路径 -> (kws_label:int, wake_angle_gt:int) wake_angle_gt:0~35 or -100
        self.wav_truth_map = dict()

        # 第一步：加载varcol临时文件，保存唤醒真值
        with open(varcol_tmp_list, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.split()
                wav = os.path.abspath(parts[0])
                label = int(parts[1])
                # n_src = int(parts[2])
                slot_angles = [int(x) for x in parts[3:6]]  # ang0 ang1 ang2 固定3槽，含‑100
                if label == 1:
                    wake_angle = slot_angles[0]
                else:
                    wake_angle = -100
                self.wav_truth_map[wav] = (label, wake_angle)

        # 第二步：加载排序后的spatial list
        with open(data_list, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) < 3:
                    continue
                wav_path = os.path.abspath(parts[0])
                num_mic = int(parts[1])
                rest = list(map(int, parts[2:]))
                try:
                    kws_label, wake_angle_gt = self.wav_truth_map[wav_path]
                except KeyError:
                    raise KeyError(f"wav key不匹配：{wav_path}，检查varcol_tmp_list与data_list路径是否统一为绝对路径")
                self.items.append((wav_path, num_mic, rest, kws_label, wake_angle_gt))

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        wav_path, num_mic, rest, kws_label, wake_angle_gt = self.items[idx]
        # =========只读取原始波形，STFT移至模型GPU端=========
        wav, sr = torchaudio.load(wav_path)
        wav = wav[:num_mic, :]

        gt_s = torch.zeros(self.max_gt, dtype=torch.float32)
        gt_doa = torch.full((self.max_gt,), -100, dtype=torch.long)
        gt_valid_mask = torch.zeros(self.max_gt, dtype=torch.bool)

        pair_num = min(len(rest) // 2, self.max_gt)
        for i in range(pair_num):
            s_val = rest[2 * i]
            doa_val = rest[2 * i + 1]
            gt_s[i] = s_val
            gt_doa[i] = doa_val
            # =========关键修复：mask必须由doa_val是否等于‑100决定=========
            if doa_val != -100:
                gt_valid_mask[i] = True
            else:
                gt_valid_mask[i] = False

        return {
            "wave": wav,                     # [M, T] 原始多通道波形，CPU张量
            "gt_s": gt_s,                    # [G_max]
            "gt_doa": gt_doa,                # [G_max] 0~35 or -100
            "gt_valid_mask": gt_valid_mask,  # [G_max]
            "kws_label": torch.tensor(kws_label, dtype=torch.long),
            "wake_angle_gt": torch.tensor(wake_angle_gt, dtype=torch.long)
        }


def spatial_collate_fn(batch):
    """
    batch内样本麦克风通道数目不一致，波形保留list，不在collate做stack
    返回顺序：wave_list, gt_s, gt_doa, gt_valid_mask, kws_label, wake_angle_gt
    """
    wave_list = [x["wave"] for x in batch]
    gt_s = torch.stack([x["gt_s"] for x in batch])
    gt_doa = torch.stack([x["gt_doa"] for x in batch])
    gt_valid_mask = torch.stack([x["gt_valid_mask"] for x in batch])
    kws_label = torch.stack([x["kws_label"] for x in batch])
    wake_angle_gt = torch.stack([x["wake_angle_gt"] for x in batch])

    return wave_list, gt_s, gt_doa, gt_valid_mask, kws_label, wake_angle_gt
