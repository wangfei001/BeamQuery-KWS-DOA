# Copyright (c) 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
import torch
import torch.nn as nn
import torch.nn.functional as F


class Stacked1DCNNEncoder(nn.Module):
    """
    自实现编码器，完全不依赖wekws内部FSMN，规避版本兼容坑
    输入 [B, T, input_dim]
    输出 [B, T, hidden_dim]
    """
    def __init__(self, input_dim, hidden_dim, num_layers):
        super().__init__()
        layers = []
        in_d = input_dim
        for _ in range(num_layers):
            layers.append(nn.Conv1d(in_d, hidden_dim, kernel_size=5, padding=2))
            layers.append(nn.BatchNorm1d(hidden_dim))
            layers.append(nn.GELU())
            in_d = hidden_dim
        self.conv_layers = nn.Sequential(*layers)

    def forward(self, x):
        # x: [B, T, C]
        x = x.transpose(1, 2)   # [B, C, T]
        y = self.conv_layers(x) # [B, hidden_dim, T]
        return y.transpose(1, 2) # [B, T, hidden_dim]


class FrameWiseQueryGenerator(nn.Module):
    """
    核心模块：逐帧动态生成Query，无手工波束分支
    输入阵列特征: enc_feat [B, M, D, T]
    返回 queries: [B, T, Q, D]
    """
    def __init__(self, encoder_dim: int, num_query: int):
        super().__init__()
        self.num_query = num_query
        self.dim = encoder_dim
        self.mlp = nn.Sequential(
            nn.Linear(encoder_dim, encoder_dim),
            nn.LayerNorm(encoder_dim),
            nn.ReLU(inplace=True),
            nn.Linear(encoder_dim, num_query * encoder_dim)
        )

    def forward(self, enc_feat: torch.Tensor):
        B, M, D, T = enc_feat.shape
        # 在麦克风维度M求平均，输出 [B,D,T]
        frame_global = torch.mean(enc_feat, dim=1)
        frame_global = frame_global.permute(0, 2, 1)  # [B, T, D]
        q_all = self.mlp(frame_global)  # [B, T, Q*D]
        queries = q_all.reshape(B, T, self.num_query, self.dim)
        return queries


class QueryCrossAggregate(nn.Module):
    """
    Query与阵列多通道特征交叉注意力聚合 + 时间维池化。

    pool_type:
      "mean"     : 全段帧平均（原行为）
      "mean_max" : 拼接 [帧平均, 帧最大]，唤醒词只占短时段时 max 不易被稀释
      "attn"     : 可学习注意力池化（逐 query 对时间维 softmax 加权）

    queries:      [B, T, Q, D]
    array_feat:   [B, M, D, T]
    return：[B, Q, D]  (mean_max 时为 [B, Q, 2D])
    """
    def __init__(self, dim: int, pool_type: str = "mean_max"):
        super().__init__()
        self.dim = dim
        self.pool_type = pool_type
        self.q_proj = nn.Linear(dim, dim)
        self.k_proj = nn.Linear(dim, dim)
        self.v_proj = nn.Linear(dim, dim)
        if pool_type == "attn":
            self.pool_score = nn.Linear(dim, 1)

    def forward(self, queries: torch.Tensor, array_feat: torch.Tensor):
        B, T, Q, D = queries.shape
        B, M, D, T = array_feat.shape
        arr = array_feat.permute(0, 3, 1, 2) # [B, T, M, D]
        q = self.q_proj(queries)          # [B, T, Q, D]
        k = self.k_proj(arr)              # [B, T, M, D]
        v = self.v_proj(arr)              # [B, T, M, D]
        attn_score = torch.einsum("btqd,btmd->btqm", q, k) / (D ** 0.5)
        attn_weight = F.softmax(attn_score, dim=-1)
        frame_agg = torch.einsum("btqm,btmd->btqd", attn_weight, v)  # [B,T,Q,D]

        if self.pool_type == "mean":
            out = frame_agg.mean(dim=1)                      # [B,Q,D]
        elif self.pool_type == "mean_max":
            out = torch.cat([frame_agg.mean(dim=1),
                             frame_agg.max(dim=1).values], dim=-1)   # [B,Q,2D]
        elif self.pool_type == "attn":
            w = torch.softmax(self.pool_score(frame_agg).squeeze(-1), dim=1)  # [B,T,Q]
            out = torch.einsum("btq,btqd->bqd", w, frame_agg)                # [B,Q,D]
        else:
            raise ValueError(f"未知 pool_type: {self.pool_type}")
        return out


class SharedPredictHead(nn.Module):
    def __init__(self, in_dim: int, doa_classes: int):
        super().__init__()
        self.fc1 = nn.Linear(in_dim, in_dim)
        self.norm = nn.LayerNorm(in_dim)
        self.score_fc = nn.Linear(in_dim, 1)
        self.doa_fc = nn.Linear(in_dim, doa_classes)

    def forward(self, q_feat: torch.Tensor):
        x = self.fc1(q_feat)
        x = self.norm(x)
        x = F.relu(x)
        # 输出logit，训练使用 BCEWithLogitsLoss；sigmoid放到推理阶段
        s_logit = self.score_fc(x).squeeze(-1)
        doa_logit = self.doa_fc(x)
        return s_logit, doa_logit


class SpatialDynamicQueryModel(nn.Module):
    """
    动态Query多麦克风唤醒+DOA定位模型
    输入 wave_list: List[Tensor]，每个tensor [M_i, T]
    支持batch内部样本麦克风数目不一致；GPU内部执行STFT
    return dict同时兼容新旧key: s_q / doa_logit 以及 pred_s / pred_doa_logit
    """
    def __init__(
        self,
        fsmn_num_layers: int,
        fsmn_dim: int,
        num_query: int,
        doa_num_class: int,
        feat_freq_dim: int = 257,
        use_ipd: bool = True,
        use_pair_ipd: bool = True,
        num_mic: int = 3,
        pool_type: str = "mean_max",
        pair_feat_mode: str = "tdoa",
        mic_spacing: float = 0.08,
        sr: int = 16000,
        speed_sound: float = 340.0
    ):
        super().__init__()
        self.num_query = num_query
        self.doa_num_class = doa_num_class
        self.feat_freq_dim = feat_freq_dim
        # 特征方案(优先级从高到低)：
        #   use_pair_ipd=True : 每个麦克风 = [幅度_i] + 与其余每个麦的(cos,sin)相位差
        #                       通道数 = (1 + 2*(num_mic-1)) * F   (3麦 -> 5F)
        #   use_ipd=True      : 每个麦克风 = [幅度, cos(IPD), sin(IPD)]，IPD 相对第0麦
        #                       通道数 = 3F
        #   否则              : 只用幅度谱，通道数 = F
        self.use_ipd = use_ipd
        self.use_pair_ipd = use_pair_ipd
        self.num_mic = num_mic
        # 阵列几何(用于时延→角度反解)
        self.mic_spacing = mic_spacing
        self.sr = sr
        self.speed_sound = speed_sound
        # ===== 输入特征方案 =====
        #   pair_feat_mode="pair_arctan": 每麦 = [幅度_i(F)] + 与其余每个麦的相位差
        #                              arctan 值(弧度, F)，只做 atan2，不做时延/角度反解
        #   pair_feat_mode="tdoa"    : 每麦 = [幅度(F)] + 参与的各麦对 [sinθ̂, cosθ̂, 相干性]×3
        #                              （GCC-PHAT 估时延 τ，再 cosθ=c·τ/d 反解真实角度）
        #   pair_feat_mode="pair_ipd": 每麦 = [幅度, 与其余每个麦的 cos/sin 相位差]
        #   pair_feat_mode="ipd"     : 每麦 = [幅度, cos(IPD), sin(IPD)]（相对第0麦）
        #   pair_feat_mode="mag"     : 只用幅度谱
        if pair_feat_mode not in ("pair_arctan", "tdoa", "pair_ipd", "ipd", "mag"):
            # 兼容旧配置：未显式给 pair_feat_mode 时，用旧开关推断
            pair_feat_mode = ("pair_ipd" if use_pair_ipd else
                              ("ipd" if use_ipd else "mag"))
        self.pair_feat_mode = pair_feat_mode
        if pair_feat_mode == "pair_arctan":
            # 每麦 = [幅度(F)] + 与其余每个麦的相位差arctan值(F)
            encoder_input_dim = feat_freq_dim * num_mic
        elif pair_feat_mode == "tdoa":
            encoder_input_dim = feat_freq_dim + 3 * (num_mic - 1)
        elif pair_feat_mode == "pair_ipd":
            encoder_input_dim = feat_freq_dim * (1 + 2 * (num_mic - 1))
        elif pair_feat_mode == "ipd":
            encoder_input_dim = feat_freq_dim * 3
        elif pair_feat_mode == "mag":
            encoder_input_dim = feat_freq_dim
        else:
            raise ValueError(f"未知 pair_feat_mode: {pair_feat_mode}")

        self.encoder = Stacked1DCNNEncoder(
            input_dim=encoder_input_dim,
            hidden_dim=fsmn_dim,
            num_layers=fsmn_num_layers
        )
        self.query_gen = FrameWiseQueryGenerator(encoder_dim=fsmn_dim, num_query=num_query)
        self.cross_agg = QueryCrossAggregate(dim=fsmn_dim, pool_type=pool_type)
        # mean_max 会把特征维翻倍，这里同步调整预测头输入维
        head_in = fsmn_dim * 2 if pool_type == "mean_max" else fsmn_dim
        self.head = SharedPredictHead(in_dim=head_in, doa_classes=doa_num_class)

        # STFT 窗口注册buffer，GPU使用，采样率16000 -> F=257
        self.n_fft = 512
        self.hop_length = 160
        self.win_length = 512
        self.register_buffer("window", torch.hann_window(self.win_length))

    def _pair_angle_feature(self, stft_out, i, j):
        """用 GCC-PHAT 估计麦对(i,j)的时延，再按阵列几何反解真实角度。

        原理：
          1) 交叉谱 X = S_i · conj(S_j)，其相位 = 2πf·(τ_i-τ_j)
          2) PHAT 白化 X/|X| 后做 IFFT，峰值位置即两麦时延差(样本)
          3) 抛物线插值取亚采样峰值 → 时延 τ(秒)
          4) 均匀线阵几何：τ = (pos_i-pos_j)·cosθ / c  →  cosθ = c·τ/d_ij
          5) 输出 [sinθ, cosθ, 相干性]：sin/cos 已可直接区分 0~180° 的镜像；
             相干性 = |X|²/(|S_i|²|S_j|²) 的频率均值，作为该帧该对的置信度。
        返回: [3, T]
        """
        n = self.n_fft
        Xi, Xj = stft_out[i], stft_out[j]                 # [F,T] complex
        X = Xi * torch.conj(Xj)                           # 交叉谱
        with torch.no_grad():                             # 手工特征，不需要反传
            Xp = X / (X.abs() + 1e-8)                     # PHAT 白化
            cc = torch.fft.irfft(Xp, n=n, dim=0)          # [n,T] 广义互相关
            T = cc.shape[1]
            ar = torch.arange(T, device=cc.device)
            idx = cc.argmax(dim=0)                        # 整数峰值 [T]
            left = cc[(idx - 1) % n, ar]
            mid = cc[idx, ar]
            right = cc[(idx + 1) % n, ar]
            denom = left - 2 * mid + right
            delta = torch.where(denom.abs() > 1e-8,
                                0.5 * (left - right) / denom,
                                torch.zeros_like(mid))
            lag = idx.float() + delta                     # 亚采样峰值位置
            lag = torch.where(lag > n / 2, lag - n, lag)  # 折回 [-n/2, n/2]
            tau = lag / float(self.sr)                    # 时延(秒)
            # 有符号间距：与生成端 RIR 的时延符号对齐（否则角度会镜像成 180-θ）
            d = (j - i) * self.mic_spacing
            cos_th = (self.speed_sound * tau / d).clamp(-1.0, 1.0)
            sin_th = torch.sqrt(torch.clamp(1.0 - cos_th ** 2, min=0.0))
            # 相干性(置信度)
            num = (X.abs() ** 2).mean(dim=0)
            den = (Xi.abs() ** 2 * Xj.abs() ** 2).mean(dim=0) + 1e-8
            coh = (num / den).clamp(0.0, 1.0)
            feat = torch.stack([sin_th, cos_th, coh], dim=0)   # [3,T]
        return feat

    def forward(self, wave_list):
        """
        Args:
            wave_list: list[torch.Tensor], 每个tensor shape [M_i, T]
            M_i：单样本麦克风数量，batch之间可以不同
        Returns:
            dict同时包含两套key用于兼容旧train.py
        """
        s_q_batch = []
        doa_logit_batch = []

        for wav in wave_list:
            # wav: [M_i, T]
            wav = wav.to(self.window.device)
            # GPU STFT，返回复数谱 [M_i, F, T]
            stft_out = torch.stft(
                wav,
                n_fft=self.n_fft,
                hop_length=self.hop_length,
                win_length=self.win_length,
                window=self.window,
                return_complex=True
            )
            M_i, F, T = stft_out.shape
            mag = stft_out.abs()  # 幅度谱 [M_i, F, T]

            if self.pair_feat_mode == "pair_arctan":
                # ===== 只取相位差的 arctan 值 (弧度)，不反解角度 =====
                # 对每对麦 (i,j)：cross = S_i · conj(S_j)，
                #   dphi = atan2(Im(cross), Re(cross))   # 弧度, (-π, π]
                # 每个麦的特征 = [幅度_i, { dphi_ij | j≠i }]，通道数 = F*M (3麦 → 771)
                # 注意：相位在 ±π 处有跳变；若训练不稳，可切回 pair_ipd(cos/sin 编码)。
                angle = torch.angle(stft_out)           # [M_i,F,T]
                per_mic = []
                for i in range(M_i):
                    parts = [mag[i:i + 1]]              # [1,F,T]
                    for j in range(M_i):
                        if j == i:
                            continue
                        # cross 的相位 = φ_i - φ_j
                        dphi = angle[i:i + 1] - angle[j:j + 1]   # (-π,π]
                        parts.append(dphi)
                    per_mic.append(torch.cat(parts, dim=1).squeeze(0))  # [F*M, T]
                feat = torch.stack(per_mic, dim=0)                  # [M_i, C, T]
                feat_dim_in = feat.shape[1]
            elif self.pair_feat_mode == "tdoa":
                # ===== 各麦对：GCC-PHAT 时延 → 真实角度特征 =====
                assert M_i == self.num_mic, (
                    f"tdoa 特征需要固定 {self.num_mic} 麦, 当前 {M_i} 麦")
                pair_list = [(i, j) for i in range(M_i) for j in range(i + 1, M_i)]
                pair_feats = {p: self._pair_angle_feature(stft_out, *p) for p in pair_list}
                per_mic = []
                for m in range(M_i):
                    parts = [mag[m:m + 1]]                       # [1,F,T]
                    for (i, j), pf in pair_feats.items():
                        if m == i or m == j:                     # 该麦参与的麦对
                            parts.append(pf.unsqueeze(0))        # [1,3,T]
                    per_mic.append(torch.cat(parts, dim=1).squeeze(0))   # [F+3*(M-1), T]
                feat = torch.stack(per_mic, dim=0)                # [M_i, C, T]
                feat_dim_in = feat.shape[1]
            elif self.pair_feat_mode == "pair_ipd":
                # ===== 两两麦克风相位差 (所有麦克风对, 共 C(M,2) 对) =====
                # 对每个麦克风 i：
                #   feature_i = [ 幅度_i, { cos(φ_i-φ_j), sin(φ_i-φ_j) | j≠i } ]
                # 3 麦时包含 (0,1)、(0,2)、(1,2) 三对相位关系（比“只相对麦0”更全），
                # 相位用 cos/sin 编码以规避 2π 卷绕；每个麦通道数 = (1+2*(M-1))*F。
                angle = torch.angle(stft_out)  # [M_i, F, T]
                assert M_i == self.num_mic, (
                    f"pair_ipd 特征需要固定 {self.num_mic} 麦, 当前 {M_i} 麦")
                per_mic = []
                for i in range(M_i):
                    parts = [mag[i:i + 1]]                      # [1,F,T]
                    for j in range(M_i):
                        if j == i:
                            continue
                        dij = angle[i:i + 1] - angle[j:j + 1]    # [1,F,T]
                        parts.append(torch.cos(dij))
                        parts.append(torch.sin(dij))
                    # parts 每个是 [1,F,T]，沿“频率维(dim=1)”拼接：
                    # [幅度|cos|sin|...] -> [1, (1+2(M-1))*F, T]，再压掉第0维
                    per_mic.append(torch.cat(parts, dim=1).squeeze(0))  # [C, T]
                feat = torch.stack(per_mic, dim=0)                      # [M_i, C, T]
                feat_dim_in = feat.shape[1]
            elif self.pair_feat_mode == "ipd":
                # ===== IPD 相位差特征(相对第0麦) =====
                # IPD_i(f,t)=arg(S_i)-arg(S_0)=2*pi*f*(tau_i-tau_0)，
                # 相位有 2π 卷绕，用 cos/sin 两个实数通道编码。
                angle = torch.angle(stft_out)
                ipd = angle - angle[0:1]
                feat = torch.cat([mag, torch.cos(ipd), torch.sin(ipd)], dim=1)  # [M_i,3F,T]
                feat_dim_in = 3 * F
            else:
                feat = mag
                feat_dim_in = F

            # 伪造batch维度 B=1，复用原有整套网络逻辑
            feat = feat.unsqueeze(0) # [1, M_i, feat_dim_in, T]

            enc_out_list = []
            for mic_idx in range(M_i):
                single_feat = feat[:, mic_idx, :, :]   # [1, feat_dim_in, T]
                enc_out = self.encoder(single_feat.transpose(1, 2))
                enc_out_list.append(enc_out)

            array_enc = torch.stack(enc_out_list, dim=1).permute(0, 1, 3, 2) # [1, M_i, D, T]
            queries = self.query_gen(array_enc)
            q_agg_feat = self.cross_agg(queries, array_enc)
            s_q, doa_logit = self.head(q_agg_feat)

            s_q_batch.append(s_q.squeeze(0))
            doa_logit_batch.append(doa_logit.squeeze(0))

        s_q = torch.stack(s_q_batch, dim=0)
        doa_logit = torch.stack(doa_logit_batch, dim=0)
        # 兼容新旧两套key，train.py读取s_q不会KeyError
        return {
            "s_q": s_q,
            "doa_logit": doa_logit,
            "pred_s": s_q,
            "pred_doa_logit": doa_logit
        }


class SetMatchingLoss(nn.Module):
    """KWS(槽位二分类) + DOA(36类) 联合损失。

    KWS 分支可选：
      kws_loss_type="bce"   : BCEWithLogits，可用 pos_weight 缓解“正槽极少”的不平衡
      kws_loss_type="focal" : sigmoid focal loss（困难样本加权），配合 focal_gamma
    """
    def __init__(self, lambda_kws: float = 1.0, lambda_doa: float = 0.5,
                 kws_loss_type: str = "bce", pos_weight: float = 0.0,
                 focal_gamma: float = 2.0):
        super().__init__()
        self.lambda_kws = lambda_kws
        self.lambda_doa = lambda_doa
        self.kws_loss_type = kws_loss_type
        self.pos_weight = pos_weight
        self.focal_gamma = focal_gamma

    def forward(
        self,
        pred_s: torch.Tensor,
        pred_doa_logit: torch.Tensor,
        gt_s: torch.Tensor,
        gt_doa: torch.Tensor,
        gt_valid_mask: torch.Tensor,
        kws_label: torch.Tensor,
        wake_angle_gt: torch.Tensor
    ):
        """
        pred_s: [B, num_query] kws logit（未sigmoid）
        pred_doa_logit: [B, num_query, doa_classes]
        gt_s: [B,Q]
        gt_doa: [B,Q], padding=-100，合法角度0~35
        gt_valid_mask: [B,Q] bool
        kws_label: [B] 0/1，样本是否含唤醒词
        wake_angle_gt: [B]，唤醒词离散类别0~35；负样本=-100
        return total_loss, loss_dict
        """
        B, Q = pred_s.shape
        # --------------------------
        # 双重掩码：槽位有效 AND doa标签不等于‑100，彻底过滤padding
        # --------------------------
        combined_mask = torch.logical_and(gt_valid_mask, gt_doa != -100)
        logit_flat = pred_doa_logit.reshape(-1, pred_doa_logit.size(-1))
        gt_doa_flat = gt_doa.reshape(-1)
        mask_flat = combined_mask.reshape(-1)
        logit_valid = logit_flat[mask_flat]
        gt_doa_valid = gt_doa_flat[mask_flat]

        if logit_valid.shape[0] > 0:
            doa_loss = F.cross_entropy(logit_valid, gt_doa_valid, reduction="mean")
        else:
            # 全batch无有效声源，返回可导0，防止nan
            doa_loss = 0.0 * pred_doa_logit.sum()

        # 构造KWS真值
        kws_gt = torch.zeros_like(pred_s, dtype=torch.float32, device=pred_s.device)
        for b in range(B):
            if kws_label[b].item() == 1 and wake_angle_gt[b].item() != -100:
                target_ang = wake_angle_gt[b].item()
                for pos in range(Q):
                    if gt_valid_mask[b, pos] and gt_doa[b, pos].item() == target_ang:
                        kws_gt[b, pos] = 1.0
                    else:
                        kws_gt[b, pos] = 0.0
            else:
                kws_gt[b, :] = 0.0

        # ---- KWS 损失：BCE(可选 pos_weight) 或 focal ----
        pw = None
        if self.pos_weight and self.pos_weight > 0:
            pw = torch.tensor(float(self.pos_weight), device=pred_s.device)
        if self.kws_loss_type == "focal":
            ce = F.binary_cross_entropy_with_logits(pred_s, kws_gt,
                                                    reduction="none", pos_weight=pw)
            p = torch.sigmoid(pred_s)
            pt = torch.where(kws_gt > 0.5, p, 1.0 - p)     # 属于该类的概率
            kws_loss = (((1.0 - pt) ** self.focal_gamma) * ce).mean()
        else:
            kws_loss = F.binary_cross_entropy_with_logits(pred_s, kws_gt,
                                                          reduction="mean", pos_weight=pw)
        total_loss = self.lambda_kws * kws_loss + self.lambda_doa * doa_loss
        loss_dict = {
            "kws_loss": float(kws_loss.item()),
            "doa_loss": float(doa_loss.item()) if isinstance(doa_loss, torch.Tensor) else 0.0
        }
        return total_loss, loss_dict
