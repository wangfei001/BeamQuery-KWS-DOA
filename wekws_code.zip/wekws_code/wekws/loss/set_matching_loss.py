# Copyright (c) 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
import torch
import torch.nn as nn
import torch.nn.functional as F


class Stacked1DCNNEncoder(nn.Module):
    """
    自实现编码器，完全不依赖wekws内部FSMN，规避版本兼容坑
    输入 [B, T, input_dim]
    输出 [B, T, hidden_dim]
    """
    def __init__(self, input_dim, hidden_dim, num_layers):
        super().__init__()
        layers = []
        in_d = input_dim
        for _ in range(num_layers):
            layers.append(nn.Conv1d(in_d, hidden_dim, kernel_size=5, padding=2))
            layers.append(nn.LayerNorm(hidden_dim))
            layers.append(nn.ReLU(inplace=True))
            in_d = hidden_dim
        self.conv_layers = nn.Sequential(*layers)

    def forward(self, x):
        # x: [B, T, C]
        x = x.transpose(1, 2)   # [B, C, T]
        y = self.conv_layers(x) # [B, hidden_dim, T]
        return y.transpose(1, 2) # [B, T, hidden_dim]


class FrameWiseQueryGenerator(nn.Module):
    """
    核心模块：逐帧动态生成Query，无手工波束分支
    输入阵列特征: enc_feat [B, M, D, T]
    返回 queries: [B, T, Q, D]
    """
    def __init__(self, encoder_dim: int, num_query: int):
        super().__init__()
        self.num_query = num_query
        self.dim = encoder_dim
        self.pool_mic = nn.AdaptiveAvgPool2d((1, None))
        self.mlp = nn.Sequential(
            nn.Linear(encoder_dim, encoder_dim),
            nn.LayerNorm(encoder_dim),
            nn.ReLU(inplace=True),
            nn.Linear(encoder_dim, num_query * encoder_dim)
        )

    def forward(self, enc_feat: torch.Tensor):
        B, M, D, T = enc_feat.shape
        frame_global = self.pool_mic(enc_feat)
        frame_global = frame_global.squeeze(1)   # [B, D, T]
        frame_global = frame_global.permute(0, 2, 1)  # [B, T, D]
        q_all = self.mlp(frame_global)  # [B, T, Q*D]
        queries = q_all.reshape(B, T, self.num_query, self.dim)
        return queries


class QueryCrossAggregate(nn.Module):
    """
    Query与阵列多通道特征交叉注意力聚合
    queries:      [B, T, Q, D]
    array_feat:   [B, M, D, T]
    return：[B, Q, D]
    """
    def __init__(self, dim: int):
        super().__init__()
        self.dim = dim
        self.q_proj = nn.Linear(dim, dim)
        self.k_proj = nn.Linear(dim, dim)
        self.v_proj = nn.Linear(dim, dim)

    def forward(self, queries: torch.Tensor, array_feat: torch.Tensor):
        B, T, Q, D = queries.shape
        B, M, D, T = array_feat.shape
        # 修复：不把M和D强行合并，变换维度 [B,T,M,D]
        arr = array_feat.permute(0, 3, 1, 2)  # [B, T, M, D]
        q = self.q_proj(queries)          # [B,T,Q,D]
        k = self.k_proj(arr)              # [B,T,M,D]
        v = self.v_proj(arr)              # [B,T,M,D]
        # einstein sum：query对麦克风维度做注意力
        attn_score = torch.einsum("btqd,btmd->btqm", q, k) / (D ** 0.5)
        attn_weight = F.softmax(attn_score, dim=-1)
        frame_agg = torch.einsum("btqm,btmd->btqd", attn_weight, v)
        out = torch.mean(frame_agg, dim=1)  # 时间维度平均 [B,Q,D]
        return out


class SharedPredictHead(nn.Module):
    def __init__(self, in_dim: int, doa_classes: int):
        super().__init__()
        self.fc1 = nn.Linear(in_dim, in_dim)
        self.norm = nn.LayerNorm(in_dim)
        self.score_fc = nn.Linear(in_dim, 1)
        self.doa_fc = nn.Linear(in_dim, doa_classes)

    def forward(self, q_feat: torch.Tensor):
        x = self.fc1(q_feat)
        x = self.norm(x)
        x = F.relu(x)
        # 重要：移除sigmoid，输出logit，外部使用BCEWithLogitsLoss
        s_logit = self.score_fc(x).squeeze(-1)
        doa_logits = self.doa_fc(x)
        return s_logit, doa_logits


class SpatialDynamicQueryModel(nn.Module):
    """
    动态Query多麦克风唤醒+DOA定位模型
    input feat: [B, M, F, T]
    return dict: s_q:[B,Q] (kws logits), doa_logit:[B,Q,doa_cls]
    """
    def __init__(
        self,
        fsmn_num_layers: int,
        fsmn_dim: int,
        num_query: int,
        doa_num_class: int,
        feat_freq_dim: int = 257
    ):
        super().__init__()
        self.num_query = num_query
        self.encoder = Stacked1DCNNEncoder(
            input_dim=feat_freq_dim,
            hidden_dim=fsmn_dim,
            num_layers=fsmn_num_layers
        )
        self.query_gen = FrameWiseQueryGenerator(encoder_dim=fsmn_dim, num_query=num_query)
        self.cross_agg = QueryCrossAggregate(dim=fsmn_dim)
        self.head = SharedPredictHead(in_dim=fsmn_dim, doa_classes=doa_num_class)

    def forward(self, feat: torch.Tensor):
        B, M, F, T = feat.shape
        enc_out_list = []
        for mic_idx in range(M):
            single_feat = feat[:, mic_idx, :, :]   # [B,F,T]
            enc_out = self.encoder(single_feat.transpose(1, 2))
            enc_out_list.append(enc_out)
        array_enc = torch.stack(enc_out_list, dim=1).permute(0, 1, 3, 2) # [B,M,D,T]
        queries = self.query_gen(array_enc)
        q_agg_feat = self.cross_agg(queries, array_enc)
        s_q, doa_logit = self.head(q_agg_feat)
        return {
            "s_q": s_q,
            "doa_logit": doa_logit
        }


class SetMatchingLoss(nn.Module):
    def __init__(self, lambda_kws: float = 1.0, lambda_doa: float = 0.5):
        super().__init__()
        self.lambda_kws = lambda_kws
        self.lambda_doa = lambda_doa

    def forward(
        self,
        pred_s: torch.Tensor,
        pred_doa_logit: torch.Tensor,
        gt_s: torch.Tensor,
        gt_doa: torch.Tensor,
        gt_valid_mask: torch.Tensor,
        kws_label: torch.Tensor,
        wake_angle_gt: torch.Tensor
    ):
        """
        pred_s: [B, num_query]  kws logit（未sigmoid）
        pred_doa_logit: [B, num_query, doa_num_class]
        gt_s: [B, max_gt]
        gt_doa: [B, max_gt], padding=-100
        gt_valid_mask: [B, max_gt] bool
        kws_label: [B] 0/1，样本是否包含唤醒词
        wake_angle_gt: [B]，唤醒词角度；无效样本=-100
        return total_loss, loss_dict
        """
        B, Q = pred_s.shape

        # ========== DOA loss 修复：双重mask，先过滤再送入cross_entropy ==========
        # 组合mask：槽位有效 AND doa标签不是padding‑100
        combined_mask = torch.logical_and(gt_valid_mask, gt_doa != -100)

        logit_flat = pred_doa_logit.reshape(-1, pred_doa_logit.size(-1))
        gt_doa_flat = gt_doa.reshape(-1)
        mask_flat = combined_mask.reshape(-1)

        logit_valid = logit_flat[mask_flat]
        gt_doa_valid = gt_doa_flat[mask_flat]

        if logit_valid.shape[0] > 0:
            doa_loss = F.cross_entropy(logit_valid, gt_doa_valid, reduction="mean")
        else:
            # 没有有效声源，返回可导0张量，避免nan
            doa_loss = 0.0 * pred_doa_logit.sum()

        # ========== KWS真值构造 ==========
        kws_gt = torch.zeros_like(pred_s, dtype=torch.float32, device=pred_s.device)
        for b in range(B):
            if kws_label[b].item() == 1 and wake_angle_gt[b].item() != -100:
                target_ang = wake_angle_gt[b].item()
                for pos in range(Q):
                    if gt_valid_mask[b, pos] and gt_doa[b, pos].item() == target_ang:
                        kws_gt[b, pos] = 1.0
                    else:
                        kws_gt[b, pos] = 0.0
            else:
                kws_gt[b, :] = 0.0

        kws_loss = F.binary_cross_entropy_with_logits(pred_s, kws_gt, reduction="mean")

        total_loss = self.lambda_kws * kws_loss + self.lambda_doa * doa_loss

        loss_dict = {
            "kws_loss": float(kws_loss.item()),
            "doa_loss": float(doa_loss.item()) if isinstance(doa_loss, torch.Tensor) else 0.0
        }
        return total_loss, loss_dict
