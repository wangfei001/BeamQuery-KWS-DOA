#!/usr/bin/env python3
# Copyright (c) 2026
# Licensed under the Apache License, Version 2.0 (the "License");
"""
stage6
输入stage5可变列临时list：wav_path label n_src angle0 angle1 angle2
输出固定8字段 spatial list：
wav_path num_mic gt_s1 gt_doa1 gt_s2 gt_doa2 gt_s3 gt_doa3
规则：
1. max_src = num_mic；1mic最多1声源；2mic最多2声源；3mic最多3声源
2. 全部声源按角度从小到大排序；唤醒词不一定排在首位
3. 不足3个声源位置填充 (0,0)占位
"""
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--in_list", required=True, help="stage5输出可变列临时list")
    parser.add_argument("--out_list", required=True, help="输出8列 spatial list")
    parser.add_argument("--num_mic", type=int, required=True)
    args = parser.parse_args()

    fin = open(args.in_list, "r", encoding="utf-8")
    fout = open(args.out_list, "w", encoding="utf-8")
    line_count = 0
    max_output_src = 3

    for line in fin:
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        wav_path = parts[0]
        label = int(parts[1])
        n_src = int(parts[2])
        angles = [int(x) for x in parts[3: 3 + n_src]]

        src_list = []
        for ang in angles:
            src_list.append((1, ang))

        # 按角度升序排序核心
        src_list.sort(key=lambda x: x[1])

        # 补全至3组声源，不足填0占位
        while len(src_list) < max_output_src:
            src_list.append((0, 0))

        gt_s1, gt_doa1 = src_list[0]
        gt_s2, gt_doa2 = src_list[1]
        gt_s3, gt_doa3 = src_list[2]

        fout.write(f"{wav_path} {args.num_mic} {gt_s1} {gt_doa1} {gt_s2} {gt_doa2} {gt_s3} {gt_doa3}\n")
        line_count += 1
        if line_count % 50000 == 0:
            print(f"processed {line_count} lines")

    fin.close()
    fout.close()
    print(f"stage6 finished, total {line_count}, output {args.out_list}")


if __name__ == "__main__":
    main()
