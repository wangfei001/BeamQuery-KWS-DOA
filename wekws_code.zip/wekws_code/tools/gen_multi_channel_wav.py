#!/usr/bin/env python3
# Copyright (c) 2026
# Licensed under the Apache License, Version 2.0 (the "License");
"""
stage5：生成多麦克风多声源仿真数据集
规则：
1. max_src = num_mic：1mic最多1声源；2mic最多2声源；3mic最多3声源
2. 任意两个声源最短角度夹角 >=20°，角度范围0‑180
3. 正样本：1个唤醒词 + 0~max_src‑1路干扰；负样本：1~max_src路干扰，无唤醒词
4. 多声源SIR=0dB混合；自由场时延衰减RIR，无房间混响
输出临时list：wav_path label n_src ang0 ang1 ang2
无效槽位填充-100，角度已经映射为0~35类别id
"""
import argparse
import os
import random
import torch
import torchaudio
import math


def angle_to_class(phys_deg: int):
    """物理角度0‑180 → 36类 0~35，步长5°；180归为35"""
    if phys_deg >= 178:
        return 35
    cid = round(phys_deg / 5.0)
    return max(0, min(35, cid))


def sample_angles(num_need: int, angle_min: int = 0, angle_max: int = 180, gap_min: int = 20):
    """采样一组角度，两两最短夹角 >= gap_min，增加防死循环保护"""
    angles = []
    max_retry = 10000
    retry_cnt = 0
    while len(angles) < num_need and retry_cnt < max_retry:
        cand = random.randint(angle_min, angle_max)
        ok = True
        for a in angles:
            diff_abs = abs(cand - a)
            diff_short = min(diff_abs, 180 - diff_abs)
            if diff_short < gap_min:
                ok = False
                break
        if ok:
            angles.append(cand)
        retry_cnt += 1
    assert len(angles) == num_need, f"无法采样满足角度间隔{gap_min}的{num_need}个角度"
    return angles


def generate_array_rir(angle_deg: int, num_mic: int, mic_spacing: float, sr: int, speed_sound: float = 340.0):
    """均匀线阵自由场RIR，仅直达声无时域混响"""
    angle_rad = math.radians(angle_deg)
    rir_len = 256
    rir_tensor = torch.zeros((num_mic, rir_len), dtype=torch.float32)
    for mic_idx in range(num_mic):
        pos_x = (mic_idx - (num_mic - 1) / 2.0) * mic_spacing
        tau = pos_x * math.cos(angle_rad) / speed_sound
        sample_delay = tau * sr
        delay_int = int(math.floor(sample_delay))
        frac = sample_delay - delay_int
        amp = 1.0 / (1.0 + abs(pos_x))
        if 0 <= delay_int < rir_len - 1:
            rir_tensor[mic_idx, delay_int] = amp * (1.0 - frac)
            rir_tensor[mic_idx, delay_int + 1] = amp * frac
    return rir_tensor


def convolve_rir(single_audio: torch.Tensor, rir: torch.Tensor) -> torch.Tensor:
    """单通道语音卷积多通道RIR输出多通道波形 [num_mic, T_out]"""
    M = rir.shape[0]
    audio_mc = []
    for mic_idx in range(M):
        one_rir = rir[mic_idx:mic_idx + 1, :]
        conv_out = torch.nn.functional.conv1d(
            single_audio.unsqueeze(0),
            one_rir.unsqueeze(0),
            padding=one_rir.shape[-1] - 1
        )
        conv_out = conv_out.squeeze(0).squeeze(0)
        audio_mc.append(conv_out)
    audio_mc = torch.stack(audio_mc, dim=0)
    return audio_mc


def mix_multi_sir0db(signals_mc):
    """多通道多声源混合，全部声源能量相等 SIR=0dB"""
    if len(signals_mc) == 0:
        return None
    scaled_list = []
    T_max = max(s.shape[-1] for s in signals_mc)
    for s in signals_mc:
        s_pad = torch.nn.functional.pad(s, (0, T_max - s.shape[-1]))
        power = torch.mean(s_pad ** 2) + 1e-8
        s_scaled = s_pad / torch.sqrt(power)
        scaled_list.append(s_scaled)
    out = torch.zeros_like(scaled_list[0])
    for s in scaled_list:
        out += s
    return out


def load_scp(wav_scp_path, text_scp_path):
    """读取wekws scp，拆分唤醒词正样本池、干扰负样本池"""
    wav_dict = {}
    with open(wav_scp_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            utt, wav = line.split(maxsplit=1)
            wav_dict[utt] = wav
    text_dict = {}
    with open(text_scp_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            utt, txt = line.split(maxsplit=1)
            text_dict[utt] = txt
    pos_pool = []
    neg_pool = []
    for utt in wav_dict:
        wav_path = wav_dict[utt]
        txt = text_dict.get(utt, "")
        label = 1 if "<HI_XIAOWEN>" in txt else 0
        if label == 1:
            pos_pool.append(wav_path)
        else:
            neg_pool.append(wav_path)
    return pos_pool, neg_pool


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--wav_scp", required=True, help="data/train/wav.scp from wekws")
    parser.add_argument("--text_scp", required=True, help="data/train/text from wekws")
    parser.add_argument("--out_wav_dir", required=True, help="output multi‑channel wav dir")
    parser.add_argument("--out_temp_list", required=True, help="output variable‑column temp list")
    parser.add_argument("--num_mic", type=int, required=True)
    parser.add_argument("--mic_spacing", type=float, default=0.08, help="麦克风间距 m")
    parser.add_argument("--sr", type=int, default=16000)
    parser.add_argument("--seed", type=int, default=666)
    args = parser.parse_args()

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    os.makedirs(args.out_wav_dir, exist_ok=True)

    pos_pool, neg_pool = load_scp(args.wav_scp, args.text_scp)
    print(f"positive pool {len(pos_pool)}, negative/interf pool {len(neg_pool)}")
    assert len(pos_pool) > 0 and len(neg_pool) > 0, "数据集正负样本不能为空"

    max_src = args.num_mic
    gap_min = 20
    fout = open(args.out_temp_list, "w", encoding="utf-8")

    # 处理正样本 label=1：1唤醒词 + 0 ~ max_src‑1个干扰
    for idx, target_wav_path in enumerate(pos_pool):
        num_interf = random.randint(0, max_src - 1)
        total_src_num = 1 + num_interf
        src_angles = sample_angles(total_src_num, 0, 180, gap_min)
        src_multichannel = []

        # 唤醒声源
        rir_tgt = generate_array_rir(src_angles[0], args.num_mic, args.mic_spacing, args.sr)
        s_tgt, sr_tgt = torchaudio.load(target_wav_path)
        if sr_tgt != args.sr:
            resampler = torchaudio.transforms.Resample(sr_tgt, args.sr)
            s_tgt = resampler(s_tgt)
        assert s_tgt.shape[0] == 1
        sig_tgt_mc = convolve_rir(s_tgt, rir_tgt)
        src_multichannel.append(sig_tgt_mc)

        # 干扰声源
        for ia in src_angles[1:]:
            interf_wav = random.choice(neg_pool)
            s_interf, sr_interf = torchaudio.load(interf_wav)
            if sr_interf != args.sr:
                resampler = torchaudio.transforms.Resample(sr_interf, args.sr)
                s_interf = resampler(s_interf)
            s_interf = s_interf[:1, :]
            rir_i = generate_array_rir(ia, args.num_mic, args.mic_spacing, args.sr)
            sig_i_mc = convolve_rir(s_interf, rir_i)
            src_multichannel.append(sig_i_mc)

        mixed_audio = mix_multi_sir0db(src_multichannel)
        basename = os.path.splitext(os.path.basename(target_wav_path))[0]
        out_wav_full = os.path.join(args.out_wav_dir, f"{basename}_mc.wav")
        torchaudio.save(out_wav_full, mixed_audio, args.sr)

        class_ids = [angle_to_class(a) for a in src_angles]
        out_slots = [-100] * 3
        for i, c in enumerate(class_ids):
            if i < 3:
                out_slots[i] = c
        slot_str = " ".join(str(x) for x in out_slots)
        fout.write(f"{out_wav_full} 1 {total_src_num} {slot_str}\n")

        if (idx + 1) % 200 == 0:
            print(f"processed positive {idx+1}")
            break

    # 处理负样本 label=0：全部干扰声源，无唤醒词
    for idx, neg_wav_path in enumerate(neg_pool):
        num_src = random.randint(1, max_src)
        src_angles = sample_angles(num_src, 0, 180, gap_min)
        src_multichannel = []
        for ang in src_angles:
            wav_pick = random.choice(neg_pool)
            s_neg, sr_neg = torchaudio.load(wav_pick)
            if sr_neg != args.sr:
                resampler = torchaudio.transforms.Resample(sr_neg, args.sr)
                s_neg = resampler(s_neg)
            s_neg = s_neg[:1, :]
            rir_neg = generate_array_rir(ang, args.num_mic, args.mic_spacing, args.sr)
            sig_neg_mc = convolve_rir(s_neg, rir_neg)
            src_multichannel.append(sig_neg_mc)

        mixed_audio = mix_multi_sir0db(src_multichannel)
        basename = os.path.splitext(os.path.basename(neg_wav_path))[0]
        out_wav_full = os.path.join(args.out_wav_dir, f"{basename}_mc.wav")
        torchaudio.save(out_wav_full, mixed_audio, args.sr)

        class_ids = [angle_to_class(a) for a in src_angles]
        out_slots = [-100] * 3
        for i, c in enumerate(class_ids):
            if i < 3:
                out_slots[i] = c
        slot_str = " ".join(str(x) for x in out_slots)
        fout.write(f"{out_wav_full} 0 {num_src} {slot_str}\n")

        if (idx + 1) % 500 == 0:
            print(f"processed negative {idx+1}")
            # break

    fout.close()
    print("stage5 gen_multi_channel_wav.py done")


if __name__ == "__main__":
    main()
